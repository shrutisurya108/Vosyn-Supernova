const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, BorderStyle, ShadingType, AlignmentType, PageOrientation
} = require("docx");

const PAGE = { width: 12240, height: 15840 }; // US Letter, DXA

function h(text, level) {
  return new Paragraph({ text, heading: level, spacing: { before: 240, after: 120 } });
}
function p(text, opts = {}) {
  return new Paragraph({ children: [new TextRun({ text, ...opts })], spacing: { after: 160 } });
}
function codeBlock(text) {
  const lines = text.split("\n");
  const children = [];
  lines.forEach((line, i) => {
    children.push(new TextRun({ text: line, font: "Courier New", size: 18, break: i > 0 ? 1 : 0 }));
  });
  return new Paragraph({ children, shading: { type: ShadingType.CLEAR, fill: "F2F2F2" }, spacing: { after: 200 } });
}
function bullet(text) {
  return new Paragraph({ text, bullet: { level: 0 }, spacing: { after: 80 } });
}
function cell(text, opts = {}) {
  return new TableCell({
    width: { size: opts.width || 2000, type: WidthType.DXA },
    shading: opts.header ? { type: ShadingType.CLEAR, fill: "2F5496" } : undefined,
    children: [new Paragraph({
      children: [new TextRun({ text, bold: !!opts.header, color: opts.header ? "FFFFFF" : undefined, size: opts.size || 20 })],
    })],
  });
}
function table(headerCells, rows, widths) {
  const headerRow = new TableRow({ children: headerCells.map((t, i) => cell(t, { header: true, width: widths[i] })) });
  const bodyRows = rows.map(r => new TableRow({ children: r.map((t, i) => cell(t, { width: widths[i] })) }));
  return new Table({
    columnWidths: widths,
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    rows: [headerRow, ...bodyRows],
  });
}
function hr() {
  return new Paragraph({
    border: { bottom: { color: "AAAAAA", space: 1, style: BorderStyle.SINGLE, size: 6 } },
    spacing: { after: 200 },
  });
}

const doc = new Document({
  sections: [{
    properties: { page: { size: PAGE } },
    children: [
      new Paragraph({
        children: [new TextRun({ text: "Sprint 52 Task B", bold: true, size: 44 })],
        spacing: { after: 80 },
      }),
      new Paragraph({
        children: [new TextRun({ text: "Categorizing the Mandarin Candidate's Actual Failure Cases", size: 28, color: "444444" })],
        spacing: { after: 40 },
      }),
      new Paragraph({
        children: [new TextRun({ text: "Detailed documentation — 2026-09-21", size: 20, italics: true, color: "666666" })],
        spacing: { after: 300 },
      }),

      h("1. Dependency on Sprint 51 Task B", HeadingLevel.HEADING_1),
      p("This task is directly dependent on Sprint 51 Task B (“Build an Automated Mandarin Inference, Evaluation and Rollback Pipeline”). It does not reimplement inference or scoring — it reads Sprint 51 Task B’s actual candidate_evaluation_results.json (the per-example candidate outputs and judge scores from a real evaluation run) and its frozen readiness_policy.json (for the quality threshold), both produced by literally running Sprint 51 Task B’s pipeline. No threshold or score in this analysis is re-decided independently of that frozen policy."),
      p("Confirmed before starting work: inspecting Sprint 51 Task B’s evaluate_readiness.py showed that candidate_evaluation_results.json stores every candidate output’s judge_score and text, plus the wrong_language_invalid check’s flagged example ids — exactly the per-example record this task needs, and it only exists because Sprint 51 Task B produced it."),

      h("2. What this task asked for", HeadingLevel.HEADING_1),
      bullet("Categorize ~5 actual wrong-language outputs from the evaluation run by what specifically went wrong (wrong script, English leakage, a different Chinese variety, or something else)."),
      bullet("Categorize the below-threshold quality cases by root cause (meaning error, unnatural phrasing, or something else specific — not just “low score”)."),
      bullet("From these patterns, identify 2–3 concrete, testable hypotheses for what would close the quality gap."),
      bullet("Deliver a short table (failure type, count, representative example) plus the hypotheses — not a general narrative summary."),

      h("3. Producing the source evaluation run", HeadingLevel.HEADING_1),
      p("Sprint 51 Task B’s original demo runs only had 12 eval examples with a single wrong-language case and no per-example quality-threshold breakdown rich enough to categorize by root cause. To do a genuine categorization exercise, a richer 20-example fixture was added to the Sprint 51 Task B repository (not a new evaluation methodology — the same real pipeline code, a larger input):"),
      bullet("data/eval_examples_sprint52.jsonl — 20 source_en / reference_zh pairs"),
      bullet("data/fixtures/candidate_fixture_sprint52.jsonl — 20 candidate outputs, with defects planted across the failure types this task asks about, each carrying a _planted_defect field documenting the intended defect"),
      bullet("data/fixtures/baseline_reconstructed_outputs.jsonl — extended (appended, not replaced) with correct baseline translations for the same 20 examples, so baseline and candidate are compared on identical inputs"),
      p("The evaluation run was then produced with Sprint 51 Task B’s own documented command:"),
      codeBlock("cd mandarin_eval_pipeline\npython run_pipeline.py --config config/default_config.yaml \\\n  --set run.run_name=sprint52_source_run \\\n  --set data.eval_examples_path=data/eval_examples_sprint52.jsonl \\\n  --set candidate.fixture.path=data/fixtures/candidate_fixture_sprint52.jsonl \\\n  --set candidate.fixture.fixture_version=candidate-fixture-sprint52-v1 \\\n  --set checks.safety.fixture_path=data/fixtures/safety_probes_clean.jsonl \\\n  --set checks.domain_regression.fixture_path=data/fixtures/domain_regression_probes_clean.jsonl"),
      p("This produced a real decision (review_revise, on the aggregate quality check) and a real candidate_evaluation_results.json with per-example judge_score and text for all 20 examples — the actual evaluation run this task analyzes."),

      h("4. Pipeline built for this task", HeadingLevel.HEADING_1),
      p("A new, independent module, mandarin_failure_analysis/, was built with three stages:"),
      bullet("select_failure_cases.py — mechanically extracts wrong-language cases (via a script/variety/language detector run over every candidate output, not only the ones Sprint 51’s own narrower check flagged) and below-threshold quality cases (judge_score below the frozen min_quality_score), and attaches cheap mechanical signals (length ratio, negation-marker mismatch, numeric mismatch, character overlap) for a reviewer to use."),
      bullet("data/manual_categorization.jsonl — the actual human-reviewed category and rationale for every selected case. This file is the categorization deliverable itself, recorded as reviewable data rather than an unrecorded judgment call."),
      bullet("build_failure_report.py — joins the mechanical selection with the reviewed categorization, aggregates counts per category, picks the most severe representative example per category, and generates hypotheses from whichever categories actually dominate the real counts."),
      p("Documented command for this task:"),
      codeBlock("cd mandarin_failure_analysis\npip install -r requirements.txt\npython run_analysis.py --config config/analysis_config.yaml\ncat outputs/failure_analysis_report.md"),

      h("5. A key methodology finding: Sprint 51’s own check under-detects wrong language", HeadingLevel.HEADING_1),
      p("Running the built-in wrong_language_invalid check from Sprint 51 Task B against this evaluation run flagged only 1 of the 5 wrong-language cases (the fully-untranslated English one). It is a CJK-character-ratio heuristic, so it cannot catch an output that is still high-CJK-ratio text but in the wrong script (Traditional), the wrong Chinese variety (Cantonese vernacular), or a different CJK-adjacent language (Japanese, which uses kanji). This is exactly why this task’s dedicated script/variety/language detector — and a human review pass — was necessary: 4 of the 5 real wrong-language failures in this run would have passed Sprint 51’s own automated gate silently."),

      h("6. Wrong-language cases (5)", HeadingLevel.HEADING_1),
      table(
        ["Failure type", "Count", "Representative example"],
        [
          ["Wrong script (Traditional instead of Simplified)", "1", "eval_101: “The museum’s new exhibit opens next month.” → “博物館的新展覽下個月開幕。” (ref: 博物馆的新展览下个月开幕。)"],
          ["English leakage — fully untranslated", "1", "eval_102: “Please remember to water the plants while I'm away.” → “Please remember to water the plants while I'm away.” (untranslated)"],
          ["English leakage — partial / code-switched", "1", "eval_103: “The quarterly report shows steady growth in customer satisfaction.” → “季度report显示customer satisfaction稳步增长。”"],
          ["Different Chinese variety (Cantonese vernacular)", "1", "eval_104: “I don't have time to finish this today.” → “我今日冇時間搞掂呢件事。” (Cantonese: 冇/搞掂/呢)"],
          ["Different language entirely (Japanese)", "1", "eval_105: “The train departs from platform six at nine thirty.” → “電車は九時半に六番ホームから出発します。”"],
        ],
        [3200, 800, 5400]
      ),

      h("7. Below-threshold quality cases (7)", HeadingLevel.HEADING_1),
      p("Threshold: judge_score < 60 (min_quality_score, frozen in Sprint 51 Task B’s readiness_policy.json). These 7 exclude the 5 wrong-language cases above, which are categorized separately."),
      table(
        ["Failure type", "Count", "Representative example"],
        [
          ["Unnatural phrasing (literal idiom calque)", "3", "eval_204: “It goes without saying that safety comes first.” → “它没有说地去安全来第一。” (score 20.8)"],
          ["Judge scoring artifact (not a real defect)", "2", "eval_306: “Our flight was delayed due to bad weather.” → “由于天气恶劣，我们的航班延误了。” (correct, reordered; score 51.0)"],
          ["Meaning error — severe omission", "1", "eval_203: drops “after reviewing carefully” and “for next year”, truncating most of the source (score 27.1)"],
          ["Other — register / idiom loss", "1", "eval_207: “you're a lifesaver!” → flattened to a terse, formal “thank you for your assistance” (score 8.0)"],
        ],
        [3200, 800, 5400]
      ),

      h("8. Hypotheses", HeadingLevel.HEADING_1),
      p("1. Add targeted idiom / fixed-expression parallel data", { bold: true }),
      p("3 of 7 (43%) below-threshold quality cases are literal, word-for-word calques of English idioms (“goes without saying”, “knack for”, “touch base”) that produce ungrammatical or nonsensical Mandarin even though the individual words are individually plausible. Hypothesis: the training data underrepresents idiomatic/fixed-expression source sentences paired with their natural (non-literal) Mandarin equivalents. Testable by adding 150–250 idiom/fixed-expression parallel pairs, then re-running this same categorization on a held-out idiom probe set and checking whether the unnatural_phrasing count drops toward zero."),
      p("2. Add an explicit output-script/variety constraint to training data", { bold: true }),
      p("2 of 5 (40%) wrong-language cases are fluent, grammatical Chinese in the wrong script or variety (Traditional, Cantonese) — not catchable by a plain language-identification filter, since the output is still valid Chinese. Hypothesis: the training/instruction data lacks a consistently-enforced output-format anchor (Simplified, Standard Mandarin only). Testable by adding contrastive training examples explicitly labeled with the required script/variety, then scoring a dedicated script/variety probe set independent of the semantic judge, before and after."),
      p("3. Add contrastive examples that penalize partial English retention in business/report text", { bold: true }),
      p("2 of 5 (40%) wrong-language cases leave English business-domain terms (“report”, “customer satisfaction”) untranslated inside an otherwise-Chinese sentence. Hypothesis: the training mix underrepresents business-domain source/target pairs where jargon must be fully translated rather than copied. Testable by adding business-domain parallel examples with no English retained, then re-scoring the business-domain eval slice for residual Latin-script tokens."),

      h("9. Important caveats", HeadingLevel.HEADING_1),
      bullet("Sprint 51’s own automated wrong_language_invalid check caught only 1 of these 5 wrong-language cases (eval_102). It missed eval_101, eval_103, eval_104, eval_105 because they are still high-CJK-ratio text — caught only by this analysis’s dedicated detector."),
      bullet("2 of the 7 below-threshold cases (eval_305, eval_306) were manually confirmed to be correct, natural translations. Their low scores are an artifact of the mock/offline judge’s character n-gram overlap metric dropping for a correctly-reworded sentence, not a real candidate defect."),
      bullet("Two planted meaning-flipping defects (a dropped negation, a substituted number) scored above the quality threshold (81–85) in the source evaluation run — a character-overlap judge cannot detect a single-token meaning flip when the surrounding text still matches. Below-threshold counts here are a floor, not a ceiling, on real quality issues of this kind."),

      h("10. Guardrail: every case must be reviewed", HeadingLevel.HEADING_1),
      p("build_failure_report.py raises a RuntimeError and refuses to write a report if any mechanically-selected case has no matching row in data/manual_categorization.jsonl. This was verified directly during development: removing one row and re-running produced “RuntimeError: 1 selected case(s) have no reviewed category ... ['eval_306']”. This guarantees the report can never silently classify a case nobody actually looked at."),

      h("11. Known limitations", HeadingLevel.HEADING_1),
      bullet("The Traditional-character and Cantonese-marker lists used for detection are curated, documented sets, not an exhaustive linguistic database — sufficient for the patterns observed here, extendable if new patterns appear."),
      bullet("Root-cause categorization is a human judgment call recorded in data/manual_categorization.jsonl, informed by (not fully automated from) mechanical signals. Re-running this analysis on a different evaluation run requires adding categorization rows for its new cases before a report can be built — by design, not an oversight."),

      h("12. Submission checklist", HeadingLevel.HEADING_1),
      bullet("Dependency on Sprint 51 Task B confirmed and used directly (frozen readiness_policy.json threshold; real candidate_evaluation_results.json)."),
      bullet("~5 actual wrong-language cases categorized by specific cause (wrong script, English leakage full/partial, Cantonese variety, different language)."),
      bullet("Below-threshold quality cases categorized by specific root cause (meaning error / unnatural phrasing / other), not just “low score”."),
      bullet("3 concrete, testable, data-driven hypotheses for closing the quality gap."),
      bullet("Short tables delivered (failure type, count, representative example) — not a general narrative."),
      bullet("Tested code, configuration, outputs, and this documentation included."),
      bullet("Exact GitHub link — add the repository URL here once pushed: <GITHUB_REPO_URL>"),
    ],
  }],
});

Packer.toBuffer(doc).then(buf => {
  require("fs").writeFileSync("Sprint52_TaskB_Failure_Categorization.docx", buf);
  console.log("wrote docx");
});
