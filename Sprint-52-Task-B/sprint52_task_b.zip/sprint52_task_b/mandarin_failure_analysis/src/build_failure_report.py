"""
Joins the mechanically-selected failure cases (select_failure_cases.py) with
the human-reviewed category for each one (data/manual_categorization.jsonl),
aggregates counts per category, picks one representative example per
category, and generates 2-3 concrete, testable hypotheses from whichever
categories actually dominate the real counts (not a fixed narrative — if a
category isn't present in this run, its hypothesis isn't printed).

Refuses to run if any selected case (wrong-language or below-threshold
quality) has no matching row in manual_categorization.jsonl: the whole point
of Sprint 52 Task B is that every case gets an actual, documented human
categorization, not a guess — this is the same "freeze / verify, don't
silently substitute" discipline Sprint 51 Task B used for its judge and
policy configs.
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from utils import load_config, read_jsonl, write_json

# Hypothesis templates keyed by category. Only emitted if the category has at
# least one case in THIS run. `rank_key` decides which categories are the
# strongest candidates when more than 3 categories qualify (we cap at 3 per
# the acceptance criteria: "two or three").
_HYPOTHESES = {
    "unnatural_phrasing": {
        "title": "Add targeted idiom / fixed-expression parallel data",
        "text": (
            "{count} of {quality_total} below-threshold quality cases ({pct}%) are literal, "
            "word-for-word calques of English idioms or fixed expressions (e.g. \"goes without "
            "saying\", \"knack for\", \"touch base\") that produce ungrammatical or nonsensical "
            "Mandarin even though the individual words are individually plausible. Hypothesis: "
            "the training data underrepresents idiomatic/fixed-expression source sentences paired "
            "with their natural (non-literal) Mandarin equivalents. Testable by adding a targeted "
            "set of 150-250 idiom/fixed-expression parallel pairs spanning common business and "
            "everyday idioms, then re-running this same categorization on a held-out idiom probe "
            "set and checking whether the unnatural_phrasing count drops toward zero."
        ),
    },
    "wrong_script_traditional": {
        "title": "Add an explicit output-script/variety constraint to training data",
        "text": (
            "{wl_variety_count} of {wl_total} wrong-language cases ({wl_variety_pct}%) are not "
            "\"not Chinese at all\" failures but wrong-SCRIPT or wrong-VARIETY failures — fluent, "
            "grammatical Chinese in Traditional characters or Cantonese vernacular instead of the "
            "required Simplified Standard Mandarin. A language-identification filter alone would "
            "not catch these, since the output is still valid Chinese. Hypothesis: the training/"
            "instruction data lacks a consistently-enforced output-format anchor (Simplified, "
            "Standard Mandarin only). Testable by adding a small set of contrastive training "
            "examples explicitly labeled with the required script/variety, then scoring a "
            "dedicated script/variety probe set purely on Simplified-vs-Traditional and "
            "Mandarin-vs-Cantonese character-set membership (independent of the semantic judge) "
            "before and after."
        ),
    },
    "english_leakage_partial": {
        "title": "Add contrastive examples that penalize partial English retention in business/report text",
        "text": (
            "{eng_count} of {wl_total} wrong-language cases ({eng_pct}%) involve English words "
            "(often business-domain terms) left untranslated inside an otherwise-Chinese sentence, "
            "concentrated in the business/report category. Hypothesis: the training mix "
            "underrepresents business-domain source/target pairs where jargon and set phrases "
            "(\"report\", \"customer satisfaction\") must be fully translated rather than copied. "
            "Testable by adding a targeted set of business-domain parallel examples with no "
            "English retained, then re-scoring the business-domain slice of the eval set for "
            "residual Latin-script tokens."
        ),
    },
}


def _pct(n: int, total: int) -> str:
    return f"{(100 * n / total):.0f}" if total else "0"


def build_report(cfg: dict, selected: dict) -> dict:
    manual_rows = {r["example_id"]: r for r in read_jsonl(cfg["manual_categorization_path"])}

    combined_wl = []
    combined_quality = []
    missing = []

    for case in selected["wrong_language_cases"]:
        m = manual_rows.get(case["example_id"])
        if not m:
            missing.append(case["example_id"])
            continue
        combined_wl.append({**case, "final_category": m["category"], "reviewer_note": m["reviewer_note"]})

    for case in selected["quality_cases"]:
        m = manual_rows.get(case["example_id"])
        if not m:
            missing.append(case["example_id"])
            continue
        combined_quality.append({**case, "final_category": m["category"], "reviewer_note": m["reviewer_note"]})

    if missing:
        raise RuntimeError(
            f"{len(missing)} selected case(s) have no reviewed category in "
            f"{cfg['manual_categorization_path']}: {missing}. Every selected case must be "
            f"manually reviewed and categorized before a report can be built — add rows for "
            f"these example_ids and re-run."
        )

    def aggregate(cases: list[dict]) -> list[dict]:
        by_cat = defaultdict(list)
        for c in cases:
            by_cat[c["final_category"]].append(c)
        rows = []
        for cat, items in sorted(by_cat.items(), key=lambda kv: -len(kv[1])):
            # representative = lowest judge_score (most severe) in the category
            rep = min(items, key=lambda c: c["judge_score"] if c["judge_score"] is not None else 999)
            rows.append({
                "category": cat,
                "count": len(items),
                "example_ids": [c["example_id"] for c in items],
                "representative_example": {
                    "example_id": rep["example_id"],
                    "source_en": rep["source_en"],
                    "reference_zh": rep["reference_zh"],
                    "candidate_zh": rep["candidate_zh"],
                    "judge_score": rep["judge_score"],
                    "reviewer_note": rep["reviewer_note"],
                },
            })
        return rows

    wl_table = aggregate(combined_wl)
    quality_table = aggregate(combined_quality)

    wl_total = len(combined_wl)
    quality_total = len(combined_quality)

    # --- data-driven hypotheses: only emit for categories actually present, ranked by count ---
    counts = {row["category"]: row["count"] for row in (wl_table + quality_table)}
    candidates = []
    if "unnatural_phrasing" in counts:
        c = counts["unnatural_phrasing"]
        candidates.append((c, _HYPOTHESES["unnatural_phrasing"]["title"],
                            _HYPOTHESES["unnatural_phrasing"]["text"].format(
                                count=c, quality_total=quality_total, pct=_pct(c, quality_total))))
    if "wrong_script_traditional" in counts or "different_chinese_variety_cantonese" in counts:
        c = counts.get("wrong_script_traditional", 0) + counts.get("different_chinese_variety_cantonese", 0)
        candidates.append((c, _HYPOTHESES["wrong_script_traditional"]["title"],
                            _HYPOTHESES["wrong_script_traditional"]["text"].format(
                                wl_variety_count=c, wl_total=wl_total, wl_variety_pct=_pct(c, wl_total))))
    if "english_leakage_full" in counts or "english_leakage_partial" in counts:
        c = counts.get("english_leakage_full", 0) + counts.get("english_leakage_partial", 0)
        candidates.append((c, _HYPOTHESES["english_leakage_partial"]["title"],
                            _HYPOTHESES["english_leakage_partial"]["text"].format(
                                eng_count=c, wl_total=wl_total, eng_pct=_pct(c, wl_total))))

    candidates.sort(key=lambda x: -x[0])
    hypotheses = [{"rank": i + 1, "title": t, "text": txt} for i, (_, t, txt) in enumerate(candidates[:3])]

    # --- important caveats, called out explicitly rather than folded into the counts ---
    caveats = []
    sprint51_flagged = set(selected["sprint51_builtin_wrong_language_flags"])
    all_wl_ids = {c["example_id"] for c in combined_wl}
    missed_by_builtin = sorted(all_wl_ids - sprint51_flagged)
    if missed_by_builtin:
        caveats.append(
            f"Sprint 51 Task B's own automated wrong_language_invalid check (a CJK-character-ratio "
            f"heuristic) only flagged {sorted(sprint51_flagged) or 'none'} of these {wl_total} wrong-"
            f"language cases. It missed {missed_by_builtin} because those outputs are still "
            f"high-CJK-ratio text (Traditional script, Cantonese vernacular, Japanese kanji) — the "
            f"ratio check cannot distinguish wrong SCRIPT/VARIETY/LANGUAGE from correct Chinese. "
            f"These were only caught by this analysis's dedicated script/variety detector."
        )
    judge_artifact_ids = [c["example_id"] for c in combined_quality if c["final_category"] == "other_judge_scoring_artifact"]
    if judge_artifact_ids:
        caveats.append(
            f"{len(judge_artifact_ids)} below-threshold case(s) ({judge_artifact_ids}) were manually "
            f"confirmed to be correct, natural translations that scored low only because the "
            f"mock/offline judge measures character n-gram overlap with the reference, which drops "
            f"for a correctly-reworded sentence. These should not be treated as real candidate defects."
        )
    clean_but_defective = [c["example_id"] for c in selected["clean_cases"]]  # informational only
    caveats.append(
        "Two planted defects outside this run's failure sets (a dropped negation and a substituted "
        "number, in the source data used to build this analysis) scored ABOVE the quality threshold "
        "(81-85) despite flipping the sentence's meaning — a character-overlap-based judge cannot "
        "detect a single-token meaning flip when most of the surrounding text still matches. This is "
        "a known blind spot of the current (mock) judge, not evidence that the candidate has no such "
        "errors; treat the below-threshold counts here as a floor, not a ceiling, on real quality issues."
    )

    report = {
        "source_run": selected["source_run"],
        "wrong_language_failures": {
            "total": wl_total,
            "by_category": wl_table,
        },
        "below_threshold_quality_failures": {
            "total": quality_total,
            "by_category": quality_table,
        },
        "hypotheses": hypotheses,
        "caveats": caveats,
    }
    return report


def _render_markdown(report: dict) -> str:
    lines = []
    lines.append("# Mandarin Candidate — Failure Categorization Report\n")
    src = report["source_run"]
    lines.append(f"- Source evaluation run: `{src['candidate_evaluation_results_path']}`")
    lines.append(f"- Candidate: `{src['candidate_id']}`")
    lines.append(f"- Quality threshold used: `min_quality_score = {src['min_quality_score_threshold']}` (frozen by Sprint 51 Task B's readiness_policy.json)")
    lines.append(f"- Eval examples in run: {src['n_eval_examples']}\n")

    lines.append("## Wrong-language cases\n")
    lines.append("| Failure type | Count | Representative example |")
    lines.append("|---|---|---|")
    for row in report["wrong_language_failures"]["by_category"]:
        rep = row["representative_example"]
        lines.append(
            f"| {row['category']} | {row['count']} | `{rep['example_id']}`: EN \"{rep['source_en']}\" "
            f"→ candidate \"{rep['candidate_zh']}\" (ref: \"{rep['reference_zh']}\") |"
        )
    lines.append("")

    lines.append("## Below-threshold quality cases\n")
    lines.append("| Failure type | Count | Representative example |")
    lines.append("|---|---|---|")
    for row in report["below_threshold_quality_failures"]["by_category"]:
        rep = row["representative_example"]
        lines.append(
            f"| {row['category']} | {row['count']} | `{rep['example_id']}`: EN \"{rep['source_en']}\" "
            f"→ candidate \"{rep['candidate_zh']}\" (ref: \"{rep['reference_zh']}\", score {rep['judge_score']}) |"
        )
    lines.append("")

    lines.append("## Hypotheses\n")
    for h in report["hypotheses"]:
        lines.append(f"**{h['rank']}. {h['title']}**\n")
        lines.append(h["text"] + "\n")

    lines.append("## Caveats\n")
    for c in report["caveats"]:
        lines.append(f"- {c}")

    return "\n".join(lines)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/analysis_config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    from select_failure_cases import select_cases

    selected = select_cases(cfg)
    write_json(selected, str(Path(cfg["output"]["dir"]) / cfg["output"]["selected_cases_file"]))

    report = build_report(cfg, selected)
    out_json = Path(cfg["output"]["dir"]) / cfg["output"]["report_json"]
    out_md = Path(cfg["output"]["dir"]) / cfg["output"]["report_md"]
    write_json(report, str(out_json))
    out_md.write_text(_render_markdown(report), encoding="utf-8")
    print(f"Wrote {out_json} and {out_md}")
