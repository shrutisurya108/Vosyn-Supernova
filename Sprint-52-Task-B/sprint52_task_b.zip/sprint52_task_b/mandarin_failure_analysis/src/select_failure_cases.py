"""
Mechanically selects the two case sets Sprint 52 Task B has to categorize,
straight from Sprint 51 Task B's actual evaluation-run output:

  1. Wrong-language cases: every candidate output whose text trips a
     script/variety/language detector (wrong script, English leakage, a
     different Chinese variety, or a different language entirely). This is
     run over ALL candidate outputs in the run, not just the ones Sprint 51's
     own wrong_language_invalid check flagged — that check only catches a
     low-CJK-character-ratio output (i.e. mostly non-CJK), so it misses a
     fluent-looking output that is simply in the wrong script or variety.
     That gap is intentional to surface (see README) and is exactly why a
     manual/deeper pass like this Sprint 52 task is worth doing.

  2. Below-threshold quality cases: every candidate output (that isn't
     already a wrong-language case) whose judge_score is below the
     min_quality_score FROZEN in Sprint 51 Task B's readiness_policy.json.

This module only selects cases and attaches cheap, mechanical signals
(length ratio, negation-marker mismatch, numeric mismatch) that a human
reviewer can use — it does not itself decide the final root-cause category.
That decision is recorded separately in data/manual_categorization.jsonl,
and build_failure_report.py refuses to run if any selected case is missing
its human-reviewed category (see that file's docstring).
"""
from __future__ import annotations

import re
from pathlib import Path

from utils import read_json, write_json

_NEGATION_MARKERS = ["不", "没有", "没", "未", "别", "无", "莫", "非"]


def _cjk_count(text: str) -> int:
    return sum(1 for ch in text if "一" <= ch <= "鿿")


def _latin_letter_count(text: str) -> int:
    return sum(1 for ch in text if ch.isascii() and ch.isalpha())


def detect_wrong_language(text: str, wl_cfg: dict) -> tuple[str | None, str | None]:
    """Returns (category, evidence) or (None, None) if nothing trips.

    Full vs. partial English leakage is decided by whether ANY Chinese
    (CJK-range) characters are present at all, not by a letter-count ratio —
    a ratio biased by letter count would misclassify a short code-switched
    sentence like "季度report显示customer satisfaction稳步增长" as "full"
    leakage just because the English words happen to have more letters than
    the handful of Chinese characters around them, even though it plainly
    contains real Chinese text and is a partial/code-switch case, not a
    fully-untranslated one.
    """
    # 1. Japanese kana (Hiragana/Katakana) — an unambiguous different-language signal.
    if any("぀" <= ch <= "ヿ" for ch in text):
        return "different_language_japanese", "Contains Hiragana/Katakana characters, not Chinese script at all."

    cjk_count = _cjk_count(text)
    latin_count = _latin_letter_count(text)
    total_letters = cjk_count + latin_count

    if latin_count > 0 and cjk_count == 0:
        return "english_leakage_full", "Contains no Chinese (CJK) characters at all — effectively untranslated."
    if total_letters > 0:
        ratio = latin_count / total_letters
        if ratio >= wl_cfg["latin_partial_threshold"] and cjk_count > 0:
            return "english_leakage_partial", f"Mixes {latin_count} Latin letters with {cjk_count} Chinese characters — code-switched, not fully translated."

    # 3. Cantonese written-vernacular markers — checked before the generic
    #    Traditional-script check because Cantonese vernacular text is often
    #    also written with Traditional characters; the more specific signal wins.
    hits = [m for m in wl_cfg["cantonese_markers"] if m in text]
    if hits:
        return "different_chinese_variety_cantonese", f"Contains Cantonese written-vernacular marker(s): {hits}."

    # 4. Traditional-only characters with no Simplified counterpart present.
    trad_hits = [t for t in wl_cfg["traditional_only_chars"] if t in text]
    if trad_hits:
        return "wrong_script_traditional", f"Contains Traditional-only character(s) not used in Simplified: {trad_hits}."

    return None, None


def _char_set(text: str) -> set[str]:
    return {ch for ch in text if "一" <= ch <= "鿿"}


def _digits(text: str) -> set[str]:
    return set(re.findall(r"\d+", text))


def _mechanical_signals(candidate_zh: str, reference_zh: str, omission_ratio_threshold: float) -> dict:
    cand_len = len(candidate_zh.strip())
    ref_len = max(1, len(reference_zh.strip()))
    length_ratio = round(cand_len / ref_len, 3)

    cand_neg = [m for m in _NEGATION_MARKERS if m in candidate_zh]
    ref_neg = [m for m in _NEGATION_MARKERS if m in reference_zh]
    negation_mismatch = bool(set(cand_neg) ^ set(ref_neg))

    cand_digits = _digits(candidate_zh)
    ref_digits = _digits(reference_zh)
    numeric_mismatch = bool(ref_digits) and cand_digits != ref_digits

    char_overlap = _char_set(candidate_zh) & _char_set(reference_zh)
    char_union = _char_set(candidate_zh) | _char_set(reference_zh)
    char_jaccard = round(len(char_overlap) / len(char_union), 3) if char_union else 0.0

    return {
        "length_ratio_vs_reference": length_ratio,
        "possible_omission": length_ratio < omission_ratio_threshold,
        "negation_marker_mismatch": negation_mismatch,
        "candidate_negation_markers": cand_neg,
        "reference_negation_markers": ref_neg,
        "numeric_mismatch": numeric_mismatch,
        "candidate_numbers": sorted(cand_digits),
        "reference_numbers": sorted(ref_digits),
        "char_jaccard_vs_reference": char_jaccard,
    }


def select_cases(cfg: dict, base_dir: str = ".") -> dict:
    pipeline_dir = Path(base_dir) / cfg["source_run"]["eval_pipeline_dir"]
    results_path = pipeline_dir / cfg["source_run"]["candidate_evaluation_results"]
    policy_path = pipeline_dir / cfg["source_run"]["readiness_policy"]

    results = read_json(str(results_path))
    policy = read_json(str(policy_path))
    min_quality_score = policy["thresholds"]["min_quality_score"]

    reference_by_id = {}
    for c in results["checks"]:
        pass  # reference text isn't in checks; pull from candidate/baseline outputs' paired eval examples instead

    # candidate_evaluation_results.json doesn't carry reference_zh directly on
    # each row (it's scored via the judge, not stored per-row) — but the eval
    # examples file used for the run does. Re-derive its path from the run's
    # resolved config so this stays correct even if the eval set changes.
    resolved_cfg_path = results_path.parent / "resolved_config.yaml"
    import yaml as _yaml
    with open(resolved_cfg_path, encoding="utf-8") as f:
        resolved_cfg = _yaml.safe_load(f)
    eval_examples_path = pipeline_dir / resolved_cfg["data"]["eval_examples_path"]
    from utils import read_jsonl
    eval_examples = read_jsonl(str(eval_examples_path))
    reference_by_id = {e["example_id"]: e["reference_zh"] for e in eval_examples}
    source_by_id = {e["example_id"]: e["source_en"] for e in eval_examples}

    wl_cfg = cfg["wrong_language_detection"]
    omission_ratio_threshold = cfg["quality"]["omission_length_ratio"]

    # Sprint 51's own aggregate check, for the explicit comparison this
    # analysis calls out (see README): which example ids did IT flag?
    sprint51_flagged_ids = set()
    for c in results["checks"]:
        if c["check_name"] == "wrong_language_invalid[candidate]":
            sprint51_flagged_ids = set(c["metrics"]["wrong_language_example_ids"])

    wrong_language_cases = []
    quality_cases = []
    clean_cases = []

    for row in results["candidate_outputs"]:
        eid = row["example_id"]
        candidate_zh = row.get("candidate_zh", "")
        reference_zh = reference_by_id.get(eid, "")
        source_en = source_by_id.get(eid, "")
        score = row.get("judge_score")

        wl_category, wl_evidence = detect_wrong_language(candidate_zh, wl_cfg)
        if wl_category:
            wrong_language_cases.append({
                "example_id": eid,
                "source_en": source_en,
                "reference_zh": reference_zh,
                "candidate_zh": candidate_zh,
                "judge_score": score,
                "auto_detected_category": wl_category,
                "auto_detected_evidence": wl_evidence,
                "flagged_by_sprint51_builtin_check": eid in sprint51_flagged_ids,
            })
            continue  # wrong-language cases are categorized in that bucket, not double-counted as a quality failure

        if score is not None and score < min_quality_score:
            quality_cases.append({
                "example_id": eid,
                "source_en": source_en,
                "reference_zh": reference_zh,
                "candidate_zh": candidate_zh,
                "judge_score": score,
                "min_quality_score_threshold": min_quality_score,
                "mechanical_signals": _mechanical_signals(candidate_zh, reference_zh, omission_ratio_threshold),
            })
        else:
            clean_cases.append({"example_id": eid, "judge_score": score})

    selected = {
        "source_run": {
            "candidate_evaluation_results_path": str(results_path),
            "readiness_policy_path": str(policy_path),
            "min_quality_score_threshold": min_quality_score,
            "candidate_id": results["candidate"]["candidate_id"],
            "n_eval_examples": results["n_eval_examples"],
        },
        "sprint51_builtin_wrong_language_flags": sorted(sprint51_flagged_ids),
        "wrong_language_cases": wrong_language_cases,
        "quality_cases": quality_cases,
        "clean_cases": clean_cases,
        "n_wrong_language": len(wrong_language_cases),
        "n_below_threshold_quality": len(quality_cases),
        "n_clean": len(clean_cases),
    }
    return selected


if __name__ == "__main__":
    import argparse

    from utils import load_config

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/analysis_config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    selected = select_cases(cfg)
    out_path = Path(cfg["output"]["dir"]) / cfg["output"]["selected_cases_file"]
    write_json(selected, str(out_path))
    print(f"Selected {selected['n_wrong_language']} wrong-language cases, "
          f"{selected['n_below_threshold_quality']} below-threshold quality cases, "
          f"{selected['n_clean']} clean cases. Wrote {out_path}")
