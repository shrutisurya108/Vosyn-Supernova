"""
Small shared utilities for the Sprint 52 Task B failure-analysis pipeline.

Deliberately independent of Sprint 51 Task B's own utils.py (same philosophy
as Sprint 51 being independent of Task A's utils.py): this pipeline only ever
*reads* Sprint 51 Task B's output files as data, it does not import its code.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml


def load_config(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def read_json(path: str) -> Any:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def write_json(obj: Any, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def read_jsonl(path: str) -> list[dict]:
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows
