"""
Documented command for Sprint 52 Task B.

Usage:
    python run_analysis.py --config config/analysis_config.yaml

Runs the two steps in order:
  1. select_failure_cases.select_cases  — mechanically pulls the wrong-
     language cases and below-threshold quality cases straight out of
     Sprint 51 Task B's actual evaluation run.
  2. build_failure_report.build_report  — joins those with the reviewed
     categorization in data/manual_categorization.jsonl, aggregates counts,
     picks a representative example per category, and generates hypotheses.

Writes:
  outputs/selected_failure_cases.json   — the mechanical selection
  outputs/failure_analysis_report.json  — the full categorized report
  outputs/failure_analysis_report.md    — the human-readable table + hypotheses
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from build_failure_report import _render_markdown, build_report  # noqa: E402
from select_failure_cases import select_cases  # noqa: E402
from utils import load_config, write_json  # noqa: E402


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config/analysis_config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)

    selected = select_cases(cfg)
    out_dir = Path(cfg["output"]["dir"])
    write_json(selected, str(out_dir / cfg["output"]["selected_cases_file"]))
    print(
        f"Selected {selected['n_wrong_language']} wrong-language cases, "
        f"{selected['n_below_threshold_quality']} below-threshold quality cases, "
        f"{selected['n_clean']} clean cases from {selected['source_run']['candidate_evaluation_results_path']}"
    )

    report = build_report(cfg, selected)
    out_json = out_dir / cfg["output"]["report_json"]
    out_md = out_dir / cfg["output"]["report_md"]
    write_json(report, str(out_json))
    out_md.write_text(_render_markdown(report), encoding="utf-8")

    print(f"Wrote {out_json}")
    print(f"Wrote {out_md}")
    print(f"\nWrong-language categories: {[(r['category'], r['count']) for r in report['wrong_language_failures']['by_category']]}")
    print(f"Quality categories: {[(r['category'], r['count']) for r in report['below_threshold_quality_failures']['by_category']]}")
    print(f"\n{len(report['hypotheses'])} hypotheses generated.")


if __name__ == "__main__":
    main()
