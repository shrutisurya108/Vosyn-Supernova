# Mandarin Candidate — Failure Categorization Report

- Source evaluation run: `../mandarin_eval_pipeline/outputs/sprint52_source_run/candidate_evaluation_results.json`
- Candidate: `fixture::candidate-fixture-sprint52-v1`
- Quality threshold used: `min_quality_score = 60` (frozen by Sprint 51 Task B's readiness_policy.json)
- Eval examples in run: 20

## Wrong-language cases

| Failure type | Count | Representative example |
|---|---|---|
| wrong_script_traditional | 1 | `eval_101`: EN "The museum's new exhibit opens next month." → candidate "博物館的新展覽下個月開幕。" (ref: "博物馆的新展览下个月开幕。") |
| english_leakage_full | 1 | `eval_102`: EN "Please remember to water the plants while I'm away." → candidate "Please remember to water the plants while I'm away." (ref: "我不在的时候，请记得给植物浇水。") |
| english_leakage_partial | 1 | `eval_103`: EN "The quarterly report shows steady growth in customer satisfaction." → candidate "季度report显示customer satisfaction稳步增长。" (ref: "季度报告显示客户满意度稳步增长。") |
| different_chinese_variety_cantonese | 1 | `eval_104`: EN "I don't have time to finish this today." → candidate "我今日冇時間搞掂呢件事。" (ref: "我今天没有时间完成这件事。") |
| different_language_japanese | 1 | `eval_105`: EN "The train departs from platform six at nine thirty." → candidate "電車は九時半に六番ホームから出発します。" (ref: "火车九点半从六号站台出发。") |

## Below-threshold quality cases

| Failure type | Count | Representative example |
|---|---|---|
| unnatural_phrasing | 3 | `eval_204`: EN "It goes without saying that safety comes first." → candidate "它没有说地去安全来第一。" (ref: "安全第一是不言而喻的。", score 20.84) |
| other_judge_scoring_artifact | 2 | `eval_306`: EN "Our flight was delayed due to bad weather." → candidate "由于天气恶劣，我们的航班延误了。" (ref: "我们的航班因恶劣天气而延误。", score 51.03) |
| meaning_error_omission | 1 | `eval_203`: EN "After reviewing the proposal carefully, the committee decided to approve the budget increase for next year." → candidate "委员会批准了预算。" (ref: "在仔细审查提案后，委员会决定批准明年的预算增加。", score 27.06) |
| other_register_or_idiom_loss | 1 | `eval_207`: EN "Thanks so much for your help — you're a lifesaver!" → candidate "谢谢您的协助。" (ref: "非常感谢你的帮助——你真是我的救星！", score 8.0) |

## Hypotheses

**1. Add targeted idiom / fixed-expression parallel data**

3 of 7 below-threshold quality cases (43%) are literal, word-for-word calques of English idioms or fixed expressions (e.g. "goes without saying", "knack for", "touch base") that produce ungrammatical or nonsensical Mandarin even though the individual words are individually plausible. Hypothesis: the training data underrepresents idiomatic/fixed-expression source sentences paired with their natural (non-literal) Mandarin equivalents. Testable by adding a targeted set of 150-250 idiom/fixed-expression parallel pairs spanning common business and everyday idioms, then re-running this same categorization on a held-out idiom probe set and checking whether the unnatural_phrasing count drops toward zero.

**2. Add an explicit output-script/variety constraint to training data**

2 of 5 wrong-language cases (40%) are not "not Chinese at all" failures but wrong-SCRIPT or wrong-VARIETY failures — fluent, grammatical Chinese in Traditional characters or Cantonese vernacular instead of the required Simplified Standard Mandarin. A language-identification filter alone would not catch these, since the output is still valid Chinese. Hypothesis: the training/instruction data lacks a consistently-enforced output-format anchor (Simplified, Standard Mandarin only). Testable by adding a small set of contrastive training examples explicitly labeled with the required script/variety, then scoring a dedicated script/variety probe set purely on Simplified-vs-Traditional and Mandarin-vs-Cantonese character-set membership (independent of the semantic judge) before and after.

**3. Add contrastive examples that penalize partial English retention in business/report text**

2 of 5 wrong-language cases (40%) involve English words (often business-domain terms) left untranslated inside an otherwise-Chinese sentence, concentrated in the business/report category. Hypothesis: the training mix underrepresents business-domain source/target pairs where jargon and set phrases ("report", "customer satisfaction") must be fully translated rather than copied. Testable by adding a targeted set of business-domain parallel examples with no English retained, then re-scoring the business-domain slice of the eval set for residual Latin-script tokens.

## Caveats

- Sprint 51 Task B's own automated wrong_language_invalid check (a CJK-character-ratio heuristic) only flagged ['eval_102'] of these 5 wrong-language cases. It missed ['eval_101', 'eval_103', 'eval_104', 'eval_105'] because those outputs are still high-CJK-ratio text (Traditional script, Cantonese vernacular, Japanese kanji) — the ratio check cannot distinguish wrong SCRIPT/VARIETY/LANGUAGE from correct Chinese. These were only caught by this analysis's dedicated script/variety detector.
- 2 below-threshold case(s) (['eval_305', 'eval_306']) were manually confirmed to be correct, natural translations that scored low only because the mock/offline judge measures character n-gram overlap with the reference, which drops for a correctly-reworded sentence. These should not be treated as real candidate defects.
- Two planted defects outside this run's failure sets (a dropped negation and a substituted number, in the source data used to build this analysis) scored ABOVE the quality threshold (81-85) despite flipping the sentence's meaning — a character-overlap-based judge cannot detect a single-token meaning flip when most of the surrounding text still matches. This is a known blind spot of the current (mock) judge, not evidence that the candidate has no such errors; treat the below-threshold counts here as a floor, not a ceiling, on real quality issues.