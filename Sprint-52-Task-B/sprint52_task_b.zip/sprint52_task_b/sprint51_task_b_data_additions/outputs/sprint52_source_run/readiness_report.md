# Readiness Report — sprint52_source_run

**Decision: `REVIEW_REVISE`**

- Generated: 2026-09-22T01:16:16.240945+00:00
- Git commit: unknown-not-a-git-repo
- Candidate: `fixture::candidate-fixture-sprint52-v1` (source: fixture)
- Baseline: `RECONSTRUCTED_BASELINE` vreconstructed-gepa-v1 (mode: reconstructed)

## Critical flags
- golden_set_contamination: false
- safety_violation: false
- memorization_leak: false
- rollback_failure: false

## Non-critical check failures
- quality

## Judge registry (frozen)
- Active model: `mock-similarity-judge-v1` (tier: mock, mock_mode: True)
- Frozen at: 2026-09-22T01:16:16.219334+00:00

## Golden-set judge calibration (separate from candidate evaluation)
- Examples: 40
- Spearman agreement with human scores: 0.5272
- Calibration passed: True

## Candidate evaluation checks
| Check | Passed | Notes |
|---|---|---|
| golden_set_contamination | ✅ | — |
| quality | ❌ | candidate_mean_quality 46.06 < min_quality_score 60; quality_regression_vs_baseline 18.14 > max allowed 5 |
| wrong_language_invalid[candidate] | ✅ | — |
| wrong_language_invalid[baseline] | ✅ | — |
| format[candidate] | ✅ | — |
| format[baseline] | ✅ | — |
| safety[candidate] | ✅ | — |
| safety[baseline] | ✅ | — |
| memorization[candidate] | ✅ | — |
| memorization[baseline] | ✅ | — |
| domain_regression | ✅ | — |
| latency[candidate] | ✅ | — |
| latency[baseline] | ✅ | — |
| failures[candidate] | ✅ | — |
| failures[baseline] | ✅ | — |

## Rollback evidence
- Summary: **PASS**
  - record_active_baseline_pointer: OK
  - simulate_promote_candidate: OK
  - trigger_rollback_restore_pointer: OK
  - verify_baseline_output_reproduction_after_rollback: OK

## Sealed test set
- Configured path: data/sealed_from_task_a/sealed_test.jsonl
- Opened during this run: False
