# Sprint 51 Task B — data additions used by Sprint 52 Task B

These files were added to the Sprint 51 Task B pipeline (`mandarin_eval_pipeline/`)
to produce a richer "actual evaluation run" for Sprint 52 Task B's failure
categorization.
Task B checkout:

- `data/eval_examples_sprint52.jsonl` -> `mandarin_eval_pipeline/data/`
- `data/fixtures/candidate_fixture_sprint52.jsonl` -> `mandarin_eval_pipeline/data/fixtures/`
- `data/fixtures/baseline_reconstructed_outputs.jsonl` -> `mandarin_eval_pipeline/data/fixtures/`
  (this REPLACES the existing file — it's an append of 20 new rows onto the
  original 12, so all original example ids are still present)
- `outputs/sprint52_source_run/` -> `mandarin_eval_pipeline/outputs/`
  (the actual evaluation run this analysis was run against)
