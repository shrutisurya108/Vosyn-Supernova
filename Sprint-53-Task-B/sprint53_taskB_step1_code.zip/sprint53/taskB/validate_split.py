"""
Task B · Step B1 — validate the dev / held-out split and record the BASELINE reference numbers
for each half (computed from the Task A runs of the Sprint 50 prompts, no new GPU calls).

Hard checks (exit code 1 if any fails)
  1. Halves are disjoint and together cover every Set A item, Set B row and pair exactly once.
  2. No English source appears in both halves (Set B rows, pairs, and Set A items linked to a
     Set B source).
  3. 20 / 20 sources; each category differs by at most 1 between halves; 20 / 20 Set A items.
  4. Repeat subset: 40 items, all held-out, 20 Set A + 20 Set B, 4 rows of each core variant,
     20 distinct Set B sources.
Soft checks (reported): balance of variant types, Set A human-score distribution.

Baseline reference (Sprint 50 prompts, Task A runs, per half): agreement with humans, paired
contrast, false errors on correct translations, invalid spans, position bias, repeatability.
These are the numbers each Task B strategy has to beat on the same half.

Run:  python taskB/validate_split.py
Out:  data/taskB/split_validation_report.txt, data/taskB/baseline_reference.csv
"""
import glob
import json
import os
import re
import sys
from collections import Counter

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = os.path.join(ROOT, "data", "taskB")
P = os.path.join(ROOT, "data", "processed")


def rj(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


hard, soft, lines = [], [], []
half = {h: {k: rj(os.path.join(D, f"{h}_{k}.jsonl")) for k in ("setA", "setB", "pairs")} for h in ("dev", "heldout")}
A = rj(os.path.join(P, "setA_items.jsonl"))
B = [r for r in rj(os.path.join(P, "setB_items.jsonl")) if r.get("include_in_experiments", True)]
PR = rj(os.path.join(P, "pairs.jsonl"))
meta = json.load(open(os.path.join(D, "split.json"), encoding="utf-8"))
rep = rj(os.path.join(D, "repeat_subset.jsonl"))

# 1 coverage / disjointness
for key, full, idf in (("setA", A, "item_id"), ("setB", B, "item_id"), ("pairs", PR, "pair_id")):
    d = [r[idf] for r in half["dev"][key]]
    h = [r[idf] for r in half["heldout"][key]]
    if set(d) & set(h):
        hard.append(f"{key}: {len(set(d) & set(h))} ids in both halves")
    if sorted(d + h) != sorted(r[idf] for r in full):
        hard.append(f"{key}: halves do not cover the full set exactly once")

# 2 no source leakage
src = {h: {r["source_id"] for r in half[h]["setB"]} for h in half}
if src["dev"] & src["heldout"]:
    hard.append(f"Set B sources in both halves: {src['dev'] & src['heldout']}")
for h in half:
    if {p["source_id"] for p in half[h]["pairs"]} - src[h]:
        hard.append(f"{h}: a pair uses a source from the other half")
    a_ids = {a["item_id"] for a in half[h]["setA"]}
    for sid, aid in meta["setA_linked_sources"].items():
        if sid in src[h] and aid not in a_ids:
            hard.append(f"{h}: Set B source {sid} is here but its Set A item {aid} is in the other half")

# 3 sizes and balance
if len(src["dev"]) != 20 or len(src["heldout"]) != 20:
    hard.append("source counts are not 20 / 20")
if len(half["dev"]["setA"]) != 20 or len(half["heldout"]["setA"]) != 20:
    hard.append("Set A counts are not 20 / 20")
cat = {h: Counter(r["category"] for r in {r["source_id"]: r for r in half[h]["setB"]}.values()) for h in half}
for c in set(cat["dev"]) | set(cat["heldout"]):
    if abs(cat["dev"][c] - cat["heldout"][c]) > 1:
        hard.append(f"category {c} unbalanced: {cat['dev'][c]} vs {cat['heldout'][c]}")

# 4 repeat subset
held_ids = {r["item_id"] for k in ("setA", "setB") for r in half["heldout"][k]}
if len(rep) != 40 or any(r["item_id"] not in held_ids for r in rep):
    hard.append("repeat subset is not 40 held-out items")
slots = Counter(r["repeat_slot"] for r in rep)
if slots["setA"] != 20 or any(slots[f"setB_{v}"] != 4 for v in ("gold", "paraphrase", "literal", "fluent_wrong", "targeted_error")):
    hard.append(f"repeat subset composition wrong: {dict(slots)}")
if len({r["source_id"] for r in rep if r["repeat_slot"] != "setA"}) != 20:
    hard.append("repeat subset Set B rows do not come from 20 distinct sources")

# soft: balance
vt = {h: Counter(r["variant_type"] for r in half[h]["setB"]) for h in half}
hsA = {h: [a["human_score"] for a in half[h]["setA"]] for h in half}
for v in sorted(set(vt["dev"]) | set(vt["heldout"])):
    if abs(vt["dev"][v] - vt["heldout"][v]) > 4:
        soft.append(f"variant {v}: {vt['dev'][v]} vs {vt['heldout'][v]}")

# ---------------------------------------------------------------- baseline reference numbers
R = pd.DataFrame([json.loads(l) for f in sorted(glob.glob(os.path.join(ROOT, "results", "P*.jsonl"))) for l in open(f, encoding="utf-8")])
Bdf = pd.DataFrame(B).set_index("item_id")
hsmap = {a["item_id"]: a["human_score"] for a in A}
split_of = {r["item_id"]: h for h in half for k in ("setA", "setB") for r in half[h][k]}
pair_split = {p["pair_id"]: h for h in half for p in half[h]["pairs"]}
R["split"] = [pair_split.get(i) if ph == "P10_E9_pairwise" else split_of.get(i) for i, ph in zip(R.item_id, R.phase)]


def band(s):
    return "clean" if s >= 85 else ("moderate" if s >= 60 else "poor")


rows = []
for h in ("dev", "heldout"):
    for m in ("glm4", "qwen"):
        for p in ("mqm", "flat"):
            q = R[(R.split == h) & (R.model == m)]
            # agreement with humans, Set A, T=0 run 0
            a0 = q[(q.phase == "P01_E1_T00") & (q.prompt_id == p) & (q.run == 0)]
            rho_h = spearmanr(a0.score, a0.item_id.map(hsmap)).statistic
            # repeatability T=0.7, Set A
            e = q[(q.phase == "P02_E1_T07") & (q.prompt_id == p)]
            g = e.groupby("item_id").score
            inc = ((g.max() - g.min() >= 10) | (g.apply(lambda s: len({band(x) for x in s}) > 1))).mean()
            spread = (g.max() - g.min()).mean()
            # Set B paired contrast
            b = q[(q.set == "B") & (q.prompt_id == p) & (q.phase.isin(["P06_E4_setB_mqm", "P08_E5_setB_flat"]))].copy()
            b["vt"] = b.item_id.map(Bdf.variant_type)
            b["sid"] = b.item_id.map(Bdf.source_id)
            gold = b[b.vt == "gold"].set_index("sid").score
            fl = b[b.vt.isin(["fluent_wrong", "targeted_error"])]
            d = fl.sid.map(gold) - fl.score
            corr = b[b.vt.isin(["gold", "paraphrase"])]
            row = dict(half=h, model=m, prompt=p, rho_human_setA=rho_h, inconsistent_T07=inc, mean_spread_T07=spread,
                       below_gold_strict=(d > 0).mean(), above_gold=(d < 0).mean())
            if p == "mqm":
                row["false_error_rate_on_correct"] = (corr.n_errors > 0).mean()
                sp = [np.mean([str(x.get("text") or "") not in Bdf.loc[i, "candidate"] for x in es]) for i, es in zip(b.item_id, b.errors) if es]
                row["spans_not_in_translation"] = float(np.mean(sp))
            rows.append(row)
    pw = R[(R.split == h) & (R.phase == "P10_E9_pairwise")]
    for m in ("glm4", "qwen"):
        x = pw[pw.model == m]
        w = x.pivot_table(index="item_id", columns="order", values="better", aggfunc="first")
        # verdict on original sides
        flip = {"A": "B", "B": "A", "tie": "tie"}
        consistent = (w["AB"] == w["BA"].map(flip)).mean()
        rows.append(dict(half=h, model=m, prompt="pairwise", first_position_rate=(x.better == "A").mean(),
                         order_consistent=consistent, n_pairs=len(w)))
ref = pd.DataFrame(rows)
ref.round(3).to_csv(os.path.join(D, "baseline_reference.csv"), index=False)

# ---------------------------------------------------------------- report
lines += ["TASK B · STEP B1 — SPLIT VALIDATION AND BASELINE REFERENCE", "=" * 64,
          f"Split seed {meta['seed']} (best of {meta['candidate_seeds_tried']} candidates, penalty {meta['penalty']})", ""]
for h in ("dev", "heldout"):
    sA = hsA[h]
    lines.append(f"{h.upper():8s} sources {len(src[h])}  Set B rows {len(half[h]['setB'])}  pairs {len(half[h]['pairs'])}  "
                 f"Set A {len(sA)} (human mean {np.mean(sA):.1f}, sd {np.std(sA, ddof=1):.1f}, clean {sum(s >= 85 for s in sA)}, moderate {sum(s < 85 for s in sA)})")
    lines.append(f"         categories {dict(sorted(cat[h].items()))}")
    lines.append(f"         variants   {dict(sorted(vt[h].items()))}")
lines.append(f"\nRepeat subset (held-out): {len(rep)} items  {dict(sorted(slots.items()))}")
lines.append(f"\nHARD FAILURES: {len(hard)}")
lines += [f"  - {x}" for x in hard]
lines.append(f"WARNINGS: {len(soft)}")
lines += [f"  - {x}" for x in soft]
lines.append("\nBASELINE REFERENCE (Sprint 50 prompts, Task A runs) - per half")
pd.set_option("display.width", 200)
lines.append(ref.round(2).to_string(index=False))
report = "\n".join(lines)
open(os.path.join(D, "split_validation_report.txt"), "w", encoding="utf-8").write(report + "\n")
print(report)
sys.exit(1 if hard else 0)
