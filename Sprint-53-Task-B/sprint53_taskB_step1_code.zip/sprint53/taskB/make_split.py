"""
Task B · Step B1 — split the Task A data into a DEVELOPMENT half and a HELD-OUT half.

Why: prompts are designed and screened on the development half only; the final comparison
(Stage 2) uses the held-out half, so a prompt cannot "win" by being tuned to the test items.
(Same principle as the Sprint 50 fine-tuning readiness document: prompt-validation data and
final test data are kept separate.)

Rules
  * The unit of splitting is the English SOURCE sentence: every variant of a source (gold,
    paraphrase, errors, Traditional copies, MT output) and every pair built from it stays in the
    same half - otherwise the judge would see near-copies of test items during design.
  * Set B: 40 sources -> 20 / 20, balanced within each of the 8 categories (difference <= 1).
  * Set A: 40 items -> 20 / 20. The 10 Set A items that are also Set B sources (A_xxx) follow
    their Set B source; the other 30 are split so both halves have a similar human-score
    distribution.
  * Balance constraints (checked for every candidate split, best one kept):
      - Set A-linked Set B sources 5 / 5
      - padded and Taiwan-localised rows spread over both halves
      - Set A mean human score and clean/moderate counts as close as possible
  * Deterministic: candidate splits come from seeds 0..1999; the best-scoring one is kept and
    its seed recorded.

Also pre-registers the Stage 2 REPEAT SUBSET (held-out only, used for repeated runs):
  all 20 held-out Set A items + 20 held-out Set B rows (one row from each held-out source,
  4 each of gold / paraphrase / literal / fluent_wrong / targeted_error, spread over categories).

Run:  python taskB/make_split.py        (CPU, a few seconds)
Out:  data/taskB/split.json, data/taskB/{dev,heldout}_{setA,setB,pairs}.jsonl,
      data/taskB/repeat_subset.jsonl
"""
import json
import os
import random
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, "data", "processed")
OUT = os.path.join(ROOT, "data", "taskB")
os.makedirs(OUT, exist_ok=True)

N_SEEDS = 2000
REPEAT_VARIANTS = ["gold", "paraphrase", "literal", "fluent_wrong", "targeted_error"]


def rj(name):
    with open(os.path.join(P, name), encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def wj(name, rows):
    with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def band(s):
    return "clean" if s >= 85 else ("moderate" if s >= 60 else "poor")


A = rj("setA_items.jsonl")
B = [r for r in rj("setB_items.jsonl") if r.get("include_in_experiments", True)]
PAIRS = rj("pairs.jsonl")

sources = {}
for r in B:
    sources.setdefault(r["source_id"], {"category": r["category"], "origin": r["source_origin"],
                                        "ref": r.get("source_origin_ref") or "", "variants": Counter()})
    sources[r["source_id"]]["variants"][r["variant_type"]] += 1
cats = sorted({s["category"] for s in sources.values()})
a_linked = {sid: "A::" + s["ref"] for sid, s in sources.items() if s["origin"] == "sprint50"}
linked_items = set(a_linked.values())
A_free = [a for a in A if a["item_id"] not in linked_items]
hs = {a["item_id"]: a["human_score"] for a in A}


def candidate(seed):
    rng = random.Random(seed)
    dev = set()
    flip = rng.random() < 0.5
    for c in cats:
        sids = sorted(s for s, v in sources.items() if v["category"] == c)
        rng.shuffle(sids)
        k = len(sids) // 2 + (len(sids) % 2 if flip else 0)
        if len(sids) % 2:
            flip = not flip            # alternate which half gets the odd source
        dev |= set(sids[:k])
    # Set A: linked items follow their source; the rest are split by score strata
    a_dev = {a_linked[s] for s in dev if s in a_linked}
    free = sorted(A_free, key=lambda a: (a["human_score"], a["item_id"]))
    need = 20 - len(a_dev)
    if not 0 <= need <= len(free):
        return None
    # stratified: walk score-sorted list in blocks of 2, send one of each block to dev
    picked = []
    for i in range(0, len(free), 2):
        block = free[i:i + 2]
        rng.shuffle(block)
        picked.append(block[0])
    rest = [a for a in free if a not in picked]
    rng.shuffle(rest)
    chosen = picked[:need] if need <= len(picked) else picked + rest[:need - len(picked)]
    a_dev |= {a["item_id"] for a in chosen}
    return dev, a_dev


def score(dev, a_dev):
    held = set(sources) - dev
    pen = 0.0
    if len(dev) != 20:
        return None
    for c in cats:
        d = sum(1 for s in dev if sources[s]["category"] == c)
        h = sum(1 for s in held if sources[s]["category"] == c)
        if abs(d - h) > 1:
            return None
    if sum(1 for s in dev if s in a_linked) != 5:
        return None
    if len(a_dev) != 20:
        return None
    for v in ("padded", "traditional_tw", "traditional_char", "original_candidate"):
        d = sum(sources[s]["variants"][v] for s in dev)
        h = sum(sources[s]["variants"][v] for s in held)
        pen += abs(d - h)
    a_held = set(hs) - a_dev
    md = sum(hs[i] for i in a_dev) / 20
    mh = sum(hs[i] for i in a_held) / 20
    pen += 4 * abs(md - mh)
    pen += 2 * abs(sum(band(hs[i]) == "clean" for i in a_dev) - sum(band(hs[i]) == "clean" for i in a_held))
    return pen


best = None
for seed in range(N_SEEDS):
    c = candidate(seed)
    if c is None:
        continue
    s = score(*c)
    if s is not None and (best is None or s < best[0]):
        best = (s, seed, c)
if best is None:
    raise SystemExit("No split satisfied the constraints")
pen, seed, (dev_src, a_dev) = best
held_src = set(sources) - dev_src
a_held = set(hs) - a_dev

# ---------------------------------------------------------------- write halves
halves = {"dev": (dev_src, a_dev), "heldout": (held_src, a_held)}
for name, (src, aset) in halves.items():
    wj(f"{name}_setA.jsonl", [dict(a, split=name) for a in A if a["item_id"] in aset])
    wj(f"{name}_setB.jsonl", [dict(r, split=name) for r in B if r["source_id"] in src])
    wj(f"{name}_pairs.jsonl", [dict(p, split=name) for p in PAIRS if p["source_id"] in src])

# ---------------------------------------------------------------- repeat subset (held-out)
held_sorted = sorted(held_src, key=lambda s: (sources[s]["category"], s))
rep = [dict(a, split="heldout", repeat_slot="setA") for a in A if a["item_id"] in a_held]
byid = {(r["source_id"], r["variant_type"]): r for r in B}
for k, sid in enumerate(held_sorted):
    v = REPEAT_VARIANTS[k % len(REPEAT_VARIANTS)]
    rep.append(dict(byid[(sid, v)], split="heldout", repeat_slot=f"setB_{v}"))
wj("repeat_subset.jsonl", rep)

meta = {
    "seed": seed, "penalty": round(pen, 3), "candidate_seeds_tried": N_SEEDS,
    "dev_sources": sorted(dev_src), "heldout_sources": sorted(held_src),
    "dev_setA": sorted(a_dev), "heldout_setA": sorted(a_held),
    "setA_linked_sources": a_linked,
    "repeat_subset_ids": [r["item_id"] for r in rep],
}
json.dump(meta, open(os.path.join(OUT, "split.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
print(f"Chosen seed {seed} (penalty {pen:.2f}). dev sources {len(dev_src)}, held-out sources {len(held_src)}; "
      f"repeat subset {len(rep)} items -> data/taskB/")
