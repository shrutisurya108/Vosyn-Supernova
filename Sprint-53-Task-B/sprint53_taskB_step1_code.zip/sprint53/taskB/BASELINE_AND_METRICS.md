# Task B · Step B1 — Baseline, data split and success rules (pre-registered)

Written **before** any Task B prompt is run, so the definition of "better" cannot be adjusted to fit
the results afterwards.

## 1. Baseline evaluation prompt (acceptance criterion 1)

| Item | Baseline |
|---|---|
| Judges | glm4:latest (digest 5b699761eca5) and qwen2.5:7b (digest 845dbda0ea48), Ollama, Colab T4 — same as Task A |
| Absolute prompts | Sprint 50 **MQM** prompt and Sprint 50 **flat 0–100** prompt, verbatim (`judge/prompts.py`: `mqm`, `flat`) |
| MQM score | 100 − Σ(minor 1, major 5, critical 25), floor 0, computed in Python |
| Ensemble (Sprint 50 choice) | median of glm4 and qwen MQM scores (= their mean) |
| Pairwise prompt | Task A `pairwise` prompt (A / B / tie), shown in one order |
| Decoding | temperature 0 (plus 0.7 for repeat runs), seed 1000 + run, num_ctx 4096, same output caps as Task A |
| Output format | free text with JSON requested, tolerant parser (as Task A) |

The baseline is **re-run in Task B alongside every strategy**, so environment drift (Task A F3)
cannot be mistaken for an improvement. Task A numbers per half are kept as a cross-check
(`data/taskB/baseline_reference.csv`).

## 2. Data split

| | Development half | Held-out half |
|---|---|---|
| English sources (Set B) | 20 | 20 |
| Set B rows | 138 | 137 |
| Set A items (human scores) | 20 (mean 84.0, 9 clean / 11 moderate) | 20 (mean 84.0, 10 clean / 10 moderate) |
| Pairs | 28 | 32 |
| Used for | designing prompts, few-shot examples, Stage 1 screening | Stage 2 confirmation only |

* Split unit = English source: all variants and pairs of a source stay in one half; Set A items that
  are also Set B sources follow their source.
* Every category is within ±1 source between halves; best of 2,000 seeded candidates (seed 1324).
* **Held-out rule:** held-out items are never used to write or tune prompts or few-shot examples, and
  held-out results of the new prompts are not looked at until Stage 2.
* **Repeat subset** (pre-registered, held-out): all 20 held-out Set A items + 20 Set B rows from 20
  different sources (4 each: gold, paraphrase, literal, fluent-wrong, category error).

## 3. Strategies and the scoring style each is tested in

| Strategy | Style | Primary metric (what it must improve) |
|---|---|---|
| S1 Defined scoring rubric + score definitions | flat | Consistency at T = 0.7 (inconsistent share, spread); glm4–qwen gap |
| S2 Few-shot calibration examples (incl. a no-error example) | MQM | False-error rate on correct translations; flawed-above-gold rate |
| S3 Step-by-step criteria (meaning → names/numbers/terms → idioms/culture → valid variation) | MQM | Spans not in translation; planted-error detection |
| S4 Separate accuracy and fluency scores | flat | Flawed-below-gold (strict); literal-correct ranked above fluent-wrong |
| S5 Pairwise with tie definition, randomized order (both orders judged) | pairwise | Order consistency; first-position rate |
| C Combined prompt(s) from the best of S1–S4 | per style | All of the above |

## 4. Metrics

**Consistency** (computed on repeated runs)
* Inconsistent share — runs differ by ≥ 10 points or fall in different bands (clean ≥ 85, moderate 60–84, poor < 60).
* Mean and max run-to-run spread (points); Krippendorff's α across runs.
* Wording robustness (Stage 2, finalists only): ρ between the prompt and a reworded copy of it.
* Pairwise: order consistency (same verdict when the order is swapped) and first-position rate.

**Reliability**
* Agreement with humans: Spearman ρ with the human MQM score on Set A.
* Paired contrast on Set B: flawed version scored strictly below its own gold (strict), and scored above it (above-gold).
* False-error rate on correct translations (gold + valid paraphrase) — MQM-style prompts.
* Spans not in translation — MQM-style prompts.
* Planted-error detection (span-based, lower bound) — MQM-style prompts.
* Malformed-output rate (must stay ≤ 5%, Sprint 50 guardrail).

## 5. Decision rules

**Stage 1 (development half, temperature 0, one run):** a strategy goes forward if it improves its
primary metric over the baseline for at least one judge **and** does not make any reliability metric
clearly worse (> 10 percentage points, or ρ drop > 0.15) for either judge. At most 3 finalists plus
1 combined prompt per style. Stage 1 is screening only — no claims are made from it.

**Stage 2 (held-out half):** a finalist is called **promising** if, against the baseline re-run in the
same session:
1. its primary metric improves, with a **paired bootstrap 95% CI** (2,000 resamples over items or
   sources, seed 42) that excludes zero, for at least one judge;
2. no other metric is clearly worse (same thresholds as Stage 1);
3. malformed output ≤ 5%.

A strategy that helps only one judge is reported as judge-specific. With 20 items per half, small
improvements will not reach significance; those are reported as "directional, not confirmed".

**Recommended prompt (acceptance criterion 7):** the promising prompt — or combination — with the
best consistency that also keeps or improves reliability; if none is promising, the guidelines say
so and list what is directionally helpful.

## 6. Reproduce Step B1

```bash
python taskB/make_split.py        # writes data/taskB/ (deterministic, seed recorded)
python taskB/validate_split.py    # must end with HARD FAILURES: 0; writes baseline_reference.csv
```
