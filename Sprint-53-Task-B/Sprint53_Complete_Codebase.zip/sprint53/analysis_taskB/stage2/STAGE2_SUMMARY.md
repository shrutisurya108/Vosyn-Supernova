# Task B · Stage 2 (held-out half)

Calls: 4478, malformed 36, retried 72, cut off 0. Sessions: 6, Ollama 0.35.1, same model digests in all sessions: True. Finalists: ['mqm_fewshot', 'pairwise_tie'].
Items: Set A 20, Set B 137 (20 sources), pairs 32, repeat subset 40.

## T1 · Main run, T = 0, held-out half (157 items)

```
     prompt model  n_setA  n_flawed  n_correct  rho_human_setA  rho_human_ci  rho_true_band_setB  band_accuracy_setB  below_gold_strict  tie_with_gold  above_gold  literal_beats_fluent_wrong  correct_below_85  mean_score_correct  mean_score_flawed  malformed  mean_abs_judge_gap  judge_agreement_rho  false_error_rate_on_correct  major_or_critical_on_correct  spans_not_in_translation  planted_error_detected  mean_errors_listed
       flat  glm4      20        40         40           0.509  [0.00, 0.80]               0.545               0.569              0.775          0.200       0.025                        0.65             0.025              93.375             75.875        0.0                 NaN                  NaN                          NaN                           NaN                       NaN                     NaN                 NaN
       flat  qwen      20        40         40           0.634  [0.27, 0.87]               0.576               0.664              0.825          0.150       0.025                        0.85             0.000              91.750             60.250        0.0                 NaN                  NaN                          NaN                           NaN                       NaN                     NaN                 NaN
       flat   ens      20        40         40           0.623  [0.22, 0.87]               0.594               0.657              0.875          0.100       0.025                        0.85             0.025              92.562             68.062        NaN               8.822                0.752                          NaN                           NaN                       NaN                     NaN                 NaN
        mqm  glm4      20        40         40           0.550  [0.08, 0.85]              -0.011               0.482              0.375          0.425       0.200                        0.40             0.125              87.225             83.925        0.0                 NaN                  NaN                        1.000                         1.000                     0.475                   0.550               2.321
        mqm  qwen      20        40         40           0.367 [-0.13, 0.72]               0.106               0.511              0.650          0.225       0.125                        0.70             0.100              94.225             90.575        0.0                 NaN                  NaN                        0.600                         0.475                     0.019                   0.725               1.182
        mqm   ens      20        40         40           0.527  [0.09, 0.79]               0.051               0.496              0.600          0.200       0.200                        0.65             0.175              90.725             87.250        NaN              11.057                0.230                          NaN                           NaN                       NaN                     NaN                 NaN
mqm_fewshot  glm4      20        40         40           0.162 [-0.36, 0.68]               0.101               0.511              0.625          0.175       0.200                        0.55             0.025              94.225             91.175        0.0                 NaN                  NaN                        0.900                         0.775                     0.120                   0.825               1.701
mqm_fewshot  qwen      20        40         40           0.661  [0.29, 0.91]               0.316               0.533              0.850          0.100       0.050                        0.55             0.000              97.975             93.575        0.0                 NaN                  NaN                        0.425                         0.300                     0.008                   0.800               0.934
mqm_fewshot   ens      20        40         40           0.346 [-0.21, 0.77]               0.270               0.533              0.850          0.100       0.050                        0.70             0.000              96.100             92.375        NaN               4.643                0.552                          NaN                           NaN                       NaN                     NaN                 NaN
```

## T2 · Consistency on the repeat subset (40 items): T = 0 x 3 runs, T = 0.7 x 5 runs

```
     prompt model  temperature  runs  n_items  inconsistent_share  band_changes  identical_all_runs  mean_spread  max_spread  mean_sd  kripp_alpha_runs  rho_human_mean_of_runs
       flat  glm4          0.0     3       40               0.075         0.075               0.875        0.875        10.0    0.505             0.986                   0.505
       flat  qwen          0.0     3       40               0.050         0.000               0.950        1.125        35.0    0.650             0.983                   0.634
        mqm  glm4          0.0     3       40               0.200         0.125               0.725        5.925        91.0    3.230             0.823                   0.587
        mqm  qwen          0.0     3       40               0.100         0.075               0.825        2.325        28.0    1.342             0.861                   0.414
mqm_fewshot  glm4          0.0     3       40               0.075         0.075               0.725        3.150        48.0    1.819             0.744                   0.227
mqm_fewshot  qwen          0.0     3       40               0.000         0.000               0.900        0.425         5.0    0.245             0.984                   0.665
       flat  glm4          0.7     5       40               0.625         0.350               0.050        8.700        25.0    3.888             0.880                   0.537
       flat  qwen          0.7     5       40               0.425         0.175               0.525        6.425        40.0    2.806             0.965                   0.657
        mqm  glm4          0.7     5       40               0.975         0.925               0.000       50.100        98.0   21.105             0.177                   0.257
        mqm  qwen          0.7     5       40               0.525         0.425               0.200       13.375        52.0    5.885             0.514                   0.590
mqm_fewshot  glm4          0.7     5       40               0.575         0.500               0.025       18.575        98.0    7.940             0.230                   0.470
mqm_fewshot  qwen          0.7     5       40               0.275         0.225               0.450        5.875        25.0    2.767             0.632                   0.466
```

## T3 · Finalist vs baseline, paired bootstrap 95% CI

```
       strategy       vs                       metric model        role  baseline  strategy_value   delta   ci_lo   ci_hi  better  ci_excludes_zero  clearly_worse
    S2 few-shot      mqm               rho_human_setA  glm4       guard     0.550           0.162  -0.388  -0.914   0.186   False             False           True
    S2 few-shot      mqm           rho_true_band_setB  glm4       guard    -0.011           0.101   0.112  -0.091   0.336    True             False          False
    S2 few-shot      mqm           band_accuracy_setB  glm4       guard     0.482           0.511   0.029  -0.043   0.104    True             False          False
    S2 few-shot      mqm            below_gold_strict  glm4       guard     0.375           0.625   0.250   0.000   0.500    True             False          False
    S2 few-shot      mqm                   above_gold  glm4     PRIMARY     0.200           0.200   0.000  -0.225   0.225   False             False          False
    S2 few-shot      mqm   literal_beats_fluent_wrong  glm4       guard     0.400           0.550   0.150  -0.150   0.450    True             False          False
    S2 few-shot      mqm             correct_below_85  glm4       guard     0.125           0.025  -0.100  -0.250   0.025    True             False          False
    S2 few-shot      mqm  false_error_rate_on_correct  glm4     PRIMARY     1.000           0.900  -0.100  -0.200  -0.025    True              True          False
    S2 few-shot      mqm     spans_not_in_translation  glm4       guard     0.475           0.120  -0.355  -0.565  -0.129    True              True          False
    S2 few-shot      mqm       planted_error_detected  glm4       guard     0.550           0.825   0.275   0.125   0.450    True              True          False
    S2 few-shot      mqm major_or_critical_on_correct  glm4       guard     1.000           0.775  -0.225  -0.376  -0.100    True              True          False
    S2 few-shot      mqm      inconsistent_share_T0.0  glm4 consistency     0.200           0.075  -0.125  -0.275   0.000    True             False          False
    S2 few-shot      mqm             mean_spread_T0.0  glm4 consistency     5.925           3.150  -2.775  -9.025   1.876    True             False          False
    S2 few-shot      mqm      inconsistent_share_T0.7  glm4 consistency     0.975           0.575  -0.400  -0.550  -0.250    True              True          False
    S2 few-shot      mqm             mean_spread_T0.7  glm4 consistency    50.100          18.575 -31.525 -41.326 -22.173    True              True          False
    S2 few-shot      mqm      wording_mean_abs_change  glm4  robustness     9.438           4.450  -4.988  -8.963  -1.549    True              True          False
S5 pairwise+tie pairwise             order_consistent  glm4     PRIMARY     0.531           0.625   0.094  -0.156   0.344    True             False          False
S5 pairwise+tie pairwise          first_position_rate  glm4     PRIMARY     0.703           0.312  -0.391  -0.516  -0.266    True              True          False
S5 pairwise+tie pairwise     verdict_matches_expected  glm4       guard     0.375           0.609   0.234   0.109   0.359    True              True          False
S5 pairwise+tie pairwise             flawed_preferred  glm4       guard     0.125           0.047  -0.078  -0.141  -0.016    True              True          False
S5 pairwise+tie pairwise                     tie_rate  glm4        info     0.000           0.234   0.234   0.125   0.359   False              True          False
S5 pairwise+tie pairwise           correct_on_a_pairs  glm4       guard     0.733           0.833   0.100  -0.071   0.278    True             False          False
S5 pairwise+tie pairwise    wording_verdict_agreement  glm4  robustness     0.844           0.641  -0.203     NaN     NaN   False             False          False
    S2 few-shot      mqm               rho_human_setA  qwen       guard     0.367           0.661   0.294  -0.266   0.876    True             False          False
    S2 few-shot      mqm           rho_true_band_setB  qwen       guard     0.106           0.316   0.210  -0.030   0.453    True             False          False
    S2 few-shot      mqm           band_accuracy_setB  qwen       guard     0.511           0.533   0.022  -0.007   0.054    True             False          False
    S2 few-shot      mqm            below_gold_strict  qwen       guard     0.650           0.850   0.200   0.050   0.375    True              True          False
    S2 few-shot      mqm                   above_gold  qwen     PRIMARY     0.125           0.050  -0.075  -0.200   0.000    True             False          False
    S2 few-shot      mqm   literal_beats_fluent_wrong  qwen       guard     0.700           0.550  -0.150  -0.450   0.150   False             False           True
    S2 few-shot      mqm             correct_below_85  qwen       guard     0.100           0.000  -0.100  -0.200  -0.025    True              True          False
    S2 few-shot      mqm  false_error_rate_on_correct  qwen     PRIMARY     0.600           0.425  -0.175  -0.325  -0.025    True              True          False
    S2 few-shot      mqm     spans_not_in_translation  qwen       guard     0.019           0.008  -0.011  -0.026   0.000    True             False          False
    S2 few-shot      mqm       planted_error_detected  qwen       guard     0.725           0.800   0.075  -0.075   0.225    True             False          False
    S2 few-shot      mqm major_or_critical_on_correct  qwen       guard     0.475           0.300  -0.175  -0.325  -0.025    True              True          False
    S2 few-shot      mqm      inconsistent_share_T0.0  qwen consistency     0.100           0.000  -0.100  -0.200  -0.025    True              True          False
    S2 few-shot      mqm             mean_spread_T0.0  qwen consistency     2.325           0.425  -1.900  -4.051  -0.150    True              True          False
    S2 few-shot      mqm      inconsistent_share_T0.7  qwen consistency     0.525           0.275  -0.250  -0.400  -0.075    True              True          False
    S2 few-shot      mqm             mean_spread_T0.7  qwen consistency    13.375           5.875  -7.500 -11.651  -3.524    True              True          False
    S2 few-shot      mqm      wording_mean_abs_change  qwen  robustness     6.062           1.850  -4.212  -6.562  -2.188    True              True          False
S5 pairwise+tie pairwise             order_consistent  qwen     PRIMARY     0.656           0.594  -0.062  -0.219   0.063   False             False          False
S5 pairwise+tie pairwise          first_position_rate  qwen     PRIMARY     0.578           0.531  -0.047  -0.156   0.047    True             False          False
S5 pairwise+tie pairwise     verdict_matches_expected  qwen       guard     0.562           0.656   0.094  -0.016   0.219    True             False          False
S5 pairwise+tie pairwise             flawed_preferred  qwen       guard     0.047           0.094   0.047   0.000   0.109   False             False          False
S5 pairwise+tie pairwise                     tie_rate  qwen        info     0.094           0.234   0.141   0.047   0.250   False              True          False
S5 pairwise+tie pairwise           correct_on_a_pairs  qwen       guard     0.900           0.800  -0.100  -0.211   0.000   False             False          False
S5 pairwise+tie pairwise    wording_verdict_agreement  qwen  robustness     0.766           0.789   0.023     NaN     NaN    True             False          False
```

## Stage 2 decision (pre-registered rule)

```
       strategy       prompt                                           primary_improved_CI_excl_0                          primary_directional_only                                                                clearly_worse  malformed_max   stage2_rule
    S2 few-shot  mqm_fewshot false_error_rate_on_correct[glm4], false_error_rate_on_correct[qwen]                                  above_gold[qwen] rho_human_setA[glm4] 0.55->0.16, literal_beats_fluent_wrong[qwen] 0.70->0.55            0.0 NOT CONFIRMED
S5 pairwise+tie pairwise_tie                                            first_position_rate[glm4] order_consistent[glm4], first_position_rate[qwen]                                                                         none            0.0     PROMISING
```

## T4 · Pairwise, T = 0, both orders (32 pairs)

```
      prompt model  n_pairs  order_consistent  first_position_rate  first_share_of_non_tie  tie_rate  verdict_matches_expected  flawed_preferred  ties_on_tie_pairs  correct_on_a_pairs  malformed
    pairwise  glm4       32             0.531                0.703                   0.703     0.000                     0.375             0.125              0.000               0.733        0.0
    pairwise  qwen       32             0.656                0.578                   0.638     0.094                     0.562             0.047              0.200               0.900        0.0
pairwise_tie  glm4       32             0.625                0.312                   0.408     0.234                     0.609             0.047              0.367               0.833        0.0
pairwise_tie  qwen       32             0.594                0.531                   0.694     0.234                     0.656             0.094              0.500               0.800        0.0
```

## T5 · Pairwise stability, T = 0.7 x 3 runs

```
      prompt model  pair_orders  same_verdict_all_3_runs  order_consistent_mean_of_runs  first_position_rate  tie_rate  verdict_matches_expected  malformed
    pairwise  glm4           64                    0.688                          0.510                0.682     0.052                     0.443        0.0
    pairwise  qwen           64                    0.906                          0.729                0.531     0.109                     0.578        0.0
pairwise_tie  glm4           64                    0.516                          0.583                0.349     0.208                     0.625        0.0
pairwise_tie  qwen           64                    0.766                          0.552                0.474     0.240                     0.667        0.0
```

## T6 · Wording robustness (2 rewordings per prompt)

```
      prompt        rewording model  items  rho_vs_original  mean_abs_change  moved_10plus  band_changed  mean_score_change  malformed  verdict_agreement_with_original  order_consistent  first_position_rate  tie_rate  verdict_matches_expected
         mqm     mqm_reworded  glm4     40            0.663            9.025         0.250         0.225              6.275      0.000                              NaN               NaN                  NaN       NaN                       NaN
         mqm          mqm_rw2  glm4     40            0.350            9.850         0.400         0.350             -0.650      0.000                              NaN               NaN                  NaN       NaN                       NaN
         mqm     mqm_reworded  qwen     40            0.871            2.850         0.100         0.100              0.700      0.000                              NaN               NaN                  NaN       NaN                       NaN
         mqm          mqm_rw2  qwen     40            0.360            9.275         0.375         0.350             -3.275      0.000                              NaN               NaN                  NaN       NaN                       NaN
 mqm_fewshot  mqm_fewshot_rw1  glm4     40            0.669            3.525         0.125         0.150              0.825      0.000                              NaN               NaN                  NaN       NaN                       NaN
 mqm_fewshot  mqm_fewshot_rw2  glm4     40            0.515            5.375         0.125         0.125              3.675      0.000                              NaN               NaN                  NaN       NaN                       NaN
 mqm_fewshot  mqm_fewshot_rw1  qwen     40            0.855            2.050         0.050         0.075             -1.100      0.000                              NaN               NaN                  NaN       NaN                       NaN
 mqm_fewshot  mqm_fewshot_rw2  qwen     40            0.803            1.650         0.025         0.025              0.150      0.000                              NaN               NaN                  NaN       NaN                       NaN
    pairwise     pairwise_rw1  glm4     64              NaN              NaN           NaN           NaN                NaN      0.000                            0.922             0.438                0.781     0.000                     0.359
    pairwise     pairwise_rw2  glm4     39              NaN              NaN           NaN           NaN                NaN      0.391                            0.692             0.583                0.487     0.256                     0.641
    pairwise     pairwise_rw1  qwen     64              NaN              NaN           NaN           NaN                NaN      0.000                            0.828             0.750                0.422     0.156                     0.594
    pairwise     pairwise_rw2  qwen     64              NaN              NaN           NaN           NaN                NaN      0.000                            0.703             0.812                0.344     0.359                     0.719
pairwise_tie pairwise_tie_rw1  glm4     62              NaN              NaN           NaN           NaN                NaN      0.031                            0.677             0.600                0.339     0.290                     0.629
pairwise_tie pairwise_tie_rw2  glm4     55              NaN              NaN           NaN           NaN                NaN      0.141                            0.618             0.739                0.200     0.473                     0.836
pairwise_tie pairwise_tie_rw1  qwen     64              NaN              NaN           NaN           NaN                NaN      0.000                            0.906             0.594                0.500     0.219                     0.625
pairwise_tie pairwise_tie_rw2  qwen     64              NaN              NaN           NaN           NaN                NaN      0.000                            0.672             0.812                0.297     0.516                     0.875
```

## T7 · Baseline drift vs Task A (same prompts, T = 0)

```
model prompt  items  identical  moved_10plus  mean_abs_change
 glm4   flat    157      0.943         0.019            0.382
 glm4    mqm    157      0.809         0.089            3.280
 qwen   flat    157      0.962         0.032            0.350
 qwen    mqm    157      0.828         0.038            1.344
```
