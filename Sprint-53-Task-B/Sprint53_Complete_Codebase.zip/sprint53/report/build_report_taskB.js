// Sprint 53 · Task B report builder.   node report/build_report_taskB.js
// Reads report/report_data_taskB.json (built by report/build_report_data_taskB.py) + analysis_taskB/charts/*.png
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, AlignmentType, HeadingLevel,
  LevelFormat, WidthType, ShadingType, BorderStyle, Footer, Header, PageNumber,
} = require("docx");

const ROOT = path.join(__dirname, "..");
const D = JSON.parse(fs.readFileSync(path.join(ROOT, "report", "report_data_taskB.json"), "utf8"));
const OUT = path.join(ROOT, "report", "Sprint53_TaskB_Prompt_Engineering_Report.docx");

const FONT = { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei", cs: "Arial" };
const MONO = { ascii: "Consolas", hAnsi: "Consolas", eastAsia: "Microsoft YaHei", cs: "Consolas" };
const W = 9360;
const NAVY = "1F3864", BLUE = "2F5496", GREY = "595959", LIGHT = "D9E1F2", PALE = "F2F2F2";
const GOOD = "E2EFDA", BAD = "FCE4D6", MID = "FFF2CC";
const bd = { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" };
const borders = { top: bd, bottom: bd, left: bd, right: bd };

// ---------- inline markup: **bold**, `code`, _italic_
function runs(text, o = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|(?<![A-Za-z0-9])_[^_]+_(?![A-Za-z0-9]))/g;
  let last = 0, m;
  const sz = o.size || 21;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...o, size: sz }));
    const s = m[0];
    if (s.startsWith("**")) out.push(new TextRun({ text: s.slice(2, -2), font: FONT, ...o, size: sz, bold: true }));
    else if (s.startsWith("`")) out.push(new TextRun({ text: s.slice(1, -1), ...o, font: MONO, size: sz - 2 }));
    else out.push(new TextRun({ text: s.slice(1, -1), font: FONT, ...o, size: sz, italics: true }));
    last = m.index + s.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...o, size: sz }));
  return out;
}
const P = (text, o = {}) => new Paragraph({ spacing: { after: 120, line: 276 }, children: runs(text, o) });
const BREAK = new Set(["Contents", "1. Executive summary", "2. The task", "7. How the experiments were run", "8. Stage 1 results (development half)", "10. Stage 2 results (held-out half)", "12. Recommendation", "Appendix A. Prompts (verbatim)"]);
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: BREAK.has(t), spacing: { before: BREAK.has(t) ? 240 : 480, after: 160 }, children: [new TextRun({ text: t, font: FONT })] });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t, font: FONT })] });
const H3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun({ text: t, font: FONT })] });
const B = (text, level = 0) => new Paragraph({ numbering: { reference: "bullets", level }, spacing: { after: 60, line: 264 }, children: runs(text) });
let numRef = 0;
const numbered = (items) => { const ref = `n${numRef++}`; NUMREFS.push(ref); return items.map((t) => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 60, line: 264 }, children: runs(t) })); };
const NUMREFS = [];
const cap = (t) => new Paragraph({ spacing: { before: 60, after: 200 }, children: runs(t, { size: 17, color: GREY }) });
const gap = () => new Paragraph({ spacing: { after: 80 }, children: [] });

function table(widths, header, rows, o = {}) {
  const fs_ = o.size || 17;
  const tot = widths.reduce((a, b) => a + b, 0);
  const w = widths.map((x) => Math.round(x * W / tot));
  w[w.length - 1] += W - w.reduce((a, b) => a + b, 0);
  const cell = (text, i, head, fill) => new TableCell({
    borders, width: { size: w[i], type: WidthType.DXA },
    shading: head ? { fill: NAVY, type: ShadingType.CLEAR, color: "auto" } : (fill ? { fill, type: ShadingType.CLEAR, color: "auto" } : undefined),
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: String(text).split("\n").map((line) => new Paragraph({
      alignment: (!head && o.alignRight && i >= (o.firstNumCol || 1)) ? AlignmentType.RIGHT : AlignmentType.LEFT,
      children: runs(line, head ? { bold: true, color: "FFFFFF", size: fs_ } : { size: fs_ }),
    })),
  });
  const fillFor = (r, k, i) => {
    if (o.fill) { const f = o.fill(r, i); if (f) return f; }
    if (o.shadeFirst && i === 0) return LIGHT;
    return (o.zebra !== false && k % 2 === 1) ? PALE : undefined;
  };
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: w,
    rows: [
      new TableRow({ tableHeader: true, children: header.map((h, i) => cell(h, i, true)) }),
      ...rows.map((r, k) => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, i, false, fillFor(r, k, i))) })),
    ],
  });
}
function pngSize(p) { const b = fs.readFileSync(p); return [b.readUInt32BE(16), b.readUInt32BE(20)]; }
function figure(file, caption, widthIn = 6.5) {
  const p = path.join(ROOT, "analysis_taskB", "charts", file);
  const [w, h] = pngSize(p);
  const wpx = Math.round(widthIn * 96);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120 }, keepNext: true, children: [new ImageRun({ type: "png", data: fs.readFileSync(p), transformation: { width: wpx, height: Math.round(wpx * h / w) }, altText: { title: caption, description: caption, name: file } })] }),
    cap(caption),
  ];
}
function callout(title, lines, color = BLUE, fill = "EEF3FA") {
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [W],
    rows: [new TableRow({ children: [new TableCell({
      borders: { top: { style: BorderStyle.SINGLE, size: 12, color }, bottom: bd, left: bd, right: bd },
      shading: { fill, type: ShadingType.CLEAR, color: "auto" }, width: { size: W, type: WidthType.DXA },
      margins: { top: 100, bottom: 100, left: 160, right: 160 },
      children: [new Paragraph({ spacing: { after: 80 }, children: runs(title, { bold: true, color: NAVY }) }),
        ...lines.map((l) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 50 }, children: runs(l, { size: 20 }) }))],
    })] })],
  });
}
function mono(text) {
  return text.split("\n").map((line) => new Paragraph({ spacing: { after: 0, line: 240 }, shading: { fill: PALE, type: ShadingType.CLEAR, color: "auto" },
    children: [new TextRun({ text: line || " ", font: MONO, size: 15 })] }));
}

// ---------- data helpers
const pct = (x) => (x === null || x === undefined || Number.isNaN(x)) ? "–" : `${Math.round(x * 100)}%`;
const f2 = (x) => (x === null || x === undefined || Number.isNaN(x)) ? "–" : x.toFixed(2);
const f1 = (x) => (x === null || x === undefined || Number.isNaN(x)) ? "–" : x.toFixed(1);
const S1 = D.stage1, S2 = D.stage2;
const find = (rows, q) => rows.find((r) => Object.entries(q).every(([k, v]) => r[k] === v));
const t1 = (p, m) => find(S2.T1_main_T0, { prompt: p, model: m });
const s1a = (p, m) => find(S1.S1_absolute_T0, { prompt: p, model: m });
const s1c = (p, m) => find(S1.S1_consistency_T07, { prompt: p, model: m });
const s1p = (p, m) => find(S1.S1_pairwise, { prompt: p, model: m });
const t2 = (p, m, T) => find(S2.T2_consistency, { prompt: p, model: m, temperature: T });
const t3 = (s, metric, m) => find(S2.T3_deltas_vs_baseline, { strategy: s, metric, model: m });
const t4 = (p, m) => find(S2.T4_pairwise_T0, { prompt: p, model: m });
const t5 = (p, m) => find(S2.T5_pairwise_T07, { prompt: p, model: m });
const ci = (r) => `[${f2(r.ci_lo)}, ${f2(r.ci_hi)}]`;
const ppci = (r) => `[${r.ci_lo >= 0 ? "+" : ""}${Math.round(r.ci_lo * 100)}, ${r.ci_hi >= 0 ? "+" : ""}${Math.round(r.ci_hi * 100)}]`;
const arrow = (a, b, f = pct) => `${f(a)} → ${f(b)}`;
const R = D.runs;
const sumCalls = (pre) => Object.entries(R).filter(([k]) => k.startsWith(pre)).reduce((a, [, v]) => a + v.calls, 0);
const sumMin = (pre) => Object.entries(R).filter(([k]) => k.startsWith(pre)).reduce((a, [, v]) => a + v.gpu_minutes, 0);
const N1 = sumCalls("B1_"), N1b = sumCalls("B1b_"), N2 = sumCalls("B2_");
const verdictFill = (r) => (/PASS|PROMISING|Confirmed/.test(r[r.length - 1]) ? GOOD : (/FAIL|NOT|Avoid/.test(r[r.length - 1]) ? BAD : undefined));

// =====================================================================================
const C = [];

// ---------------- title page
C.push(
  new Paragraph({ spacing: { before: 1600, after: 120 }, children: [new TextRun({ text: "Vosyn Supernova · Sprint 53 · Task B", font: FONT, size: 22, color: GREY })] }),
  new Paragraph({ spacing: { after: 240 }, children: [new TextRun({ text: "Prompt Engineering for More Consistent and Reliable LLM-as-a-Judge Evaluation of English → Mandarin Translation", font: FONT, size: 42, bold: true, color: NAVY })] }),
  new Paragraph({ spacing: { after: 420 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: BLUE, space: 8 } },
    children: [new TextRun({ text: "Which prompt structures make the judge more consistent and more reliable — tested, confirmed on held-out data, and turned into guidelines", font: FONT, size: 24, color: BLUE })] }),
  table([2400, 6960], ["Item", "Detail"], [
    ["Sprint goal", "Improve the reliability and consistency of LLM-as-a-judge evaluation for English-to-Mandarin translation"],
    ["User story", "As an ML Engineer, I want to investigate prompt-engineering techniques that improve the consistency and reliability of LLM-as-a-Judge evaluations so that the judge produces more stable and trustworthy assessments of English-to-Mandarin translations."],
    ["Judges", `glm4 (9B) and qwen2.5 (7B) via Ollama ${D.env.ollama}, 4-bit, on a Google Colab ${D.env.gpu.split(",")[0]} — the Sprint 50 judges`],
    ["Strategies tested", "S1 defined scoring rubric · S2 few-shot calibration · S3 step-by-step criteria · S4 separate accuracy and fluency · S5 pairwise with tie definition and both orders · C combined prompt"],
    ["Scale", `${(N1 + N1b + N2).toLocaleString()} judge calls (${Math.round(sumMin("B") / 60 * 10) / 10} GPU-hours) · 40 real MT outputs with human scores · 275 reviewer-checked translation variants · 60 comparison pairs · split 20 / 20 English sources into development and held-out halves`],
    ["Outcome", "S5 confirmed for glm4 (pairwise). S2 strongly improves consistency and robustness but is not confirmed under the pre-registered rule. S1, S3, S4 and C not adopted. Recommendation and 15 guidelines in Sections 12–13."],
    ["Date", "3 October 2026"],
    ["Builds on", "Task A — Failure analysis of LLM-as-a-judge (Sprint53_TaskA_LLM_Judge_Failure_Analysis.docx)"],
  ], { zebra: false, shadeFirst: true, size: 19 }),
);

// ---------------- contents
C.push(H1("Contents"));
[
  "1. Executive summary", "2. The task", "3. Setup", "4. Data", "5. Baseline and how “better” was measured", "6. Strategies tested",
  "    6.3 Decisions made along the way", "7. How the experiments were run", "8. Stage 1 results (development half)",
  "9. Stage 1b — combined prompt C", "10. Stage 2 results (held-out half)", "    10.2 S2 few-shot vs baseline MQM",
  "    10.3 Why glm4 lost agreement with human scores", "    10.6 Pairwise: S5 vs baseline", "11. Consistency compared across all approaches",
  "12. Recommendation", "13. Guidelines", "14. Improvements and limitations", "15. Future work", "16. Acceptance criteria",
  "Appendix A. Prompts (verbatim)", "Appendix B. Files and how to reproduce", "Appendix C. Glossary",
].forEach((t) => C.push(new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: t, font: FONT, size: 22 })] })));

// ---------------- 1 executive summary
const g = (s, m, k) => t3(s, k, m);
C.push(H1("1. Executive summary"));
C.push(P(`Task A showed that the Sprint 50 judges are inconsistent (scores change between runs), inaccurate on close calls (the MQM prompt cannot separate a correct translation from one with a meaning error), sensitive to prompt wording and biased by the order of translations. Task B tested whether **changes to the prompt** can fix this. Five prompt-engineering strategies were each written to change one thing relative to the Sprint 50 prompts, screened on a development half of the data, and the survivors confirmed on a held-out half that was not used to design anything — ${(N1 + N1b + N2).toLocaleString()} judge calls in total, every strategy compared with the Sprint 50 baseline re-run in the same session, under success rules written down before the first run.`));
C.push(callout("Headline results", [
  `**Pairwise comparison — S5 is confirmed for glm4.** Defining “tie”, saying the order is random, asking for a short assessment of each translation first and judging both orders cut glm4’s habit of picking whichever translation is shown first from ${pct(t4("pairwise", "glm4").first_position_rate)} to ${pct(t4("pairwise_tie", "glm4").first_position_rate)}, and raised verdicts matching the expected answer from ${pct(t4("pairwise", "glm4").verdict_matches_expected)} to ${pct(t4("pairwise_tie", "glm4").verdict_matches_expected)} (95% CIs exclude zero). qwen did not change significantly.`,
  `**Few-shot calibration (S2) is the most effective change for consistency — but not confirmed.** Three worked examples, one of them a correct translation with no errors, cut items with inconsistent scores at temperature 0.7 from ${pct(t2("mqm", "glm4", 0.7).inconsistent_share)} to ${pct(t2("mqm_fewshot", "glm4", 0.7).inconsistent_share)} (glm4) and ${pct(t2("mqm", "qwen", 0.7).inconsistent_share)} to ${pct(t2("mqm_fewshot", "qwen", 0.7).inconsistent_share)} (qwen), halved score changes caused by rewording the prompt, and reduced errors flagged on correct translations for both judges (all CIs exclude zero). It fails the pre-registered rule because glm4’s agreement with human scores fell (ρ ${f2(t1("mqm", "glm4").rho_human_setA)} → ${f2(t1("mqm_fewshot", "glm4").rho_human_setA)}, not statistically significant on 20 items) — glm4 became too lenient on badly flawed machine translations, most likely because every example shows at most one error.`,
  `**What did not work.** A scoring rubric with band definitions (S1) made glm4 snap to the band edges (85 for 125 of 158 items); step-by-step criteria with “different wording is not an error” (S3) made both judges excuse real errors (planted-error detection ${pct(s1a("mqm", "glm4").planted_error_detected)} → ${pct(s1a("mqm_steps", "glm4").planted_error_detected)} for glm4); separate accuracy and fluency scores (S4) gave small gains and made qwen less consistent; a combined prompt (C) was not better than S2 alone.`,
  `**The plain Sprint 50 flat 0–100 prompt is still the most stable and the best at ranking translations** (ρ with true quality ${f2(t1("flat", "glm4").rho_true_band_setB)}–${f2(t1("flat", "qwen").rho_true_band_setB)} vs at most ${f2(t1("mqm_fewshot", "qwen").rho_true_band_setB)} for any MQM prompt), confirming Task A finding F1 on new data.`,
]));
C.push(gap());
C.push(P("**Recommendation (Section 12).** For comparing two translations, use S5 judged in both orders. For error annotation, use few-shot MQM (S2) as the structure, with a multi-error example added before production use — this addition is the main future-work item (Section 15). For a single quality score used to rank translations, keep the flat 0–100 prompt at temperature 0. Fifteen guidelines (Section 13) record what to do and what to avoid, each with its evidence and status."));
C.push(P("**Caveat.** Each half has only 20 English sources and 20 human-scored items, so effects smaller than about 15–20 percentage points cannot be confirmed, and correlations with human scores have very wide intervals. All results are for two small 4-bit open models."));

// ---------------- 2 task
C.push(H1("2. The task"));
C.push(H2("2.1 User story and description"));
C.push(P("**User story.** As an ML Engineer, I want to investigate prompt-engineering techniques that improve the consistency and reliability of LLM-as-a-Judge evaluations so that the judge produces more stable and trustworthy assessments of English-to-Mandarin translations."));
C.push(P("**Description.** Research and experiment with prompt-design strategies that may reduce variability in LLM-as-a-judge evaluation; compare prompt structures and evaluate their effect on consistency across repeated runs; recommend a prompt structure or guidelines."));
C.push(H2("2.2 Acceptance criteria"));
C.push(table([5200, 4160], ["Acceptance criterion", "Where it is met"], [
  ["A baseline evaluation prompt is established", "Section 5 — Sprint 50 flat and MQM prompts and the Task A pairwise prompt, verbatim, re-run in every session"],
  ["Multiple prompt-engineering approaches are designed and tested", "Sections 6–10 — S1–S5 and combined prompt C"],
  ["Experiments use representative English → Mandarin translation examples", "Section 4 — real MT with human scores + reviewer-checked controlled variants across 8 categories"],
  ["Each selected configuration is evaluated across repeated runs", "Sections 8–10 — 3 runs at T = 0.7 (screening); 3 runs at T = 0 and 5 at T = 0.7 (confirmation); 3 runs at T = 0.7 for pairwise"],
  ["Consistency is compared across approaches", "Section 11 and Figures 2, 4, 5"],
  ["Improvements and limitations are documented", "Sections 10, 14"],
  ["A recommended prompt structure or guidelines are proposed", "Sections 12–13"],
], { size: 17 }));
C.push(H2("2.3 Starting point: what Task A found"));
C.push(P("Task A (same sprint) ran 4,758 judge calls and catalogued thirteen failure modes. The ones that prompt engineering could plausibly address became the targets of Task B:"));
C.push(table([1000, 4400, 3960], ["Task A", "Failure", "Task B strategy aimed at it"], [
  ["F1", "MQM prompt cannot separate correct from one-error translations; flags errors on correct translations (glm4 98%, qwen 66%)", "S2 few-shot (incl. a no-error example), S3 valid-variation step"],
  ["F2 / F3", "Scores vary across runs, strongly at T > 0; T = 0 not fully reproducible", "S1 rubric (anchors), S2 calibration; all measured over repeated runs"],
  ["F4", "Rewording the prompt changes the verdict", "Wording-robustness test with two rewordings of every finalist"],
  ["F5", "Position bias: glm4 picks the first translation 72%, keeps verdict when swapped 48%", "S5 pairwise with tie definition and both orders"],
  ["F7", "glm4 quotes error spans that are not in the translation (32%), often the English source", "S3 delimiters + “quote only from the translation”"],
  ["F8 / F9", "Scale calibration; stiff literal translations not penalised", "S1 rubric; S4 separate accuracy and fluency"],
], { size: 16 }));
C.push(H2("2.4 Scope"));
C.push(B("In scope: prompt changes only — same judges, same quantisation, same decoding settings, same parsing and scoring as Sprint 50 and Task A."));
C.push(B("Out of scope: changing the judge models, fine-tuning, changing the MQM severity weights, or building a new evaluation dataset (the Task A datasets were reused and split)."));
C.push(B("Language: instructions in English (as Sprint 50); Mandarin only inside the translations and few-shot examples."));

// ---------------- 3 setup
C.push(H1("3. Setup"));
C.push(H2("3.1 Judges and platform"));
C.push(table([2600, 6760], ["Setting", "Value and reason"], [
  ["Judge models", `${D.env.models.glm4} and ${D.env.models.qwen} — the Sprint 50 tags; digests identical in all ${D.env.sessions} Task B sessions and in Task A`],
  ["Runtime", `Ollama ${D.env.ollama} on Google Colab free tier, ${D.env.gpu}. Task A used Ollama 0.35.0; because the baseline is re-run in every Task B session, comparisons are not affected`],
  ["No Google Drive", "At the user’s request. Code and data are uploaded as zip files each session; a checkpoint zip with all results is downloaded every 30 minutes and uploaded to resume"],
  ["Decoding", "Temperature 0 for the main runs (0.7 for repeat runs), seed = 1000 + run index, num_ctx 4096, output-length caps per format (flat 256, MQM 1024, step-by-step 1536, pairwise with assessments 768 tokens)"],
  ["Output handling", "No forced-JSON mode (as Sprint 50); a tolerant parser extracts the JSON; up to 3 attempts if unreadable; unreadable answers are kept and counted as “malformed”"],
  ["Scoring", "MQM score = 100 − Σ(minor 1, major 5, critical 25), floor 0, computed in code. S4 score = 0.8 × accuracy + 0.2 × fluency, computed in code"],
  ["One call at a time", "Parallel calls on a T4 slow each call and could change results; every call is saved to disk immediately, so a disconnect loses nothing"],
], { size: 17 }));
C.push(H2("3.2 How the work was organised"));
C.push(P("The task was run in seven steps. Each step was completed and its output confirmed before the next began; all code was run by the ML engineer on Colab, and every analysis was re-run from the downloaded checkpoint to make sure the numbers reproduce exactly."));
C.push(...figure("B_fig1_design.png", "Figure 1. The seven steps of Task B."));
C.push(table([1000, 2600, 5760], ["Step", "What", "Output"], [
  ["B1", "Baseline, data split, metrics and decision rules", "Split by English source (seed 1324, best of 2,000 candidate splits); `taskB/BASELINE_AND_METRICS.md` written before any Task B run"],
  ["B2", "Strategy prompts", "S1–S5 written; 3 few-shot examples from the development half, checked by a native Mainland Mandarin reviewer; automated checks (baseline unchanged, rendering, no held-out text in prompts, parser round-trip)"],
  ["B3", "GPU smoke test", "16/16 test calls readable, no answer cut off; time estimate"],
  ["B4", "Stage 1 screening (development half)", `${N1.toLocaleString()} calls, ${Math.round(sumMin("B1_"))} GPU-minutes; S2 and S5 pass`],
  ["B5", "Stage 1b (combined prompt C) and Stage 2 confirmation (held-out half)", `${N1b} + ${N2.toLocaleString()} calls, ${Math.round(sumMin("B1b_") + sumMin("B2_"))} GPU-minutes`],
  ["B6", "Stage 2 analysis", "Paired bootstrap comparisons, consistency, wording robustness, pairwise stability"],
  ["B7", "Recommendation and guidelines", "Sections 12–13 of this report"],
], { size: 17 }));

// ---------------- 4 data
const dv = D.counts.dev, ho = D.counts.heldout;
C.push(H1("4. Data"));
C.push(P("Task B reused the two datasets built and reviewed in Task A, so that every Task B number can be compared with the Task A failure analysis."));
C.push(table([1900, 7460], ["Dataset", "Content"], [
  ["Set A — real MT", "40 English → Mandarin machine translations from SiniticMTError with human MQM error annotations and scores (the Sprint 50 gold data). Used for agreement with human judgement"],
  ["Set B — controlled variants", "275 translations of 40 English sources in 8 categories (simple control, numbers/units/dates, named entities, terminology, idioms, culture, ambiguity/context, register). Each source has a correct gold translation, a valid paraphrase, a stiff literal version, a fluent-but-wrong version, a version with one planted error, and in some cases Traditional-script, padded or original-MT versions. Every row checked by a native Mainland Mandarin reviewer in Task A"],
  ["Pairs", "60 pairs for side-by-side judging: gold vs paraphrase (tie expected), literal vs fluent-but-wrong (literal expected), gold vs targeted error (gold expected), Simplified vs Traditional (tie, Task A decision: script is neutral), concise vs padded"],
], { size: 17 }));
C.push(H2("4.1 Development / held-out split"));
C.push(P("The data were split **by English source**, so all versions and pairs of one sentence fall in the same half and nothing about a held-out sentence can leak into prompt design. Set A items that are also Set B sources follow their source. The split was chosen as the most balanced of 2,000 seeded candidates (seed 1324): every category is within ±1 source between halves and both Set A halves have the same mean human score."));
C.push(table([3400, 2980, 2980], ["", "Development half", "Held-out half"], [
  ["English sources (Set B)", dv.sources, ho.sources],
  ["Set B rows", dv.setB, ho.setB],
  ["Set A items (mean human score)", `${dv.setA} (${dv.setA_mean})`, `${ho.setA} (${ho.setA_mean})`],
  ["Pairs", dv.pairs, ho.pairs],
  ["Used for", "Designing prompts and choosing few-shot examples; Stage 1 and Stage 1b screening", "Stage 2 confirmation only — results not looked at until Stage 2"],
], { size: 17, shadeFirst: true, zebra: false }));
C.push(P(`**Repeat subset (fixed in advance).** 40 held-out items used for all repeated-run and wording tests in Stage 2: all 20 held-out Set A items plus 20 Set B rows from 20 different sources (4 each of gold, paraphrase, literal, fluent-but-wrong and targeted-error).`));
C.push(P(`**Few-shot exclusion.** The two Set B sources and one Set A item used as few-shot examples (${D.fewshot.map((e) => "`" + e.item_id + "`").join(", ")}) are in the development half and were left out of Stage 1 scoring **for every prompt**, so no prompt was scored on its own examples. Stage 1 therefore scores 19 Set A items, 126 Set B rows and 26 pairs.`));

// ---------------- 5 baseline and metrics
C.push(H1("5. Baseline and how “better” was measured"));
C.push(H2("5.1 Baseline prompts"));
C.push(table([2200, 7160], ["Baseline", "Description"], [
  ["Flat 0–100", "Sprint 50 flat prompt, verbatim: “Rate the machine translation’s quality from 0 to 100…”, JSON `{\"score\": n}`"],
  ["MQM", "Sprint 50 MQM prompt, verbatim: list every error with span, type (8 categories) and severity; score computed in code. The Sprint 50 ensemble (median of glm4 and qwen MQM scores, which for two judges equals their mean) is also reported"],
  ["Pairwise", "Task A pairwise prompt: “Which translation is better? Answer A, B, or tie”, JSON `{\"better\": …}`"],
], { size: 17 }));
C.push(P("The baseline prompts were **re-run in every session alongside the strategies**, so that drift between sessions (Task A F3) cannot be mistaken for an improvement. Against the Task A run of the same prompts at temperature 0, 81–96% of baseline scores were identical (Section 10.8)."));
C.push(H2("5.2 Metrics"));
C.push(table([2900, 6460], ["Metric", "Definition"], [
  ["Inconsistent share", "Share of items whose repeated runs differ by ≥ 10 points or fall in different bands (clean ≥ 85, moderate 60–84, poor < 60) — the Task A definition"],
  ["Mean / max spread, Krippendorff α", "Run-to-run range in points; agreement of runs beyond chance (1 = identical)"],
  ["Wording robustness", "Mean absolute score change (and ρ) between a prompt and two rewordings that change only the English wording"],
  ["Agreement with humans", "Spearman ρ between judge score and human MQM score on Set A"],
  ["Tracks true quality", "Spearman ρ between judge score and the reviewer-confirmed quality band on Set B (Simplified, non-gold rows)"],
  ["Below gold (strict) / above gold", "Share of flawed versions (fluent-but-wrong, targeted error) scored strictly below / strictly above their own correct gold version"],
  ["Literal over fluent-wrong", "Share of sources where the correct but stiff literal version scores above the fluent but wrong version"],
  ["False errors on correct translations", "Share of correct translations (gold + valid paraphrase) with at least one listed error (MQM-style prompts)"],
  ["Spans not in translation", "Share of listed error spans that do not occur in the translation (MQM-style)"],
  ["Planted error detected", "A listed span contains or lies inside the planted error span (lower bound; Task A rule)"],
  ["First-position rate, order consistency", "Pairwise: share of verdicts for the translation shown first; share of pairs with the same verdict in both orders"],
  ["Verdict matches expected", "Pairwise: verdict equals the expected preference (gold, literal, tie…)"],
  ["Malformed", "Share of answers that could not be read after 3 attempts (Sprint 50 guardrail: ≤ 5%)"],
], { size: 16 }));
C.push(H2("5.3 Decision rules (written before any Task B run)"));
C.push(B("**Stage 1 (screening, development half, T = 0, one run):** a strategy goes forward if it improves its primary metric over the baseline for at least one judge, does not make any reliability metric clearly worse for either judge (more than 10 percentage points, or a drop in ρ of more than 0.15), and has ≤ 5% malformed output. At most 3 finalists plus one combined prompt."));
C.push(B("**Stage 2 (confirmation, held-out half):** a finalist is **promising** (confirmed) if its primary metric improves with a paired bootstrap 95% confidence interval (2,000 resamples, seed 42) that excludes zero for at least one judge, no other metric is clearly worse (same thresholds), and malformed output ≤ 5%. Resampling units: English sources for Set B metrics, items for Set A and repeat-subset metrics, pairs for pairwise metrics."));
C.push(B("**Combined prompt C (rule added in Step B5, before C was run):** C goes to Stage 2 only if it passes the Stage 1 rule against the baseline **and** is not clearly worse than S2 on any metric — otherwise S2 alone is the better choice."));
C.push(B("A strategy that helps only one judge is reported as judge-specific. Improvements that do not reach significance are reported as “directional, not confirmed”."));

// ---------------- 6 strategies
C.push(H1("6. Strategies tested"));
C.push(H2("6.1 Why these five"));
C.push(P("The story listed a range of candidate techniques. Five were chosen because each targets a specific Task A failure, can be tested by changing one thing relative to a Sprint 50 prompt, and fits the Colab free-tier budget. Two candidates were folded into the design rather than tested as separate strategies: **randomised / swapped translation order** is part of S5 (every pair is judged in both orders), and **prompt wording robustness** became a test applied to every finalist. **Structured JSON output** was already used by every prompt."));
C.push(table([1600, 2700, 1300, 3760], ["Strategy", "What changes vs its baseline", "Style", "Primary metric (fixed in advance)"], [
  ["S1 Scoring rubric", "Five score bands with definitions (85–100 meaning fully preserved and natural … 0–19 mostly wrong); “first decide the band, then the score”", "flat", "Consistency at T = 0.7 (inconsistent share, spread); glm4–qwen gap"],
  ["S2 Few-shot calibration", "Three worked examples with correct answers: a correct translation worded differently (no errors), one major meaning error, one minor omission from real MT", "MQM", "False errors on correct translations; flawed above gold"],
  ["S3 Step-by-step criteria", "Delimited source/translation; steps: meaning → names, numbers, terms → idioms and culture → valid variation (“different wording is NOT an error”) → list errors quoted from the translation only; one sentence per step", "MQM", "Spans not in translation; planted-error detection"],
  ["S4 Accuracy + fluency", "Two separate 0–100 scores, combined in code as 0.8 × accuracy + 0.2 × fluency", "flat", "Flawed below gold; literal correct over fluent-but-wrong"],
  ["S5 Pairwise with tie", "Assess each translation first; answer A or B only if clearly better; tie defined (incl. both correct, different wording); “order is random”; both orders judged", "pairwise", "Order consistency; first-position rate"],
  ["C Combined (Step B5)", "S2 examples + S3 delimiters + “quote only from the translation” + one-line checklist (meaning; names, numbers, dates, units, terms; idioms). Without S3’s valid-variation step", "MQM", "S2’s and S3’s primary metrics"],
], { size: 16 }));
C.push(H2("6.2 Few-shot examples and reviewer check"));
C.push(P("The three S2 examples were taken from the development half only and chosen to cover the cases Task A found the judges get wrong: a correct translation in different words (to teach that this is not an error), a fluent translation with one meaning error, and a real machine translation with a minor issue. A native Mainland Mandarin reviewer confirmed that each annotation and severity is correct."));
C.push(table([800, 3200, 2700, 2660], ["#", "Source → translation", "Answer shown to the judge", "Why"],
  D.fewshot.map((e, i) => [String(i + 1), `${e.source}\n${e.mt}`, e.answer.errors.length ? e.answer.errors.map((x) => `「${x.text}」 ${x.type}, ${x.severity}`).join("; ") : "No errors", e.why]), { size: 16 }));
C.push(P("All prompt texts are given verbatim in Appendix A."));
C.push(H2("6.3 Decisions made along the way"));
C.push(table([2500, 3300, 3560], ["Decision", "Options considered", "Chosen and why"], [
  ["Which strategies", "Candidate techniques listed in the story", "Five (S1–S5) — one per targeted Task A failure, each a one-change test (6.1). Approved by the user"],
  ["Scoring style per strategy", "Apply every strategy to both flat and MQM", "One style each, matched to the failure it targets; keeps the run on the free tier"],
  ["Split", "Random items; by source; no split", "20 / 20 by English source — no leakage between versions of a sentence; held-out half for confirmation"],
  ["Instruction language", "English or Chinese", "English, as Sprint 50 (Task A found Chinese instructions are a separate wording effect)"],
  ["Number of few-shot examples", "1–5", "3 — covers no-error, major and minor cases while keeping the prompt short on a T4"],
  ["S4 weights", "Equal; accuracy-heavy", "0.8 × accuracy + 0.2 × fluency — meaning errors matter more for GEPA; fixed before running"],
  ["Few-shot review", "Self-check; native reviewer", "Native Mainland reviewer — examples are shown to the judge as correct, so they must be right"],
  ["Stage 2 finalists", "Up to 3 + combined", "S2 and S5 (the only Stage 1 passes), approved by the user"],
  ["Combined prompt C", "Skip; build and go straight to Stage 2; build and screen first", "Built from the parts of S3 that did no harm and screened on the development half first; not taken forward (Section 9)"],
  ["Flat-style finalist", "Carry S1 forward as qwen-only", "None — S1 and S4 failed the rule; carrying a failed prompt would weaken the confirmation. Flat baseline kept as reference"],
  ["Rewordings review", "Reviewer; author only", "No reviewer — only English wording changes; few-shot examples byte-identical (checked automatically)"],
  ["Multi-error example (S2b)", "Test now on new data; future work", "Future work (agreed with the user) — the held-out half has been used, so a fair test needs fresh items"],
], { size: 16 }));

// ---------------- 7 experiment design
C.push(H1("7. How the experiments were run"));
C.push(H2("7.1 Stage 1 — screening on the development half"));
C.push(table([2000, 2700, 2300, 1100, 1260], ["Phase", "Data", "Prompts", "Temp × runs", "Calls"], [
  ["B1_baseline", "Set A + Set B (158 items)", "flat, MQM", "0 × 1", R.B1_baseline.calls],
  ["B1_S1_rubric … B1_S4_accflu", "Set A + Set B", "one strategy each", "0 × 1", 4 * R.B1_S1_rubric.calls],
  ["B1_pairwise", "28 pairs × 2 orders", "pairwise, S5", "0 × 1", R.B1_pairwise.calls],
  ["B1_repeat_T07", "Set A (20)", "all 6 absolute prompts", "0.7 × 3", R.B1_repeat_T07.calls],
  ["B1b_C_T0, B1b_C_repeat_T07", "as above", "combined C", "0 × 1; 0.7 × 3", N1b],
], { size: 16, alignRight: true, firstNumCol: 4 }));
C.push(P("Every call is made once per judge. Seeds are 1000 + run index, the same as Task A, so the baseline at temperature 0 can be compared directly with the Task A run of the same items."));
C.push(H2("7.2 Stage 2 — confirmation on the held-out half"));
C.push(table([2000, 2700, 2300, 1100, 1260], ["Phase", "Data", "Prompts", "Temp × runs", "Calls"], [
  ["B2_T0", "Set A + Set B (157 items)", "flat, MQM, S2", "0 × 1", R.B2_T0.calls],
  ["B2_pairwise_T0", "32 pairs × 2 orders", "pairwise, S5", "0 × 1", R.B2_pairwise_T0.calls],
  ["B2_repeat_T07", "repeat subset (40)", "flat, MQM, S2", "0.7 × 5", R.B2_repeat_T07.calls],
  ["B2_repeat_T0", "repeat subset (40)", "flat, MQM, S2", "0 × 2 more (3 in total)", R.B2_repeat_T0.calls],
  ["B2_pairwise_T07", "32 pairs × 2 orders", "pairwise, S5", "0.7 × 3", R.B2_pairwise_T07.calls],
  ["B2_wording", "repeat subset (40)", "2 rewordings each of MQM and S2", "0 × 1", R.B2_wording.calls],
  ["B2_wording_pairs", "32 pairs × 2 orders", "2 rewordings each of pairwise and S5", "0 × 1", R.B2_wording_pairs.calls],
], { size: 16, alignRight: true, firstNumCol: 4 }));
C.push(H2("7.3 Run log"));
const runRows = Object.entries(R).map(([k, v]) => [k, v.calls, v.malformed, v.retried, v.cut_off, f1(v.gpu_minutes)]);
C.push(table([3000, 1300, 1300, 1300, 1200, 1260], ["Phase", "Calls", "Unreadable", "Retried", "Cut off", "GPU min"], runRows, { size: 16, alignRight: true }));
C.push(cap(`Totals: ${(N1 + N1b + N2).toLocaleString()} calls, ${Object.values(R).reduce((a, v) => a + v.malformed, 0)} unreadable, ${Math.round(sumMin("B"))} GPU-minutes of judging (plus about 5 minutes of setup per session), ${D.env.sessions} Colab sessions, same model digests in all sessions.`));
C.push(P(`**36 of the 37 unreadable answers** come from glm4 on reworded pairwise prompts: it copied the format placeholder literally (\`{"better": "A|B|tie"}\`) in 25 of 64 answers to one rewording and 9 of 64 to another. The main prompts produced at most one unreadable answer in 2,840 + 436 + 3,330 calls. This is itself a finding (Section 10.7).`));

// ---------------- 8 stage 1 results
C.push(H1("8. Stage 1 results (development half)"));
C.push(P("Stage 1 is screening: one run at temperature 0 per item plus three runs at 0.7 on Set A. It decides which strategies are worth confirming; no claims are made from it alone."));
const dec1 = S1.S1_decisions;
const dname = { "S1 rubric": "S1 rubric", "S4 acc+flu": "S4 accuracy + fluency", "S2 few-shot": "S2 few-shot", "S3 steps": "S3 step-by-step", "S5 pairwise+tie": "S5 pairwise + tie", "C combined": "C combined (Stage 1b)" };
const s1prim = {
  "S1 rubric": `Inconsistent at T = 0.7: glm4 ${arrow(s1c("flat", "glm4").inconsistent_share, s1c("flat_rubric", "glm4").inconsistent_share)}, qwen ${arrow(s1c("flat", "qwen").inconsistent_share, s1c("flat_rubric", "qwen").inconsistent_share)}`,
  "S4 acc+flu": `Below gold: glm4 ${arrow(s1a("flat", "glm4").below_gold_strict, s1a("flat_accflu", "glm4").below_gold_strict)}, qwen ${arrow(s1a("flat", "qwen").below_gold_strict, s1a("flat_accflu", "qwen").below_gold_strict)}`,
  "S2 few-shot": `False errors on correct: glm4 ${arrow(s1a("mqm", "glm4").false_error_rate_on_correct, s1a("mqm_fewshot", "glm4").false_error_rate_on_correct)}, qwen ${arrow(s1a("mqm", "qwen").false_error_rate_on_correct, s1a("mqm_fewshot", "qwen").false_error_rate_on_correct)}; above gold qwen ${arrow(s1a("mqm", "qwen").above_gold, s1a("mqm_fewshot", "qwen").above_gold)}`,
  "S3 steps": `Spans not in translation: glm4 ${arrow(s1a("mqm", "glm4").spans_not_in_translation, s1a("mqm_steps", "glm4").spans_not_in_translation)}; detection glm4 ${arrow(s1a("mqm", "glm4").planted_error_detected, s1a("mqm_steps", "glm4").planted_error_detected)}`,
  "S5 pairwise+tie": `First-position: glm4 ${arrow(s1p("pairwise", "glm4").first_position_rate, s1p("pairwise_tie", "glm4").first_position_rate)}; order consistency glm4 ${arrow(s1p("pairwise", "glm4").order_consistent, s1p("pairwise_tie", "glm4").order_consistent)}`,
  "C combined": `False errors on correct: glm4 ${arrow(s1a("mqm", "glm4").false_error_rate_on_correct, s1a("mqm_combined", "glm4").false_error_rate_on_correct)}; spans not in translation glm4 ${arrow(s1a("mqm", "glm4").spans_not_in_translation, s1a("mqm_combined", "glm4").spans_not_in_translation)}`,
};
const worseTxt = (s) => s.replace(/rho_human_setA/g, "agreement with humans").replace(/rho_true_band_setB/g, "tracks true quality").replace(/below_gold_strict/g, "below gold").replace(/correct_below_85/g, "correct scored < 85").replace(/inconsistent_share/g, "inconsistent at T = 0.7").replace(/ -> /g, " → ");
C.push(table([1700, 4200, 2460, 1000], ["Strategy", "Primary metric (baseline → strategy)", "Clearly worse (guard)", "Rule"],
  dec1.map((r) => [dname[r.strategy], s1prim[r.strategy], r.clearly_worse === "none" ? "none" : worseTxt(r.clearly_worse), r.stage1_rule]),
  { size: 16, fill: (r, i) => (i === 3 ? (r[3] === "PASS" ? GOOD : BAD) : undefined) }));
C.push(cap("Table 8.1. Stage 1 decision. Full tables: analysis_taskB/stage1/. C passed against the baseline but failed the extra condition against S2 (Section 9)."));
C.push(...figure("B_fig2_stage1_consistency.png", "Figure 2. Stage 1 consistency: share of the 19 development Set A items whose three runs at temperature 0.7 are inconsistent, by prompt and judge."));
C.push(H2("8.1 What each strategy did"));
C.push(H3("S1 — scoring rubric: helps qwen, flattens glm4"));
C.push(P(`qwen became much more consistent (${pct(s1c("flat", "qwen").inconsistent_share)} → ${pct(s1c("flat_rubric", "qwen").inconsistent_share)} of items inconsistent). glm4 instead **snapped to the bottom of the bands**: it gave exactly 85 to 125 of 158 items and 60 to 29 more. With scores collapsed onto a few anchor values, glm4 could no longer separate a flawed version from its correct version (below gold ${pct(s1a("flat", "glm4").below_gold_strict)} → ${pct(s1a("flat_rubric", "glm4").below_gold_strict)}; ties with gold ${pct(s1a("flat", "glm4").tie_with_gold)} → ${pct(s1a("flat_rubric", "glm4").tie_with_gold)}). FAIL.`));
C.push(H3("S2 — few-shot calibration: improves everything screened"));
C.push(P(`Fewer false errors for both judges (the paired intervals excluded zero even on the development half), fewer flawed versions above gold, better consistency (glm4 ${pct(s1c("mqm", "glm4").inconsistent_share)} → ${pct(s1c("mqm_fewshot", "glm4").inconsistent_share)}, qwen ${pct(s1c("mqm", "qwen").inconsistent_share)} → ${pct(s1c("mqm_fewshot", "qwen").inconsistent_share)}), better planted-error detection for glm4 (${pct(s1a("mqm", "glm4").planted_error_detected)} → ${pct(s1a("mqm_fewshot", "glm4").planted_error_detected)}), and qwen’s agreement with humans rose from ${f2(s1a("mqm", "qwen").rho_human_setA)} to ${f2(s1a("mqm_fewshot", "qwen").rho_human_setA)} (19 items). No guard metric worse. PASS.`));
C.push(H3("S3 — step-by-step criteria: over-corrects into leniency"));
C.push(P(`Errors flagged on correct translations almost disappeared (glm4 ${pct(s1a("mqm", "glm4").false_error_rate_on_correct)} → ${pct(s1a("mqm_steps", "glm4").false_error_rate_on_correct)}), but so did real errors: glm4 found ${pct(s1a("mqm_steps", "glm4").planted_error_detected)} of planted errors (baseline ${pct(s1a("mqm", "glm4").planted_error_detected)}), listed ${f1(s1a("mqm_steps", "glm4").mean_errors_listed)} errors per item instead of ${f1(s1a("mqm", "glm4").mean_errors_listed)}, and its agreement with humans fell from ${f2(s1a("mqm", "glm4").rho_human_setA)} to ${f2(s1a("mqm_steps", "glm4").rho_human_setA)}. The written steps show why — the “valid variation” step was used to explain real errors away:`));
C.push(table([2600, 6760], ["", "Example (glm4, S3, development half)"], [
  ["Source", "The password is \"Muiriel\"."],
  ["Translation (planted error)", "密码不是“Muiriel”。  (“The password is **not** Muiriel”)"],
  ["glm4 step “meaning”", "“…correctly conveys the meaning that the password is not 'Muiriel'.”"],
  ["glm4 step “valid variation”", "“The translation uses a different sentence structure … but maintains the same meaning.”"],
  ["Errors listed", "none → score 100"],
], { size: 16, shadeFirst: true, zebra: false }));
C.push(P("FAIL (glm4 agreement with humans dropped by more than 0.15)."));
C.push(H3("S4 — separate accuracy and fluency: small gains, less consistent"));
C.push(P(`Flawed versions below gold rose slightly for both judges (glm4 ${pct(s1a("flat", "glm4").below_gold_strict)} → ${pct(s1a("flat_accflu", "glm4").below_gold_strict)}, qwen ${pct(s1a("flat", "qwen").below_gold_strict)} → ${pct(s1a("flat_accflu", "qwen").below_gold_strict)}), but qwen’s scores became less consistent across runs (${pct(s1c("flat", "qwen").inconsistent_share)} → ${pct(s1c("flat_accflu", "qwen").inconsistent_share)} inconsistent). FAIL.`));
C.push(H3("S5 — pairwise with tie definition: removes most of glm4’s position bias"));
C.push(P(`glm4 picked the first-shown translation ${pct(s1p("pairwise_tie", "glm4").first_position_rate)} of the time instead of ${pct(s1p("pairwise", "glm4").first_position_rate)}, and verdicts matched the expected answer ${pct(s1p("pairwise_tie", "glm4").verdict_matches_expected)} of the time for both judges (baseline ${pct(s1p("pairwise", "glm4").verdict_matches_expected)} glm4, ${pct(s1p("pairwise", "qwen").verdict_matches_expected)} qwen). Ties rose to about 40%. PASS.`));

// ---------------- 9 stage 1b
C.push(H1("9. Stage 1b — combined prompt C"));
C.push(P("The plan allowed one combined prompt built from the best Stage 1 elements. C kept S2’s examples and added the parts of S3 that had not caused harm — the clear source/translation delimiters, “quote each error exactly as it appears in the translation, never the English source”, and a one-line checklist (meaning; names, numbers, dates, units, terms; idioms) — while leaving out S3’s valid-variation step. Because C is new, it was screened on the development half first (436 calls) against a rule fixed before it ran: pass the Stage 1 rule against the baseline **and** not be clearly worse than S2."));
const cs2 = S1.S1b_C_vs_S2;
const cnames = { rho_human_setA: "Agreement with humans (ρ)", rho_true_band_setB: "Tracks true quality (ρ)", below_gold_strict: "Flawed below gold", above_gold: "Flawed above gold", band_accuracy_setB: "Band accuracy", correct_below_85: "Correct scored < 85", false_error_rate_on_correct: "False errors on correct", spans_not_in_translation: "Spans not in translation", planted_error_detected: "Planted error detected", malformed: "Unreadable", inconsistent_share: "Inconsistent at T = 0.7" };
C.push(table([3200, 1000, 1300, 1300, 1260, 1300], ["Metric", "Judge", "S2", "C", "C better?", "Clearly worse?"],
  cs2.filter((r) => r.metric !== "malformed").map((r) => [cnames[r.metric] || r.metric, r.model, /rho/.test(r.metric) ? f2(r.S2) : pct(r.S2), /rho/.test(r.metric) ? f2(r.C) : pct(r.C), r.C_better ? "yes" : "no", r.clearly_worse ? "**yes**" : "no"]),
  { size: 16, fill: (r, i) => (i === 5 && r[5] === "**yes**" ? BAD : undefined) }));
C.push(cap("Table 9.1. Combined prompt C vs S2 on the development half (same items, same session)."));
C.push(P(`**Result.** C passed against the baseline, and it improved two things over S2 for glm4 — error spans not in the translation (${pct(find(cs2, { metric: "spans_not_in_translation", model: "glm4" }).S2)} → ${pct(find(cs2, { metric: "spans_not_in_translation", model: "glm4" }).C)}) and false errors on correct translations (${pct(find(cs2, { metric: "false_error_rate_on_correct", model: "glm4" }).S2)} → ${pct(find(cs2, { metric: "false_error_rate_on_correct", model: "glm4" }).C)}). But it was clearly worse than S2 on qwen’s agreement with humans, glm4’s planted-error detection and glm4’s consistency. Under the rule, **C did not go to Stage 2**; Stage 2 ran ${N2.toLocaleString()} calls instead of 5,512. The “quote only from the translation” instruction is kept as a directional finding and a future-work item (FW2).`));

// ---------------- 10 stage 2
C.push(H1("10. Stage 2 results (held-out half)"));
C.push(P("Stage 2 tested the finalists S2 and S5 on the 20 held-out sources that had not been used for any design decision, against the baseline re-run in the same session. All intervals are paired bootstrap 95% CIs."));
C.push(H2("10.1 Main run (temperature 0, 157 items)"));
const rowT1 = (p, m) => { const r = t1(p, m); return [({ flat: "flat (baseline)", mqm: "MQM (baseline)", mqm_fewshot: "S2 few-shot" })[p], m === "ens" ? "ensemble" : m, `${f2(r.rho_human_setA)} ${r.rho_human_ci}`, f2(r.rho_true_band_setB), pct(r.below_gold_strict), pct(r.above_gold), pct(r.literal_beats_fluent_wrong), r.false_error_rate_on_correct == null ? "–" : pct(r.false_error_rate_on_correct), r.planted_error_detected == null ? "–" : pct(r.planted_error_detected)]; };
C.push(table([1500, 900, 1500, 1000, 900, 900, 1000, 900, 900], ["Prompt", "Judge", "Agree w/ humans ρ [CI]", "Tracks quality ρ", "Below gold", "Above gold", "Literal > fluent-wrong", "False errors", "Error found"],
  ["flat", "mqm", "mqm_fewshot"].flatMap((p) => ["glm4", "qwen", "ens"].map((m) => rowT1(p, m))), { size: 15 }));
C.push(cap("Table 10.1. Held-out main run. Ensemble = mean of glm4 and qwen (Sprint 50 median of two). “Error found” = planted-error detection (MQM-style prompts only)."));
C.push(H2("10.2 S2 few-shot vs baseline MQM"));
C.push(...figure("B_fig4_s2_deltas.png", "Figure 3. Change with S2 on the held-out half, oriented so that right is better. Dots = estimate; lines = 95% paired bootstrap CI. A line that crosses zero is not statistically supported."));
const s2rows = [["false_error_rate_on_correct", "False errors on correct (PRIMARY)"], ["above_gold", "Flawed above gold (PRIMARY)"], ["below_gold_strict", "Flawed below gold"], ["planted_error_detected", "Planted error detected"], ["spans_not_in_translation", "Spans not in translation"], ["major_or_critical_on_correct", "Major/critical error on correct"], ["correct_below_85", "Correct scored < 85"], ["literal_beats_fluent_wrong", "Literal over fluent-wrong"], ["rho_true_band_setB", "Tracks true quality (ρ)"], ["rho_human_setA", "Agreement with humans (ρ)"], ["inconsistent_share_T0.0", "Inconsistent, T = 0 × 3"], ["inconsistent_share_T0.7", "Inconsistent, T = 0.7 × 5"], ["mean_spread_T0.7", "Mean spread, T = 0.7 (points)"], ["wording_mean_abs_change", "Score change under rewording (points)"]];
const fmtv = (k, v) => (/rho/.test(k) ? f2(v) : (/spread|wording/.test(k) ? f1(v) : pct(v)));
const fmtci = (k, r) => (/rho|spread|wording/.test(k) ? `[${f2(r.ci_lo)}, ${f2(r.ci_hi)}]` : ppci(r));
const s2tab = [];
for (const [k, lab] of s2rows) for (const m of ["glm4", "qwen"]) {
  const r = t3("S2 few-shot", k, m);
  s2tab.push([lab, m, fmtv(k, r.baseline), fmtv(k, r.strategy_value), fmtci(k, r), r.clearly_worse ? "clearly worse" : (Math.abs(r.delta) < 1e-9 ? "no change" : (r.better && r.ci_excludes_zero ? "better (CI)" : (r.better ? "better (n.s.)" : "worse (n.s.)")))]);
}
C.push(table([3100, 900, 1200, 1200, 1660, 1300], ["Metric", "Judge", "MQM", "S2", "95% CI of change", "Verdict"], s2tab,
  { size: 15, fill: (r, i) => (i === 5 ? (r[5] === "better (CI)" ? GOOD : (r[5] === "clearly worse" ? BAD : undefined)) : undefined) }));
C.push(cap("Table 10.2. S2 vs baseline MQM, held-out half. CI of the change in percentage points for shares, in raw units for ρ and points. “n.s.” = interval includes zero."));
C.push(P(`**Reading.** On its primary target S2 is confirmed for both judges (false errors on correct translations, intervals exclude zero). Many secondary measures also improve with intervals excluding zero — consistency at temperature 0.7, spread, robustness to rewording, glm4’s span validity and error detection, qwen’s paired contrast. Two measures crossed the pre-registered “clearly worse” threshold on the point estimate: **glm4’s agreement with human scores** (${f2(t3("S2 few-shot", "rho_human_setA", "glm4").baseline)} → ${f2(t3("S2 few-shot", "rho_human_setA", "glm4").strategy_value)}, CI of the change ${ci(t3("S2 few-shot", "rho_human_setA", "glm4"))}) and **qwen’s literal-over-fluent-wrong** (${pct(t3("S2 few-shot", "literal_beats_fluent_wrong", "qwen").baseline)} → ${pct(t3("S2 few-shot", "literal_beats_fluent_wrong", "qwen").strategy_value)}, 3 of 20 sources). Neither change is statistically significant, but the rule fixed in advance uses the point estimate, so **S2 is reported as “not confirmed”**. The rule was not changed after seeing the data.`));
C.push(H2("10.3 Why glm4 lost agreement with human scores"));
C.push(P(`With S2, glm4 is more lenient on real machine translations with many errors. On held-out Set A items with five or more human-marked errors it listed 3.2 errors per item instead of 4.8, and the two worst items (human scores 65 and 70) received 84 and 89. The three few-shot examples contain at most one error each, so glm4 appears to have learned “a translation has zero or one error”. qwen did not show this (its agreement with humans rose from ${f2(t1("mqm", "qwen").rho_human_setA)} to ${f2(t1("mqm_fewshot", "qwen").rho_human_setA)}). One item shows both the Task A failure that S2 fixes and the new one it introduces:`));
C.push(table([2400, 6960], ["", "A::en_to_cmn_1832 (held-out Set A, human score 70, six major errors)"], [
  ["Source", "Many German baked goods also feature almonds, hazelnuts, and other tree nuts. Popular cakes often pair particularly well with a cup of strong coffee."],
  ["Machine translation", "许多德国的制品也提供杏仁,海和其他树. 流行蛋糕通常与一杯强烈咖啡结合得特别好."],
  ["Human errors", "制品, 提供, 海, 树, 流行, 强烈 — all major"],
  ["glm4, baseline MQM → 54", "14 “errors”, almost all quoting the **English source** (“Many German baked goods also feature…”, “provide”, “pair”) — Task A failure F7"],
  ["glm4, S2 few-shot → 89", "3 errors, all quoted correctly from the Chinese (许多德国的制品也提供杏仁…, 海和其他树, 流行蛋糕…), but too few and one marked minor → score too high"],
], { size: 16, shadeFirst: true, zebra: false }));
C.push(P("The fix — adding a fourth example with several errors of mixed severity — is the main future-work item (FW1, Section 15)."));
C.push(H2("10.4 Consistency across repeated runs"));
C.push(...figure("B_fig3_stage2_consistency.png", "Figure 4. Stage 2 consistency on the 40-item held-out repeat subset: share of items whose runs disagree (≥ 10 points or a band change)."));
const crow = (p, m, T) => { const r = t2(p, m, T); return [({ flat: "flat (baseline)", mqm: "MQM (baseline)", mqm_fewshot: "S2 few-shot" })[p], m, T === 0 ? "0 × 3" : "0.7 × 5", pct(r.inconsistent_share), pct(r.identical_all_runs), f1(r.mean_spread), String(Math.round(r.max_spread)), f2(r.kripp_alpha_runs)]; };
C.push(table([1700, 900, 1100, 1300, 1300, 1100, 900, 1060], ["Prompt", "Judge", "Temp × runs", "Inconsistent", "Identical in all runs", "Mean spread", "Max spread", "Kripp. α"],
  [0, 0.7].flatMap((T) => ["flat", "mqm", "mqm_fewshot"].flatMap((p) => ["glm4", "qwen"].map((m) => crow(p, m, T)))), { size: 15 }));
C.push(cap("Table 10.3. Held-out repeated runs (40 items). Run 0 at temperature 0 is the main run; runs 1–2 used seeds 1001–1002."));
C.push(P(`At temperature 0.7, S2 cut inconsistent items from ${pct(t2("mqm", "glm4", 0.7).inconsistent_share)} to ${pct(t2("mqm_fewshot", "glm4", 0.7).inconsistent_share)} (glm4) and from ${pct(t2("mqm", "qwen", 0.7).inconsistent_share)} to ${pct(t2("mqm_fewshot", "qwen", 0.7).inconsistent_share)} (qwen), and the average run-to-run spread from ${f1(t2("mqm", "glm4", 0.7).mean_spread)} to ${f1(t2("mqm_fewshot", "glm4", 0.7).mean_spread)} and ${f1(t2("mqm", "qwen", 0.7).mean_spread)} to ${f1(t2("mqm_fewshot", "qwen", 0.7).mean_spread)} points (all intervals exclude zero). At temperature 0, qwen with S2 gave the same verdict band on every item in every run. The flat prompt remains the most reproducible at temperature 0 (${pct(t2("flat", "glm4", 0).identical_all_runs)} and ${pct(t2("flat", "qwen", 0).identical_all_runs)} of items identical in all three runs).`));
C.push(H2("10.5 Robustness to prompt wording"));
C.push(...figure("B_fig6_wording.png", "Figure 5. Mean absolute score change when only the English wording of the prompt changes (two rewordings, 40 held-out items)."));
const wr = S2.T6_wording_robustness.filter((r) => ["mqm", "mqm_fewshot"].includes(r.prompt));
C.push(table([1700, 2100, 900, 1300, 1300, 1060, 1000], ["Prompt", "Rewording", "Judge", "ρ with original", "Mean |change|", "Moved ≥ 10", "Band changed"],
  wr.map((r) => [r.prompt === "mqm" ? "MQM (baseline)" : "S2 few-shot", "`" + r.rewording + "`", r.model, f2(r.rho_vs_original), f1(r.mean_abs_change), pct(r.moved_10plus), pct(r.band_changed)]), { size: 15 }));
C.push(cap("Table 10.4. Wording robustness. Rewording 1 keeps the sentence order; rewording 2 also reorders and reframes. Baseline rewording 1 is the Task A `mqm_reworded` prompt."));
C.push(P(`With the baseline prompt, rewording moved scores by ${f2(t3("S2 few-shot", "wording_mean_abs_change", "glm4").baseline)} (glm4) and ${f2(t3("S2 few-shot", "wording_mean_abs_change", "qwen").baseline)} (qwen) points on average and changed the band of up to 35% of items. With S2 the change fell to ${f2(t3("S2 few-shot", "wording_mean_abs_change", "glm4").strategy_value)} and ${f2(t3("S2 few-shot", "wording_mean_abs_change", "qwen").strategy_value)} points (intervals exclude zero): the worked examples anchor the judge more than the exact instructions do.`));
C.push(H2("10.6 Pairwise: S5 vs baseline"));
C.push(...figure("B_fig5_pairwise.png", "Figure 6. Held-out pairwise results, 32 pairs each judged in both orders at temperature 0."));
const prow = (p, m) => { const r = t4(p, m); const s = t5(p, m); return [p === "pairwise" ? "pairwise (baseline)" : "S5 pairwise + tie", m, pct(r.first_position_rate), pct(r.order_consistent), pct(r.verdict_matches_expected), pct(r.flawed_preferred), pct(r.tie_rate), pct(s.same_verdict_all_3_runs)]; };
C.push(table([1800, 800, 1100, 1200, 1200, 1100, 900, 1260], ["Prompt", "Judge", "Picks first", "Same in both orders", "Matches expected", "Prefers flawed", "Ties", "Stable over 3 runs at T = 0.7"],
  ["pairwise", "pairwise_tie"].flatMap((p) => ["glm4", "qwen"].map((m) => prow(p, m))), { size: 15 }));
C.push(cap("Table 10.5. Pairwise, held-out half. “Stable over 3 runs” = share of pair-orders with the same verdict in all three runs at temperature 0.7."));
const s5 = (k, m) => t3("S5 pairwise+tie", k, m);
C.push(P(`For glm4, S5 cut first-position picks from ${pct(s5("first_position_rate", "glm4").baseline)} to ${pct(s5("first_position_rate", "glm4").strategy_value)} (CI of change ${ppci(s5("first_position_rate", "glm4"))} points), raised verdicts matching the expected answer from ${pct(s5("verdict_matches_expected", "glm4").baseline)} to ${pct(s5("verdict_matches_expected", "glm4").strategy_value)} (${ppci(s5("verdict_matches_expected", "glm4"))}) and lowered preference for the flawed translation from ${pct(s5("flawed_preferred", "glm4").baseline)} to ${pct(s5("flawed_preferred", "glm4").strategy_value)} (${ppci(s5("flawed_preferred", "glm4"))}). Order consistency rose ${pct(s5("order_consistent", "glm4").baseline)} → ${pct(s5("order_consistent", "glm4").strategy_value)} but not significantly. For qwen no change was significant. Ties rose to ${pct(t4("pairwise_tie", "glm4").tie_rate)} for both judges — mostly on pairs where a tie is the right answer (glm4 ties on tie-pairs ${pct(t4("pairwise", "glm4").ties_on_tie_pairs)} → ${pct(t4("pairwise_tie", "glm4").ties_on_tie_pairs)}).`));
C.push(table([2600, 6760], ["", "P::gold_vs_targeted_error::S52_005 (held-out, glm4)"], [
  ["Source", "I will be back soon."],
  ["Translations", "a: 我很快就回来。 (correct)   b: 我明天就回来。 (“tomorrow” — planted error)"],
  ["Baseline pairwise", "Answers “A” in both orders — i.e. prefers the correct one when it is shown first and the wrong one when it is shown first"],
  ["S5", "Prefers the correct translation in both orders. Assessment of the wrong one: “introduces a specific time frame (‘tomorrow’) that is not present in the source text”"],
], { size: 16, shadeFirst: true, zebra: false }));
C.push(P(`**Wording.** glm4’s S5 verdicts agreed with its reworded versions less often than the baseline’s (${pct(t3("S5 pairwise+tie", "wording_verdict_agreement", "glm4").strategy_value)} vs ${pct(t3("S5 pairwise+tie", "wording_verdict_agreement", "glm4").baseline)}), but part of the baseline’s stability is simply that it nearly always answers “A”. qwen’s S5 verdicts were as stable as its baseline (${pct(t3("S5 pairwise+tie", "wording_verdict_agreement", "qwen").strategy_value)} vs ${pct(t3("S5 pairwise+tie", "wording_verdict_agreement", "qwen").baseline)}).`));
C.push(H2("10.7 Output-format failures under rewording"));
C.push(P("All 36 unreadable answers in Stage 2 came from glm4 on reworded pairwise prompts. In the second rewording of the baseline pairwise prompt glm4 returned the placeholder from the instructions verbatim — `{\"better\": \"A|B|tie\"}` — in 25 of 64 calls (39%); in the second rewording of S5, 9 of 64 (14%); and 2 of 64 in the first S5 rewording. The original prompts use the same placeholder without trouble, so the format instruction is fragile: a small wording change can push glm4 into copying it. Guideline G8 addresses this."));
C.push(H2("10.8 Stage 2 decision"));
const dec2 = S2.T3_decision;
C.push(table([1700, 3000, 2700, 1960], ["Finalist", "Primary metric improved (CI excludes 0)", "Clearly worse (point estimate)", "Pre-registered verdict"],
  dec2.map((r) => [r.strategy === "S2 few-shot" ? "S2 few-shot" : "S5 pairwise + tie", r.primary_improved_CI_excl_0.replace(/false_error_rate_on_correct/g, "false errors on correct").replace(/first_position_rate/g, "first-position rate"), r.clearly_worse === "none" ? "none" : r.clearly_worse.replace(/rho_human_setA/g, "agreement with humans").replace(/literal_beats_fluent_wrong/g, "literal over fluent-wrong").replace(/->/g, " → "), r.stage2_rule === "PROMISING" ? "PROMISING (confirmed, glm4-specific)" : "NOT CONFIRMED (directional)"]),
  { size: 16, fill: (r, i) => (i === 3 ? (/PROMISING/.test(r[3]) ? GOOD : MID) : undefined) }));
C.push(P(`**Baseline drift.** Re-running the Sprint 50 prompts in Task B reproduced the Task A score exactly for ${S2.T7_drift_vs_taskA.map((r) => pct(r.identical)).join(", ")} of items (glm4 flat, glm4 MQM, qwen flat, qwen MQM). This is why every strategy was compared with a baseline run in the same session.`));

// ---------------- 11 consistency comparison
C.push(H1("11. Consistency compared across all approaches"));
C.push(P("The acceptance criteria ask for consistency to be compared across approaches. The table brings together every prompt tested, on the data where it was measured."));
const crow1 = (p, lab) => ["glm4", "qwen"].map((m) => { const r = s1c(p, m); return r ? `${pct(r.inconsistent_share)} / ${f1(r.mean_spread)}` : "–"; });
const c2r = (p, T) => ["glm4", "qwen"].map((m) => { const r = t2(p, m, T); return r ? `${pct(r.inconsistent_share)} / ${f1(r.mean_spread)}` : "–"; });
C.push(table([2600, 1700, 1700, 1700, 1660], ["Prompt", "Stage 1 dev, T = 0.7 × 3\nglm4", "Stage 1 dev, T = 0.7 × 3\nqwen", "Stage 2 held-out, T = 0.7 × 5\nglm4", "Stage 2 held-out, T = 0.7 × 5\nqwen"], [
  ["flat (baseline)", ...crow1("flat"), ...c2r("flat", 0.7)],
  ["S1 rubric", ...crow1("flat_rubric"), "–", "–"],
  ["S4 accuracy + fluency", ...crow1("flat_accflu"), "–", "–"],
  ["MQM (baseline)", ...crow1("mqm"), ...c2r("mqm", 0.7)],
  ["S2 few-shot", ...crow1("mqm_fewshot"), ...c2r("mqm_fewshot", 0.7)],
  ["S3 step-by-step", ...crow1("mqm_steps"), "–", "–"],
  ["C combined", ...crow1("mqm_combined"), "–", "–"],
], { size: 16, shadeFirst: true }));
C.push(cap("Table 11.1. Share of items inconsistent / mean run-to-run spread in points. Stage 1: 19 development Set A items; Stage 2: 40 held-out repeat-subset items. Pairwise consistency is in Table 10.5."));
C.push(B("**Few-shot calibration (S2) gave the largest consistency gain** for MQM scoring on both halves and both judges."));
C.push(B("**S3 was also very consistent, but for the wrong reason** — it gave nearly every translation 100 (Section 8.1)."));
C.push(B("**A rubric (S1) made qwen much more consistent but not glm4**; separate accuracy/fluency scores (S4) made qwen less consistent."));
C.push(B("**Temperature matters more than any prompt:** at temperature 0 every prompt had at most 20% inconsistent items; at 0.7 the baseline MQM prompt had 98% for glm4."));

// ---------------- 12 recommendation
C.push(H1("12. Recommendation"));
C.push(table([2200, 2700, 1500, 2960], ["Use case", "Recommended prompt", "Status", "Main evidence"], [
  ["Comparing two translations", "**S5 pairwise with tie definition**, judged in both orders; an order disagreement counts as a tie", "Confirmed (glm4)", `glm4 first-position ${pct(t4("pairwise", "glm4").first_position_rate)} → ${pct(t4("pairwise_tie", "glm4").first_position_rate)}; matches expected ${pct(t4("pairwise", "glm4").verdict_matches_expected)} → ${pct(t4("pairwise_tie", "glm4").verdict_matches_expected)} (CIs exclude 0)`],
  ["Error annotation (MQM lists)", "**S2 few-shot MQM**, with a multi-error example added before production (FW1)", "Directional", "False errors ↓ both judges; inconsistency and rewording effects roughly halved (CIs exclude 0); glm4 human agreement ↓ (n.s.)"],
  ["One score to rank translations", "**Sprint 50 flat 0–100**, temperature 0", "Baseline retained", `Most reproducible; tracks true quality ρ ${f2(t1("flat", "glm4").rho_true_band_setB)}–${f2(t1("flat", "qwen").rho_true_band_setB)} vs ≤ ${f2(t1("mqm_fewshot", "qwen").rho_true_band_setB)} for MQM prompts`],
  ["Not recommended", "S1 rubric, S3 step-by-step, S4 accuracy + fluency, combined C", "Avoid / not adopted", "Sections 8–9"],
], { size: 16, fill: (r, i) => (i === 2 ? (/Confirmed/.test(r[2]) ? GOOD : (/Directional/.test(r[2]) ? MID : (/Avoid/.test(r[2]) ? BAD : undefined))) : undefined) }));
C.push(gap());
C.push(P("**Judge set-up for all three:** temperature 0, fixed seed and context length, no forced JSON with a tolerant parser, scores computed in code, unreadable-output guardrail ≤ 5%, and the Ollama version and model digests recorded every session. For decisions that matter, run three times and take the median."));
C.push(P("**For the Sprint 50 ensemble (glm4 + qwen MQM):** with S2 the two judges agree much more closely (mean gap " + f1(t1("mqm", "ens").mean_abs_judge_gap) + " → " + f1(t1("mqm_fewshot", "ens").mean_abs_judge_gap) + " points), and the ensemble separates flawed from correct versions better (below gold " + pct(t1("mqm", "ens").below_gold_strict) + " → " + pct(t1("mqm_fewshot", "ens").below_gold_strict) + "; above gold " + pct(t1("mqm", "ens").above_gold) + " → " + pct(t1("mqm_fewshot", "ens").above_gold) + "), but its agreement with human scores on real MT fell (" + f2(t1("mqm", "ens").rho_human_setA) + " → " + f2(t1("mqm_fewshot", "ens").rho_human_setA) + "), driven by glm4. Until FW1 is done, the safest MQM configuration is **qwen with S2**, or the ensemble with S2 monitored against human scores."));
C.push(H2("12.1 Recommended prompt structure"));
C.push(P("**Pairwise (S5)** — building blocks, in order:"));
C.push(...numbered(["Role line, source, Translation A, Translation B (as Sprint 50).", "“First assess each translation on its own: note any meaning errors (mistranslation, omission, addition) and any problems with naturalness. Then compare them.”", "Decision rule: A or B only if clearly better (fewer or less serious meaning errors; if both accurate, clearly more natural).", "Tie definition: equally good or equally flawed, **including both correct but worded differently**.", "“The order in which the translations are shown is random and must not affect your decision.”", "JSON output with an assessment of each translation and the verdict — written with concrete values (G8).", "Run in both orders; map back to the original translations; disagreement = tie."]));
C.push(P("**Error annotation (S2, to be extended)** — building blocks:"));
C.push(...numbered(["Role line and the Sprint 50 MQM instruction (error span, type from 8 categories, severity).", "JSON output format.", "Worked examples with correct answers, reviewed by a native speaker: one **correct translation worded differently with no errors**, one with a single major meaning error, one with a minor issue — and (FW1) **one real MT with several errors of mixed severity**.", "The translation to evaluate, then “Answer:”.", "Score computed in code from the error list."]));
C.push(P("Full texts are in Appendix A."));

// ---------------- 13 guidelines
C.push(H1("13. Guidelines"));
C.push(P("Status: **Confirmed** = passed the held-out rule · **Directional** = consistent improvement, partly statistically supported, not confirmed by the rule · **Avoid** = made things worse · **Method** = how to run and validate · **Untested** = proposed, needs an experiment."));
const G = [
  ["G1", "Calibrate with few-shot examples, and include a correct translation with no errors.", "Directional", "False errors glm4 100% → 90%, qwen 60% → 43%; inconsistency at T = 0.7 roughly halved (all CIs exclude 0)"],
  ["G2", "Cover the full range of errors in the examples, including one with several errors of mixed severity.", "Untested", "glm4 + S2 listed 4.8 → 3.2 errors on heavily flawed MT; human agreement 0.55 → 0.16"],
  ["G3", "Take few-shot examples only from development data, have a native speaker check them, and exclude their sources from scoring.", "Method", "Reviewer approved all three; automated check that no held-out text is in any prompt"],
  ["G4", "Do not add a separate “different wording is not an error” step; show it with an example instead.", "Avoid", "S3: planted-error detection 58% → 17% (glm4); real errors explained away"],
  ["G5", "Do not give glm4 score-band anchors.", "Avoid (glm4)", "S1: glm4 gave 85 to 125 of 158 items; below gold 78% → 44%. qwen benefited (judge-specific)"],
  ["G6", "Do not split accuracy and fluency into two sub-scores for these judges.", "Avoid", "S4: small gains; qwen inconsistency 53% → 68%"],
  ["G7", "Pairwise: define tie, say the order is random, assess each translation first, judge both orders.", "Confirmed (glm4)", "First-position 70% → 31%; matches expected 38% → 61%; prefers flawed 13% → 5%"],
  ["G8", "Show the output format with concrete values, not a placeholder like \"A|B|tie\"; list allowed values in words.", "Directional", "glm4 copied the placeholder in 39% of answers to one rewording; all 36 unreadable answers"],
  ["G9", "Use a single flat score to rank translations; use MQM lists for diagnosis.", "Baseline", "Tracks true quality: flat ρ 0.55–0.58 vs MQM ≤ 0.11, S2 ≤ 0.32"],
  ["G10", "Run at temperature 0 with fixed seed and context; record versions; for important decisions run 3 times and take the median.", "Method", "Baseline MQM glm4 inconsistent 20% at T = 0 vs 98% at T = 0.7; T = 0 still not fully reproducible"],
  ["G11", "Validate every prompt per judge before adopting it.", "Method", "S5 helps glm4 only; S1 helps qwen only; S2 human agreement ↑ qwen, ↓ glm4"],
  ["G12", "Test every new prompt with two rewordings before adopting it.", "Method", "Rewording moved baseline MQM scores 9.4 / 6.1 points; S2 4.5 / 1.85"],
  ["G13", "Ask for error spans quoted from the translation only, and check it in code.", "Directional", "Baseline glm4 48% of spans not in the translation; S2 12%; explicit instruction further 14% → 5% (dev, prompt C)"],
  ["G14", "Compute scores in code and keep an unreadable-output guardrail (≤ 5%).", "Method", "All main prompts ≤ 0.5% unreadable"],
  ["G15", "Keep a held-out split and write the success rule down before testing.", "Method", "Several Stage 1 gains shrank or reversed on held-out data (e.g. qwen + S2 human agreement 0.22 → 0.81 on dev; 0.37 → 0.66 held-out; glm4 fell)"],
];
C.push(table([700, 4000, 1300, 3360], ["#", "Guideline", "Status", "Evidence"], G, { size: 16, fill: (r, i) => (i === 2 ? (/Confirmed/.test(r[2]) ? GOOD : (/Avoid/.test(r[2]) ? BAD : (/Directional|Untested/.test(r[2]) ? MID : undefined))) : undefined) }));

// ---------------- 14 improvements and limitations
C.push(H1("14. Improvements and limitations"));
C.push(H2("14.1 Improvements achieved"));
C.push(B(`**Position bias in pairwise judging** — largely removed for glm4 (S5), confirmed on held-out data.`));
C.push(B(`**Run-to-run consistency of MQM scores** — inconsistent items at temperature 0.7 roughly halved for both judges with few-shot calibration; qwen fully stable at temperature 0.`));
C.push(B(`**Sensitivity to prompt wording** — score changes under rewording halved (glm4) or cut by two-thirds (qwen) with few-shot calibration.`));
C.push(B(`**False errors on correct translations** — reduced for both judges (S2), though still high for glm4 (90%).`));
C.push(B(`**glm4 quoting the English source as “errors”** (Task A F7) — spans not in the translation ${pct(t1("mqm", "glm4").spans_not_in_translation)} → ${pct(t1("mqm_fewshot", "glm4").spans_not_in_translation)}.`));
C.push(B(`**Agreement between the two judges** — mean glm4–qwen gap ${f1(t1("mqm", "ens").mean_abs_judge_gap)} → ${f1(t1("mqm_fewshot", "ens").mean_abs_judge_gap)} points with S2.`));
C.push(H2("14.2 What prompt engineering did not fix"));
C.push(B("MQM-style prompts still rank controlled translations worse than the flat prompt (Task A F1 persists)."));
C.push(B("glm4 still lists errors on 90% of correct translations with S2."));
C.push(B("Temperature 0 is still not fully reproducible on Ollama / T4 (81–96% of scores identical between sessions)."));
C.push(B("For qwen, the pairwise prompt changes had no significant effect."));
C.push(H2("14.3 Limitations of the study"));
C.push(B("**Small samples.** 20 sources and 20 human-scored items per half. Correlations with human scores have very wide intervals (glm4 + S2: 0.16, CI −0.36 to 0.68); effects below roughly 15–20 percentage points cannot be confirmed."));
C.push(B("**Two small 4-bit open models.** Results may not transfer to larger or API judges or other quantisations."));
C.push(B("**One language pair, short sentences.** English → Mandarin (Simplified) only; Set B sentences are short and built around specific error types."));
C.push(B("**Constructed ground truth for Set B.** Planted errors and bands were authored and reviewer-checked, not produced by full MQM annotation; “detected” is a span-matching lower bound."));
C.push(B("**The pre-registered rule uses point estimates for the guard metrics.** With 20 items this makes the guard strict — S2 failed on two drops that are not statistically significant. The rule was kept as written."));
C.push(B("**Only one combined prompt and one set of few-shot examples were tried**, and the S2 examples cover at most one error each."));
C.push(B("**The held-out half has now been used,** so further prompt changes need fresh test items."));
C.push(B("**Environment.** Ollama 0.35.1 in Task B vs 0.35.0 in Task A; free-tier Colab sessions (6) with identical model digests."));

// ---------------- 15 future work
C.push(H1("15. Future work"));
C.push(H2("FW1 — S2b: few-shot MQM with a multi-error example (highest priority)"));
C.push(table([2000, 7360], ["", "Plan"], [
  ["Problem", "With S2, glm4 under-lists errors on heavily flawed machine translations (4.8 → 3.2 per item on items with ≥ 5 human-marked errors) and its agreement with human scores fell (0.55 → 0.16)"],
  ["Change", "Add a fourth example: a real machine translation with 3–5 human-annotated errors of mixed severity (SiniticMTError, development material only), reviewed by the Mandarin reviewer. Keep examples 1–3 unchanged"],
  ["Test data", "Fresh items — the held-out half has been looked at. For example 30–40 new SiniticMTError items with human MQM scores not used in Sprints 50–53, plus Set B-style variants for 15–20 new sources (reviewer-checked)"],
  ["Design", "S2b vs S2 vs baseline MQM, same session; temperature 0 on all items; 5 runs at T = 0.7 and 2 rewordings on a 40-item subset; same metrics and pre-registered rule as Task B"],
  ["Cost", "About 2,500–3,000 judge calls, roughly 1.5–2 GPU-hours on a Colab T4, plus about one hour of reviewer time"],
  ["Success", "glm4 agreement with human scores at least back to the baseline level, while keeping S2’s gains in false errors, consistency and wording robustness"],
], { size: 16, shadeFirst: true, zebra: false }));
C.push(H2("Other follow-ups"));
C.push(table([900, 4400, 4060], ["#", "Follow-up", "Why"], [
  ["FW2", "Re-test “quote errors only from the translation” on its own, on top of S2b", "Improved glm4 span validity in Stage 1b (14% → 5%) but was not isolated"],
  ["FW3", "S1 rubric for qwen only", "Large consistency gain for qwen on dev (53% → 21% inconsistent); glm4-specific failure"],
  ["FW4", "Replace the “A|B|tie” placeholder with concrete examples in all prompts; re-measure unreadable rates under rewording", "All 36 unreadable answers came from this (G8)"],
  ["FW5", "Larger human-scored sample (≥ 60 items)", "So human-agreement changes of about 0.15 can be confirmed"],
  ["FW6", "Check whether S5 and S2 results hold for a larger or API judge", "Results are for two small 4-bit models"],
  ["FW7", "Decide how GEPA should use pairwise ties and order disagreements", "S5 returns ties for about a quarter of pairs"],
], { size: 16 }));

// ---------------- 16 acceptance criteria
C.push(H1("16. Acceptance criteria"));
C.push(table([4200, 1200, 3960], ["Criterion", "Status", "Evidence"], [
  ["A baseline evaluation prompt is established", "Met", "Sprint 50 flat + MQM and Task A pairwise, verbatim; re-run in every session (Section 5)"],
  ["Multiple prompt-engineering approaches are designed and tested", "Met", "S1–S5 and C (Sections 6–9)"],
  ["Experiments use representative English → Mandarin examples", "Met", "Set A real MT with human scores; Set B in 8 categories; 60 pairs (Section 4)"],
  ["Each selected configuration is evaluated across repeated runs", "Met", "Stage 1: 3 runs at T = 0.7; Stage 2: 3 at T = 0, 5 at T = 0.7, 3 at T = 0.7 for pairwise, 2 rewordings (Sections 7, 10)"],
  ["Consistency is compared across approaches", "Met", "Section 11; Figures 2, 4, 5; Tables 10.3–10.5"],
  ["Improvements and limitations are documented", "Met", "Sections 10, 14"],
  ["A recommended prompt structure or guidelines are proposed", "Met", "Sections 12–13; prompts in Appendix A"],
], { size: 17, fill: (r, i) => (i === 1 ? GOOD : undefined) }));

// ---------------- appendices
C.push(H1("Appendix A. Prompts (verbatim)"));
C.push(P("Placeholders: {src_lang} = English · {tgt_lang} = Standard Mandarin Chinese (Simplified script) · {source}, {mt}, {a}, {b} = the item being judged."));
const PA = [["flat", "A.1 Baseline — flat 0–100 (Sprint 50)"], ["mqm", "A.2 Baseline — MQM (Sprint 50)"], ["pairwise", "A.3 Baseline — pairwise (Task A)"], ["flat_rubric", "A.4 S1 — scoring rubric"], ["mqm_fewshot", "A.5 S2 — few-shot calibration"], ["mqm_steps", "A.6 S3 — step-by-step criteria"], ["flat_accflu", "A.7 S4 — accuracy and fluency"], ["pairwise_tie", "A.8 S5 — pairwise with tie definition"], ["mqm_combined", "A.9 C — combined prompt (Stage 1b)"]];
for (const [k, t] of PA) { C.push(H2(t)); C.push(...mono(D.prompts[k])); }
C.push(H2("A.10 Rewordings used for the wording-robustness test"));
C.push(P("Each rewording keeps the same instructions, the same few-shot examples (byte-identical) and the same JSON schema; only the English wording changes. Rewording 1 paraphrases in the same order; rewording 2 also changes the order and framing. Shown here: the two rewordings of S2’s instructions (the examples are identical to A.5 and are omitted) and of S5."));
const stripEx = (t) => t.replace(/Example 1[\s\S]*?Answer: \{"errors": \[\{"text": "降低威胁水平到严重"[^\n]*\n/, "[three examples identical to A.5]\n");
for (const k of ["mqm_reworded", "mqm_rw2", "mqm_fewshot_rw1", "mqm_fewshot_rw2", "pairwise_rw1", "pairwise_rw2", "pairwise_tie_rw1", "pairwise_tie_rw2"]) {
  C.push(H3(k));
  C.push(...mono(stripEx(D.prompts[k])));
}

C.push(H1("Appendix B. Files and how to reproduce"));
C.push(table([3900, 5460], ["File", "Content"], [
  ["taskB/BASELINE_AND_METRICS.md", "Baseline, split, metrics and decision rules — written before any Task B run"],
  ["taskB/make_split.py, validate_split.py", "Step B1: development / held-out split by source and its checks"],
  ["judge/prompts_taskb.py", "All Task B prompts (S1–S5, C, rewordings) and the few-shot examples"],
  ["judge/parsing.py, settings.py", "Parser for every output format; output caps and decoding settings"],
  ["taskB/check_prompts.py, check_prompts_b5.py", "Automated prompt checks (baseline unchanged, rendering, few-shot provenance, no held-out text, parser)"],
  ["taskB/plan_taskb.py, run_taskb.py", "Experiment plan (Stages 1, 1b, 2) and resumable runner"],
  ["notebooks/TaskB_GPU_Colab.ipynb, TaskB_B5_GPU_Colab.ipynb", "Colab T4 notebooks (no Google Drive; checkpoint zips)"],
  ["taskB/analyze_stage1.py, analyze_stage2.py, charts_taskB.py", "Analyses and charts → analysis_taskB/stage1, stage2, charts"],
  ["results_taskB/", "Every judge call (one JSON line each), environment records, prompt snapshots"],
  ["taskB/RECOMMENDATION_AND_GUIDELINES.md", "Step B7 recommendation and guidelines (also in the project)"],
  ["report/build_report_data_taskB.py, build_report_taskB.js", "Rebuild this document"],
  ["sprint53_taskB_run_20261003_2105.zip", "Final checkpoint containing all of the above and all results"],
], { size: 16 }));
C.push(gap());
C.push(P("**To reproduce the analysis** (CPU, about two minutes): unpack the final checkpoint, then run"));
C.push(...mono("python taskB/analyze_stage1.py\npython taskB/analyze_stage2.py\npython taskB/charts_taskB.py\npython report/build_report_data_taskB.py && node report/build_report_taskB.js"));
C.push(P("**To re-run the judges** (Colab T4): open `TaskB_GPU_Colab.ipynb` (Stage 1) or `TaskB_B5_GPU_Colab.ipynb` (Stages 1b and 2), set the runtime to T4, run cells 1–5 (upload the checkpoint, install Ollama and both models), then the stage cell; every call is saved immediately and a run resumes from the newest checkpoint."));

C.push(H1("Appendix C. Glossary"));
C.push(table([2400, 6960], ["Term", "Meaning"], [
  ["LLM-as-a-judge", "Using a language model to score or compare translations"],
  ["MQM", "Multidimensional Quality Metrics: each error annotated with a type and severity; here score = 100 − Σ(minor 1, major 5, critical 25)"],
  ["Flat prompt", "The judge gives one holistic 0–100 score"],
  ["Few-shot", "Worked examples with correct answers included in the prompt"],
  ["Development / held-out half", "Data used to design and screen prompts / data kept aside to confirm results"],
  ["Pre-registered rule", "Success criterion written down before the experiment, so it cannot be adjusted to fit the results"],
  ["Paired bootstrap 95% CI", "Interval for the change between two prompts, from 2,000 resamples of the same items / sources / pairs; if it excludes zero the change is statistically supported"],
  ["Temperature", "Randomness of generation; 0 = always the most likely continuation"],
  ["Inconsistent item", "Repeated runs differ by ≥ 10 points or fall in different bands"],
  ["Spearman ρ", "Rank correlation, −1 to 1"],
  ["Krippendorff’s α", "Agreement of repeated ratings beyond chance; 1 = identical"],
  ["Position bias", "Preferring a translation because of where it is shown, not its quality"],
  ["GEPA", "The prompt-optimisation pipeline that uses the judge to rank translation candidates"],
], { size: 16, zebra: false, shadeFirst: true }));

// =====================================================================================
const doc = new Document({
  creator: "Vosyn Supernova · Sprint 53",
  title: "Sprint 53 Task B — Prompt engineering for LLM-as-a-judge (English → Mandarin)",
  styles: {
    default: { document: { run: { font: "Arial", size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, color: NAVY, font: "Arial" }, paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 25, bold: true, color: BLUE, font: "Arial" }, paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 22, bold: true, color: NAVY, font: "Arial" }, paragraph: { spacing: { before: 220, after: 80 }, outlineLevel: 2, keepNext: true } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [0, 1, 2].map((l) => ({ level: l, format: LevelFormat.BULLET, text: ["•", "–", "·"][l], alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540 + l * 360, hanging: 270 } } } })) },
      ...NUMREFS.map((ref) => ({ reference: ref, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] })),
    ],
  },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1300, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "Sprint 53 · Task B · Prompt engineering for LLM-as-a-Judge (EN → ZH)", font: FONT, size: 16, color: GREY })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Page ", font: FONT, size: 16, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: GREY })] })] }) },
    children: C,
  }],
});
Packer.toBuffer(doc).then((b) => { fs.writeFileSync(OUT, b); console.log("wrote " + OUT); });
