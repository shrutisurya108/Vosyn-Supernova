"""
Collect every number the Task B report needs into report/report_data_taskB.json.
  python taskB/analyze_stage1.py && python taskB/analyze_stage2.py && python taskB/charts_taskB.py
  python report/build_report_data_taskB.py && node report/build_report_taskB.js
"""
import collections
import glob
import json
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from judge.prompts import PROMPTS  # noqa: E402
from judge.prompts_taskb import FEWSHOT_EXAMPLES  # noqa: E402

S1 = os.path.join(ROOT, "analysis_taskB", "stage1")
S2 = os.path.join(ROOT, "analysis_taskB", "stage2")
D = os.path.join(ROOT, "data", "taskB")


def csv(path):
    return json.loads(pd.read_csv(path).to_json(orient="records"))


out = {"stage1": {}, "stage2": {}}
for f in glob.glob(os.path.join(S1, "*.csv")):
    out["stage1"][os.path.basename(f)[:-4]] = csv(f)
for f in glob.glob(os.path.join(S2, "*.csv")):
    out["stage2"][os.path.basename(f)[:-4]] = csv(f)

# run log
runs = {}
mal = collections.Counter()
retr = collections.Counter()
for f in sorted(glob.glob(os.path.join(ROOT, "results_taskB", "B*.jsonl"))):
    ph = os.path.basename(f)[:-6]
    rows = [json.loads(l) for l in open(f, encoding="utf-8")]
    runs[ph] = dict(calls=len(rows), malformed=sum(r["parse_status"] == "malformed" for r in rows),
                    retried=sum(r["attempts"] > 1 for r in rows), cut_off=sum(r["done_reason"] == "length" for r in rows),
                    gpu_minutes=round(sum(r["wall_seconds"] for r in rows) / 60, 1),
                    prompts=sorted({r["prompt_id"] for r in rows}))
out["runs"] = runs
env = [json.loads(l) for l in open(os.path.join(ROOT, "results_taskB", "environment.jsonl"))]
out["env"] = {"sessions": len(env), "ollama": env[-1]["ollama_version"], "gpu": env[-1]["gpu"],
              "models": {k: v["tag"] + " @ " + v["digest"][:12] for k, v in env[-1]["models"].items()},
              "same_digests": len({json.dumps(e["models"], sort_keys=True) for e in env}) == 1}
split = json.load(open(os.path.join(D, "split.json")))
out["split"] = {k: split[k] for k in ("seed", "candidate_seeds_tried", "dev_sources", "heldout_sources")}
cnt = {}
for h in ("dev", "heldout"):
    A = [json.loads(l) for l in open(os.path.join(D, f"{h}_setA.jsonl"))]
    B = [json.loads(l) for l in open(os.path.join(D, f"{h}_setB.jsonl"))]
    Pp = [json.loads(l) for l in open(os.path.join(D, f"{h}_pairs.jsonl"))]
    cnt[h] = dict(setA=len(A), setA_mean=round(sum(a["human_score"] for a in A) / len(A), 1), setB=len(B),
                  sources=len({b["source_id"] for b in B}), pairs=len(Pp),
                  variants=dict(collections.Counter(b["variant_type"] for b in B)),
                  categories=dict(collections.Counter(b["category"] for b in {x["source_id"]: x for x in B}.values())),
                  pair_types=dict(collections.Counter(p["pair_type"] for p in Pp)))
out["counts"] = cnt
out["finalists"] = json.load(open(os.path.join(D, "stage2_finalists.json")))
show = ["flat", "mqm", "pairwise", "flat_rubric", "mqm_fewshot", "mqm_steps", "flat_accflu", "pairwise_tie", "mqm_combined",
        "mqm_reworded", "mqm_rw2", "mqm_fewshot_rw1", "mqm_fewshot_rw2", "pairwise_rw1", "pairwise_rw2", "pairwise_tie_rw1",
        "pairwise_tie_rw2", "mqm_combined_rw1", "mqm_combined_rw2"]
out["prompts"] = {k: PROMPTS[k][0].replace("{{", "{").replace("}}", "}") for k in show}
out["fewshot"] = [{k: e[k] for k in ("item_id", "source", "mt", "answer", "why")} for e in FEWSHOT_EXAMPLES]
json.dump(out, open(os.path.join(ROOT, "report", "report_data_taskB.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("phases:", {k: v["calls"] for k, v in runs.items()})
print("GPU minutes:", round(sum(v["gpu_minutes"] for v in runs.values()), 1))
