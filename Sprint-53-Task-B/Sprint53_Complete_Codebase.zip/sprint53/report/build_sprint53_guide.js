// Sprint 53 complete reference guide + runbook.   node report/build_sprint53_guide.js
// Numbers come from the Task A and Task B reports (which are generated from the result files) and
// from report/report_data_taskB.json.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, AlignmentType, HeadingLevel,
  LevelFormat, WidthType, ShadingType, BorderStyle, Footer, Header, PageNumber,
} = require("docx");

const ROOT = path.join(__dirname, "..");
const OUT = path.join(ROOT, "report", "Sprint53_Complete_Guide_and_Runbook.docx");
const FONT = { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei", cs: "Arial" };
const MONO = { ascii: "Consolas", hAnsi: "Consolas", eastAsia: "Microsoft YaHei", cs: "Consolas" };
const W = 9360;
const NAVY = "1F3864", BLUE = "2F5496", GREY = "595959", LIGHT = "D9E1F2", PALE = "F2F2F2";
const GOOD = "E2EFDA", BAD = "FCE4D6", MID = "FFF2CC";
const bd = { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" };
const borders = { top: bd, bottom: bd, left: bd, right: bd };

function runs(text, o = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|(?<![A-Za-z0-9])_[^_]+_(?![A-Za-z0-9]))/g;
  let last = 0, m;
  const sz = o.size || 21;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...o, size: sz }));
    const s = m[0];
    if (s.startsWith("**")) out.push(new TextRun({ text: s.slice(2, -2), font: FONT, ...o, size: sz, bold: true }));
    else if (s.startsWith("`")) out.push(new TextRun({ text: s.slice(1, -1), ...o, font: MONO, size: sz - 2 }));
    else out.push(new TextRun({ text: s.slice(1, -1), font: FONT, ...o, size: sz, italics: true }));
    last = m.index + s.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...o, size: sz }));
  return out;
}
const C = [];
const NUMREFS = [];
let numRef = 0;
const P = (text, o = {}) => C.push(new Paragraph({ spacing: { after: 120, line: 276 }, children: runs(text, o) }));
const BREAK = new Set();
const H1 = (t, brk = true) => C.push(new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: brk, spacing: { before: brk ? 240 : 480, after: 160 }, children: [new TextRun({ text: t, font: FONT })] }));
const H2 = (t) => C.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t, font: FONT })] }));
const H3 = (t) => C.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun({ text: t, font: FONT })] }));
const B = (text, level = 0) => C.push(new Paragraph({ numbering: { reference: "bullets", level }, spacing: { after: 60, line: 264 }, children: runs(text) }));
const Bs = (arr) => arr.forEach((t) => B(t));
const N = (items) => { const ref = `n${numRef++}`; NUMREFS.push(ref); items.forEach((t) => C.push(new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 70, line: 264 }, children: runs(t) }))); };
const cap = (t) => C.push(new Paragraph({ spacing: { before: 60, after: 200 }, children: runs(t, { size: 17, color: GREY }) }));
const gap = () => C.push(new Paragraph({ spacing: { after: 80 }, children: [] }));
function T(widths, header, rows, o = {}) {
  const fs_ = o.size || 17;
  const tot = widths.reduce((a, b) => a + b, 0);
  const w = widths.map((x) => Math.round(x * W / tot));
  w[w.length - 1] += W - w.reduce((a, b) => a + b, 0);
  const cell = (text, i, head, fill) => new TableCell({
    borders, width: { size: w[i], type: WidthType.DXA },
    shading: head ? { fill: NAVY, type: ShadingType.CLEAR, color: "auto" } : (fill ? { fill, type: ShadingType.CLEAR, color: "auto" } : undefined),
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: String(text).split("\n").map((line) => new Paragraph({ children: runs(line, head ? { bold: true, color: "FFFFFF", size: fs_ } : { size: fs_ }) })),
  });
  const fillFor = (r, k, i) => {
    if (o.fill) { const f = o.fill(r, i); if (f) return f; }
    if (o.shadeFirst && i === 0) return LIGHT;
    return (o.zebra !== false && k % 2 === 1) ? PALE : undefined;
  };
  C.push(new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: w,
    rows: [
      new TableRow({ tableHeader: true, children: header.map((h, i) => cell(h, i, true)) }),
      ...rows.map((r, k) => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, i, false, fillFor(r, k, i))) })),
    ],
  }));
  if (o.caption) cap(o.caption); else gap();
}
function box(title, lines, color = BLUE, fill = "EEF3FA") {
  C.push(new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [W],
    rows: [new TableRow({ children: [new TableCell({
      borders: { top: { style: BorderStyle.SINGLE, size: 12, color }, bottom: bd, left: bd, right: bd },
      shading: { fill, type: ShadingType.CLEAR, color: "auto" }, width: { size: W, type: WidthType.DXA },
      margins: { top: 100, bottom: 100, left: 160, right: 160 },
      children: [new Paragraph({ spacing: { after: 80 }, children: runs(title, { bold: true, color: NAVY }) }),
        ...lines.map((l) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 50 }, children: runs(l, { size: 20 }) }))],
    })] })],
  }));
  gap();
}
function code(text) {
  text.split("\n").forEach((line) => C.push(new Paragraph({ spacing: { after: 0, line: 240 }, shading: { fill: PALE, type: ShadingType.CLEAR, color: "auto" },
    children: [new TextRun({ text: line || " ", font: MONO, size: 16 })] })));
  gap();
}
const QA = (q, a) => { C.push(new Paragraph({ spacing: { before: 120, after: 40 }, keepNext: true, children: runs("Q. " + q, { bold: true, color: NAVY }) })); P(a); };
const STEP = (t) => C.push(new Paragraph({ spacing: { before: 160, after: 80 }, keepNext: true, children: runs(t, { bold: true, color: BLUE, size: 22 }) }));

// =====================================================================================  TITLE
C.push(
  new Paragraph({ spacing: { before: 1500, after: 120 }, children: [new TextRun({ text: "Vosyn Supernova · Sprint 53", font: FONT, size: 22, color: GREY })] }),
  new Paragraph({ spacing: { after: 240 }, children: [new TextRun({ text: "LLM-as-a-Judge for English → Mandarin Translation: Complete Reference Guide and Runbook", font: FONT, size: 42, bold: true, color: NAVY })] }),
  new Paragraph({ spacing: { after: 420 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: BLUE, space: 8 } },
    children: [new TextRun({ text: "Part 1 explains everything that was done in Sprint 53 — concepts, decisions, experiments, results and their meaning. Part 2 explains how to run all of it again from the code base.", font: FONT, size: 24, color: BLUE })] }),
);
T([2300, 7060], ["Item", "Detail"], [
  ["Sprint goal", "Improve the reliability and consistency of LLM-as-a-judge evaluation for English-to-Mandarin translation"],
  ["Task A", "Failure analysis — where and why the judge is inconsistent, inaccurate, biased or sensitive to setup (4,758 judge calls)"],
  ["Task B", "Prompt engineering — which prompt structures make the judge more consistent and reliable (7,754 judge calls)"],
  ["Judges", "glm4 (9B) and qwen2.5 (7B) via Ollama, 4-bit, on a free Google Colab Tesla T4 — the judges chosen in Sprint 50"],
  ["Deliverables", "Sprint53_TaskA_LLM_Judge_Failure_Analysis.docx · Sprint53_TaskB_Prompt_Engineering_Report.docx · this guide · the code base (Sprint53_Complete_Codebase.zip)"],
  ["Dates", "Task A completed 30 September 2026 · Task B completed 3 October 2026"],
], { zebra: false, shadeFirst: true, size: 19 });

H1("How to use this guide");
P("This guide is written to be read from start to finish once, and then used as a reference. Part 1 tells the story of the sprint in order: why it was needed, the ideas it relies on, what was built, every decision and its alternatives, what the experiments found and what the findings mean. Part 2 is a runbook: exact steps, commands and expected outputs for anyone who wants to run the same experiments again.");
Bs([
  "**Short on time?** Read Section 1 (the sprint at a glance), then the boxes at the start of Sections 6 and 7.",
  "**Preparing for a review or an interview?** Sections 9 (alternatives and trade-offs) and 10 (question bank) collect the questions you are most likely to be asked, with answers.",
  "**Need a definition?** Section 3 explains every concept in plain terms; Appendix A is a short glossary.",
  "**Want to re-run something?** Go straight to Part 2.",
]);
P("**Numbers** in this guide are copied from the two sprint reports, whose tables are generated directly from the raw result files. “glm4 / qwen” after a number means the first value is for glm4 and the second for qwen2.5. Percentages are shares of items; ρ is Spearman rank correlation.");

H1("Contents", true);
[
  "PART 1 — REFERENCE GUIDE",
  "1. Sprint 53 at a glance", "2. Background: Vosyn, GEPA and Sprints 50–52", "3. Concepts you need",
  "4. How the work was organised: platforms, engineering and working method", "5. Task A — failure analysis",
  "6. Task A results and what they mean", "7. Task B — prompt engineering", "8. Putting it together: what Sprint 53 means for Vosyn",
  "9. Alternatives, trade-offs and “why not …?”", "10. Question bank (team lead, product manager, interviewer)", "11. Lessons learned",
  "PART 2 — RUNBOOK", "12. What you need", "13. The code base", "14. Two ways to use it", "15. Reproduce all analyses and reports from saved results",
  "16. Full re-run — Task A", "17. Full re-run — Task B", "18. Running outside Colab, and testing without a GPU", "19. Expected outputs checklist",
  "20. Troubleshooting", "21. Adapting the experiments", "Appendix A. Glossary", "Appendix B. File reference",
].forEach((t) => C.push(new Paragraph({ spacing: { after: 50 }, children: [new TextRun({ text: t, font: FONT, size: /^PART/.test(t) ? 22 : 21, bold: /^PART/.test(t), color: /^PART/.test(t) ? NAVY : undefined })] })));

// =====================================================================================  PART 1
C.push(new Paragraph({ pageBreakBefore: true, spacing: { before: 2400, after: 200 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "PART 1", font: FONT, size: 28, color: GREY })] }));
C.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 300 }, children: [new TextRun({ text: "Reference guide", font: FONT, size: 48, bold: true, color: NAVY })] }));
C.push(new Paragraph({ alignment: AlignmentType.CENTER, children: runs("What was done in Sprint 53, why, how, what it found and what it means", { color: BLUE, size: 24 }) }));

// ---------------------------------------------------------------- 1
H1("1. Sprint 53 at a glance");
P("**The problem.** Vosyn uses a small open language model as a “judge” to score machine translations automatically. Those scores steer automatic prompt optimisation (GEPA), so if the judge is unreliable, the optimiser chases noise. Sprint 50 had picked two local judges (glm4 and qwen2.5, run through Ollama) and an MQM-style scoring prompt. Sprint 53 asked two questions: **where does this judge fail?** (Task A) and **can better prompts fix it?** (Task B).");
P("**What Task A did.** Built test data whose correct answer is known in advance — 40 real machine translations with human scores (Set A), 275 deliberately constructed translations of 40 English sentences in which exactly one thing is changed (Set B, checked by a native Mainland reviewer), and 60 pairs for side-by-side judging — then ran 4,758 judge calls in 10 experiments on a free Colab GPU and analysed where the judges go wrong.");
box("Task A — main findings", [
  "**The Sprint 50 MQM prompt cannot separate a correct translation from one with a meaning error.** It lists errors on correct translations (glm4 98%, qwen 66%), and one real major error costs only 5 points, so it vanishes in the noise. Its score barely follows true quality on controlled data (ρ 0.05 / 0.14), while a plain 0–100 prompt does (0.55 / 0.57). (F1)",
  "**Sampling makes verdicts close to random.** At temperature 0.7–1.0, 98–100% of items got inconsistent MQM scores from glm4; one sentence scored 98, 80, 78, 70 and 0. Even at temperature 0, 5–8% of items changed. (F2, F3)",
  "**Rewording the prompt reorders the items** (ρ 0.29–0.69 with the original). **Changing the scale changes the verdict** (glm4 calls 8% of translations poor on 0–100 but 70% on 1–5). (F4, F8)",
  "**Biases:** glm4 picks whichever translation is shown first 72% of the time (F5); with a reference, correct paraphrases are penalised 98–100% of the time (F6); glm4 quotes the English source as “errors” (32% of its spans are not in the translation) (F7).",
]);
P("**What Task B did.** Tested five prompt-engineering strategies, each changing one thing relative to the Sprint 50 prompt (S1 scoring rubric, S2 few-shot examples, S3 step-by-step criteria, S4 separate accuracy and fluency, S5 pairwise with a tie definition), plus a combined prompt. The data were split into a development half (to design and screen) and a held-out half (to confirm), and the success rules were written down before any run. 7,754 judge calls.");
box("Task B — main findings", [
  "**S5 (pairwise with tie definition, both orders) is confirmed for glm4:** first-position picks 70% → 31%, verdicts matching the expected answer 38% → 61%.",
  "**S2 (few-shot calibration) is the most effective change for consistency** — inconsistent items at temperature 0.7 roughly halved, score changes caused by rewording halved, fewer false errors — **but it is not confirmed** under the pre-registered rule, because glm4’s agreement with human scores fell (0.55 → 0.16). glm4 became too lenient on badly flawed translations, most likely because every example shows at most one error. Fix (adding a multi-error example) is future work.",
  "**S1, S3, S4 and the combined prompt did not work** — each failed for an instructive reason (Section 7).",
  "**The plain 0–100 prompt remains the most stable and best at ranking translations.**",
]);
P("**What it means.** Keep temperature 0. Do not rely on MQM scores for close calls between candidates. For comparing two translations, use the S5 prompt in both orders. For error annotation, use few-shot MQM with a multi-error example added. For a single ranking score, keep the flat 0–100 prompt. Fifteen guidelines record what to do and what to avoid.");
T([2400, 2300, 2300, 2360], ["", "Task A", "Task B", "Total"], [
  ["Judge calls", "4,758", "7,754", "12,512"],
  ["GPU judging time", "≈ 2.5 h", "≈ 4.6 h", "≈ 7 h"],
  ["Colab sessions", "5", "6", "11"],
  ["Unreadable answers", "0", "37 (36 from one reworded prompt)", "37"],
  ["Human review", "265 rows of Set B", "3 few-shot examples", "1 native Mainland reviewer"],
], { size: 17, shadeFirst: true });

// ---------------------------------------------------------------- 2
H1("2. Background: Vosyn, GEPA and Sprints 50–52");
H2("2.1 Why a translation judge matters");
P("Checking translations by hand is slow and expensive. An **LLM-as-a-judge** reads a source sentence and a translation and returns a quality score (or a list of errors, or a preference between two translations). In Vosyn Supernova the judge is used inside **GEPA**, an automatic prompt-optimisation loop: GEPA proposes variations of a translation prompt, generates candidate translations, asks the judge which candidates are better and keeps the winners. The judge is therefore the optimiser’s only signal of quality. Two properties matter most:");
Bs([
  "**Consistency** — the same translation should get the same verdict every time. If the score of one candidate moves by 20 points between two calls, GEPA can “improve” a prompt by luck.",
  "**Reliability on close calls** — GEPA compares candidates that are often nearly identical (one wording change, one error). A judge that can rank very bad against very good translations but cannot tell “correct” from “one meaning error” is of little use there.",
]);
H2("2.2 What the earlier sprints provided");
T([1000, 4300, 4060], ["Sprint", "What it produced", "How Sprint 53 used it"], [
  ["50", "Judge validation: five configurations (glm4 / qwen × flat 0–100 / MQM, plus a glm4 + qwen MQM ensemble) scored against human-labelled gold sets. Chose **glm4_qwen_ensemble_mqm** for English → Mandarin (Spearman 0.598 with humans, MAE 8.43). Prompts, Ollama client, severity weights 1 / 5 / 25.", "Same judges, same model tags, same prompts verbatim, same scoring formula. Its 40-item English → Mandarin gold set (SiniticMTError, human MQM annotations) became **Set A**. Its per-sentence scores were used to test reproducibility."],
  ["51", "Reproducible English → Mandarin fine-tuning pipeline on Colab (LoRA / QLoRA).", "Not needed; a possible future source of candidate translations."],
  ["52", "20 independently sourced English → Mandarin items with candidate translations and seeded errors, packaged for human review.", "Sources reused in Set B (16 of 20); its review-package design (workbook + instructions) was reused."],
], { size: 16 });
P("Two observations in Sprint 50’s own results pointed to where to look: the ensemble “median of two judges” is mathematically the mean, so one wildly wrong judge (e.g. glm4 7 vs qwen 88 on one sentence) drags the result; and qwen’s flat 0–100 scores ranked well but were badly calibrated (MAE 23.1), clustering on a few values such as 20.");
H2("2.3 The sprint’s user stories");
T([1300, 8060], ["Task", "User story and acceptance criteria (summary)"], [
  ["A", "As an ML Engineer, I want to investigate failure cases when using LLM-as-a-Judge for English-to-Mandarin translation evaluation, so that we understand where automated evaluation becomes unreliable or inconsistent. Criteria: failure categories identified and documented; English → Mandarin examples; repeated evaluations; inconsistencies and causes documented; areas for prompt engineering identified; findings summarised."],
  ["B", "As an ML Engineer, I want to investigate prompt-engineering techniques that improve the consistency and reliability of LLM-as-a-Judge evaluations, so that the judge produces more stable and trustworthy assessments. Criteria: baseline prompt; multiple approaches designed and tested; representative examples; repeated runs per configuration; consistency compared; improvements and limitations documented; recommended prompt structure or guidelines."],
], { size: 17 });
P("Task A investigated thirteen areas listed in the story: variability across repeated evaluations, sensitivity to prompt wording, score calibration, over-reliance on a reference, semantic equivalence despite different wording, multiple valid translations, literal vs natural translations, fluency vs accuracy, idioms / culture / context, proper nouns and terminology, Simplified vs Traditional Chinese, position bias, and reasoning inconsistencies.");

// ---------------------------------------------------------------- 3
H1("3. Concepts you need", false);
P("Each concept is explained in plain terms, followed by why it matters in this sprint.");
H2("3.1 Ways of asking a judge");
T([2200, 4200, 2960], ["Concept", "What it is", "Why it matters here"], [
  ["Flat (direct) score", "The judge gives one holistic number, here 0–100 (“Rate the translation’s quality from 0 to 100”).", "Simple, stable; turned out to rank translations best. But numbers are poorly calibrated and judges cluster on a few values."],
  ["MQM (Multidimensional Quality Metrics)", "A professional annotation scheme: list every error with its text span, type (Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible) and severity (minor, major, critical). The score is computed from the list.", "Sprint 50’s choice. Explainable, but its quality depends on the judge listing real errors only."],
  ["MQM score formula", "100 − Σ(minor 1, major 5, critical 25), floor 0 — computed in code, never by the model.", "One major error costs only 5 points, so a translation with one meaning error still scores 95 (“clean”) — central to finding F1."],
  ["Pairwise comparison", "Show two translations of the same source and ask which is better (A, B or tie).", "Matches how GEPA uses the judge (comparing candidates); vulnerable to position bias."],
  ["Reference-free vs reference-based", "With a reference, the judge also sees a human translation as a model answer.", "References make judges penalise valid paraphrases (F6). The main prompts are reference-free."],
  ["Ensemble", "Combine several judges’ scores. Sprint 50 used the median of glm4 and qwen MQM scores.", "With two judges the median is the mean — no protection against one judge being badly wrong."],
], { size: 16 });
H2("3.2 How the model generates an answer");
T([2200, 4200, 2960], ["Concept", "What it is", "Why it matters here"], [
  ["Temperature", "Controls randomness. 0 = always pick the most likely next token (greedy). 0.7–1.0 = sample, so answers vary.", "The deployed setting is 0. Higher temperatures were used on purpose to expose variability (Task A) and to measure consistency more sensitively (Task B)."],
  ["Seed", "The random-number starting point. Fixed here as 1000 + run index.", "Makes sampled runs reproducible and distinct; a retry uses seed + 100 so it does not repeat the same bad output."],
  ["GPU non-determinism", "Even greedy decoding can differ slightly between runs because floating-point sums on a GPU are not always done in the same order.", "Explains why temperature 0 was not perfectly reproducible (F3)."],
  ["Quantisation (4-bit)", "Storing model weights with fewer bits so a 7–9B model fits on a 15 GB GPU. Ollama’s default tags are 4-bit.", "Same tags as Sprint 50; results describe these quantised models."],
  ["Model digest", "A hash identifying the exact model file.", "Recorded every session (glm4 5b699761eca5, qwen 845dbda0ea48) to prove the same model was used throughout."],
  ["Ollama", "A local server that runs open models and exposes an HTTP API.", "The Sprint 50 runtime; installed fresh in every Colab session."],
  ["Context (num_ctx) and output cap (num_predict)", "Maximum tokens the model can read / write.", "Fixed (4096 in; 256–1536 out by format) so long answers cannot run away; a cut-off answer is flagged."],
  ["Forced JSON mode", "An Ollama option that constrains output to valid JSON.", "Not used, to match Sprint 50; instead a tolerant parser extracts JSON and unreadable answers are counted."],
], { size: 16 });
H2("3.3 Measuring agreement and consistency");
T([2200, 4200, 2960], ["Concept", "What it is", "Why it matters here"], [
  ["Spearman ρ (rho)", "Rank correlation from −1 to 1: do two sets of scores put items in the same order? 1 = same order, 0 = unrelated.", "Used for agreement with human scores and with the true quality band. Ranks matter more than raw numbers for choosing between candidates."],
  ["Bands", "clean ≥ 85, moderate 60–84, poor < 60 on 0–100 (Sprint 50 buckets).", "Used to decide if two runs disagree (“band change”) and to compare with the reviewer’s band."],
  ["Inconsistent item", "Repeated runs differ by ≥ 10 points or fall in different bands.", "The main consistency measure in both tasks."],
  ["Spread", "Highest minus lowest score across repeated runs.", "How far scores move."],
  ["Krippendorff’s α", "Agreement of repeated ratings beyond chance; 1 = identical, 0 = no better than chance.", "A single number for self-consistency across runs."],
  ["Bootstrap confidence interval (CI)", "Re-compute a statistic on 2,000 random resamples of the items to see how much it could vary by chance. A 95% CI is the range covering the middle 95%.", "With only 20–40 items, intervals are wide; differences inside them are not claimed."],
  ["Paired bootstrap", "Resample the same units for both prompts and compute the difference each time. If the 95% CI of the difference excludes zero, the difference is statistically supported.", "Task B’s confirmation test. Units: English sources, items or pairs."],
  ["chrF", "Character n-gram overlap between two texts, 0–100. Measures surface similarity, not meaning.", "Used to check paraphrases really differ from gold (median 17) and to test whether reference-based judges reward surface similarity."],
], { size: 16 });
H2("3.4 Experimental design ideas");
T([2200, 4200, 2960], ["Concept", "What it is", "Why it matters here"], [
  ["Ground truth by construction", "Build translations whose quality you control (correct, paraphrased, one planted error) so a judge mistake can be proven, not guessed.", "Set B; makes failures unambiguous."],
  ["Paired contrast", "Compare the same sentence in two versions of known order (correct vs one planted error). The flawed one must score strictly lower.", "The strongest test of reliability: independent of calibration and thresholds."],
  ["One change at a time", "Each prompt variant differs from its baseline in one respect only.", "So any effect can be attributed to that change."],
  ["Development / held-out split", "Design and screen on one half; confirm on the other, untouched half.", "Prevents choosing prompts that only work on the data they were tuned on."],
  ["Pre-registration", "Write the success rule before running the experiment.", "Stops the definition of “better” from being adjusted to fit the results."],
  ["Position bias", "Preferring an option because of where it is shown.", "Measured by showing every pair in both orders."],
  ["Few-shot prompting", "Including worked examples with correct answers in the prompt.", "Strategy S2."],
  ["Step-by-step / chain-of-thought", "Asking the model to reason in steps before answering.", "Strategy S3; it backfired here."],
  ["Rubric / anchors", "Defining what each score range means.", "Strategy S1."],
], { size: 16 });
H2("3.5 Chinese-language points");
Bs([
  "**Simplified vs Traditional script.** Mainland Mandarin uses Simplified characters; Taiwan and Hong Kong use Traditional. **OpenCC** converts between them: `s2tw` changes characters only; `s2twp` also changes vocabulary to Taiwan usage. Automatic `s2twp` changed only 6 of 30 sentences and got two wrong, so Taiwan versions were written by hand.",
  "**Product decision:** Traditional-script output counts as **neutral behaviour, not an error** (decided by the team in Task A).",
  "**Cultural conventions** matter for errors: “40% off” is 六折 in Chinese (“60% of the price”); both judges wrongly flagged the correct 全场六折 as an error.",
]);

// ---------------------------------------------------------------- 4
H1("4. How the work was organised: platforms, engineering and working method");
H2("4.1 Working method");
P("Both tasks were run as a sequence of confirmed steps. For each step the plan, settings and alternatives were explained, open questions were asked and answered, the code was delivered as a zip, the ML engineer ran it, and the output was checked before moving on. All code was tested beforehand against a fake judge server (`tests/mock_ollama.py`) — including stopping, killing and resuming — so GPU time was never spent debugging. Every analysis was re-run from the downloaded checkpoint to make sure the numbers reproduce exactly.");
H2("4.2 Platform history and why");
T([2600, 6760], ["Platform", "What happened and why"], [
  ["Claude via API (considered first)", "Replaced by the Sprint 50 Ollama judges, so the study tests the configuration the team actually uses."],
  ["Local Mac with 8 GB RAM (considered)", "Fine for building datasets, too slow for ~4,800 judge calls (glm4 9B would swap memory). Rejected."],
  ["Lightning AI Studio, CPU (Task A Step 1)", "Used to build and validate datasets and merge the review. Its persistent storage suited CPU work; its 4-hour restarts would have complicated long GPU runs."],
  ["Google Colab free tier, Tesla T4 (all GPU work)", "Free 15 GB GPU — enough to keep both 4-bit judges loaded. Requirement: **no Google Drive**. Solution: upload zips at the start of each session and download a checkpoint zip every 30 minutes."],
  ["Word documents instead of Notion", "At the user’s request; reports built with code from the result tables."],
], { size: 16 });
H2("4.3 Engineering for a free, disconnecting GPU");
Bs([
  "**Every call saved immediately.** Each finished judge call is appended to its phase file with a unique key (phase | model | prompt | item | temperature | run | order). On restart the runner skips saved keys, so a disconnect loses at most the call in flight.",
  "**Time-boxed runs.** The notebook runs 30-minute chunks, downloads a checkpoint after each and stops after 3 h 15 min, before a free session typically ends.",
  "**Phases.** Work is split into phases (e.g. each temperature its own phase), so sessions can stop and resume cleanly.",
  "**Environment record.** Every session records GPU, Ollama version and model digests (`environment.jsonl`).",
  "**One call at a time.** Parallel calls are batched on the GPU, which can change outputs slightly and would confound the repeatability test; speed was sufficient without it.",
  "**Scores computed in code** from the parsed answer; unreadable answers retried up to 3 times with a new seed and otherwise kept as “malformed”.",
]);

// ---------------------------------------------------------------- 5
H1("5. Task A — failure analysis");
H2("5.1 Approach");
P("The central idea: **you can only prove a judge is wrong if you know the right answer.** So Task A first built data with known answers, then designed one experiment per question in the user story, ran them on the actual Sprint 50 judges, and judged “failure” only against a trustworthy reference.");
H2("5.2 From the story’s questions to ten experiments");
T([3400, 900, 5060], ["Area in the story", "Exp.", "How it was tested"], [
  ["Variability across repeated evaluations", "E1", "Every Set A item judged 3× at temperature 0 and 5× at 0.7 and 1.0 (1.0 added at the user’s request), both prompts, both judges"],
  ["Sensitivity to prompt wording", "E2", "Four rewordings of the Sprint 50 MQM prompt, each changing one thing: reworded English, instructions in Chinese, severity definitions added, analysis before the error list"],
  ["Score calibration / scales", "E3", "Same flat prompt on 0–100, 1–10 and 1–5"],
  ["Over-reliance on a reference / lexical similarity", "E4", "MQM with and without a reference; correlation with chrF to the reference"],
  ["Semantic equivalence; multiple valid translations", "E5", "Valid paraphrases deliberately worded differently from gold"],
  ["Literal vs natural; fluency vs accuracy", "E6", "Stiff-but-correct vs fluent-but-wrong versions of the same sentence"],
  ["Idioms, culture, context, names, terminology", "E7", "One planted error per category; is it found and is the score lowered?"],
  ["Simplified vs Traditional", "E8", "Character-converted and Taiwan-localised copies of gold, with the usual and a neutral target label"],
  ["Position bias", "E9", "60 pairs, each shown in both orders"],
  ["Reasoning inconsistencies", "E10", "Rationale-before-score prompt, analysis-first prompt, rule checks and a manual audit of 50 explanations"],
], { size: 16 });
H2("5.3 Data");
H3("Set A — real machine translation with human scores");
P("40 English sentences (FLORES-style news, science and travel text) from the Sprint 50 gold set (SiniticMTError), each with one machine translation, a human reference and human MQM annotations: 171 error spans (117 major, 54 minor). Human score = 100 − Σ(minor 1, major 5), range 65–100, mean 84 (19 clean, 21 moderate, none poor). **Purpose:** does the judge agree with people on real, messy output?");
H3("Set B — controlled variants");
P("For each of 40 English sources, several Mandarin versions whose quality is controlled. Every error version contains **exactly one planted error**, recorded with its span, MQM type, severity and description, so a miss is unambiguous.");
Bs([
  "**Sources:** 16 from Sprint 52, 10 from Set A (chosen by one rule: the sentence contains a named entity, domain term, number or unit), 14 new — so that every category has at least five sources.",
  "**Categories (8):** simple control (4), numbers/units/dates (5), named entities (6), domain terminology (5), idioms (5), culture-specific references (5), ambiguity/context (5), register and tone (5).",
]);
T([2300, 5800, 1260], ["Variant", "What it is / what it tests", "Rows"], [
  ["Gold", "Correct, natural Mainland Mandarin reference", "40"],
  ["Valid paraphrase", "Same meaning, deliberately different wording (median chrF to gold 17) — semantic equivalence", "40"],
  ["Literal but correct", "Word-for-word English structure, no meaning error — literal vs natural", "40"],
  ["Fluent, one meaning error", "Reads naturally, one meaning error (negation, number, agent, tense…) — fluency vs accuracy", "40"],
  ["One category error", "One error typical of the category (idiom taken literally, wrong name, wrong unit, register slip…)", "40"],
  ["Padded", "Same meaning, deliberately wordy", "5"],
  ["Traditional (characters)", "Gold converted with OpenCC s2tw", "30"],
  ["Traditional (Taiwan)", "Gold hand-localised for Taiwan (伺服器, 公尺, 「」)", "14"],
  ["Original MT output", "Existing Sprint 50/52 machine translation, kept exactly as produced", "26"],
], { size: 16, caption: "Set B: 275 rows. Expected bands 144 clean, 49 moderate, 82 poor." });
H3("How Set B was built and checked");
Bs([
  "**Writing.** All hand-written text lives in `scripts/setb_content.py`; `scripts/build_datasets.py` builds the datasets deterministically (rebuilding gives byte-identical files).",
  "**Automatic validation** (`scripts/validate_datasets.py`, must end with 0 hard failures): required fields and unique IDs; every planted span present verbatim; no flawed row identical to gold; Simplified rows contain no Traditional-only characters and vice versa (character-level check); paraphrases lexically distant from gold (chrF < 60; one expected exception — a password must stay verbatim); at least five sources per category; pairs match their rows.",
  "**Human review.** One native Mainland Mandarin reviewer checked all 265 rows not already human-labelled, using an Excel workbook with dropdowns and a four-page instruction document. Per row: does it match its description; their quality band; severity of the planted error; any other errors; corrected sentence if needed. Result: all rows confirmed, band agreement 265 / 265.",
  "**Correction applied:** one gold improved (S52_020 → 说得客气一点，首席财务官的那番话不太坦诚。) and its Taiwan version updated by hand.",
  "**Process bug caught:** the reviewer also wrote corrections of five Sprint 52 machine translations; the first merge replaced those machine outputs with the corrections, which would have made four “poor” rows identical to gold. A new validation check caught it; `scripts/apply_manual_fixes.py` restored the original outputs and kept the corrections as `reviewer_suggested_correction`. The merge script now never overwrites original machine output.",
  "**Caveat:** 100% agreement is unusually high and may partly reflect anchoring on the “expected band” column shown in the workbook.",
]);
H3("Pairs");
P("60 pairs drawn with seed 42: 20 gold vs paraphrase (tie expected), 15 literal-correct vs fluent-wrong (literal should win), 10 gold vs category error (gold should win), 5 + 5 Simplified vs Traditional (tie), 5 concise vs padded (concise or tie). Every pair is judged in both orders.");
H2("5.4 Judge harness and prompts");
P("The Sprint 50 flat and MQM prompts were copied verbatim (checked character for character, including the target label “Standard Mandarin Chinese (Simplified script)”). Every other prompt changes one thing:");
T([2300, 1200, 5860], ["Prompt", "Experiment", "What changes vs Sprint 50"], [
  ["flat", "E1, E5–E7", "Nothing (holistic 0–100)"],
  ["mqm", "E1, E4–E7", "Nothing (error list; score computed in code)"],
  ["mqm_reworded / mqm_zh", "E2", "Same instructions in different English / in Chinese"],
  ["mqm_severity_defs", "E2", "Adds definitions of minor / major / critical"],
  ["mqm_analysis_first", "E2, E10", "Short analysis (≤ 3 sentences) before the error list"],
  ["flat_1to5 / flat_1to10", "E3", "Different scale"],
  ["mqm_ref", "E4", "Adds the reference translation"],
  ["mqm_neutral_label", "E8", "Target label “Mandarin Chinese” (no script named)"],
  ["pairwise", "E9", "Which of A or B is better, or tie"],
  ["flat_rationale", "E10", "1–2 sentence rationale before the score"],
], { size: 16 });
T([2300, 3200, 3860], ["Setting", "Value", "Why"], [
  ["Output format", "Free text, parsed by us", "Same as Sprint 50; malformed output is itself a failure mode"],
  ["Temperatures / runs", "E1: 0 ×3, 0.7 ×5, 1.0 ×5; others 0 ×1", "0 is deployed; higher values expose variability"],
  ["Seed", "1000 + run; retries +100", "Reproducible; a same-seed retry at 0 would repeat the bad output"],
  ["Attempts", "Up to 3", "Sprint 50 value"],
  ["Context / output caps", "4096 / flat 256, MQM 1024, analysis 1536, rationale 512, pairwise 256", "Bounded and reproducible; truncation flagged"],
  ["Timeout", "180 s per call", "Sprint 50 value"],
  ["Parallelism", "1 call at a time", "Avoid GPU batching effects on repeatability"],
], { size: 16 });
H2("5.5 Execution");
T([2000, 900, 2600, 2400, 1460], ["Phase", "Exp.", "Data", "Prompts", "Calls"], [
  ["P01_E1_T00", "E1", "Set A (40)", "mqm, flat — T 0 ×3", "480"],
  ["P02_E1_T07", "E1", "Set A", "mqm, flat — T 0.7 ×5", "800"],
  ["P03_E1_T10", "E1", "Set A", "mqm, flat — T 1.0 ×5", "800"],
  ["P04_E2_prompts", "E2", "Set A", "4 MQM variants", "320"],
  ["P05_E3_scales", "E3", "Set A", "flat 1–5, 1–10", "160"],
  ["P06_E4_setB_mqm", "E4–E7", "Set B (275)", "mqm", "550"],
  ["P07_E4_mqm_ref", "E4", "Set A + B", "mqm + reference", "630"],
  ["P08_E5_setB_flat", "E5–E7", "Set B", "flat", "550"],
  ["P09_E8_script", "E8", "44 Traditional + 30 golds", "mqm, neutral label", "148"],
  ["P10_E9_pairwise", "E9", "60 pairs × 2 orders", "pairwise", "240"],
  ["P11_E10_rationale", "E10", "Set A", "flat + rationale", "80"],
  ["Total", "", "", "", "4,758"],
], { size: 16, caption: "Every call made once per judge; counts include both judges." });
P("Smoke test: 24 calls (every prompt × both judges), all parsed; measured 2.3 s/call (glm4) and 1.4 s/call (qwen), so the plan fitted in about 2.5 hours with no need to trim or parallelise. The full run used 5 Colab sessions with identical model digests in each; 4,758 / 4,758 calls present, 0 duplicates, 0 unreadable answers, 2 calls needed a second attempt, none hit the output cap. Ollama 0.35.0.");
H2("5.6 Analysis method — how a judge failure is defined");
P("An output counts as a failure only when it disagrees with a reference we can trust. Four kinds of reference, strongest first:");
T([2400, 3400, 3560], ["Test", "Compared against", "Failure when"], [
  ["1. Invariance", "The judge itself under a change that should not matter (re-running, swapping order, rewording)", "The verdict changes (≥ 10 points or a band change; flipped preference; reordered items)"],
  ["2. Paired contrast (Set B)", "The same sentence in two versions of known order", "The flawed version is not scored strictly lower than its gold; a valid paraphrase is penalised"],
  ["3. Checkable facts", "The text itself", "A reported error does not exist, English source quoted as “untranslated”, a correct rendering called wrong"],
  ["4. Human scores (Set A)", "Independent human MQM scores", "Measured statistically as rank agreement; a failure only when agreement collapses relative to a comparable setup"],
], { size: 16 });
Bs([
  "**Why the paired contrast carries most weight:** it needs no calibration or threshold. If the judge gives 95 both to 全场六折 (correct) and to 部分商品六折 (wrong), it cannot tell them apart whatever cut-off is used.",
  "**Not called a failure:** a single disagreement with a human score (humans disagree too); differences inside statistical noise (ρ differences below ≈ 0.25 with 40 items); Traditional-script output (neutral by product decision).",
  "**Tie rule.** The strict rule counts a tie with the gold as “not separated”. Under a looser rule MQM looks better (glm4 35% → 71%, qwen 60% → 85%), but the conclusion holds: with MQM the flawed version is scored strictly **higher** than the correct one 29% (glm4) and 15% (qwen) of the time, versus 1% for the flat prompt.",
  "**“Judge” means the whole configuration** — model + prompt + scoring formula. Some failures belong to the model (glm4 quoting English), others to the formula (5 points per major error); prompt changes cannot fix the formula.",
]);

// ---------------------------------------------------------------- 6
H1("6. Task A results and what they mean");
box("The four ways the judges fail", [
  "**Inaccurate** on close calls (F1, F7, F9, F11)", "**Inconsistent** across runs (F2, F3, F12)", "**Sensitive to setup** — wording, scale, script label (F4, F8, F10, F13)", "**Biased** — position and reference (F5, F6)",
]);
H2("6.1 E1 — Repeatability");
T([1000, 1300, 900, 1500, 1500, 1500, 1660], ["Judge", "Prompt", "T", "Identical all runs", "Inconsistent", "Mean spread", "α"], [
  ["glm4", "MQM", "0", "85%", "8%", "1.5", "0.96"], ["glm4", "MQM", "0.7", "0%", "98%", "55.6", "0.15"], ["glm4", "MQM", "1.0", "0%", "100%", "60.7", "0.14"],
  ["qwen", "MQM", "0", "88%", "8%", "1.1", "0.97"], ["qwen", "MQM", "0.7", "10%", "72%", "21.3", "0.48"], ["qwen", "MQM", "1.0", "8%", "70%", "19.9", "0.50"],
  ["glm4", "Flat", "0", "92%", "5%", "0.6", "0.99"], ["glm4", "Flat", "0.7", "5%", "82%", "11.1", "0.86"],
  ["qwen", "Flat", "0", "95%", "5%", "0.5", "1.00"], ["qwen", "Flat", "0.7", "45%", "50%", "8.1", "0.95"],
], { size: 16, caption: "Selected rows; Set A, 40 items." });
Bs([
  "**Temperature 0 is almost but not fully deterministic** (5–8% of items change) — most likely GPU numerical non-determinism. Re-running Sprint 50’s exact configurations reproduced only 29–37 of its 40 scores (F3).",
  "**Sampling makes glm4’s MQM verdicts close to random** (F2). Why: the number of errors it lists barely changes, but at T > 0 it labels at least one error “critical” (−25) in 40–51% of calls, and about 9% of calls end at 0. Example: A::en_to_cmn_511 scored 98, 80, 78, 70 and 0 in five runs.",
  "**Same score, different reasons:** among MQM run pairs with the same score, only 51% listed the same errors.",
  "**Averaging runs** helped some configurations (qwen MQM at 0.7, averaged over 5 runs: ρ 0.66 vs 0.41 single run at 0) but the intervals overlap — a candidate fix, not a result.",
  "**Significance:** GEPA uses single-shot scores, so any T > 0 configuration is unusable; even at T = 0 small drifts exist, which is why Task B re-ran the baseline in every session.",
]);
H2("6.2 E2 — Prompt wording");
Bs([
  "Four rewordings that ask for the same thing **reorder the items** (ρ 0.29–0.69 with the original prompt) and move 22–45% of scores by ≥ 10 points (F4). On one sentence (A::en_to_cmn_1832) glm4 gave 11, 89, 70, 7 and 86 under the five wordings.",
  "The “best” wording differs by judge (glm4: original 0.61; qwen: reworded 0.66 vs 0.41) but all intervals overlap — **the finding is the instability itself**, not a winner.",
  "Asking for analysis first made glm4 use “minor” far more (52 vs 13) and raised its scores. Humans marked 32% of errors minor; judges 3–35% depending on the prompt.",
  "**Significance:** a judge whose ranking depends on wording cannot be trusted to rank close candidates; any prompt change must be validated with rewordings (Task B did this).",
]);
H2("6.3 E3 — Scale and calibration");
Bs([
  "Rankings are stable across scales (ρ 0.85–0.95 between scales) but **absolute verdicts are not:** glm4 calls 8% of translations poor on 0–100, 48% on 1–10 and 70% on 1–5 (F8). Any fixed acceptance threshold depends on the scale.",
  "The judges disagree on what the scale means: on 0–100 glm4 averages 79, qwen 61, humans 84. Scores cluster: glm4 uses 85 in 28% of flat calls; qwen gives exactly 20 in 15% of calls (9 Set A items whose human scores average 77).",
]);
H2("6.4 E4 — References");
Bs([
  "With a reference, **valid paraphrases score below the reference wording 98–100% of the time** (40–43% lose ≥ 10 points) versus 25–48% without (F6). The judge becomes a difference detector: its scores correlate with chrF to the reference (0.21–0.26), not with true quality (−0.09 to 0.00).",
  "**Significance:** GEPA generates new wordings; a reference-based judge would punish good variation. If a reference is ever used, the prompt must say it is one valid option.",
]);
H2("6.5 E5–E7 — Paraphrase, literal vs fluent, planted errors");
T([2200, 1300, 1300, 1300, 1300, 1960], ["Measure", "Flat glm4", "Flat qwen", "MQM glm4", "MQM qwen", "Meaning"], [
  ["Tracks true quality (ρ, Set B)", "0.55", "0.57", "0.05", "0.14", "MQM barely follows quality"],
  ["Flawed below its own gold", "79%", "84%", "35%", "60%", "MQM often cannot separate"],
  ["Flawed above its own gold", "1%", "1%", "29%", "15%", "MQM prefers the wrong one 1 in 5–7"],
  ["Planted error found (MQM)", "–", "–", "57%", "69%", "Found, but…"],
  ["Correct translations with any error listed", "–", "–", "98%", "66%", "…false errors drown it"],
], { size: 16 });
Bs([
  "**F1 — the key Task A result.** The MQM judges usually find the planted error, yet the flawed version is scored below the correct one only 35% / 60% of the time, because they also list errors on correct translations (2.1 / 1.3 per correct row), and one major error costs only 5 points. Example: both judges gave 95 to the correct 全场六折 (flagging it wrongly) and 95 to the wrong 部分商品六折.",
  "**F9 — literal translations not penalised:** stiff word-for-word rows scored 88–94 (reviewer: moderate). With MQM, a stiff-but-correct version beat a fluent-but-wrong version only 35% / 55% of the time (flat: 65% / 82%).",
  "**F11 — blind spots by category:** planted-error detection was weakest for named entities (25% / 58%) and terminology (30% / 40%), strongest for register (80%).",
  "**F7 — glm4 confuses source and translation:** 32% of glm4’s error spans are not in the translation; it often lists English phrases as “Untranslated/critical”. One correct translation (The Onion sentence) scored 0 for this reason.",
]);
H2("6.6 E8 — Script (informational)");
P("Traditional copies score within about ±4 points of the gold, the same under the “Simplified” label and a neutral label, and none of 352 outputs mentions the script — consistent with the product decision that Traditional output is acceptable (F10). Script changes are penalised only indirectly: with a Simplified reference (glm4 90–93% of the time), and in pairwise comparisons glm4 prefers Simplified 80% of the time. If a script policy is ever adopted, the prompt must state it explicitly.");
H2("6.7 E9 — Position bias");
P("glm4 picked the first-shown translation 72% of the time and kept its verdict when the order was swapped only 48% of the time (qwen 52% / 70%) (F5). Bias is worst when the two translations are equally good (gold vs paraphrase: order-consistent 30% / 55%) and smallest when one has a real error (70% / 100%). Neither judge used “tie” much (3% / 13%).");
H2("6.8 E10 — Reasoning and explanations");
Bs([
  "Asking for a rationale **changes the score**: glm4 moved ≥ 10 points on 70% of items (mean 79 → 71); agreement with humans did not improve significantly.",
  "Manual audit of 50 explanations: 22 consistent and accurate, 13 false error claims (e.g. flagging the correct 700万年前), 5 invalid spans, 4 mis-graded severities, 2 missed major errors, 4 vague (F12).",
  "Format drift (F13): glm4 wraps 100% of answers in code fences (a strict JSON parser would reject them all); qwen used off-list error types 64 times in 2,550 errors.",
]);
H2("6.9 Failure catalogue");
T([700, 3200, 3460, 2000], ["#", "Failure", "Key evidence (glm4 / qwen)", "Prompt-fixable?"], [
  ["F1", "MQM cannot separate correct from one-error translations", "Set B ρ 0.05 / 0.14 (flat 0.55 / 0.57); below gold 35% / 60%", "Partly (also the 5-point weight)"],
  ["F2", "Sampling makes verdicts random", "T 0.7/1.0: glm4 MQM 98–100% inconsistent", "No — use T = 0 or average runs"],
  ["F3", "T = 0 not fully reproducible", "5–8% items change; Sprint 50 reproduced 29–37 / 40", "No"],
  ["F4", "Wording changes the ranking", "ρ 0.29–0.69 vs original; 22–45% move ≥ 10", "Yes — main Task B target"],
  ["F5", "Position bias", "glm4 first 72%, order-consistent 48%", "Partly (+ both orders)"],
  ["F6", "Reference anchoring", "Paraphrases below gold 98–100% with reference", "Yes"],
  ["F7", "glm4 quotes the English source", "32% of glm4 spans not in the translation", "Yes"],
  ["F8", "Scale / calibration", "glm4 poor 8% (0–100) vs 70% (1–5); means 79 vs 61", "Yes"],
  ["F9", "Literal translations not penalised", "Literal rows 88–94", "Yes"],
  ["F10", "Script label has no effect", "0 / 352 outputs mention script", "Informational"],
  ["F11", "Blind spots: names, terms, conventions", "Entities 25% / 58%; terms 30% / 40% detected", "Partly"],
  ["F12", "Explanations often wrong", "22 / 50 consistent; 13 false claims", "Partly"],
  ["F13", "Format drift", "glm4 code fences 100%; qwen off-list types", "Yes (or JSON mode)"],
], { size: 15 });
H2("6.10 Implications drawn in Task A");
Bs([
  "Keep temperature 0; never single-shot at 0.7–1.0.",
  "Do not rely on MQM scores for close calls: the ensemble ranks real error-heavy MT acceptably (Set A ρ 0.52 vs 0.60 in Sprint 50, within noise) but cannot separate one error from none (Set B ρ 0.09).",
  "Revisit the ensemble (two-judge median = mean) and the MQM weights (one real error is smaller than the false-error noise).",
  "For pairwise judging, always evaluate both orders. Do not show a single reference as “the answer”. Record the environment with every run.",
  "Hand-off: a table of prompt-engineering candidates per failure became the menu for Task B.",
]);

// ---------------------------------------------------------------- 7
H1("7. Task B — prompt engineering");
box("Task B in one box", [
  "Five strategies, each one change vs the Sprint 50 prompt; development / held-out split by source (20 / 20); success rules written first; baseline re-run in every session; 7,754 calls.",
  "**Confirmed:** S5 pairwise with tie definition and both orders — for glm4.",
  "**Directional, not confirmed:** S2 few-shot — big gains in consistency and robustness, but glm4’s human agreement fell.",
  "**Did not work:** S1 rubric, S3 step-by-step, S4 accuracy + fluency, combined prompt C.",
  "**Future work:** S2b — add a multi-error example and test on fresh items.",
]);
H2("7.1 Choosing the strategies");
P("The story offered a range of candidate techniques. Five were chosen because each targets a specific Task A failure, can be tested by changing one thing, and fits the free GPU budget. Order randomisation became part of S5 (both orders judged), wording robustness became a test applied to every finalist, and structured JSON output was already used everywhere.");
T([1700, 3300, 1100, 3260], ["Strategy", "What changes", "Style", "Targets / primary metric"], [
  ["S1 Scoring rubric", "Five score bands with definitions; “decide the band, then the score”", "flat", "F2/F8 — consistency at T = 0.7; judge gap"],
  ["S2 Few-shot calibration", "3 worked examples: correct paraphrase (no errors), one major error, one minor omission from real MT", "MQM", "F1 — false errors on correct translations; flawed above gold"],
  ["S3 Step-by-step criteria", "Delimited texts; steps meaning → names/numbers/terms → idioms/culture → “different wording is NOT an error” → list errors quoted from the translation", "MQM", "F7, F11 — spans not in translation; planted-error detection"],
  ["S4 Accuracy + fluency", "Two 0–100 scores, combined in code 0.8 × accuracy + 0.2 × fluency", "flat", "F9 — flawed below gold; literal over fluent-wrong"],
  ["S5 Pairwise with tie", "Assess each translation first; tie defined (incl. both correct, different wording); “order is random”; both orders judged", "pairwise", "F5 — order consistency; first-position rate"],
], { size: 16 });
P("**Decisions taken with the user:** strategies approved; each strategy tested in one scoring style (matched to the failure it targets — cheaper than testing every strategy in both styles); English instructions (as Sprint 50 — Chinese instructions were already shown in Task A to be a separate wording effect); 3 few-shot examples (covers no-error, major and minor while keeping the prompt short); S4 weights 0.8 / 0.2 (meaning errors matter more for GEPA); a native reviewer checked the few-shot examples (they are shown to the judge as correct, so they must be right).");
H2("7.2 Design");
Bs([
  "**Split by English source** (seed 1324, the most balanced of 2,000 candidate splits): all versions and pairs of a sentence stay in one half. Each half: 20 sources, ~137 Set B rows, 20 Set A items (both with mean human score 84.0), 28 / 32 pairs. Every category within ±1 source between halves.",
  "**Repeat subset** (fixed in advance): 40 held-out items — all 20 held-out Set A items + 20 Set B rows from 20 sources (4 each of gold, paraphrase, literal, fluent-wrong, targeted error).",
  "**Few-shot exclusion:** the example sources (N_IDI1, N_NUM1) and Set A item en_to_cmn_258 were removed from Stage 1 scoring for every prompt.",
  "**Stage 1 rule (screening, dev half):** primary metric better than baseline for ≥ 1 judge; no reliability metric clearly worse (> 10 percentage points, or ρ drop > 0.15) for either judge; malformed ≤ 5%.",
  "**Stage 2 rule (confirmation, held-out half):** primary metric improves with a paired bootstrap 95% CI excluding zero for ≥ 1 judge; no other metric clearly worse (same thresholds, on the point estimate); malformed ≤ 5%.",
]);
H2("7.3 Runs");
T([2600, 4300, 2460], ["Stage", "What", "Calls / GPU time"], [
  ["B3 smoke test", "8 prompts × 2 judges, 16/16 readable, nothing cut off", "16"],
  ["Stage 1 (dev)", "Baseline flat + MQM; S1–S4; pairwise baseline + S5 both orders; all 6 absolute prompts 3× at T = 0.7 on Set A", "2,840 / 91 min"],
  ["Stage 1b (dev)", "Combined prompt C, plus 3× at T = 0.7", "436 / 17 min"],
  ["Stage 2 (held-out)", "Baseline flat + MQM and S2 on 157 items; pairwise baseline + S5 both orders; repeats T = 0 ×3 and T = 0.7 ×5 on 40 items; pairwise 3× at T = 0.7; 2 rewordings of each prompt", "4,478 / 166 min"],
], { size: 16 });
H2("7.4 Stage 1 results (screening)");
T([1900, 4600, 1200], ["Strategy", "What happened", "Rule"], [
  ["S1 rubric", "qwen much more consistent (53% → 21% inconsistent); glm4 **snapped to band edges** — gave exactly 85 to 125 of 158 items — and could no longer separate flawed from correct (below gold 78% → 44%)", "FAIL"],
  ["S2 few-shot", "False errors ↓ both judges (glm4 94% → 83%, qwen 78% → 53%); flawed above gold ↓; consistency ↑ (glm4 84% → 63%, qwen 63% → 21%); glm4 detection 58% → 72%", "PASS"],
  ["S3 steps", "False errors almost vanished (94% → 3%) — but so did real errors: glm4 detection 58% → 17%, human agreement 0.73 → 0.36. The “valid variation” step explained errors away: for 密码**不**是“Muiriel” (“the password is **not** Muiriel”) glm4 wrote “a different sentence structure … but maintains the same meaning”", "FAIL"],
  ["S4 acc + flu", "Small gains (below gold 78% → 81%, 83% → 89%); qwen less consistent (53% → 68%)", "FAIL"],
  ["S5 pairwise + tie", "glm4 first-position 75% → 25%; verdicts matching expected 40% / 60% → 71% / 71%; ties ≈ 40%", "PASS"],
], { size: 16, fill: (r, i) => (i === 2 ? (r[2] === "PASS" ? GOOD : BAD) : undefined) });
H2("7.5 Stage 1b — combined prompt C");
P("C = S2’s examples + S3’s delimiters + “quote errors only from the translation” + a one-line checklist (meaning; names, numbers, dates, units, terms; idioms), **without** S3’s valid-variation step. A rule was fixed before it ran: pass the Stage 1 rule against the baseline **and** not be clearly worse than S2. C passed against the baseline and improved glm4’s span validity (14% → 5% spans not in translation), but was clearly worse than S2 on qwen’s human agreement (0.81 → 0.59), glm4 detection (72% → 58%) and glm4 consistency (63% → 74%), so it did not go to Stage 2.");
H2("7.6 Stage 2 results (held-out confirmation)");
T([3000, 1500, 1500, 3360], ["Measure (S2 vs baseline MQM)", "glm4", "qwen", "Statistically supported?"], [
  ["False errors on correct translations (primary)", "100% → 90%", "60% → 43%", "Yes, both"],
  ["Flawed above gold (primary)", "20% → 20%", "13% → 5%", "No"],
  ["Inconsistent at T = 0.7 × 5", "98% → 57%", "53% → 28%", "Yes, both"],
  ["Mean spread at T = 0.7 (points)", "50.1 → 18.6", "13.4 → 5.9", "Yes, both"],
  ["Score change under rewording (points)", "9.4 → 4.5", "6.1 → 1.85", "Yes, both"],
  ["Spans not in translation", "48% → 12%", "2% → 1%", "glm4"],
  ["Planted error detected", "55% → 83%", "73% → 80%", "glm4"],
  ["Flawed below gold", "38% → 63%", "65% → 85%", "qwen"],
  ["Agreement with humans (ρ)", "0.55 → 0.16", "0.37 → 0.66", "No (glm4 CI −0.91 to +0.19)"],
  ["Literal over fluent-wrong", "40% → 55%", "70% → 55%", "No"],
], { size: 16 });
P("**Verdict for S2: NOT CONFIRMED** — the primary metric improved with intervals excluding zero, but two guard metrics crossed the “clearly worse” threshold on the point estimate (glm4 human agreement, qwen literal-over-fluent-wrong). Neither drop is statistically significant, but the rule was fixed in advance and was not changed after seeing the data.");
P("**Why glm4 lost human agreement.** With S2, glm4 is more lenient on real machine translations with many errors: on items with ≥ 5 human-marked errors it listed 3.2 errors instead of 4.8, and the two worst items (human 65 and 70) got 84 and 89. The three examples contain at most one error each, so glm4 appears to have learned “a translation has zero or one error”. One item shows both sides: for A::en_to_cmn_1832 the baseline listed 14 “errors”, almost all quoting the English source (F7), and scored 54; with S2 it quoted three spans correctly from the Chinese — but too few — and scored 89 (human: 70).");
T([3000, 1500, 1500, 3360], ["Measure (S5 vs baseline pairwise)", "glm4", "qwen", "Statistically supported?"], [
  ["Picks the first-shown translation (primary)", "70% → 31%", "58% → 53%", "glm4"],
  ["Same verdict in both orders (primary)", "53% → 62%", "66% → 59%", "No"],
  ["Verdict matches expected", "38% → 61%", "56% → 66%", "glm4"],
  ["Prefers the flawed translation", "13% → 5%", "5% → 9%", "glm4"],
  ["Ties", "0% → 23%", "9% → 23%", "(information)"],
], { size: 16 });
P("**Verdict for S5: PROMISING (confirmed), glm4-specific.** Ties rose, mostly on pairs where a tie is right (glm4 ties on tie-pairs 0% → 37%). glm4’s S5 verdicts agreed less with its reworded versions (64% vs 84%), but part of the baseline’s “stability” is that it nearly always answers “A”.");
P("**Format failures under rewording.** All 36 unreadable answers in Stage 2 came from glm4 on reworded pairwise prompts: it returned the placeholder `{\"better\": \"A|B|tie\"}` literally in 25 of 64 answers to one rewording. The original prompts with the same placeholder had no such problem — format instructions are fragile.");
P("**The flat prompt** remained the most reproducible at T = 0 (88% / 95% of items identical in all runs) and the best at tracking true quality (ρ 0.55–0.58 vs ≤ 0.32 for any MQM prompt). Re-running the baseline reproduced Task A scores exactly for 81–96% of items.");
H2("7.7 Recommendation and guidelines");
T([2300, 3300, 1500, 2260], ["Use case", "Recommended", "Status", "Why"], [
  ["Comparing two translations", "S5 pairwise with tie definition; both orders; order disagreement = tie", "Confirmed (glm4)", "Position bias removed for glm4"],
  ["Error annotation (MQM)", "S2 few-shot MQM + a multi-error example (FW1)", "Directional", "Consistency and robustness roughly doubled; glm4 leniency to fix"],
  ["One ranking score", "Sprint 50 flat 0–100, T = 0", "Baseline", "Most stable; best ranking"],
  ["Not recommended", "S1, S3, S4, C", "Avoid", "See 7.4–7.5"],
], { size: 16, fill: (r, i) => (i === 2 ? (/Confirmed/.test(r[2]) ? GOOD : /Directional/.test(r[2]) ? MID : /Avoid/.test(r[2]) ? BAD : undefined) : undefined) });
P("For the Sprint 50 ensemble: with S2 the two judges agree much more (mean gap 11.1 → 4.6 points) and the ensemble separates flawed from correct better (below gold 60% → 85%), but its human agreement on real MT fell (0.53 → 0.35), driven by glm4. Until FW1 is done, the safest MQM configuration is qwen with S2, or the ensemble with S2 monitored against human scores.");
T([700, 5000, 1300, 2360], ["#", "Guideline", "Status", "Evidence"], [
  ["G1", "Calibrate with few-shot examples, including a correct translation with no errors", "Directional", "False errors and inconsistency down, CIs exclude 0"],
  ["G2", "Cover the full range of errors in the examples, including several errors of mixed severity", "Untested", "glm4 + S2 too lenient on heavily flawed MT"],
  ["G3", "Few-shot examples from development data only, native-checked, excluded from scoring", "Method", "—"],
  ["G4", "Do not add a separate “different wording is not an error” step", "Avoid", "S3 detection 58% → 17%"],
  ["G5", "Do not give glm4 score-band anchors", "Avoid", "S1: 85 for 125 / 158 items"],
  ["G6", "Do not split accuracy and fluency for these judges", "Avoid", "S4"],
  ["G7", "Pairwise: define tie, say order is random, assess each first, judge both orders", "Confirmed", "S5"],
  ["G8", "Show the output format with concrete values, not “A|B|tie”", "Directional", "36 unreadable answers"],
  ["G9", "Flat score for ranking; MQM lists for diagnosis", "Baseline", "ρ 0.55–0.58 vs ≤ 0.32"],
  ["G10", "Temperature 0, fixed seed and context, record versions; 3 runs + median for important decisions", "Method", "F2, F3"],
  ["G11", "Validate every prompt per judge", "Method", "Effects differ by judge"],
  ["G12", "Test every new prompt with two rewordings", "Method", "F4"],
  ["G13", "Ask for spans quoted from the translation only; check in code", "Directional", "F7; Stage 1b"],
  ["G14", "Compute scores in code; malformed guardrail ≤ 5%", "Method", "—"],
  ["G15", "Keep a held-out split; write success rules first", "Method", "Stage 1 gains shrank on held-out"],
], { size: 15 });
H2("7.8 Future work");
Bs([
  "**FW1 — S2b (highest priority):** add a fourth example — a real MT with 3–5 human-annotated errors of mixed severity — and test on **fresh** items (the held-out half has now been looked at): e.g. 30–40 new SiniticMTError items plus Set B-style variants for 15–20 new sources; S2b vs S2 vs baseline, same rules; ≈ 2,500–3,000 calls (1.5–2 GPU-hours). Success: glm4 human agreement back to baseline while keeping S2’s gains.",
  "**FW2** re-test “quote errors only from the translation” on its own; **FW3** S1 rubric for qwen only; **FW4** replace the “A|B|tie” placeholder everywhere and re-measure; **FW5** larger human-scored sample (≥ 60 items); **FW6** check results on a larger or API judge; **FW7** decide how GEPA should use pairwise ties.",
]);

// ---------------------------------------------------------------- 8
H1("8. Putting it together: what Sprint 53 means for Vosyn");
H2("8.1 The judge configuration to use now");
T([3000, 6360], ["Setting", "Recommendation"], [
  ["Temperature", "0, fixed seed, fixed context; record Ollama version and model digests every run"],
  ["Ranking candidates (GEPA)", "Prefer pairwise S5 in both orders (glm4), or the flat 0–100 prompt; avoid MQM scores for close calls"],
  ["Error annotation / explanations", "S2 few-shot MQM (qwen preferred until FW1); treat glm4 MQM lists with caution"],
  ["Ensemble", "With two judges the median is the mean; add a third judge, a trimmed rule or a disagreement flag for outlier protection"],
  ["References", "Do not show a single reference as “the answer”"],
  ["Repeats", "For important decisions, 3 runs at T = 0 and take the median"],
], { size: 17, shadeFirst: true });
H2("8.2 What remains open");
Bs([
  "**Formula vs prompt.** Part of F1 is the scoring formula (5 points per major error). Prompting reduced false errors but did not close the gap with the flat prompt; revising the MQM weights is a separate experiment.",
  "**Scale of evidence.** 20–40 items per comparison give wide intervals; a larger human-scored set (FW5) would make conclusions firmer.",
  "**Model size.** Results are for 7–9B 4-bit judges; larger judges may not show the same failures.",
  "**Second reviewer.** A blind second reviewer on Set B would strengthen the ground truth.",
]);

// ---------------------------------------------------------------- 9
H1("9. Alternatives, trade-offs and “why not …?”");
P("Every significant choice in the sprint had alternatives. This section lists them, with the reason for the choice made.");
const alt = [
  ["Test the Sprint 50 judges, not a stronger API model", "The question was whether the judges Vosyn uses are reliable. An API model would answer a different question and cost money."],
  ["Build controlled data (Set B) instead of using only real MT", "Real MT has many overlapping errors, so a judge’s miss cannot be pinned down. One planted error per row makes misses unambiguous. Set A (real MT + humans) keeps the realism; the two sets complement each other."],
  ["Exactly one planted error per variant", "Makes “what did the judge miss?” unambiguous. Alternative: multiple errors (more realistic, harder to analyse)."],
  ["Gold references written by Claude, corrected by a native reviewer", "No existing references for new sources. Alternative: professional translators (cost, time)."],
  ["One reviewer", "Availability. A second blind reviewer is listed as a limitation and future improvement."],
  ["No forced-JSON mode", "Matches Sprint 50 and makes format failures measurable. Alternative: JSON mode (near-zero malformed, but changes decoding and hides F13)."],
  ["Temperature 0.7 and 1.0 in Task A", "To expose variability; 1.0 added at the user’s request. 0 is the deployed setting."],
  ["One worker (no parallel calls)", "Parallel calls are batched on the GPU and could change outputs, confounding the repeatability test; speed was adequate."],
  ["Colab without Google Drive", "User requirement. Zip upload / checkpoint download every 30 minutes; nothing lost on disconnect."],
  ["Spearman (rank) rather than Pearson correlation", "Judges’ scores are clustered and not linear; for choosing candidates the order matters most."],
  ["Bootstrap intervals", "No distributional assumptions; works with small, clustered data. Alternatives: t-tests (assume normality), permutation tests (similar conclusions)."],
  ["Paired contrast as the main reliability test", "Independent of calibration and thresholds; band accuracy would overstate MQM failure because one major error leaves 95 (“clean”)."],
  ["Strict tie rule", "For ranking, a tie means “cannot separate”. The loose rule was reported too; conclusions unchanged."],
  ["Five strategies, one style each (Task B)", "Fits the free GPU budget and isolates each effect. Alternative: every strategy in both styles (double the cost)."],
  ["Split by source, 20 / 20", "Prevents leakage between versions of a sentence. Alternatives: random item split (leaks), cross-validation (more GPU time), no split (overfits)."],
  ["Pre-registered rules with point-estimate guards", "Prevents moving the goalposts. Trade-off: with 20 items the guard is strict; S2 failed on non-significant drops. The rule was kept as written; this is reported openly."],
  ["Screening C on the development half before Stage 2", "C was new; adding an unscreened prompt to the confirmation would spend ~1,000 calls on an unknown. Alternative: skip C or test it directly on held-out."],
  ["No flat-style finalist in Stage 2", "S1 and S4 failed the rule; carrying a failed prompt forward would weaken the confirmation."],
  ["Rewordings not reviewed by a native speaker", "Only English instructions changed; the Mandarin examples were byte-identical (checked by code)."],
  ["S2b left as future work", "The held-out half has been used, so a fair test needs fresh items (agreed with the user)."],
  ["Averaging several sampled runs instead of T = 0", "A possible fix for F2 (qwen MQM averaged over 5 runs: ρ 0.66 vs 0.41) but costs 5× and the intervals overlap. Not adopted; listed as an option."],
  ["Changing MQM weights", "Out of scope for prompt engineering; an open follow-up."],
];
T([3300, 6060], ["Choice", "Why, and the alternatives"], alt, { size: 16 });

// ---------------------------------------------------------------- 10
H1("10. Question bank (team lead, product manager, interviewer)");
H2("10.1 Big picture");
QA("In one sentence, what did Sprint 53 find?", "The Sprint 50 judges are reliable for ranking clearly different translations at temperature 0, but not for close calls with the MQM prompt; prompt engineering fixes glm4’s position bias in pairwise judging (confirmed) and makes MQM scoring much more consistent with few-shot examples (directional), while some popular techniques — rubrics, step-by-step reasoning — made things worse.");
QA("Why does this matter for the product?", "GEPA uses the judge to choose between close translation candidates. If the judge is inconsistent or cannot separate a correct translation from one with a meaning error, GEPA optimises noise and may promote worse prompts.");
QA("What should we change today?", "Keep temperature 0; for comparing candidates use the S5 pairwise prompt in both orders (or the flat 0–100 prompt) rather than MQM scores; if MQM error lists are needed, use the few-shot prompt, preferably with qwen, and add a multi-error example (FW1).");
QA("How confident are you?", "Confident about the large effects: glm4’s position bias reduction, the consistency gains of few-shot prompting, the failure of S1 and S3, and Task A’s F1–F7. Less confident about anything that depends on agreement with human scores, because only 20–40 human-scored items were available, giving wide intervals.");
QA("How much did it cost?", "About 12,500 judge calls and 7 GPU-hours on the free Colab tier, plus a native reviewer’s time to check 265 Set B rows and 3 few-shot examples. No paid compute.");
H2("10.2 Method");
QA("How do you know the judge is wrong rather than your test data?", "Failures are defined only against trustworthy references: invariance (the same input should give the same verdict), paired contrast (a flawed version must score below its own correct version), checkable facts (quoted errors must exist) and independent human scores. Set B was reviewed by a native Mainland reviewer. The remaining risk — that some planted errors are debatable — is stated as a limitation.");
QA("Why construct data instead of using real translations?", "Real MT has many overlapping errors, so you cannot tell which one the judge missed. Constructed variants change one thing, so every miss is attributable. Real MT with human scores (Set A) was kept for realism.");
QA("Why Spearman and not accuracy against bands?", "For choosing candidates, the order matters more than the number. Band accuracy also unfairly penalises MQM, because one major error leaves 95, which is “clean”. Both are reported.");
QA("What is a paired bootstrap and why use it?", "Resample the same items (or sources, or pairs) for both prompts 2,000 times and look at the distribution of the difference. If its 95% interval excludes zero, the improvement is statistically supported. It needs no normality assumption and respects that both prompts were run on the same items.");
QA("Why a development / held-out split?", "Prompts and examples were designed while looking at results. Confirming on untouched data shows the improvement is not an artefact of tuning — and indeed several Stage 1 gains shrank on held-out data.");
QA("Why was the success rule written before running?", "So “better” could not be redefined after seeing the results. That is also why S2 is reported as not confirmed even though most of its numbers improved.");
QA("Isn’t it unfair that S2 failed on drops that are not significant?", "It is strict — the guard uses the point estimate, and with 20 items that is noisy. But the rule was fixed in advance, and the glm4 drop has a plausible mechanism (examples show at most one error), so it is a real concern worth fixing (FW1) rather than ignoring.");
QA("Why one change per prompt?", "So that any effect can be attributed to that change. The combined prompt C was tested only after the single changes were understood.");
QA("Why temperature 0.7 in Task B if production uses 0?", "At T = 0 most prompts are nearly deterministic, so consistency differences are hard to see. Sampling at 0.7 amplifies instability and makes differences between prompts measurable; T = 0 repeats were run as well.");
H2("10.3 Results");
QA("What was the most surprising result?", "Two: step-by-step criteria (S3) made the judges excuse real errors — glm4 called “the password is NOT Muiriel” a valid rewording — and a rubric with band definitions made glm4 snap to band edges (85 for 125 of 158 items), destroying its ability to separate translations.");
QA("Why does the MQM prompt fail on close calls?", "Two reasons together: the judges list errors on correct translations (glm4 98%, qwen 66%), and one real major error costs only 5 points, so the real error is smaller than the false-error noise.");
QA("Why does the flat prompt rank better than MQM?", "A holistic score reacts strongly to a real meaning error (e.g. 93 → 73 for glm4) and is not lowered by spurious minor issues, whereas MQM accumulates small false errors and gives real errors only 5 points.");
QA("Why did few-shot help consistency so much?", "Worked examples anchor what an answer should look like — how many errors, what severity — more than the wording of instructions does. That is also why S2 halved the score changes caused by rewording the instructions.");
QA("Why did few-shot hurt glm4 on real MT?", "The three examples have zero or one error. glm4 seems to imitate that, listing too few errors on translations with five or more, and so scoring them too high.");
QA("Why does S5 help glm4 but not qwen?", "glm4 had a strong first-position prior (72% in Task A); explicitly defining ties and saying order is random removes much of it. qwen had a weaker bias to begin with.");
QA("Is temperature 0 deterministic?", "Almost: 85–95% of items identical across runs, 5–8% changing — most likely GPU numerical non-determinism. Across environments (Sprint 50 vs 53, Task A vs B) 73–96% of scores were identical.");
QA("What about Traditional Chinese?", "The judges ignore the script label and treat Traditional copies like Simplified ones; per the product decision this is acceptable. If a script policy is ever needed, it must be stated explicitly in the prompt.");
QA("Did asking the judge to explain itself help?", "No. It changed scores (glm4 moved ≥ 10 points on 70% of items) without improving agreement with humans, and 13 of 50 audited explanations described errors that did not exist.");
H2("10.4 Engineering and process");
QA("How did you run 12,500 calls on a free GPU that disconnects?", "Every call is saved immediately with a unique key; the runner skips completed keys; runs are time-boxed in 30-minute chunks with a checkpoint zip downloaded after each; a new session uploads the newest zip and continues. Tested against a fake server, including kills and crashes.");
QA("How do you know the same model was used throughout?", "Model digests and the Ollama version were recorded every session; digests were identical in all 11 sessions.");
QA("Can someone reproduce this?", "Yes — Part 2 of this guide. All analyses rebuild from saved results in minutes on a CPU; a full re-run needs a T4-class GPU for about 7 hours of judging. Exact scores may differ slightly (F3), but conclusions should not.");
QA("What were the main risks and how were they handled?", "Data quality (automatic validation + native review; a merge bug caught by a new check); overfitting prompts (held-out split, pre-registration); environment drift (baseline re-run every session, digests recorded); GPU disconnects (resumable runner, checkpoints).");
H2("10.5 Next steps");
QA("What would you do next?", "FW1 (multi-error few-shot example on fresh items) first; then a larger human-scored set, a test of revised MQM weights, and a check on a larger judge model.");
QA("Should we switch to a bigger judge model?", "Possibly, but Sprint 53 did not test one, so there is no evidence either way here. Larger judges may show fewer of these failures (position bias, false errors, format drift), but cost and latency rise and the same tests should be run before switching. The test harness and datasets can evaluate any Ollama or API model with small changes (Section 21).");

// ---------------------------------------------------------------- 11
H1("11. Lessons learned");
Bs([
  "**Know the answer before you test the judge.** Constructed data with one change per variant turned vague impressions into measurable failures.",
  "**Measure invariance.** Re-running, swapping and rewording are cheap and reveal unreliability without any ground truth.",
  "**Popular prompting techniques can backfire.** Reasoning steps and rubrics, often assumed to help, made these small judges worse in specific, explainable ways.",
  "**Examples teach more than instructions** — including unintended lessons (at most one error).",
  "**Small judges are fragile to wording and format**; always test with rewordings and check output formats.",
  "**Write the rule first, then keep it** — even when the result is disappointing.",
  "**Engineer for interruptions** on free hardware: save every call, checkpoint often, test against a fake server first.",
  "**Validate data merges with automatic checks**; a reviewer’s helpful corrections nearly corrupted test rows.",
]);

// =====================================================================================  PART 2
C.push(new Paragraph({ pageBreakBefore: true, spacing: { before: 2400, after: 200 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "PART 2", font: FONT, size: 28, color: GREY })] }));
C.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 300 }, children: [new TextRun({ text: "Runbook", font: FONT, size: 48, bold: true, color: NAVY })] }));
C.push(new Paragraph({ alignment: AlignmentType.CENTER, children: runs("Step-by-step instructions to reproduce or re-run Sprint 53 from the code base", { color: BLUE, size: 24 }) }));

H1("12. What you need");
T([2600, 6760], ["Item", "Details"], [
  ["Code base", "`Sprint53_Complete_Codebase.zip` — one folder `sprint53/` with all code, data, review files, notebooks, saved results and reports"],
  ["Google account", "For Google Colab (free tier is enough). Google Drive is not needed"],
  ["GPU (full re-run only)", "Colab Tesla T4 (15 GB) or any NVIDIA GPU with ≥ 12 GB that can hold glm4 9B and qwen2.5 7B at 4-bit together"],
  ["CPU environment (analysis, datasets)", "Colab CPU runtime, or any Linux / macOS machine with Python 3.10+ and (for reports) Node.js 18+"],
  ["Python packages", "pandas, numpy, scipy, matplotlib, openpyxl, opencc-python-reimplemented, requests (all preinstalled on Colab except OpenCC)"],
  ["Node package", "docx (only to rebuild the Word reports): `npm install docx`"],
  ["Native reviewer (optional)", "Only if you rebuild Set B from scratch or change few-shot examples"],
  ["Time", "Reproduce analyses: ≈ 10 minutes. Full re-run: Task A ≈ 2.5 GPU-hours, Task B ≈ 4.6 GPU-hours (2–4 Colab sessions each), plus ≈ 5 minutes of setup per session"],
], { size: 16 });

H1("13. The code base", false);
T([2900, 6460], ["Folder / file", "Purpose"], [
  ["data/raw/", "Unchanged Sprint 50 gold set, Sprint 50 per-sentence scores and Sprint 52 items"],
  ["data/processed/", "Set A (40), Set B (275), pairs (60), validation and merge reports"],
  ["data/taskB/", "Development / held-out split, repeat subset, few-shot exclusion list, Stage 2 finalists"],
  ["scripts/", "Dataset building (`build_datasets.py`, `setb_content.py`), validation, review workbook, review merge and fixes, chrF"],
  ["review/", "Reviewer workbooks and instructions (blank and completed) for Set B and the Task B few-shot examples"],
  ["judge/", "`settings.py` (all settings), `prompts.py` (Task A prompts), `prompts_taskb.py` (Task B prompts), `ollama_client.py`, `parsing.py`, `plan.py` (Task A phases)"],
  ["run_experiments.py", "Task A runner: `--check`, `--status`, `--smoke`, `--run` (resumable, time-boxed)"],
  ["colab/setup_ollama.sh", "Installs and starts Ollama, downloads both judges"],
  ["taskB/", "Task B: split, prompt checks, plan, runner (`run_taskb.py`), analyses, charts, pre-registered rules, guidelines"],
  ["notebooks/", "Colab notebooks for every step (listed in Sections 16–17)"],
  ["analysis/", "Task A analysis (`analyze.py`, `charts.py`, `examples.py`) and the manual audit labels"],
  ["results/, results_taskB/", "Every judge call of Task A and Task B (one JSON line each), environment records, prompt snapshots"],
  ["analysis_out/, analysis_taskB/", "Analysis tables, charts and summaries"],
  ["report/", "Report builders and the three Word documents"],
  ["tests/mock_ollama.py", "Fake Ollama server for testing without a GPU"],
], { size: 16 });

H1("14. Two ways to use it", false);
T([2600, 3500, 3260], ["Goal", "What to do", "Needs"], [
  ["A. Check or reuse the results, rebuild tables, charts and reports", "Section 15 — run the analysis scripts on the saved results", "CPU only, ≈ 10 minutes"],
  ["B. Run the experiments again (new judge calls)", "Sections 16–17 — follow Task A then Task B step by step", "T4 GPU, ≈ 7 hours of judging over several sessions"],
], { size: 17 });
P("**Before a full re-run, start from a clean copy.** Saved results make the runners skip work that is already done. Unzip the code base on your computer and delete these folders and files, then zip the `sprint53` folder again (zip the folder itself, so the zip contains a single top-level `sprint53/`):");
code("sprint53/results/\nsprint53/results_taskB/\nsprint53/analysis_out/\nsprint53/analysis_taskB/\nsprint53/data/taskB/          (Task B rebuilds it in Step B1)");
P("Keep `data/raw/`, `data/processed/` and `review/` — they hold the reviewed datasets. Call the new zip `sprint53_clean.zip`.");

H1("15. Reproduce all analyses and reports from saved results");
P("Works on a Colab CPU runtime or any machine with Python and Node.");
STEP("Step 1 — Open a CPU environment and unpack");
P("In Colab: **File → New notebook**, **Runtime → Change runtime type → CPU**. Then run in a cell:");
code("from google.colab import files\nup = files.upload()                       # choose Sprint53_Complete_Codebase.zip\n!unzip -q -o Sprint53_Complete_Codebase.zip -d /content\n%cd /content/sprint53\n!pip -q install -r requirements.txt pandas scipy matplotlib");
STEP("Step 2 — Task A analysis");
code("!python analysis/analyze.py      # tables -> analysis_out/tables, charts -> analysis_out/charts, metrics.json\n!python analysis/examples.py     # worked examples -> analysis_out/examples.md");
STEP("Step 3 — Task B analyses and charts");
code("!python taskB/analyze_stage1.py   # must start 'Calls: 3276, malformed 1' and end with 'FINALISTS: mqm_fewshot, pairwise_tie'\n!python taskB/analyze_stage2.py   # must start 'Calls: 4478, malformed 36'; decision: S2 NOT CONFIRMED, S5 PROMISING\n!python taskB/charts_taskB.py");
P("Note: with the Stage 1b results present, `analyze_stage1.py` counts Stage 1 + Stage 1b calls together (2,840 + 436 = 3,276).");
STEP("Step 4 — Rebuild the Word reports (optional)");
code("!npm install -s docx\n!python report/build_report_data.py && node report/build_report.js               # Task A report\n!python report/build_report_data_taskB.py && node report/build_report_taskB.js   # Task B report\n!node report/build_sprint53_guide.js                                               # this guide");
STEP("Step 5 — Download");
code("!zip -q -r /content/outputs.zip analysis_out analysis_taskB report\nfiles.download('/content/outputs.zip')");

// ---------------------------------------------------------------- 16 Task A
H1("16. Full re-run — Task A");
P("Order: A1 datasets (CPU) → A2 GPU setup and smoke test → A3 all experiments → A4 analysis → A5 report. Each step lists what to run and what correct output looks like.");
H2("A1. Datasets (CPU)");
P("**Recommended: reuse the reviewed datasets** that are already in `data/processed/`. Just validate them:");
code("# in a CPU notebook, after unpacking sprint53_clean.zip to /content\n%cd /content/sprint53\n!bash run_step1.sh");
P("Because a review has already been merged, the script **does not rebuild** (that would discard the reviewer’s corrections) and only validates. Correct output ends with `HARD FAILURES: 0`, `WARNINGS: 1` (the S52_004 password paraphrase is lexically close — expected) and `>> Step 1 finished.`");
P("**Only if you want to rebuild Set B from scratch** (e.g. after editing `scripts/setb_content.py`) — this needs a new human review:");
N([
  "`bash run_step1.sh --force-rebuild --review-files` — builds and validates the datasets and the reviewer workbook `review/SetB_Review_Workbook.xlsx` and instructions `review/SetB_Reviewer_Instructions.docx` (the .docx needs Node).",
  "Send both files to a native Mainland Mandarin reviewer; they fill the yellow columns.",
  "Put the returned workbook in `review/` and run `bash run_step1.sh --merge review/<returned_workbook>.xlsx`. Read `data/processed/merge_report.txt` and resolve anything under NEEDS ATTENTION.",
  "Run `bash run_step1.sh --fixes` to apply hand fixes (restores original MT outputs if a reviewer corrected them; updates dependent Taiwan versions). Must end with `HARD FAILURES: 0`.",
]);
H2("A2. GPU setup and smoke test (Colab T4)");
N([
  "Open `notebooks/Sprint53_Colab.ipynb` in Colab (**File → Upload notebook**). **Runtime → Change runtime type → T4 GPU**.",
  "**Cell 1** — GPU check: shows `Tesla T4, 15360 MiB`.",
  "**Cell 2** — upload `sprint53_clean.zip` (a single zip containing data and code satisfies both checks). Output lists the folder contents and `Results files: none yet`.",
  "**Cell 3** — installs Ollama, starts it, downloads glm4 (≈ 5.5 GB) and qwen2.5:7b (≈ 4.7 GB); 3–15 minutes; ends with `Setup finished`, the GPU, the Ollama version and two model lines with digests. The original run had `5b699761eca5` (glm4) and `845dbda0ea48` (qwen); if Ollama publishes new versions of these tags, digests may differ — record them.",
  "**Cell 4** — status: 11 phases, `TOTAL 4758`, 0 done.",
  "**Cell 5** — defines `save_checkpoint()`.",
  "**Cell 6** — smoke test: one call per registered prompt per judge (54 calls, because the Task B prompts are registered too); expect `Parsed: 54/54` or close, warm seconds per call and a total time estimate. A checkpoint zip downloads.",
]);
H2("A3. Run all experiments");
N([
  "**Cell 7** runs the phases in 30-minute chunks, downloads a checkpoint zip after each chunk, and stops after 3 h 15 min (`SESSION_BUDGET_MIN = 195`). `WORKERS = 1` (keep it).",
  "Keep the browser tab open; allow multiple downloads; click in the notebook every 20–30 minutes.",
  "When the session ends or disconnects: new session → T4 → cells 1–5 (in cell 2 upload **only the newest** `sprint53_checkpoint_<time>.zip`) → cell 7 again. It continues where it stopped; nothing is duplicated.",
  "Done when it prints that all phases are complete; cell 4 shows `TOTAL 4758 4758 100%`. Run **cell 8** for a final checkpoint. Expected judging time ≈ 2.5 hours.",
]);
H2("A4. Analysis (CPU)");
P("Unpack the final checkpoint in a CPU notebook and run Section 15, Step 2. Outputs: `analysis_out/tables/*.csv` (22 tables), `analysis_out/charts/*.png` (7 charts), `analysis_out/metrics.json`, `analysis_out/examples.md`. The manual audit uses `analysis/manual_audit_labels.csv`, keyed to the audit sample; with new results the sample changes, so a new manual audit is needed if you want E10’s audit table.");
H2("A5. Task A report");
P("Section 15, Step 4 (first line). The report text contains hand-written interpretation of the original numbers; after a re-run, check the narrative against the new tables.");

// ---------------------------------------------------------------- 17 Task B
H1("17. Full re-run — Task B");
P("Task B starts from the complete Task A project (its results are needed for the baseline reference and the prompt snapshot). Order: B1 split → B2 prompts → B3 smoke → B4 Stage 1 → B5 Stage 1b + Stage 2 → B6 analysis → B7 report.");
H2("B1. Baseline and split (CPU)");
N([
  "Open `notebooks/TaskB_Step1_Colab.ipynb` (CPU runtime).",
  "**Cell 1** — upload the final Task A checkpoint (or the complete code base without `data/taskB/`). It asks one file at a time until it has both Task A results and Task B code; a single complete zip satisfies both.",
  "**Cell 2** — `python taskB/make_split.py`: expected `Chosen seed 1324 (penalty 3.20). dev sources 20, held-out sources 20; repeat subset 40 items`.",
  "**Cell 3** — `python taskB/validate_split.py`: must end `HARD FAILURES: 0` and `WARNINGS: 0`; writes `data/taskB/baseline_reference.csv` (Task A numbers per half).",
  "**Cell 4** — downloads `sprint53_taskB_B1_<time>.zip`.",
]);
P("The pre-registered rules are in `taskB/BASELINE_AND_METRICS.md`. If you change them, do it **before** running anything.");
H2("B2. Strategy prompts and reviewer check (CPU)");
N([
  "Open `notebooks/TaskB_Step2_Colab.ipynb` (CPU). Cell 1: upload the B1 checkpoint.",
  "**Cell 2** — `python taskB/check_prompts.py`: must end `HARD FAILURES: 0`. It checks that the baseline prompts are identical to Task A’s, every prompt renders, few-shot examples come from the development half and match the data, no held-out text is in any prompt, and the parser handles every format.",
  "**Cell 3** — downloads `review/TaskB_FewShot_Review.xlsx` (send to the reviewer; ≈ 10 minutes), `taskB/PROMPTS_FOR_REVIEW.md` (all prompts in full) and a checkpoint.",
  "If the reviewer changes an example, edit `FEWSHOT_EXAMPLES` in `judge/prompts_taskb.py` and re-run cell 2. The original review is in `review/TaskB_FewShot_Review_completed.xlsx` (all three confirmed).",
]);
H2("B3. GPU smoke test (Colab T4)");
N([
  "Open `notebooks/TaskB_GPU_Colab.ipynb`; runtime **T4 GPU**.",
  "**Cell 1** GPU check. **Cell 2** upload the B2 checkpoint (it asks until it has data and code). **Cell 3** installs Ollama and both models and records the environment (ends with the model digests). **Cell 4** status: 7 phases, `TOTAL 2840`, 0 done. **Cell 5** defines `save_checkpoint()`.",
  "**Cell 6** — 16 calls (8 prompts × 2 judges): expect `Parsed: 16/16`, every `end` = `stop` (not `length`), and a Stage 1 time estimate (the original estimate of 1h43m was pessimistic; actual 91 minutes).",
]);
H2("B4. Stage 1 screening (Colab T4)");
N([
  "**Cell 7** (same notebook) runs Stage 1 in 30-minute chunks with checkpoint downloads, stopping after 3 h 15 min. Expected ≈ 1.5 hours; ends with `STAGE 1 COMPLETE` and all 7 phases at 100%.",
  "If interrupted: new session → cells 1–5, uploading only the newest `sprint53_taskB_run_<time>.zip` → cell 7.",
  "Optional CPU check: `notebooks/TaskB_Step4_Analysis_Colab.ipynb` runs `taskB/analyze_stage1.py` and downloads the tables. Stage 1 decision table: S2 and S5 PASS in the original run.",
  "**Finalists.** In the original run the user approved S2 and S5. They are fixed in `taskB/analyze_stage1.py` (the `fin = [\"mqm_fewshot\", \"pairwise_tie\"] + …` line). If your Stage 1 gives different passes, edit that list before Stage 2.",
]);
H2("B5. Stage 1b and Stage 2 (Colab T4)");
N([
  "Open `notebooks/TaskB_B5_GPU_Colab.ipynb`; runtime **T4 GPU**. Cells 1–5 as before (cell 2: upload the newest Stage 1 checkpoint; cell 3 also runs `taskB/check_prompts_b5.py`, which must print `HARD FAILURES: 0`). Cell 4 shows Stage 1b: 2 phases, `TOTAL 436`.",
  "**Cell 6** — smoke test of the 10 new prompts (20 calls): expect `Parsed: 20/20`, all `stop`, and time estimates (the first glm4 call includes warm-up and inflates the estimate).",
  "**Cell 7** — Stage 1b (≈ 20 minutes) then the analysis. It refuses to start if the smoke test was not clean. Ends with the decision table, the C-vs-S2 table and a `FINALISTS:` line; `data/taskB/stage2_finalists.json` is written. Original result: C passes vs baseline but is clearly worse than S2 → finalists `mqm_fewshot, pairwise_tie`.",
  "**Cell 8** — Stage 2 on the held-out half: 4,478 calls without C (5,512 with C), ≈ 2.5–3 hours, usually two sessions. Resume as before with the newest checkpoint and cells 1–5, then cell 8. Ends with `STAGE 2 COMPLETE` and 7 phases at 100%.",
  "**Cell 9** — final checkpoint.",
]);
H2("B6. Stage 2 analysis (CPU)");
P("`notebooks/TaskB_Step6_Analysis_Colab.ipynb`: upload the final checkpoint; cell 2 runs `taskB/analyze_stage2.py` (≈ 1 minute) and prints all tables and the pre-registered decision; cell 3 downloads the tables and a checkpoint. Then `python taskB/charts_taskB.py` for the report charts.");
H2("B7. Recommendation and report");
P("The recommendation and guidelines are in `taskB/RECOMMENDATION_AND_GUIDELINES.md`. To rebuild the report: `python report/build_report_data_taskB.py && node report/build_report_taskB.js`. As for Task A, check the narrative text against the new tables after a re-run.");

// ---------------------------------------------------------------- 18
H1("18. Running outside Colab, and testing without a GPU");
H2("18.1 Any Linux machine with an NVIDIA GPU");
code("cd sprint53\npip install -r requirements.txt pandas scipy matplotlib requests\nbash colab/setup_ollama.sh                 # or install Ollama yourself and: ollama pull glm4; ollama pull qwen2.5:7b\n# Task A\npython run_experiments.py --check && python run_experiments.py --smoke\npython run_experiments.py --run --budget 8h   # resumable; repeat the same command after any stop\n# Task B\npython taskB/make_split.py && python taskB/validate_split.py && python taskB/check_prompts.py\npython taskB/run_taskb.py --check && python taskB/run_taskb.py --smoke\npython taskB/run_taskb.py --run --stage 1 --budget 8h\npython taskB/analyze_stage1.py\npython taskB/check_prompts_b5.py && python taskB/run_taskb.py --smoke --prompts b5\npython taskB/run_taskb.py --run --stage 1b --budget 2h && python taskB/analyze_stage1.py\npython taskB/run_taskb.py --run --stage 2 --budget 8h\npython taskB/analyze_stage2.py && python taskB/charts_taskB.py");
P("`--status` shows progress at any time (`python run_experiments.py --status`, `python taskB/run_taskb.py --status --stage 1|1b|2`). Ollama must be started with `OLLAMA_MAX_LOADED_MODELS=2` so both judges stay in memory (the setup script does this).");
H2("18.2 Testing the pipeline without a GPU");
P("`tests/mock_ollama.py` imitates the Ollama API with random but well-formed (and occasionally malformed) answers. Use it to check that everything runs end to end before spending GPU time:");
code("python tests/mock_ollama.py 11500 &\nexport OLLAMA_HOST_URL=http://127.0.0.1:11500\npython run_experiments.py --check && python run_experiments.py --smoke\npython taskB/run_taskb.py --status --stage 1");
P("Results produced against the mock are meaningless — delete `results/` and `results_taskB/` afterwards.");

// ---------------------------------------------------------------- 19
H1("19. Expected outputs checklist", false);
T([3600, 5760], ["Step", "Correct output (original run)"], [
  ["Task A datasets", "Set B 275 rows from 40 sources; 60 pairs; HARD FAILURES 0; 1 warning (S52_004)"],
  ["Task A status before run", "11 phases, TOTAL 4758"],
  ["Task A run", "4,758 / 4,758 calls; 0 unreadable; ≈ 2.5 GPU-hours"],
  ["Task A key numbers", "Set B ρ with true quality: flat 0.55 / 0.57, MQM 0.05 / 0.14; glm4 first-position 72%"],
  ["Task B split", "seed 1324; 20 / 20 sources; repeat subset 40; HARD FAILURES 0, WARNINGS 0"],
  ["Task B prompt checks", "HARD FAILURES 0 (check_prompts.py and check_prompts_b5.py)"],
  ["Task B smoke tests", "16 / 16 and 20 / 20 parsed; all `stop`"],
  ["Stage 1", "7 phases, 2,840 calls, 1 unreadable; S2 and S5 PASS"],
  ["Stage 1b", "436 calls; C PASS vs baseline but clearly worse than S2; finalists mqm_fewshot, pairwise_tie"],
  ["Stage 2", "7 phases, 4,478 calls, 36 unreadable (glm4, reworded pairwise); S2 NOT CONFIRMED, S5 PROMISING"],
  ["Environment", "Tesla T4; Ollama 0.35.0 (Task A) / 0.35.1 (Task B); glm4 5b699761eca5, qwen 845dbda0ea48"],
], { size: 16 });
P("**Reproducibility expectation.** A re-run will not reproduce every score exactly: temperature 0 on a GPU is not fully deterministic, and Ollama or model versions may change (F3). In the original work, 73–96% of scores were identical between environments. Conclusions based on large effects should hold; small differences may move.");

// ---------------------------------------------------------------- 20
H1("20. Troubleshooting");
T([3300, 6060], ["Problem", "What to do"], [
  ["Upload dialog will not accept two files", "The Task B notebooks ask for one file at a time and keep asking until they have what they need. Upload one, wait, then the next."],
  ["No upload prompt appears in cell 2", "Colab reconnected to an old runtime that already has the files. Check with the status cell; for a clean start use **Runtime → Disconnect and delete runtime**, or run `!rm -rf /content/sprint53`."],
  ["Cell 3 seems stuck after the first `success`", "It is downloading the second model (≈ 4.7 GB) with the progress bar hidden. Wait up to ≈ 20 minutes; if longer, interrupt and re-run cell 3 (it resumes the download)."],
  ["“No GPU available” / usage limit", "The free daily GPU quota is used. Wait a few hours; resume from the newest checkpoint. Nothing is lost."],
  ["Runner stopped with an error", "Usually Ollama stopped. Re-run cell 3, then the run cell; saved calls are kept."],
  ["Session budget used", "Normal. Start a new session with the newest checkpoint zip."],
  ["Model digests differ from the original", "Ollama updated the tag. Results are still valid but not identical; record the digests. To match exactly, pin the Ollama version (`OLLAMA_VERSION=0.35.0`/`0.35.1` before the installer) — model files may still differ."],
  ["Unreadable (malformed) answers", "Counted, not an error. Check the `raw_response` field in the result file; above 5% for a main prompt, review the prompt’s output format (G8)."],
  ["`analyze_stage1.py` says finalists file not found / Stage 2 refuses to start", "Run Stage 1b and `taskB/analyze_stage1.py` first; Stage 2 reads `data/taskB/stage2_finalists.json`."],
  ["Runner skips everything", "Results for those keys already exist. For a fresh run, start from a clean copy (Section 14)."],
  ["`docx` not found when building reports", "`npm install docx` in the `sprint53` folder."],
], { size: 16 });

// ---------------------------------------------------------------- 21
H1("21. Adapting the experiments", false);
T([3000, 6360], ["Change", "Where"], [
  ["Different judge model", "`judge/settings.py` → `MODELS` (Ollama tag); check memory; re-run the smoke test"],
  ["Different decoding settings", "`judge/settings.py` (`NUM_CTX`, `NUM_PREDICT`, `MAX_ATTEMPTS`, seeds)"],
  ["New prompt", "Add the template to `judge/prompts_taskb.py` (`TASKB_PROMPTS`, with its output format), add a parser branch in `judge/parsing.py` if the format is new, add it to a phase in `taskB/plan_taskb.py`, and add checks to a `check_prompts` script"],
  ["New phases or repeats", "Task A: `judge/plan.py`; Task B: `taskB/plan_taskb.py` (`STAGE1`, `STAGE1B`, `STAGE2_ALL`)"],
  ["New data / language pair", "Add items in the same JSONL format (`item_id`, `source_text`, `candidate`, `reference`, human score or expected band, planted error). Update the target-language label in `judge/prompts.py`; re-run validation and the split"],
  ["Decision rules and metrics", "Task B: `taskB/BASELINE_AND_METRICS.md` (write before running) and the analysis scripts"],
  ["API judge instead of Ollama", "Replace `judge/ollama_client.generate()` with an API call returning the same fields (text, token counts, done reason); keep everything else"],
], { size: 16 });

// ---------------------------------------------------------------- appendices
H1("Appendix A. Glossary");
T([2400, 6960], ["Term", "Meaning"], [
  ["LLM-as-a-judge", "A language model used to score or compare translations"],
  ["GEPA", "Vosyn’s automatic prompt-optimisation loop that uses the judge"],
  ["MQM", "Multidimensional Quality Metrics; errors with type and severity; score 100 − Σ(1 / 5 / 25)"],
  ["Flat prompt", "One holistic 0–100 score"],
  ["Set A / Set B / pairs", "Real MT with human scores / controlled variants / A-vs-B comparisons"],
  ["Gold, paraphrase, literal, fluent-wrong, targeted error", "Set B variant types (correct; correct but reworded; stiff but correct; natural but one meaning error; one category error)"],
  ["Band", "clean ≥ 85, moderate 60–84, poor < 60"],
  ["Inconsistent item", "Repeated runs differ by ≥ 10 points or change band"],
  ["Paired contrast", "Flawed version must score strictly below its own correct version"],
  ["Spearman ρ", "Rank correlation (−1 to 1)"],
  ["Krippendorff’s α", "Agreement of repeated ratings beyond chance"],
  ["Bootstrap / paired bootstrap CI", "Uncertainty interval from resampling; paired = difference between two prompts on the same units"],
  ["Development / held-out half", "Data to design and screen / data to confirm"],
  ["Pre-registration", "Writing the success rule before the experiment"],
  ["Position bias", "Preferring an option because of where it is shown"],
  ["Temperature, seed", "Randomness of generation; random starting point"],
  ["Digest", "Hash identifying an exact model file"],
  ["Checkpoint zip", "Snapshot of the project folder with all results, used to resume on Colab"],
  ["S1–S5, C, S2b", "Task B strategies (rubric, few-shot, steps, accuracy+fluency, pairwise+tie), combined prompt, future multi-error few-shot"],
  ["F1–F13", "Task A failure catalogue"],
  ["G1–G15, FW1–FW7", "Task B guidelines and future-work items"],
], { size: 16, zebra: false, shadeFirst: true });
H1("Appendix B. File reference");
T([3600, 5760], ["File", "What it is"], [
  ["Sprint53_TaskA_LLM_Judge_Failure_Analysis.docx", "Task A report (37 pages)"],
  ["Sprint53_TaskB_Prompt_Engineering_Report.docx", "Task B report (34 pages)"],
  ["Sprint53_Complete_Guide_and_Runbook.docx", "This guide"],
  ["Sprint53_Complete_Codebase.zip", "Everything: code, data, reviews, notebooks, results, analyses, reports"],
  ["taskB/BASELINE_AND_METRICS.md", "Task B pre-registered baseline, split, metrics and rules"],
  ["taskB/RECOMMENDATION_AND_GUIDELINES.md", "Task B recommendation, guidelines G1–G15, future work"],
  ["taskB/PROMPTS_FOR_REVIEW.md, PROMPTS_B5_FOR_REVIEW.md", "All Task B prompts in full"],
  ["README_STEP1.md, README_STEP2.md, analysis/README_STEP5.md, LIGHTNING_GUIDE.md", "Original per-step notes for Task A"],
  ["data/processed/validation_report.txt, merge_report.txt", "Dataset validation and review-merge logs"],
  ["data/taskB/split_validation_report.txt", "Split checks"],
  ["results*/environment.jsonl", "GPU, Ollama version and model digests per session"],
], { size: 16 });

// =====================================================================================
const doc = new Document({
  creator: "Vosyn Supernova · Sprint 53",
  title: "Sprint 53 — Complete reference guide and runbook",
  styles: {
    default: { document: { run: { font: "Arial", size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, color: NAVY, font: "Arial" }, paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 25, bold: true, color: BLUE, font: "Arial" }, paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 22, bold: true, color: NAVY, font: "Arial" }, paragraph: { spacing: { before: 220, after: 80 }, outlineLevel: 2, keepNext: true } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [0, 1, 2].map((l) => ({ level: l, format: LevelFormat.BULLET, text: ["•", "–", "·"][l], alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540 + l * 360, hanging: 270 } } } })) },
      ...NUMREFS.map((ref) => ({ reference: ref, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] })),
    ],
  },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1300, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "Sprint 53 · Complete reference guide and runbook", font: FONT, size: 16, color: GREY })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Page ", font: FONT, size: 16, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: GREY })] })] }) },
    children: C,
  }],
});
Packer.toBuffer(doc).then((b) => { fs.writeFileSync(OUT, b); console.log("wrote " + OUT); });
