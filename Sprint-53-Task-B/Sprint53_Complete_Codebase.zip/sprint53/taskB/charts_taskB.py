"""
Task B report charts.  python taskB/charts_taskB.py   ->  analysis_taskB/charts/*.png
Reads the Stage 1/2 analysis tables (run analyze_stage1.py and analyze_stage2.py first).
Colours: baseline = neutral greys, strategy = categorical slot 1 (blue); judges = slots 1-2 (as Task A).
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S1 = os.path.join(ROOT, "analysis_taskB", "stage1")
S2 = os.path.join(ROOT, "analysis_taskB", "stage2")
OUT = os.path.join(ROOT, "analysis_taskB", "charts")
os.makedirs(OUT, exist_ok=True)
JC = {"glm4": "#2a78d6", "qwen": "#eb6834"}
BASE, BASE2, NEW = "#b4b2ab", "#7d7b75", "#2a78d6"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.titlesize": 10, "axes.titleweight": "bold",
                     "axes.titlecolor": INK, "figure.facecolor": SURF, "axes.facecolor": SURF, "legend.frameon": False})


def tidy(ax, grid_axis="y"):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def save(fig, name):
    fig.savefig(os.path.join(OUT, name), dpi=200, bbox_inches="tight", facecolor=SURF)
    plt.close(fig)


def bars(ax, groups, series, vals, colors, fmt="{:.0%}", ylim=(0, 1.05)):
    n = len(series)
    w = 0.8 / n
    x = np.arange(len(groups))
    for k, s in enumerate(series):
        pos = x - 0.4 + w * (k + 0.5)
        ax.bar(pos, vals[s], w * 0.92, color=colors[s], label=s, zorder=2)
        for p, v in zip(pos, vals[s]):
            ax.text(p, v + (ylim[1] - ylim[0]) * 0.015, fmt.format(v), ha="center", va="bottom", fontsize=7.5, color=INK2)
    ax.set_xticks(x, groups)
    ax.set_ylim(*ylim)
    tidy(ax)


# ---------------------------------------------------------------- 1 study design
fig, ax = plt.subplots(figsize=(9.2, 2.6))
ax.set_xlim(0, 100)
ax.set_ylim(0, 30)
ax.axis("off")
boxes = [(1, "B1\nBaseline + split", "Sprint 50 prompts\n20 / 20 sources\nrules written first"),
         (21, "B2–B3\nStrategy prompts", "S1–S5 written\nfew-shot reviewed\nsmoke test 16/16"),
         (41, "B4\nStage 1 screening", "development half\n2,840 calls\nS2, S5 pass"),
         (61, "B5\nStage 1b + Stage 2", "combined C screened\nheld-out half\n436 + 4,478 calls"),
         (81, "B6–B7\nAnalysis + advice", "paired bootstrap\nconsistency, wording\nrecommendation")]
for x0, t, sub in boxes:
    ax.add_patch(FancyBboxPatch((x0, 4), 17.5, 22, boxstyle="round,pad=0.3,rounding_size=1.2", fc="#eef3fa", ec=NEW, lw=1))
    ax.text(x0 + 8.75, 20.5, t, ha="center", va="center", fontsize=8.4, linespacing=1.3, weight="bold", color=INK)
    ax.text(x0 + 8.75, 10.0, sub, ha="center", va="center", fontsize=7.8, color=INK2, linespacing=1.5)
for x0 in (19.0, 39.0, 59.0, 79.0):
    ax.annotate("", xy=(x0 + 1.8, 15), xytext=(x0 - 0.2, 15), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=1))
save(fig, "B_fig1_design.png")

# ---------------------------------------------------------------- 2 Stage 1 consistency (dev, T=0.7 x3)
c1 = pd.read_csv(os.path.join(S1, "S1_consistency_T07.csv"))
order = ["flat", "flat_rubric", "flat_accflu", "mqm", "mqm_fewshot", "mqm_steps", "mqm_combined"]
lab = {"flat": "flat\n(baseline)", "flat_rubric": "S1\nrubric", "flat_accflu": "S4\nacc+flu", "mqm": "MQM\n(baseline)",
       "mqm_fewshot": "S2\nfew-shot", "mqm_steps": "S3\nsteps", "mqm_combined": "C\ncombined"}
order = [o for o in order if o in set(c1.prompt)]
fig, ax = plt.subplots(figsize=(9.2, 3.2))
vals = {m: [float(c1[(c1.prompt == p) & (c1.model == m)].inconsistent_share.iloc[0]) for p in order] for m in JC}
bars(ax, [lab[p] for p in order], list(JC), vals, JC)
ax.axvline(2.5, color=GRID, lw=1)
ax.set_ylabel("share of items inconsistent")
ax.legend(loc="upper left", ncol=2, fontsize=8)
ax.set_title("Stage 1 (development half): items whose 3 runs at T = 0.7 differ by ≥ 10 points or change band", loc="left", fontsize=9.5)
save(fig, "B_fig2_stage1_consistency.png")

# ---------------------------------------------------------------- 3 Stage 2 consistency
c2 = pd.read_csv(os.path.join(S2, "T2_consistency.csv"))
fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.1), sharey=True)
for ax, T, title in ((axes[0], 0.0, "T = 0, 3 runs"), (axes[1], 0.7, "T = 0.7, 5 runs")):
    g = c2[c2.temperature == T]
    vals = {s: [float(g[(g.prompt == p) & (g.model == m)].inconsistent_share.iloc[0]) for m in JC]
            for s, p in (("flat (baseline)", "flat"), ("MQM (baseline)", "mqm"), ("S2 few-shot MQM", "mqm_fewshot"))}
    bars(ax, list(JC), list(vals), vals, {"flat (baseline)": BASE, "MQM (baseline)": BASE2, "S2 few-shot MQM": NEW})
    ax.set_title(title, loc="left")
axes[0].set_ylabel("share of items inconsistent")
axes[1].legend(loc="upper right", fontsize=8)
fig.suptitle("Stage 2 (held-out repeat subset, 40 items): inconsistent items by prompt", x=0.01, ha="left", fontsize=9.5, weight="bold")
fig.tight_layout()
save(fig, "B_fig3_stage2_consistency.png")

# ---------------------------------------------------------------- 4 S2 vs MQM: paired deltas with CI
d = pd.read_csv(os.path.join(S2, "T3_deltas_vs_baseline.csv"))
d = d[d.strategy == "S2 few-shot"]
mets = [("false_error_rate_on_correct", -1, "Correct translations flagged with errors ↓"),
        ("above_gold", -1, "Flawed version scored above its correct version ↓"),
        ("below_gold_strict", +1, "Flawed version scored below its correct version ↑"),
        ("planted_error_detected", +1, "Planted error found ↑"),
        ("spans_not_in_translation", -1, "Quoted error spans not in the translation ↓"),
        ("inconsistent_share_T0.7", -1, "Inconsistent over 5 runs at T = 0.7 ↓"),
        ("literal_beats_fluent_wrong", +1, "Correct literal ranked above fluent-but-wrong ↑"),
        ("rho_human_setA", +1, "Agreement with human scores (Spearman ρ) ↑")]
fig, ax = plt.subplots(figsize=(9.2, 4.6))
y = np.arange(len(mets))[::-1]
for k, (m, sg, _) in enumerate(mets):
    for j, (judge, off) in enumerate((("glm4", 0.17), ("qwen", -0.17))):
        r = d[(d.metric == m) & (d.model == judge)].iloc[0]
        v, lo, hi = r.delta * sg, r.ci_lo * sg, r.ci_hi * sg
        lo, hi = min(lo, hi), max(lo, hi)
        ax.plot([lo, hi], [y[k] + off] * 2, color=JC[judge], lw=2, solid_capstyle="round", zorder=2)
        ax.scatter([v], [y[k] + off], s=36, color=JC[judge], edgecolor=SURF, linewidth=1.5, zorder=3,
                   label=judge if k == 0 else None)
ax.axvline(0, color=INK2, lw=1)
ax.set_yticks(y, [t for _, _, t in mets])
ax.set_xlabel("change with S2, oriented so that right = better (share in percentage points ÷ 100, or ρ)\ndot = estimate · line = 95% paired bootstrap CI · a line crossing 0 = not statistically supported")
tidy(ax, "x")
ax.legend(loc="upper left", fontsize=8)
ax.set_title("S2 few-shot vs baseline MQM on the held-out half", loc="left")
save(fig, "B_fig4_s2_deltas.png")

# ---------------------------------------------------------------- 5 pairwise
p4 = pd.read_csv(os.path.join(S2, "T4_pairwise_T0.csv"))
fig, axes = plt.subplots(1, 3, figsize=(9.2, 3.0), sharey=True)
for ax, col, title in ((axes[0], "first_position_rate", "Picks the translation shown first ↓"),
                       (axes[1], "verdict_matches_expected", "Verdict matches expected ↑"),
                       (axes[2], "order_consistent", "Same verdict in both orders ↑")):
    vals = {s: [float(p4[(p4.prompt == p) & (p4.model == m)][col].iloc[0]) for m in JC]
            for s, p in (("pairwise (baseline)", "pairwise"), ("S5 pairwise + tie", "pairwise_tie"))}
    bars(ax, list(JC), list(vals), vals, {"pairwise (baseline)": BASE, "S5 pairwise + tie": NEW})
    ax.set_title(title, loc="left", fontsize=9)
axes[0].legend(loc="upper right", fontsize=7.5)
fig.suptitle("Stage 2 pairwise (32 held-out pairs, each judged in both orders, T = 0)", x=0.01, ha="left", fontsize=9.5, weight="bold")
fig.tight_layout()
save(fig, "B_fig5_pairwise.png")

# ---------------------------------------------------------------- 6 wording robustness
w = pd.read_csv(os.path.join(S2, "T6_wording_robustness.csv"))
w = w[w.prompt.isin(["mqm", "mqm_fewshot"])]
fig, ax = plt.subplots(figsize=(9.2, 2.9))
vals = {s: [float(w[(w.prompt == p) & (w.model == m)].mean_abs_change.mean()) for m in JC]
        for s, p in (("MQM (baseline)", "mqm"), ("S2 few-shot MQM", "mqm_fewshot"))}
bars(ax, list(JC), list(vals), vals, {"MQM (baseline)": BASE2, "S2 few-shot MQM": NEW}, fmt="{:.2f}", ylim=(0, 11))
ax.set_ylabel("mean |score change| (points)")
ax.legend(loc="upper right", fontsize=8)
ax.set_title("Wording robustness: score change when only the English wording of the prompt changes (2 rewordings, 40 items)", loc="left", fontsize=9.5)
save(fig, "B_fig6_wording.png")
print("charts written to", OUT, sorted(os.listdir(OUT)))
