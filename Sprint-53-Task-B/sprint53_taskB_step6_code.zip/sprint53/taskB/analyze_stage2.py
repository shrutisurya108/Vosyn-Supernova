"""
Task B · Step B6 — Stage 2 analysis (HELD-OUT half). CPU only, deterministic (bootstrap seed 42).

  python taskB/analyze_stage2.py          # writes analysis_taskB/stage2/ (tables + STAGE2_SUMMARY.md)

Finalists (data/taskB/stage2_finalists.json): S2 mqm_fewshot vs baseline mqm; S5 pairwise_tie vs
baseline pairwise. The flat baseline is shown as a reference. All compared in the SAME session.

Pre-registered Stage 2 rule (taskB/BASELINE_AND_METRICS.md §5) - a finalist is PROMISING if
  1. its primary metric improves with a paired bootstrap 95% CI (2,000 resamples, seed 42) that
     excludes zero, for at least one judge;
  2. no other metric is clearly worse (> 10 percentage points, or rho drop > 0.15) for either judge;
  3. malformed output <= 5 %.
Bootstrap units: Set A items (agreement with humans); English sources (Set B metrics - both flawed
versions of a source move together); pairs (pairwise); items of the repeat subset (consistency).

Sections
  T1  main run, T = 0, all 157 held-out items        T4  pairwise, T = 0, both orders, 32 pairs
  T2  consistency, repeat subset (40 items):         T5  pairwise stability, T = 0.7 x 3 runs
      T = 0 x 3 runs and T = 0.7 x 5 runs            T6  wording robustness (2 rewordings each)
  T3  paired bootstrap deltas + decision             T7  baseline drift vs Task A (same prompts)
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
D = os.path.join(ROOT, "data", "taskB")
RES = os.path.join(ROOT, "results_taskB")
OUT = os.path.join(ROOT, "analysis_taskB", "stage2")
os.makedirs(OUT, exist_ok=True)
J = ["glm4", "qwen"]
SEED, NB = 42, 2000
ABS = ["flat", "mqm", "mqm_fewshot"]
MQM_STYLE = {"mqm", "mqm_fewshot", "mqm_reworded", "mqm_rw2", "mqm_fewshot_rw1", "mqm_fewshot_rw2"}
NAME = {"flat": "baseline flat", "mqm": "baseline MQM", "mqm_fewshot": "S2 few-shot", "pairwise": "baseline pairwise",
        "pairwise_tie": "S5 pairwise+tie"}
REWORD = {"mqm": ["mqm_reworded", "mqm_rw2"], "mqm_fewshot": ["mqm_fewshot_rw1", "mqm_fewshot_rw2"],
          "pairwise": ["pairwise_rw1", "pairwise_rw2"], "pairwise_tie": ["pairwise_tie_rw1", "pairwise_tie_rw2"]}


def rj(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def band(s):
    return "clean" if s >= 85 else ("moderate" if s >= 60 else "poor")


def rho(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    return float(spearmanr(x, y).statistic) if len(set(x)) > 1 and len(set(y)) > 1 else float("nan")


def kripp(mat):
    mat = np.asarray(mat, float)
    m = mat.shape[1]
    v = mat.ravel()
    do = sum(((r[:, None] - r[None, :]) ** 2).sum() / (m - 1) for r in mat) / v.size
    de = ((v[:, None] - v[None, :]) ** 2).sum() / (v.size * (v.size - 1))
    return float(1 - do / de) if de > 0 else float("nan")


def detected(errs, span):
    if not isinstance(span, str) or not span or not isinstance(errs, list):
        return False
    for e in errs:
        t = str(e.get("text") or "")
        if t and (t in span or (span in t and len(t) <= max(3 * len(span), len(span) + 6))):
            return True
    return False


def boot(f, units):
    """95% CI of f(resampled units); f returns (new - base). Units resampled with replacement."""
    rng = np.random.default_rng(SEED)
    units = np.asarray(list(units))
    vals = []
    for _ in range(NB):
        v = f(units[rng.integers(0, len(units), len(units))])
        if v == v:
            vals.append(v)
    return (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))) if vals else (np.nan, np.nan)


# ============================================================================ load
A = {r["item_id"]: r for r in rj(os.path.join(D, "heldout_setA.jsonl"))}
B = {r["item_id"]: r for r in rj(os.path.join(D, "heldout_setB.jsonl"))}
P = {r["pair_id"]: r for r in rj(os.path.join(D, "heldout_pairs.jsonl"))}
REP = [r["item_id"] for r in rj(os.path.join(D, "repeat_subset.jsonl"))]
ITEM = {**A, **B}
fin = json.load(open(os.path.join(D, "stage2_finalists.json")))
df = pd.DataFrame([r for f in sorted(os.listdir(RES)) if f.startswith("B2_") for r in rj(os.path.join(RES, f))])
env = rj(os.path.join(RES, "environment.jsonl"))
mal = df.groupby(["prompt_id", "model"]).parse_status.apply(lambda s: float((s == "malformed").mean()))
ok = df[df.parse_status != "malformed"].copy()

t0 = ok[ok.phase == "B2_T0"].copy()
t0["source_id"] = t0.item_id.map(lambda i: ITEM[i]["source_id"])
t0["variant"] = t0.item_id.map(lambda i: B[i]["variant_type"] if i in B else "setA")
t0["candidate"] = t0.item_id.map(lambda i: ITEM[i]["candidate"])
w = t0.pivot_table(index=["prompt_id", "item_id"], columns="model", values="score").dropna()
ens = w.mean(axis=1).rename("score").reset_index().assign(model="ens")
ens["set"] = ens.item_id.str[0]
ens["source_id"] = ens.item_id.map(lambda i: ITEM[i]["source_id"])
ens["variant"] = ens.item_id.map(lambda i: B[i]["variant_type"] if i in B else "setA")
ens["candidate"] = ens.item_id.map(lambda i: ITEM[i]["candidate"])
t0 = pd.concat([t0, ens], ignore_index=True)


def view(p, m):
    """Per-row frame for one prompt x judge with every column the metrics need (computed once)."""
    g = t0[(t0.prompt_id == p) & (t0.model == m)]
    ga = g[g.set == "A"].set_index("item_id").score
    gb = g[g.set == "B"].set_index("item_id").copy()
    gold = gb[gb.variant == "gold"].set_index("source_id").score
    gb["d"] = np.where(gb.variant.isin(["fluent_wrong", "targeted_error"]), gb.source_id.map(gold) - gb.score, np.nan)
    lit = gb[gb.variant == "literal"].set_index("source_id").score
    fw = gb[gb.variant == "fluent_wrong"].set_index("source_id").score
    gb["lf"] = np.where(gb.variant == "literal", gb.source_id.map(fw - lit).mul(-1), np.nan)   # literal - fluent_wrong
    gb["true_ord"] = [{"poor": 0, "moderate": 1, "clean": 2}[B[i]["expected_quality_band"]] for i in gb.index]
    gb["track"] = (gb.variant != "gold").values & np.array([B[i]["script"] == "simplified" for i in gb.index])
    gb["band_ok"] = [band(a) == B[i]["expected_quality_band"] for a, i in zip(gb.score, gb.index)]
    gb["correct"] = gb.variant.isin(["gold", "paraphrase"])
    gb["planted"] = gb.variant.isin(["fluent_wrong", "targeted_error"])
    mqm = p in MQM_STYLE and m != "ens"
    if mqm:
        gb["bad_spans"] = [sum(str(e.get("text") or "") not in c for e in es) if isinstance(es, list) else 0
                           for es, c in zip(gb.errors, gb.candidate)]
        gb["n_sp"] = [len(es) if isinstance(es, list) else 0 for es in gb.errors]
        gb["det"] = [float(detected(e, (B[i].get("planted_error") or {}).get("span"))) for e, i in zip(gb.errors, gb.index)]
        gb["any_err"] = (gb.n_errors > 0).astype(float)
        gb["maj"] = [float((c["major"] + c["critical"]) > 0) for c in gb.severity_counts]
    pos = {sid: np.flatnonzero(gb.source_id.values == sid) for sid in SOURCES}
    return dict(ga=ga, gb=gb, mqm=mqm, pos=pos)


def setb_metrics(g, mqm):
    d = g.d.values
    fl = d[~np.isnan(d)]
    lf = g.lf.values
    lf = lf[~np.isnan(lf)]
    tr = g[g.track.values]
    c = g[g.correct.values]
    r = dict(rho_true_band_setB=rho(tr.score, tr.true_ord), band_accuracy_setB=float(g.band_ok.mean()),
             below_gold_strict=float((fl > 0).mean()), tie_with_gold=float((fl == 0).mean()), above_gold=float((fl < 0).mean()),
             literal_beats_fluent_wrong=float((lf > 0).mean()), correct_below_85=float((c.score < 85).mean()))
    if mqm:
        r.update(false_error_rate_on_correct=float(c.any_err.mean()), major_or_critical_on_correct=float(c.maj.mean()),
                 spans_not_in_translation=float(g.bad_spans.sum() / g.n_sp.sum()) if g.n_sp.sum() else np.nan,
                 planted_error_detected=float(g[g.planted.values].det.mean()), mean_errors_listed=float(g.n_errors.mean()))
    return r


DIR = {"rho_human_setA": (+1, "rho"), "rho_true_band_setB": (+1, "rho"), "band_accuracy_setB": (+1, "pp"),
       "below_gold_strict": (+1, "pp"), "above_gold": (-1, "pp"), "literal_beats_fluent_wrong": (+1, "pp"),
       "correct_below_85": (-1, "pp"), "false_error_rate_on_correct": (-1, "pp"), "spans_not_in_translation": (-1, "pp"),
       "planted_error_detected": (+1, "pp"), "major_or_critical_on_correct": (-1, "pp")}
SOURCES = sorted({r["source_id"] for r in B.values()})


def rho_h(ga, items):
    x = ga.reindex(items)
    return rho(x.values, [A[i]["human_score"] for i in items])


def paired_boot(v1, v0):
    """One bootstrap loop -> CI of (v1 - v0) for every Set B metric (units: sources) and rho with humans (units: items)."""
    rng = np.random.default_rng(SEED)
    out = {}
    src = np.array(SOURCES)
    for _ in range(NB):
        s = src[rng.integers(0, len(src), len(src))]
        i1 = np.concatenate([v1["pos"][x] for x in s])
        i0 = np.concatenate([v0["pos"][x] for x in s])
        m1, m0 = setb_metrics(v1["gb"].iloc[i1], v1["mqm"]), setb_metrics(v0["gb"].iloc[i0], v0["mqm"])
        for k in m1:
            if k in m0 and m1[k] == m1[k] and m0[k] == m0[k]:
                out.setdefault(k, []).append(m1[k] - m0[k])
    items = np.array(sorted(set(v1["ga"].index) & set(v0["ga"].index)))
    rng = np.random.default_rng(SEED)
    for _ in range(NB):
        s = items[rng.integers(0, len(items), len(items))]
        a, b = rho_h(v1["ga"], s), rho_h(v0["ga"], s)
        if a == a and b == b:
            out.setdefault("rho_human_setA", []).append(a - b)
    return {k: (float(np.percentile(x, 2.5)), float(np.percentile(x, 97.5))) for k, x in out.items()}


# ============================================================================ T1 main table
V = {(p, m): view(p, m) for p in ABS for m in J + ["ens"]}
t1 = []
for p in ABS:
    for m in J + ["ens"]:
        v = V[(p, m)]
        r = dict(prompt=p, model=m, n_setA=len(v["ga"]), n_flawed=int((~v["gb"].d.isna()).sum()), n_correct=int(v["gb"].correct.sum()),
                 rho_human_setA=rho_h(v["ga"], list(v["ga"].index)))
        r["rho_human_ci"] = "[%.2f, %.2f]" % boot(lambda s: rho_h(v["ga"], s), list(v["ga"].index))
        r.update(setb_metrics(v["gb"], v["mqm"]))
        r["mean_score_correct"] = float(v["gb"][v["gb"].correct].score.mean())
        r["mean_score_flawed"] = float(v["gb"][v["gb"].planted].score.mean())
        if m != "ens":
            r["malformed"] = mal.get((p, m), 0.0)
        else:
            gg = (w.loc[p]["glm4"] - w.loc[p]["qwen"])
            r["mean_abs_judge_gap"] = float(gg.abs().mean())
            r["judge_agreement_rho"] = rho(w.loc[p]["glm4"], w.loc[p]["qwen"])
        t1.append(r)
T1 = pd.DataFrame(t1)

# ============================================================================ T2 consistency (repeat subset)
rep_all = ok[ok.item_id.isin(REP) & ok.prompt_id.isin(ABS) &
             (ok.phase.isin(["B2_repeat_T0", "B2_repeat_T07"]) | (ok.phase == "B2_T0"))]
CONS, t2 = {}, []
for (p, m, T), g in rep_all.groupby(["prompt_id", "model", "temperature"]):
    mat = g.pivot_table(index="item_id", columns="run", values="score").dropna()
    rg = mat.max(axis=1) - mat.min(axis=1)
    nb = mat.apply(lambda r: len({band(x) for x in r}), axis=1)
    inc = (rg >= 10) | (nb > 1)
    CONS[(p, m, T)] = pd.DataFrame({"inc": inc.astype(float), "spread": rg, "identical": (rg == 0).astype(float), "bands": (nb > 1).astype(float)})
    hs = [ITEM[i]["human_score"] if i in A else np.nan for i in mat.index]
    t2.append(dict(prompt=p, model=m, temperature=T, runs=mat.shape[1], n_items=len(mat), inconsistent_share=float(inc.mean()),
                   band_changes=float((nb > 1).mean()), identical_all_runs=float((rg == 0).mean()), mean_spread=float(rg.mean()),
                   max_spread=float(rg.max()), mean_sd=float(mat.std(axis=1).mean()), kripp_alpha_runs=kripp(mat.values),
                   rho_human_mean_of_runs=rho(mat.mean(axis=1)[[i in A for i in mat.index]], [h for h in hs if h == h])))
T2 = pd.DataFrame(t2)
T2["prompt"] = pd.Categorical(T2.prompt, ABS, ordered=True)
T2 = T2.sort_values(["temperature", "prompt", "model"])

# ============================================================================ pairwise helpers


def orig(better, order):
    if better == "tie":
        return "tie"
    first, second = ("a", "b") if order == "AB" else ("b", "a")
    return first if better == "A" else second


def pw_frame(phase, prompts):
    x = ok[(ok.phase == phase) & ok.prompt_id.isin(prompts)].copy()
    x["verdict"] = [orig(b, o) for b, o in zip(x.better, x.order)]
    x["expected"] = x.item_id.map(lambda i: P[i]["expected_preference"])
    x["ok_"] = [(v == e) or (e == "a_or_tie" and v in ("a", "tie")) for v, e in zip(x.verdict, x.expected)]
    x["flawed_pref"] = [(e == "a" and v == "b") for v, e in zip(x.verdict, x.expected)]
    return x


def pw_stats(x, units=None):
    if units is not None:
        x = pd.concat([x[x.item_id == u] for u in units]) if len(units) else x.iloc[:0]
    wd = x.pivot_table(index="item_id", columns="order", values="verdict", aggfunc="first").dropna()
    nontie = x[x.better != "tie"]
    return dict(order_consistent=float((wd.AB == wd.BA).mean()) if len(wd) else np.nan,
                first_position_rate=float((x.better == "A").mean()),
                first_share_of_non_tie=float((nontie.better == "A").mean()) if len(nontie) else np.nan,
                tie_rate=float((x.better == "tie").mean()), verdict_matches_expected=float(x.ok_.mean()),
                flawed_preferred=float(x.flawed_pref.mean()),
                ties_on_tie_pairs=float((x[x.expected == "tie"].verdict == "tie").mean()),
                correct_on_a_pairs=float((x[x.expected == "a"].verdict == "a").mean()))


PW0 = pw_frame("B2_pairwise_T0", ["pairwise", "pairwise_tie"])
T4 = pd.DataFrame([dict(prompt=p, model=m, n_pairs=g.item_id.nunique(), **pw_stats(g), malformed=mal.get((p, m), 0.0))
                   for (p, m), g in PW0.groupby(["prompt_id", "model"])])

# T5 pairwise stability at T = 0.7 x 3 runs
PW7 = pw_frame("B2_pairwise_T07", ["pairwise", "pairwise_tie"])
t5 = []
for (p, m), g in PW7.groupby(["prompt_id", "model"]):
    st = g.groupby(["item_id", "order"]).verdict.agg(lambda s: s.nunique() == 1 and len(s) == 3)
    per_run = [pw_stats(gr)["order_consistent"] for _, gr in g.groupby("run")]
    t5.append(dict(prompt=p, model=m, pair_orders=len(st), same_verdict_all_3_runs=float(st.mean()),
                   order_consistent_mean_of_runs=float(np.mean(per_run)), first_position_rate=float((g.better == "A").mean()),
                   tie_rate=float((g.better == "tie").mean()), verdict_matches_expected=float(g.ok_.mean()),
                   malformed=float((df[(df.phase == "B2_pairwise_T07") & (df.prompt_id == p) & (df.model == m)].parse_status == "malformed").mean())))
T5 = pd.DataFrame(t5)

# ============================================================================ T6 wording robustness
t6 = []
WR = {}
base_rep = ok[(ok.phase == "B2_T0") & ok.item_id.isin(REP)]
wrd = ok[ok.phase == "B2_wording"]
for p in ("mqm", "mqm_fewshot"):
    for m in J:
        b = base_rep[(base_rep.prompt_id == p) & (base_rep.model == m)].set_index("item_id").score
        diffs = []
        for rw in REWORD[p]:
            r_ = wrd[(wrd.prompt_id == rw) & (wrd.model == m)].set_index("item_id").score
            u = b.index.intersection(r_.index)
            d = (r_.loc[u] - b.loc[u]).abs()
            diffs.append(d.rename(rw))
            t6.append(dict(prompt=p, rewording=rw, model=m, items=len(u), rho_vs_original=rho(b.loc[u], r_.loc[u]),
                           mean_abs_change=float(d.mean()), moved_10plus=float((d >= 10).mean()),
                           band_changed=float(np.mean([band(x) != band(y) for x, y in zip(b.loc[u], r_.loc[u])])),
                           mean_score_change=float((r_.loc[u] - b.loc[u]).mean()),
                           malformed=float((df[(df.phase == "B2_wording") & (df.prompt_id == rw) & (df.model == m)].parse_status == "malformed").mean())))
        WR[(p, m)] = pd.concat(diffs, axis=1).mean(axis=1)   # mean |change| over the 2 rewordings, per item
pwr = pw_frame("B2_wording_pairs", REWORD["pairwise"] + REWORD["pairwise_tie"])
WRP = {}
for p in ("pairwise", "pairwise_tie"):
    for m in J:
        b = PW0[(PW0.prompt_id == p) & (PW0.model == m)].set_index(["item_id", "order"]).verdict
        agree = []
        for rw in REWORD[p]:
            g = pwr[(pwr.prompt_id == rw) & (pwr.model == m)]
            r_ = g.set_index(["item_id", "order"]).verdict
            u = b.index.intersection(r_.index)
            ag = (b.loc[u] == r_.loc[u])
            agree.append(ag.rename(rw))
            st = pw_stats(g)
            t6.append(dict(prompt=p, rewording=rw, model=m, items=len(u), verdict_agreement_with_original=float(ag.mean()),
                           order_consistent=st["order_consistent"], first_position_rate=st["first_position_rate"],
                           tie_rate=st["tie_rate"], verdict_matches_expected=st["verdict_matches_expected"],
                           malformed=float((df[(df.phase == "B2_wording_pairs") & (df.prompt_id == rw) & (df.model == m)].parse_status == "malformed").mean())))
        WRP[(p, m)] = pd.concat(agree, axis=1)
T6 = pd.DataFrame(t6)

# ============================================================================ T3 deltas + decision
PRIMARY = {"mqm_fewshot": ["false_error_rate_on_correct", "above_gold"], "pairwise_tie": ["order_consistent", "first_position_rate"]}
d_rows, dec = [], []


for m in J:
    cis = paired_boot(V[("mqm_fewshot", m)], V[("mqm", m)])
    base_r, new_r = T1[(T1.prompt == "mqm") & (T1.model == m)].iloc[0], T1[(T1.prompt == "mqm_fewshot") & (T1.model == m)].iloc[0]
    for k, (sg, unit) in DIR.items():
        v0, v1 = float(base_r[k]), float(new_r[k])
        lo, hi = cis.get(k, (np.nan, np.nan))
        d_rows.append(dict(strategy="S2 few-shot", vs="mqm", metric=k, model=m, role="PRIMARY" if k in PRIMARY["mqm_fewshot"] else "guard",
                           baseline=v0, strategy_value=v1, delta=v1 - v0, ci_lo=lo, ci_hi=hi, better=(v1 - v0) * sg > 0,
                           ci_excludes_zero=(lo > 0 or hi < 0),
                           clearly_worse=((v1 - v0) * sg < -0.15) if unit == "rho" else ((v1 - v0) * sg < -0.10)))
    for T in (0.0, 0.7):
        for k, col, sg in (("inconsistent_share", "inc", -1), ("mean_spread", "spread", -1)):
            c1, c0 = CONS[("mqm_fewshot", m, T)], CONS[("mqm", m, T)]
            u = c1.index.intersection(c0.index)
            v1, v0 = c1.loc[u, col].mean(), c0.loc[u, col].mean()
            lo, hi = boot(lambda s: c1.loc[s, col].mean() - c0.loc[s, col].mean(), u)
            d_rows.append(dict(strategy="S2 few-shot", vs="mqm", metric=f"{k}_T{T}", model=m, role="consistency", baseline=v0,
                               strategy_value=v1, delta=v1 - v0, ci_lo=lo, ci_hi=hi, better=(v1 - v0) * sg > 0,
                               ci_excludes_zero=(lo > 0 or hi < 0),
                               clearly_worse=((v1 - v0) * sg < -0.10) if k == "inconsistent_share" else False))
    wr1, wr0 = WR[("mqm_fewshot", m)], WR[("mqm", m)]
    u = wr1.index.intersection(wr0.index)
    lo, hi = boot(lambda s: wr1.loc[s].mean() - wr0.loc[s].mean(), u)
    d_rows.append(dict(strategy="S2 few-shot", vs="mqm", metric="wording_mean_abs_change", model=m, role="robustness",
                       baseline=wr0.loc[u].mean(), strategy_value=wr1.loc[u].mean(), delta=wr1.loc[u].mean() - wr0.loc[u].mean(),
                       ci_lo=lo, ci_hi=hi, better=wr1.loc[u].mean() < wr0.loc[u].mean(), ci_excludes_zero=(lo > 0 or hi < 0), clearly_worse=False))
    # S5
    g1, g0 = PW0[(PW0.prompt_id == "pairwise_tie") & (PW0.model == m)], PW0[(PW0.prompt_id == "pairwise") & (PW0.model == m)]

    def pair_table(g):
        """Per-pair sums, so a bootstrap resample is a cheap sum over sampled pairs."""
        rows = {}
        for pid, x in g.groupby("item_id"):
            v = dict(zip(x.order, x.verdict))
            rows[pid] = dict(cons=float(v.get("AB") == v.get("BA")) if len(v) == 2 else np.nan, has2=float(len(v) == 2),
                             n=len(x), first=float((x.better == "A").sum()), tie=float((x.better == "tie").sum()),
                             ok=float(x.ok_.sum()), flawed=float(x.flawed_pref.sum()),
                             a_n=float((x.expected == "a").sum()), a_ok=float(((x.expected == "a") & (x.verdict == "a")).sum()))
        return pd.DataFrame(rows).T

    def pt_stats(t):
        return dict(order_consistent=t.cons.sum() / t.has2.sum(), first_position_rate=t["first"].sum() / t.n.sum(),
                    verdict_matches_expected=t.ok.sum() / t.n.sum(), flawed_preferred=t.flawed.sum() / t.n.sum(),
                    tie_rate=t.tie.sum() / t.n.sum(), correct_on_a_pairs=t.a_ok.sum() / t.a_n.sum() if t.a_n.sum() else np.nan)
    t1_, t0_ = pair_table(g1), pair_table(g0)
    units = np.array(sorted(set(t1_.index) & set(t0_.index)))
    a1_, a0_ = t1_.loc[units].fillna(0).values.astype(float), t0_.loc[units].fillna(0).values.astype(float)
    cols = list(t1_.columns)
    rng = np.random.default_rng(SEED)
    bs = {}
    for _ in range(NB):
        ix = rng.integers(0, len(units), len(units))
        s1 = pt_stats(pd.Series(a1_[ix].sum(axis=0), index=cols))
        s0 = pt_stats(pd.Series(a0_[ix].sum(axis=0), index=cols))
        for k in s1:
            if s1[k] == s1[k] and s0[k] == s0[k]:
                bs.setdefault(k, []).append(s1[k] - s0[k])
    st1, st0 = pt_stats(t1_.fillna(0).sum()), pt_stats(t0_.fillna(0).sum())
    for k, sg in (("order_consistent", +1), ("first_position_rate", -1), ("verdict_matches_expected", +1), ("flawed_preferred", -1),
                  ("tie_rate", 0), ("correct_on_a_pairs", +1)):
        v1, v0 = st1[k], st0[k]
        lo, hi = float(np.percentile(bs[k], 2.5)), float(np.percentile(bs[k], 97.5))
        d_rows.append(dict(strategy="S5 pairwise+tie", vs="pairwise", metric=k, model=m,
                           role="PRIMARY" if k in PRIMARY["pairwise_tie"] else ("info" if sg == 0 else "guard"),
                           baseline=v0, strategy_value=v1, delta=v1 - v0, ci_lo=lo, ci_hi=hi, better=(v1 - v0) * sg > 0,
                           ci_excludes_zero=(lo > 0 or hi < 0), clearly_worse=((v1 - v0) * sg < -0.10) if sg else False))
    a1, a0 = WRP[("pairwise_tie", m)].mean(axis=1), WRP[("pairwise", m)].mean(axis=1)
    u = a1.index.intersection(a0.index)
    d_rows.append(dict(strategy="S5 pairwise+tie", vs="pairwise", metric="wording_verdict_agreement", model=m, role="robustness",
                       baseline=a0.loc[u].mean(), strategy_value=a1.loc[u].mean(), delta=a1.loc[u].mean() - a0.loc[u].mean(),
                       ci_lo=np.nan, ci_hi=np.nan, better=a1.loc[u].mean() > a0.loc[u].mean(), ci_excludes_zero=False, clearly_worse=False))
T3 = pd.DataFrame(d_rows)
for s, p in (("S2 few-shot", "mqm_fewshot"), ("S5 pairwise+tie", "pairwise_tie")):
    x = T3[T3.strategy == s]
    prim = x[(x.role == "PRIMARY") & x.better & x.ci_excludes_zero]
    worse = x[(x.role != "PRIMARY") & (x.clearly_worse == True)]  # noqa: E712
    malf = max(mal.get((p, m), 0.0) for m in J)
    dec.append(dict(strategy=s, prompt=p,
                    primary_improved_CI_excl_0=", ".join(f"{r.metric}[{r.model}]" for r in prim.itertuples()) or "none",
                    primary_directional_only=", ".join(f"{r.metric}[{r.model}]" for r in x[(x.role == 'PRIMARY') & x.better & ~x.ci_excludes_zero].itertuples()) or "none",
                    clearly_worse=", ".join(f"{r.metric}[{r.model}] {r.baseline:.2f}->{r.strategy_value:.2f}" for r in worse.itertuples()) or "none",
                    malformed_max=malf,
                    stage2_rule="PROMISING" if len(prim) and not len(worse) and malf <= 0.05 else "NOT CONFIRMED"))
DEC = pd.DataFrame(dec)

# ============================================================================ T7 drift vs Task A
drift = []
ta = os.path.join(ROOT, "results")
if os.path.exists(ta):
    TA = pd.DataFrame([r for f in sorted(os.listdir(ta)) if f.startswith("P") and f.endswith(".jsonl") for r in rj(os.path.join(ta, f))])
    TA = TA[((TA.phase == "P01_E1_T00") & (TA.run == 0)) | TA.phase.isin(["P06_E4_setB_mqm", "P08_E5_setB_flat"])]
    for m in J:
        for p in ("flat", "mqm"):
            a = TA[(TA.model == m) & (TA.prompt_id == p)].drop_duplicates("item_id").set_index("item_id").score
            bb = df[(df.phase == "B2_T0") & (df.model == m) & (df.prompt_id == p)].set_index("item_id").score
            u = a.index.intersection(bb.index)
            d = (bb.loc[u] - a.loc[u]).abs()
            drift.append(dict(model=m, prompt=p, items=len(u), identical=float((d == 0).mean()), moved_10plus=float((d >= 10).mean()),
                              mean_abs_change=float(d.mean())))
T7 = pd.DataFrame(drift)

# ============================================================================ write
names = [(T1, "T1_main_T0.csv", "T1 · Main run, T = 0, held-out half (157 items)"),
         (T2, "T2_consistency.csv", "T2 · Consistency on the repeat subset (40 items): T = 0 x 3 runs, T = 0.7 x 5 runs"),
         (T3, "T3_deltas_vs_baseline.csv", "T3 · Finalist vs baseline, paired bootstrap 95% CI"),
         (DEC, "T3_decision.csv", "Stage 2 decision (pre-registered rule)"),
         (T4, "T4_pairwise_T0.csv", "T4 · Pairwise, T = 0, both orders (32 pairs)"),
         (T5, "T5_pairwise_T07.csv", "T5 · Pairwise stability, T = 0.7 x 3 runs"),
         (T6, "T6_wording_robustness.csv", "T6 · Wording robustness (2 rewordings per prompt)"),
         (T7, "T7_drift_vs_taskA.csv", "T7 · Baseline drift vs Task A (same prompts, T = 0)")]
for t, n, _ in names:
    t.round(3).to_csv(os.path.join(OUT, n), index=False, encoding="utf-8-sig")
pd.set_option("display.width", 250, "display.max_columns", 50, "display.max_colwidth", 90)
L = ["# Task B · Stage 2 (held-out half)", "",
     f"Calls: {len(df)}, malformed {int((df.parse_status == 'malformed').sum())}, retried {int((df.attempts > 1).sum())}, "
     f"cut off {int((df.done_reason == 'length').sum())}. Sessions: {len(env)}, Ollama {env[-1]['ollama_version']}, same model "
     f"digests in all sessions: {len({json.dumps(e['models'], sort_keys=True) for e in env}) == 1}. Finalists: {fin['finalists']}.",
     f"Items: Set A {len(A)}, Set B {len(B)} ({len(SOURCES)} sources), pairs {len(P)}, repeat subset {len(REP)}.", ""]
for t, _, title in names:
    L += [f"## {title}", "", "```", t.round(3).to_string(index=False), "```", ""]
open(os.path.join(OUT, "STAGE2_SUMMARY.md"), "w", encoding="utf-8").write("\n".join(L))
print("\n".join(L))
print(f"Wrote {OUT}")
