# Task B · Stage 1 screening (development half)

Calls: 3276, malformed 1, retried 3, cut off 0. Sessions: 4, Ollama 0.35.1, same model digests in all sessions: True.
Scored items: Set A 19, Set B 126, pairs 26 (few-shot sources excluded for every prompt).

## Absolute prompts, T = 0

```
      prompt model  rho_human_setA  n_setA  rho_true_band_setB  band_accuracy_setB  below_gold_strict  tie_with_gold  above_gold  n_flawed  literal_beats_fluent_wrong  n_lit_fw  correct_below_85  mean_score_correct  mean_score_flawed  n_correct  malformed  mean_abs_judge_gap  judge_agreement_rho  false_error_rate_on_correct  major_or_critical_on_correct  spans_not_in_translation  n_spans  planted_error_detected  mean_errors_listed
        flat  glm4           0.338      19               0.539               0.556              0.778          0.222       0.000        36                       0.722        18             0.000              92.083             75.833         36      0.000                 NaN                  NaN                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
        flat  qwen           0.551      19               0.504               0.579              0.833          0.167       0.000        36                       0.778        18             0.056              89.167             65.417         36      0.000                 NaN                  NaN                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
        flat   ens           0.488      19               0.564               0.603              0.861          0.139       0.000        36                       0.889        18             0.028              90.625             70.625         36        NaN              11.552                0.727                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
 flat_rubric  glm4           0.513      19               0.389               0.540              0.444          0.556       0.000        36                       0.556        18             0.000              85.417             73.472         36      0.000                 NaN                  NaN                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
 flat_rubric  qwen           0.460      19               0.460               0.548              0.806          0.194       0.000        36                       0.722        18             0.167              88.028             65.889         36      0.000                 NaN                  NaN                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
 flat_rubric   ens           0.558      19               0.512               0.548              0.833          0.167       0.000        36                       0.778        18             0.167              86.722             69.681         36        NaN              10.366                0.582                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
 flat_accflu  glm4           0.486      19               0.571               0.611              0.806          0.167       0.028        36                       0.778        18             0.000              97.611             76.000         36      0.000                 NaN                  NaN                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
 flat_accflu  qwen           0.448      19               0.489               0.579              0.889          0.111       0.000        36                       0.778        18             0.028              95.350             68.433         36      0.000                 NaN                  NaN                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
 flat_accflu   ens           0.521      19               0.568               0.603              0.917          0.056       0.028        36                       0.889        18             0.028              96.481             72.217         36        NaN              11.703                0.773                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
         mqm  glm4           0.728      19               0.067               0.468              0.333          0.417       0.250        36                       0.167        18             0.111              89.722             88.750         36      0.000                 NaN                  NaN                        0.944                         0.917                     0.271    295.0                   0.583               2.341
         mqm  qwen           0.217      19               0.203               0.437              0.444          0.250       0.306        36                       0.500        18             0.167              91.639             88.389         36      0.000                 NaN                  NaN                        0.778                         0.667                     0.010    202.0                   0.583               1.603
         mqm   ens           0.417      19               0.145               0.437              0.528          0.083       0.389        36                       0.389        18             0.167              90.681             88.569         36        NaN               9.883                0.363                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
 mqm_fewshot  glm4           0.596      19               0.147               0.476              0.528          0.278       0.194        36                       0.389        18             0.111              93.861             91.444         36      0.000                 NaN                  NaN                        0.833                         0.750                     0.143    231.0                   0.722               1.833
 mqm_fewshot  qwen           0.814      19               0.227               0.492              0.556          0.361       0.083        36                       0.722        18             0.056              95.806             93.500         36      0.000                 NaN                  NaN                        0.528                         0.500                     0.026    154.0                   0.583               1.222
 mqm_fewshot   ens           0.739      19               0.244               0.492              0.722          0.111       0.167        36                       0.611        18             0.056              94.833             92.472         36        NaN               5.090                0.649                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
   mqm_steps  glm4           0.356      19               0.376               0.516              0.389          0.583       0.028        36                       0.500        18             0.000              99.833             97.500         36      0.000                 NaN                  NaN                        0.028                         0.028                     0.179     39.0                   0.167               0.310
   mqm_steps  qwen           0.365      19               0.376               0.512              0.588          0.412       0.000        34                       0.667        18             0.000              99.829             96.000         35      0.005                 NaN                  NaN                        0.057                         0.029                     0.019     52.0                   0.417               0.416
   mqm_steps   ens           0.510      19               0.421               0.512              0.618          0.353       0.029        34                       0.667        18             0.000              99.829             96.676         35        NaN               3.090                0.555                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
mqm_combined  glm4           0.712      19               0.186               0.500              0.500          0.361       0.139        36                       0.500        18             0.028              94.417             93.167         36      0.000                 NaN                  NaN                        0.722                         0.694                     0.049    183.0                   0.583               1.452
mqm_combined  qwen           0.590      19               0.224               0.500              0.583          0.389       0.028        36                       0.611        18             0.028              96.111             93.500         36      0.000                 NaN                  NaN                        0.528                         0.472                     0.030    134.0                   0.556               1.063
mqm_combined   ens           0.739      19               0.263               0.508              0.667          0.250       0.083        36                       0.667        18             0.028              95.264             93.333         36        NaN               4.193                0.560                          NaN                           NaN                       NaN      NaN                     NaN                 NaN
```

## Consistency, T = 0.7 x 3 runs, Set A

```
      prompt model  n_items  inconsistent_share  band_changes  mean_spread  max_spread  mean_sd  kripp_alpha_runs  rho_human_mean_of_runs
        flat  glm4       19               0.737         0.316       11.579        35.0    6.155             0.739                   0.575
        flat  qwen       19               0.526         0.158        7.895        30.0    4.369             0.932                   0.519
 flat_rubric  glm4       19               0.684         0.526       13.684        25.0    7.365             0.609                   0.243
 flat_rubric  qwen       19               0.211         0.053        5.105        22.0    2.898             0.919                   0.472
 flat_accflu  glm4       19               0.684         0.579       11.895        28.0    6.199             0.762                   0.526
 flat_accflu  qwen       19               0.684         0.368       12.053        40.0    6.724             0.864                   0.322
         mqm  glm4       19               0.842         0.842       33.632        88.0   17.679             0.287                   0.509
         mqm  qwen       19               0.632         0.579       16.947        45.0    8.958             0.574                   0.404
 mqm_fewshot  glm4       19               0.632         0.632       20.211        73.0   10.839             0.149                   0.488
 mqm_fewshot  qwen       19               0.211         0.211        4.474        28.0    2.503             0.540                   0.661
   mqm_steps  glm4       19               0.368         0.263       13.368        60.0    7.299             0.257                   0.548
   mqm_steps  qwen       19               0.263         0.158        7.105        40.0    3.824             0.423                   0.398
mqm_combined  glm4       19               0.737         0.684       23.526        89.0   12.782             0.179                   0.424
mqm_combined  qwen       19               0.211         0.211        6.789        40.0    3.920             0.465                   0.563
```

## Pairwise, both orders

```
      prompt model  n_pairs  order_consistent  first_position_rate  first_share_of_non_tie  tie_rate  verdict_matches_expected  flawed_preferred  ties_on_tie_pairs  malformed
    pairwise  glm4       26             0.423                0.750                   0.780     0.038                     0.404             0.058              0.071        0.0
    pairwise  qwen       26             0.615                0.500                   0.619     0.192                     0.596             0.038              0.357        0.0
pairwise_tie  glm4       26             0.577                0.250                   0.394     0.365                     0.712             0.019              0.607        0.0
pairwise_tie  qwen       26             0.538                0.365                   0.613     0.404                     0.712             0.038              0.679        0.0
```

## Deltas vs baseline (primary metrics with 95% paired bootstrap CI; guard metrics)

```
       strategy       prompt baseline    role                      metric model  baseline_value  strategy_value  delta  ci_lo  ci_hi  better ci_excludes_zero clearly_worse
      S1 rubric  flat_rubric     flat PRIMARY          inconsistent_share  glm4           0.737           0.684 -0.053 -0.263  0.158    True            False           NaN
      S1 rubric  flat_rubric     flat PRIMARY          inconsistent_share  qwen           0.526           0.211 -0.316 -0.579  0.000    True            False           NaN
      S1 rubric  flat_rubric     flat PRIMARY                 mean_spread  glm4          11.579          13.684  2.105 -2.105  6.316   False            False           NaN
      S1 rubric  flat_rubric     flat PRIMARY                 mean_spread  qwen           7.895           5.105 -2.789 -7.789  2.474    True            False           NaN
      S1 rubric  flat_rubric     flat PRIMARY          mean_abs_judge_gap   ens          11.552          10.366 -1.186 -3.448  0.890    True            False           NaN
      S1 rubric  flat_rubric     flat   guard              rho_human_setA  glm4           0.338           0.513  0.175    NaN    NaN    True              NaN         False
      S1 rubric  flat_rubric     flat   guard              rho_human_setA  qwen           0.551           0.460 -0.091    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard          rho_true_band_setB  glm4           0.539           0.389 -0.151    NaN    NaN   False              NaN          True
      S1 rubric  flat_rubric     flat   guard          rho_true_band_setB  qwen           0.504           0.460 -0.044    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard           below_gold_strict  glm4           0.778           0.444 -0.333    NaN    NaN   False              NaN          True
      S1 rubric  flat_rubric     flat   guard           below_gold_strict  qwen           0.833           0.806 -0.028    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard                  above_gold  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard                  above_gold  qwen           0.000           0.000  0.000    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard          band_accuracy_setB  glm4           0.556           0.540 -0.016    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard          band_accuracy_setB  qwen           0.579           0.548 -0.032    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard            correct_below_85  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard            correct_below_85  qwen           0.056           0.167  0.111    NaN    NaN   False              NaN          True
      S1 rubric  flat_rubric     flat   guard                   malformed  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
      S1 rubric  flat_rubric     flat   guard                   malformed  qwen           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat PRIMARY           below_gold_strict  glm4           0.778           0.806  0.028 -0.056  0.139    True            False           NaN
     S4 acc+flu  flat_accflu     flat PRIMARY           below_gold_strict  qwen           0.833           0.889  0.056 -0.056  0.167    True            False           NaN
     S4 acc+flu  flat_accflu     flat PRIMARY  literal_beats_fluent_wrong  glm4           0.722           0.778  0.056  0.000  0.167    True            False           NaN
     S4 acc+flu  flat_accflu     flat PRIMARY  literal_beats_fluent_wrong  qwen           0.778           0.778  0.000  0.000  0.000   False            False           NaN
     S4 acc+flu  flat_accflu     flat   guard              rho_human_setA  glm4           0.338           0.486  0.148    NaN    NaN    True              NaN         False
     S4 acc+flu  flat_accflu     flat   guard              rho_human_setA  qwen           0.551           0.448 -0.103    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard          rho_true_band_setB  glm4           0.539           0.571  0.032    NaN    NaN    True              NaN         False
     S4 acc+flu  flat_accflu     flat   guard          rho_true_band_setB  qwen           0.504           0.489 -0.015    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard                  above_gold  glm4           0.000           0.028  0.028    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard                  above_gold  qwen           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard          band_accuracy_setB  glm4           0.556           0.611  0.056    NaN    NaN    True              NaN         False
     S4 acc+flu  flat_accflu     flat   guard          band_accuracy_setB  qwen           0.579           0.579  0.000    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard            correct_below_85  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard            correct_below_85  qwen           0.056           0.028 -0.028    NaN    NaN    True              NaN         False
     S4 acc+flu  flat_accflu     flat   guard                   malformed  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard                   malformed  qwen           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     S4 acc+flu  flat_accflu     flat   guard          inconsistent_share  glm4           0.737           0.684 -0.053    NaN    NaN    True              NaN         False
     S4 acc+flu  flat_accflu     flat   guard          inconsistent_share  qwen           0.526           0.684  0.158    NaN    NaN   False              NaN          True
    S2 few-shot  mqm_fewshot      mqm PRIMARY false_error_rate_on_correct  glm4           0.944           0.833 -0.111 -0.222 -0.028    True             True           NaN
    S2 few-shot  mqm_fewshot      mqm PRIMARY false_error_rate_on_correct  qwen           0.778           0.528 -0.250 -0.417 -0.083    True             True           NaN
    S2 few-shot  mqm_fewshot      mqm PRIMARY                  above_gold  glm4           0.250           0.194 -0.056 -0.250  0.139    True            False           NaN
    S2 few-shot  mqm_fewshot      mqm PRIMARY                  above_gold  qwen           0.306           0.083 -0.222 -0.389 -0.056    True             True           NaN
    S2 few-shot  mqm_fewshot      mqm   guard              rho_human_setA  glm4           0.728           0.596 -0.131    NaN    NaN   False              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard              rho_human_setA  qwen           0.217           0.814  0.597    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard          rho_true_band_setB  glm4           0.067           0.147  0.080    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard          rho_true_band_setB  qwen           0.203           0.227  0.024    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard           below_gold_strict  glm4           0.333           0.528  0.194    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard           below_gold_strict  qwen           0.444           0.556  0.111    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard          band_accuracy_setB  glm4           0.468           0.476  0.008    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard          band_accuracy_setB  qwen           0.437           0.492  0.056    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard            correct_below_85  glm4           0.111           0.111  0.000    NaN    NaN   False              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard            correct_below_85  qwen           0.167           0.056 -0.111    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard    spans_not_in_translation  glm4           0.271           0.143 -0.128    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard    spans_not_in_translation  qwen           0.010           0.026  0.016    NaN    NaN   False              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard      planted_error_detected  glm4           0.583           0.722  0.139    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard      planted_error_detected  qwen           0.583           0.583  0.000    NaN    NaN   False              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard                   malformed  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard                   malformed  qwen           0.000           0.000  0.000    NaN    NaN   False              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard          inconsistent_share  glm4           0.842           0.632 -0.211    NaN    NaN    True              NaN         False
    S2 few-shot  mqm_fewshot      mqm   guard          inconsistent_share  qwen           0.632           0.211 -0.421    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm PRIMARY    spans_not_in_translation  glm4           0.271           0.179 -0.092 -0.275  0.121    True            False           NaN
       S3 steps    mqm_steps      mqm PRIMARY    spans_not_in_translation  qwen           0.010           0.019  0.009 -0.029  0.059   False            False           NaN
       S3 steps    mqm_steps      mqm PRIMARY      planted_error_detected  glm4           0.583           0.167 -0.417 -0.583 -0.250   False             True           NaN
       S3 steps    mqm_steps      mqm PRIMARY      planted_error_detected  qwen           0.583           0.417 -0.167 -0.306 -0.056   False             True           NaN
       S3 steps    mqm_steps      mqm   guard              rho_human_setA  glm4           0.728           0.356 -0.372    NaN    NaN   False              NaN          True
       S3 steps    mqm_steps      mqm   guard              rho_human_setA  qwen           0.217           0.365  0.148    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard          rho_true_band_setB  glm4           0.067           0.376  0.310    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard          rho_true_band_setB  qwen           0.203           0.376  0.173    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard           below_gold_strict  glm4           0.333           0.389  0.056    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard           below_gold_strict  qwen           0.444           0.588  0.144    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard                  above_gold  glm4           0.250           0.028 -0.222    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard                  above_gold  qwen           0.306           0.000 -0.306    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard          band_accuracy_setB  glm4           0.468           0.516  0.048    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard          band_accuracy_setB  qwen           0.437           0.512  0.075    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard            correct_below_85  glm4           0.111           0.000 -0.111    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard            correct_below_85  qwen           0.167           0.000 -0.167    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard false_error_rate_on_correct  glm4           0.944           0.028 -0.917    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard false_error_rate_on_correct  qwen           0.778           0.057 -0.721    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard                   malformed  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
       S3 steps    mqm_steps      mqm   guard                   malformed  qwen           0.000           0.005  0.005    NaN    NaN   False              NaN         False
       S3 steps    mqm_steps      mqm   guard          inconsistent_share  glm4           0.842           0.368 -0.474    NaN    NaN    True              NaN         False
       S3 steps    mqm_steps      mqm   guard          inconsistent_share  qwen           0.632           0.263 -0.368    NaN    NaN    True              NaN         False
S5 pairwise+tie pairwise_tie pairwise PRIMARY            order_consistent  glm4           0.423           0.577  0.154 -0.077  0.385    True            False           NaN
S5 pairwise+tie pairwise_tie pairwise PRIMARY            order_consistent  qwen           0.615           0.538 -0.077 -0.308  0.154   False            False           NaN
S5 pairwise+tie pairwise_tie pairwise PRIMARY         first_position_rate  glm4           0.750           0.250 -0.500 -0.654 -0.346    True             True           NaN
S5 pairwise+tie pairwise_tie pairwise PRIMARY         first_position_rate  qwen           0.500           0.365 -0.135 -0.288 -0.019    True             True           NaN
S5 pairwise+tie pairwise_tie pairwise   guard    verdict_matches_expected  glm4           0.404           0.712  0.308    NaN    NaN    True              NaN         False
S5 pairwise+tie pairwise_tie pairwise   guard    verdict_matches_expected  qwen           0.596           0.712  0.115    NaN    NaN    True              NaN         False
S5 pairwise+tie pairwise_tie pairwise   guard            flawed_preferred  glm4           0.058           0.019 -0.038    NaN    NaN    True              NaN         False
S5 pairwise+tie pairwise_tie pairwise   guard            flawed_preferred  qwen           0.038           0.038  0.000    NaN    NaN   False              NaN         False
S5 pairwise+tie pairwise_tie pairwise   guard                   malformed  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
S5 pairwise+tie pairwise_tie pairwise   guard                   malformed  qwen           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     C combined mqm_combined      mqm PRIMARY false_error_rate_on_correct  glm4           0.944           0.722 -0.222 -0.361 -0.083    True             True           NaN
     C combined mqm_combined      mqm PRIMARY false_error_rate_on_correct  qwen           0.778           0.528 -0.250 -0.417 -0.083    True             True           NaN
     C combined mqm_combined      mqm PRIMARY                  above_gold  glm4           0.250           0.139 -0.111 -0.306  0.083    True            False           NaN
     C combined mqm_combined      mqm PRIMARY                  above_gold  qwen           0.306           0.028 -0.278 -0.444 -0.111    True             True           NaN
     C combined mqm_combined      mqm PRIMARY    spans_not_in_translation  glm4           0.271           0.049 -0.222 -0.310 -0.135    True             True           NaN
     C combined mqm_combined      mqm PRIMARY    spans_not_in_translation  qwen           0.010           0.030  0.020 -0.021  0.076   False            False           NaN
     C combined mqm_combined      mqm PRIMARY      planted_error_detected  glm4           0.583           0.583  0.000 -0.139  0.139   False            False           NaN
     C combined mqm_combined      mqm PRIMARY      planted_error_detected  qwen           0.583           0.556 -0.028 -0.167  0.111   False            False           NaN
     C combined mqm_combined      mqm   guard              rho_human_setA  glm4           0.728           0.712 -0.015    NaN    NaN   False              NaN         False
     C combined mqm_combined      mqm   guard              rho_human_setA  qwen           0.217           0.590  0.373    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard          rho_true_band_setB  glm4           0.067           0.186  0.119    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard          rho_true_band_setB  qwen           0.203           0.224  0.021    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard           below_gold_strict  glm4           0.333           0.500  0.167    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard           below_gold_strict  qwen           0.444           0.583  0.139    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard          band_accuracy_setB  glm4           0.468           0.500  0.032    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard          band_accuracy_setB  qwen           0.437           0.500  0.063    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard            correct_below_85  glm4           0.111           0.028 -0.083    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard            correct_below_85  qwen           0.167           0.028 -0.139    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard                   malformed  glm4           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     C combined mqm_combined      mqm   guard                   malformed  qwen           0.000           0.000  0.000    NaN    NaN   False              NaN         False
     C combined mqm_combined      mqm   guard          inconsistent_share  glm4           0.842           0.737 -0.105    NaN    NaN    True              NaN         False
     C combined mqm_combined      mqm   guard          inconsistent_share  qwen           0.632           0.211 -0.421    NaN    NaN    True              NaN         False
```

## Stage 1 decision rule

```
       strategy       prompt                                                                                                                       primary_better_for                                                                                                       clearly_worse  malformed stage1_rule
      S1 rubric  flat_rubric                                           inconsistent_share[glm4], inconsistent_share[qwen], mean_spread[qwen], mean_abs_judge_gap[ens] rho_true_band_setB (glm4) 0.54 -> 0.39; below_gold_strict (glm4) 0.78 -> 0.44; correct_below_85 (qwen) 0.06 -> 0.17      0.000        FAIL
     S4 acc+flu  flat_accflu                                                       below_gold_strict[glm4], below_gold_strict[qwen], literal_beats_fluent_wrong[glm4]                                                                              inconsistent_share (qwen) 0.53 -> 0.68      0.000        FAIL
    S2 few-shot  mqm_fewshot                                 false_error_rate_on_correct[glm4], false_error_rate_on_correct[qwen], above_gold[glm4], above_gold[qwen]                                                                                                                none      0.000        PASS
       S3 steps    mqm_steps                                                                                                           spans_not_in_translation[glm4]                                                                                  rho_human_setA (glm4) 0.73 -> 0.36      0.005        FAIL
S5 pairwise+tie pairwise_tie                                                             order_consistent[glm4], first_position_rate[glm4], first_position_rate[qwen]                                                                                                                none      0.000        PASS
     C combined mqm_combined false_error_rate_on_correct[glm4], false_error_rate_on_correct[qwen], above_gold[glm4], above_gold[qwen], spans_not_in_translation[glm4]                                                                                                                none      0.000        PASS
```

## Baseline drift vs Task A run (same prompts, T = 0)

```
model prompt  items  identical  moved_10plus  mean_abs_change
 glm4   flat    158      0.949         0.019            0.348
 glm4    mqm    158      0.854         0.051            1.500
 qwen   flat    158      0.924         0.076            1.203
 qwen    mqm    158      0.797         0.095            2.709
```

## Stage 1b: combined prompt C vs S2 (same items)

```
                     metric model    S2     C  delta  C_better  clearly_worse
             rho_human_setA  glm4 0.596 0.712  0.116      True          False
             rho_human_setA  qwen 0.814 0.590 -0.223     False           True
         rho_true_band_setB  glm4 0.147 0.186  0.039      True          False
         rho_true_band_setB  qwen 0.227 0.224 -0.003     False          False
          below_gold_strict  glm4 0.528 0.500 -0.028     False          False
          below_gold_strict  qwen 0.556 0.583  0.028      True          False
                 above_gold  glm4 0.194 0.139 -0.056      True          False
                 above_gold  qwen 0.083 0.028 -0.056      True          False
         band_accuracy_setB  glm4 0.476 0.500  0.024      True          False
         band_accuracy_setB  qwen 0.492 0.500  0.008      True          False
           correct_below_85  glm4 0.111 0.028 -0.083      True          False
           correct_below_85  qwen 0.056 0.028 -0.028      True          False
false_error_rate_on_correct  glm4 0.833 0.722 -0.111      True          False
false_error_rate_on_correct  qwen 0.528 0.528  0.000     False          False
   spans_not_in_translation  glm4 0.143 0.049 -0.094      True          False
   spans_not_in_translation  qwen 0.026 0.030  0.004     False          False
     planted_error_detected  glm4 0.722 0.583 -0.139     False           True
     planted_error_detected  qwen 0.583 0.556 -0.028     False          False
                  malformed  glm4 0.000 0.000  0.000     False          False
                  malformed  qwen 0.000 0.000  0.000     False          False
         inconsistent_share  glm4 0.632 0.737  0.105     False           True
         inconsistent_share  qwen 0.211 0.211  0.000     False          False
```

## Stage 2 finalists (written to data/taskB/stage2_finalists.json)

C passes the rule vs baseline: True; C not clearly worse than S2: False ['rho_human_setA (qwen) 0.81 -> 0.59', 'planted_error_detected (glm4) 0.72 -> 0.58', 'inconsistent_share (glm4) 0.63 -> 0.74']
FINALISTS: mqm_fewshot, pairwise_tie
