"""
Every prompt used in Sprint 53, in one place.

FLAT_PROMPT and MQM_PROMPT are copied VERBATIM from Sprint 50 (judges/configs.py), including the
"Standard Mandarin Chinese (Simplified script)" target label. All other prompts are controlled
variations of them, each changing ONE thing so its effect can be measured:

  id                   experiment  what changes vs the Sprint 50 prompt
  -------------------  ----------  -------------------------------------------------------------
  flat                 E1 (base)   nothing (Sprint 50 flat 0-100)
  mqm                  E1 (base)   nothing (Sprint 50 MQM error list)
  mqm_reworded         E2          same instructions, different English wording
  mqm_zh               E2          same instructions written in Chinese
  mqm_severity_defs    E2          adds definitions of minor / major / critical
  mqm_analysis_first   E2, E10     asks for a short analysis before the error list
  flat_1to5            E3          1-5 scale instead of 0-100
  flat_1to10           E3          1-10 scale instead of 0-100
  mqm_ref              E4          adds a reference translation
  mqm_neutral_label    E8          target label "Mandarin Chinese" (no script specified)
  pairwise             E9          compare translation A vs B
  flat_rationale       E10         asks for a 1-2 sentence rationale before the score
"""

SRC_LANG = "English"
TGT_LANG = "Standard Mandarin Chinese (Simplified script)"   # Sprint 50 LANG_DISPLAY_NAME["en_to_cmn"]
TGT_LANG_NEUTRAL = "Mandarin Chinese"

# ------------------------------------------------------------------ Sprint 50, verbatim
FLAT_PROMPT = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Rate the machine translation's quality from 0 to 100, where 100 is a perfect, publication-quality translation and 0 is completely unusable.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"score": <integer 0-100>}}"""

MQM_PROMPT = """You are an expert professional translation quality evaluator following MQM (Multidimensional Quality Metrics) principles.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Identify every real error in the machine translation. For each error give: the exact erroneous text segment, an error type (one of: Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible), and a severity (one of: minor, major, critical).
If there are no errors, return an empty list.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}"""

# ------------------------------------------------------------------ E2 prompt-wording variants
MQM_REWORDED = """You are a professional translation quality assessor who applies the MQM (Multidimensional Quality Metrics) framework.
Source text ({src_lang}): {source}
Translation under review ({tgt_lang}): {mt}

List all genuine errors in the translation. For every error, provide the exact problematic span from the translation, its error category (choose from: Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible), and its severity (choose from: minor, major, critical).
Return an empty list if the translation has no errors.
Reply with ONLY a JSON object and nothing else, using exactly this format:
{{"errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}"""

MQM_ZH = """你是一名专业的翻译质量评估专家，遵循MQM（多维质量指标）原则。
原文（英语）：{source}
机器译文（简体中文普通话）：{mt}

请找出机器译文中所有真实存在的错误。对每个错误，给出：译文中出错的确切文字、错误类型（从以下选择：Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible）以及严重程度（从以下选择：minor, major, critical）。
如果没有错误，请返回空列表。
只返回一个JSON对象，不要输出任何其他内容，格式必须完全如下：
{{"errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}"""

MQM_SEVERITY_DEFS = """You are an expert professional translation quality evaluator following MQM (Multidimensional Quality Metrics) principles.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Identify every real error in the machine translation. For each error give: the exact erroneous text segment, an error type (one of: Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible), and a severity (one of: minor, major, critical).
Severity definitions:
- minor: noticeable, but the meaning is intact and the reader is not misled (e.g. awkward wording, small style issue).
- major: the meaning is changed or unclear; a reader would be misinformed or confused.
- critical: the translation becomes unusable, nonsensical, or misleading in a way that could cause real harm.
If there are no errors, return an empty list.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}"""

MQM_ANALYSIS_FIRST = """You are an expert professional translation quality evaluator following MQM (Multidimensional Quality Metrics) principles.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

First, briefly analyse the translation (at most 3 sentences). Then identify every real error in the machine translation. For each error give: the exact erroneous text segment, an error type (one of: Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible), and a severity (one of: minor, major, critical).
If there are no errors, return an empty list.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"analysis": "...", "errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}"""

# ------------------------------------------------------------------ E3 scale variants
FLAT_1TO5 = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Rate the machine translation's quality from 1 to 5, where 5 is a perfect, publication-quality translation and 1 is completely unusable.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"score": <integer 1-5>}}"""

FLAT_1TO10 = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Rate the machine translation's quality from 1 to 10, where 10 is a perfect, publication-quality translation and 1 is completely unusable.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"score": <integer 1-10>}}"""

# ------------------------------------------------------------------ E4 reference-based
MQM_REF = """You are an expert professional translation quality evaluator following MQM (Multidimensional Quality Metrics) principles.
Source ({src_lang}): {source}
Reference translation ({tgt_lang}): {reference}
Machine translation ({tgt_lang}): {mt}

Identify every real error in the machine translation. For each error give: the exact erroneous text segment, an error type (one of: Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible), and a severity (one of: minor, major, critical).
If there are no errors, return an empty list.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}"""

# ------------------------------------------------------------------ E9 pairwise
PAIRWISE = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Translation A ({tgt_lang}): {a}
Translation B ({tgt_lang}): {b}

Which translation is better? Answer "A", "B", or "tie" if they are equally good.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"better": "A|B|tie"}}"""

# ------------------------------------------------------------------ E10 rationale
FLAT_RATIONALE = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Rate the machine translation's quality from 0 to 100, where 100 is a perfect, publication-quality translation and 0 is completely unusable. First give a short rationale (1-2 sentences), then the score.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"rationale": "...", "score": <integer 0-100>}}"""

# id -> (template, output format, score range or None, target-language label)
PROMPTS = {
    "flat":               (FLAT_PROMPT,        "flat",           (0, 100), TGT_LANG),
    "mqm":                (MQM_PROMPT,         "mqm",            None,     TGT_LANG),
    "mqm_reworded":       (MQM_REWORDED,       "mqm",            None,     TGT_LANG),
    "mqm_zh":             (MQM_ZH,             "mqm",            None,     TGT_LANG),
    "mqm_severity_defs":  (MQM_SEVERITY_DEFS,  "mqm",            None,     TGT_LANG),
    "mqm_analysis_first": (MQM_ANALYSIS_FIRST, "mqm_analysis",   None,     TGT_LANG),
    "flat_1to5":          (FLAT_1TO5,          "flat",           (1, 5),   TGT_LANG),
    "flat_1to10":         (FLAT_1TO10,         "flat",           (1, 10),  TGT_LANG),
    "mqm_ref":            (MQM_REF,            "mqm",            None,     TGT_LANG),
    "mqm_neutral_label":  (MQM_PROMPT,         "mqm",            None,     TGT_LANG_NEUTRAL),
    "pairwise":           (PAIRWISE,           "pairwise",       None,     TGT_LANG),
    "flat_rationale":     (FLAT_RATIONALE,     "flat_rationale", (0, 100), TGT_LANG),
}

# Task B prompts (registered here so the runner can use them; Task A prompts above are unchanged)
from .prompts_taskb import TASKB_PROMPTS  # noqa: E402
PROMPTS.update(TASKB_PROMPTS)


def render(prompt_id, source, mt=None, reference=None, a=None, b=None):
    template, _, _, tgt = PROMPTS[prompt_id]
    return template.format(src_lang=SRC_LANG, tgt_lang=tgt, source=source, mt=mt,
                           reference=reference, a=a, b=b)
