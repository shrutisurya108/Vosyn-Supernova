"""
Task B prompts: the five selected prompt-engineering strategies.

Each strategy changes ONE thing relative to its Sprint 50 baseline, so its effect can be measured:

  id               strategy                                         baseline it is compared with
  ---------------  -----------------------------------------------  ----------------------------
  flat_rubric      S1 defined scoring rubric + score definitions    flat
  mqm_fewshot      S2 few-shot calibration examples (3, incl. a     mqm
                      correct translation with no errors)
  mqm_steps        S3 step-by-step criteria: meaning -> names/      mqm
                      numbers/terms -> idioms/culture -> valid
                      variation; quote errors only from translation
  flat_accflu      S4 separate accuracy and fluency scores,         flat
                      combined in code: 0.8 x accuracy + 0.2 x fluency
  pairwise_tie     S5 pairwise with tie definition + "order is      pairwise (both orders judged)
                      random", assess each before comparing

Language: instructions in English (same as Sprint 50); Mandarin appears only in the examples.
Few-shot examples come ONLY from the development half (checked by taskB/check_prompts.py).
Their sources are excluded from Stage 1 scoring for every prompt (FEWSHOT_EXCLUDE below).
Braces: templates use str.format, so literal JSON braces are doubled {{ }}.
"""
import json

ERROR_TYPES = "Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated, Unintelligible"

# ------------------------------------------------------------------------------- S1
FLAT_RUBRIC = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Rate the machine translation's quality from 0 to 100 using this scoring rubric:
- 85-100: The meaning is fully preserved and the Chinese is natural. At most a trivial wording issue.
- 60-84: The meaning is preserved, but there are noticeable issues that do not mislead the reader (stiff or word-for-word phrasing, awkward word order, slightly wrong tone).
- 40-59: One meaning error that misleads the reader about a secondary detail, or several small issues together.
- 20-39: A meaning error on a central point (for example a wrong number, name, negation, time or place, or an idiom translated word for word), or the sentence is hard to understand.
- 0-19: Mostly wrong, nonsensical, or largely untranslated.
First decide which band fits best, then choose a score within that band.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"score": <integer 0-100>}}"""

# ------------------------------------------------------------------------------- S2
FEWSHOT_EXAMPLES = [
    {   # 1 - correct translation, worded differently from the usual rendering -> no errors
        "item_id": "B::N_IDI1::paraphrase",
        "source": "After months of negotiations, the two companies finally decided to bury the hatchet.",
        "mt": "双方公司谈了好几个月，最后总算冰释前嫌。",
        "answer": {"errors": []},
        "why": "Correct and natural; the idiom is rendered by meaning (冰释前嫌). Different wording is not an error.",
    },
    {   # 2 - one major meaning error
        "item_id": "B::N_NUM1::fluent_wrong",
        "source": "The rent increased by 15% to $2,300 a month, effective October 1.",
        "mt": "房租上涨了15%，涨至每年2300美元，自10月1日起生效。",
        "answer": {"errors": [{"text": "每年", "type": "Mistranslation", "severity": "major"}]},
        "why": "'A month' was translated as 'a year' (每年 instead of 每月) - the reader is misinformed about the amount.",
    },
    {   # 3 - one minor issue (real MT output, human-annotated minor omission)
        "item_id": "A::en_to_cmn_258",
        "source": "However, the reduction of the threat level to severe does not mean the overall threat has gone away.'",
        "mt": "然而,降低威胁水平到严重并不意味着整体威胁已经消失了'.",
        "answer": {"errors": [{"text": "降低威胁水平到严重", "type": "Omission", "severity": "minor"}]},
        "why": "'To severe' refers to a threat level (严重级别); the word 级别 is missing. The meaning is still clear, so it is minor.",
    },
]
FEWSHOT_EXCLUDE = {"sources": ["N_IDI1", "N_NUM1"], "setA_items": ["A::en_to_cmn_258"]}


def _esc(s):
    return s.replace("{", "{{").replace("}", "}}")


_examples = "\n\n".join(
    f"Example {k}\nSource (English): {_esc(e['source'])}\nMachine translation (Standard Mandarin Chinese (Simplified script)): "
    f"{_esc(e['mt'])}\nAnswer: {_esc(json.dumps(e['answer'], ensure_ascii=False))}"
    for k, e in enumerate(FEWSHOT_EXAMPLES, start=1))

MQM_FEWSHOT = """You are an expert professional translation quality evaluator following MQM (Multidimensional Quality Metrics) principles.
Identify every real error in the machine translation. For each error give: the exact erroneous text segment, an error type (one of: """ + ERROR_TYPES + """), and a severity (one of: minor, major, critical).
If there are no errors, return an empty list.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}

Here are three examples of correct evaluations.

""" + _examples + """

Now evaluate this translation.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}
Answer:"""

# ------------------------------------------------------------------------------- S3
MQM_STEPS = """You are an expert professional translation quality evaluator following MQM (Multidimensional Quality Metrics) principles.

[SOURCE TEXT - {src_lang}]
{source}
[END OF SOURCE TEXT]

[TRANSLATION TO EVALUATE - {tgt_lang}]
{mt}
[END OF TRANSLATION]

Evaluate the translation step by step:
Step 1 - Meaning: compare each part of the source with the translation. Is anything mistranslated, missing, or added?
Step 2 - Names, numbers and terms: check every name, number, date, unit and technical term.
Step 3 - Idioms and culture: idioms and cultural references must be translated by their meaning, not word for word. Check any that appear.
Step 4 - Valid variation: different wording, word order or sentence structure that keeps the same meaning is NOT an error. Drop any problem from steps 1-3 that is only a difference in wording.
Step 5 - List the remaining errors. Quote each error exactly as it appears in the TRANSLATION - never quote the English source. For each error give an error type (one of: """ + ERROR_TYPES + """) and a severity (one of: minor, major, critical).
Write one short sentence for each of steps 1-4. If there are no errors, return an empty list.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"steps": {{"meaning": "...", "names_numbers_terms": "...", "idioms_culture": "...", "valid_variation": "..."}}, "errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}"""

# ------------------------------------------------------------------------------- S4
ACCFLU_WEIGHTS = {"accuracy": 0.8, "fluency": 0.2}
FLAT_ACCFLU = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Rate the machine translation on two separate criteria, each from 0 to 100:
1. Accuracy - does the translation convey exactly the meaning of the source? 100 = the same meaning, nothing wrong, missing or added; 0 = the meaning is completely wrong. Judge accuracy only: ignore how natural the Chinese sounds.
2. Fluency - is the Chinese natural, grammatical and appropriate in tone, as a native speaker would write it? 100 = perfectly natural; 0 = unreadable. Judge fluency only: ignore whether the meaning matches the source.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"accuracy": <integer 0-100>, "fluency": <integer 0-100>}}"""

# ------------------------------------------------------------------------------- S5
PAIRWISE_TIE = """You are an expert professional translation quality evaluator.
Source ({src_lang}): {source}
Translation A ({tgt_lang}): {a}
Translation B ({tgt_lang}): {b}

First assess each translation on its own: note any meaning errors (mistranslation, omission, addition) and any problems with naturalness. Then compare them.
- Answer "A" or "B" only if that translation is clearly better: it has fewer or less serious meaning errors, or, when both are accurate, it is clearly more natural.
- Answer "tie" if both are equally good or equally flawed - including when both are correct but worded differently.
- The order in which the translations are shown is random and must not affect your decision.
Respond with ONLY a JSON object, nothing else, in exactly this form:
{{"assessment_a": "...", "assessment_b": "...", "better": "A|B|tie"}}"""

TGT = "Standard Mandarin Chinese (Simplified script)"
# id -> (template, output format, score range, target label, strategy, baseline)
TASKB_PROMPTS = {
    "flat_rubric":  (FLAT_RUBRIC,  "flat",          (0, 100), TGT),
    "mqm_fewshot":  (MQM_FEWSHOT,  "mqm",           None,     TGT),
    "mqm_steps":    (MQM_STEPS,    "mqm_steps",     None,     TGT),
    "flat_accflu":  (FLAT_ACCFLU,  "accflu",        (0, 100), TGT),
    "pairwise_tie": (PAIRWISE_TIE, "pairwise_tie",  None,     TGT),
}
STRATEGY = {"flat_rubric": ("S1", "flat"), "mqm_fewshot": ("S2", "mqm"), "mqm_steps": ("S3", "mqm"),
            "flat_accflu": ("S4", "flat"), "pairwise_tie": ("S5", "pairwise")}


# =============================================================================== Step B5
# C  combined MQM prompt (built from Stage 1 results, development half only):
#    S2 few-shot examples (passed Stage 1)
#  + S3 delimiters [SOURCE TEXT]/[TRANSLATION] and "quote only from the translation" (S3's
#    span-validity part, which did not cause harm)
#  + S3 steps 1-3 as a one-line checklist (meaning; names/numbers/dates/units/terms; idioms)
#  - WITHOUT S3 step 4 "different wording is not an error" (Stage 1: it let the judge explain
#    real errors away, e.g. 密码不是 = "different sentence structure") and without written steps.
def _examples_delim(tgt):
    return "\n\n".join(
        f"Example {k}\n[SOURCE TEXT - English]\n{_esc(e['source'])}\n[END OF SOURCE TEXT]\n"
        f"[TRANSLATION TO EVALUATE - {tgt}]\n{_esc(e['mt'])}\n[END OF TRANSLATION]\n"
        f"Answer: {_esc(json.dumps(e['answer'], ensure_ascii=False))}"
        for k, e in enumerate(FEWSHOT_EXAMPLES, start=1))


_EX_DELIM = _examples_delim("Standard Mandarin Chinese (Simplified script)")
_SCHEMA = '{{"errors": [{{"text": "...", "type": "...", "severity": "minor|major|critical"}}, ...]}}'
_TARGET_DELIM = """[SOURCE TEXT - {src_lang}]
{source}
[END OF SOURCE TEXT]
[TRANSLATION TO EVALUATE - {tgt_lang}]
{mt}
[END OF TRANSLATION]"""

MQM_COMBINED = """You are an expert professional translation quality evaluator following MQM (Multidimensional Quality Metrics) principles.
Identify every real error in the machine translation. Check the meaning of every part of the source; every name, number, date, unit and technical term; and every idiom or cultural reference (it must be translated by its meaning, not word for word).
For each error give: the exact erroneous text segment, quoted exactly as it appears in the TRANSLATION (never quote the English source), an error type (one of: """ + ERROR_TYPES + """), and a severity (one of: minor, major, critical).
If there are no errors, return an empty list.
Respond with ONLY a JSON object, nothing else, in exactly this form:
""" + _SCHEMA + """

Here are three examples of correct evaluations.

""" + _EX_DELIM + """

Now evaluate this translation.
""" + _TARGET_DELIM + """
Answer:"""

# ------------------------------------------------------------------------------ rewordings
# Wording-robustness test (Stage 2). Each rewording keeps the SAME instructions, the SAME
# few-shot examples (byte-identical), the SAME output schema and the SAME item layout; only the
# English wording changes.  rw1 = sentence-level paraphrase, same order.
# rw2 = paraphrase + different sentence order / framing.
# Baseline MQM rewording 1 = Task A's `mqm_reworded` (already measured in Task A, F4).
MQM_RW2 = """Act as a senior translation reviewer who uses the MQM (Multidimensional Quality Metrics) error typology.
Your task is to find each actual error in the machine translation below and report it.
Report every error with three fields: the erroneous words copied exactly ("text"), the category ("type": Mistranslation, Omission, Addition, Grammar, Spelling, Typography, Untranslated or Unintelligible) and the seriousness ("severity": minor, major or critical).
When the translation has no errors, give an empty list.

Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}

Output a single JSON object and nothing else, formatted exactly like this:
""" + _SCHEMA

MQM_FEWSHOT_RW1 = """You are a professional translation quality assessor who applies the MQM (Multidimensional Quality Metrics) framework.
List all genuine errors in the machine translation. For every error, provide the exact problematic span, its error category (choose from: """ + ERROR_TYPES + """), and its severity (choose from: minor, major, critical).
Return an empty list if the translation has no errors.
Reply with ONLY a JSON object and nothing else, using exactly this format:
""" + _SCHEMA + """

Below are three worked examples of correct assessments.

""" + _examples + """

Now assess this translation.
Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}
Answer:"""

MQM_FEWSHOT_RW2 = """Act as a senior translation reviewer who uses the MQM (Multidimensional Quality Metrics) error typology.
The three worked examples below show how translations should be assessed.

""" + _examples + """

Your task: find each actual error in the next machine translation. Report every error with the erroneous words copied exactly ("text"), the category ("type": one of """ + ERROR_TYPES + """) and the seriousness ("severity": minor, major or critical). When there are no errors, give an empty list.
Output a single JSON object and nothing else, formatted exactly like this:
""" + _SCHEMA + """

Source ({src_lang}): {source}
Machine translation ({tgt_lang}): {mt}
Answer:"""

MQM_COMBINED_RW1 = """You are a professional translation quality assessor who applies the MQM (Multidimensional Quality Metrics) framework.
List all genuine errors in the machine translation. Verify the meaning of each part of the source; each name, number, date, unit and technical term; and each idiom or cultural reference (it has to be rendered by its meaning, not literally).
For every error, provide the exact problematic span, copied exactly from the TRANSLATION (do not quote the English source), its error category (choose from: """ + ERROR_TYPES + """), and its severity (choose from: minor, major, critical).
Return an empty list if the translation has no errors.
Reply with ONLY a JSON object and nothing else, using exactly this format:
""" + _SCHEMA + """

Below are three worked examples of correct assessments.

""" + _EX_DELIM + """

Now assess this translation.
""" + _TARGET_DELIM + """
Answer:"""

MQM_COMBINED_RW2 = """Act as a senior translation reviewer who uses the MQM (Multidimensional Quality Metrics) error typology.
The three worked examples below show how translations should be assessed.

""" + _EX_DELIM + """

Your task: find each actual error in the next machine translation. Go through the meaning of the whole source, then all names, numbers, dates, units and technical terms, then any idioms or cultural references (these need a meaning-based rendering, not a literal one).
Report every error with the erroneous words copied exactly from the TRANSLATION, never from the English source ("text"), the category ("type": one of """ + ERROR_TYPES + """) and the seriousness ("severity": minor, major or critical). When there are no errors, give an empty list.
Output a single JSON object and nothing else, formatted exactly like this:
""" + _SCHEMA + """

""" + _TARGET_DELIM + """
Answer:"""

PAIRWISE_RW1 = """You are a professional translation quality assessor.
Source text ({src_lang}): {source}
Translation A ({tgt_lang}): {a}
Translation B ({tgt_lang}): {b}

Which of the two translations is of higher quality? Reply "A", "B", or "tie" if they are of equal quality.
Reply with ONLY a JSON object and nothing else, using exactly this format:
{{"better": "A|B|tie"}}"""

PAIRWISE_RW2 = """Act as a senior translation reviewer and compare two translations of the same source sentence.
Decide which one is better: "A", "B", or "tie" when neither is better than the other.

Source ({src_lang}): {source}
Translation A ({tgt_lang}): {a}
Translation B ({tgt_lang}): {b}

Output a single JSON object and nothing else, formatted exactly like this:
{{"better": "A|B|tie"}}"""

PAIRWISE_TIE_RW1 = """You are a professional translation quality assessor.
Source text ({src_lang}): {source}
Translation A ({tgt_lang}): {a}
Translation B ({tgt_lang}): {b}

Begin by assessing each translation separately: note any meaning errors (mistranslation, omission, addition) and any naturalness problems. Then compare the two.
- Reply "A" or "B" only when that translation is clearly better: it has fewer or less serious meaning errors or, if both are accurate, it is clearly more natural.
- Reply "tie" when both are equally good or equally flawed - this includes two correct translations with different wording.
- The translations are shown in random order; the order must not influence your answer.
Reply with ONLY a JSON object and nothing else, using exactly this format:
{{"assessment_a": "...", "assessment_b": "...", "better": "A|B|tie"}}"""

PAIRWISE_TIE_RW2 = """Act as a senior translation reviewer and compare two translations of the same source sentence. They appear in random order, and that order must play no part in your decision.

Source ({src_lang}): {source}
Translation A ({tgt_lang}): {a}
Translation B ({tgt_lang}): {b}

Write a short assessment of each translation on its own (meaning errors such as mistranslation, omission or addition; naturalness problems), and only then compare them.
Give "tie" when the two are equally good or equally flawed, including when both are correct but use different words. Give "A" or "B" only when that one is clearly better - fewer or less serious meaning errors, or, if both are accurate, clearly more natural.
Output a single JSON object and nothing else, formatted exactly like this:
{{"assessment_a": "...", "assessment_b": "...", "better": "A|B|tie"}}"""

B5_PROMPTS = {
    "mqm_combined":     (MQM_COMBINED,     "mqm",          None, TGT),
    "mqm_rw2":          (MQM_RW2,          "mqm",          None, TGT),
    "mqm_fewshot_rw1":  (MQM_FEWSHOT_RW1,  "mqm",          None, TGT),
    "mqm_fewshot_rw2":  (MQM_FEWSHOT_RW2,  "mqm",          None, TGT),
    "mqm_combined_rw1": (MQM_COMBINED_RW1, "mqm",          None, TGT),
    "mqm_combined_rw2": (MQM_COMBINED_RW2, "mqm",          None, TGT),
    "pairwise_rw1":     (PAIRWISE_RW1,     "pairwise",     None, TGT),
    "pairwise_rw2":     (PAIRWISE_RW2,     "pairwise",     None, TGT),
    "pairwise_tie_rw1": (PAIRWISE_TIE_RW1, "pairwise_tie", None, TGT),
    "pairwise_tie_rw2": (PAIRWISE_TIE_RW2, "pairwise_tie", None, TGT),
}
TASKB_PROMPTS.update(B5_PROMPTS)
STRATEGY["mqm_combined"] = ("C", "mqm")
# prompt -> its two rewordings (baseline MQM rw1 is Task A's mqm_reworded)
REWORDINGS = {"mqm": ["mqm_reworded", "mqm_rw2"], "mqm_fewshot": ["mqm_fewshot_rw1", "mqm_fewshot_rw2"],
              "mqm_combined": ["mqm_combined_rw1", "mqm_combined_rw2"], "pairwise": ["pairwise_rw1", "pairwise_rw2"],
              "pairwise_tie": ["pairwise_tie_rw1", "pairwise_tie_rw2"]}
