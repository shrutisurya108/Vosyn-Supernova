"""
Task B experiment plan. Stage 1 = screening on the DEVELOPMENT half (Step B4).
Stage 1b (combined prompt C, development half) and Stage 2 (held-out half, finalists) were added in
Step B5 - see STAGE1B and STAGE2_ALL below.

  phase            data                     prompts                                    temp  runs  purpose
  B1_baseline      dev Set A + Set B (158)  flat, mqm (Sprint 50, verbatim)            0.0   1     baseline, same session
  B1_S1_rubric     dev Set A + Set B        flat_rubric                                0.0   1     S1
  B1_S2_fewshot    dev Set A + Set B        mqm_fewshot                                0.0   1     S2
  B1_S3_steps      dev Set A + Set B        mqm_steps                                  0.0   1     S3
  B1_S4_accflu     dev Set A + Set B        flat_accflu                                0.0   1     S4
  B1_pairwise      dev pairs (28) x 2 orders pairwise (baseline), pairwise_tie (S5)    0.0   1     S5
  B1_repeat_T07    dev Set A (20)           all 6 absolute prompts                     0.7   3     consistency screen

Every call is made once per judge (glm4, qwen). Seeds: 1000 + run (same as Task A), so the
baseline at T = 0 is directly comparable with the Task A run of the same items.
Few-shot sources (N_IDI1, N_NUM1, A::en_to_cmn_258) are judged like everything else but are
left out when Stage 1 is scored (data/taskB/fewshot_exclude.json).
"""
import json
import os
from collections import OrderedDict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = os.path.join(ROOT, "data", "taskB")
RESULTS_TB = os.path.join(ROOT, "results_taskB")
os.makedirs(RESULTS_TB, exist_ok=True)
MODELS = ["glm4", "qwen"]
BASE_SEED = 1000
ABS = ["flat", "mqm", "flat_rubric", "mqm_fewshot", "mqm_steps", "flat_accflu"]

STAGE1 = OrderedDict([
    ("B1_baseline",   dict(data="dev_AB",    prompts=["flat", "mqm"],              temp=0.0, runs=1, exp="baseline")),
    ("B1_S1_rubric",  dict(data="dev_AB",    prompts=["flat_rubric"],              temp=0.0, runs=1, exp="S1")),
    ("B1_S2_fewshot", dict(data="dev_AB",    prompts=["mqm_fewshot"],              temp=0.0, runs=1, exp="S2")),
    ("B1_S3_steps",   dict(data="dev_AB",    prompts=["mqm_steps"],                temp=0.0, runs=1, exp="S3")),
    ("B1_S4_accflu",  dict(data="dev_AB",    prompts=["flat_accflu"],              temp=0.0, runs=1, exp="S4")),
    ("B1_pairwise",   dict(data="dev_pairs", prompts=["pairwise", "pairwise_tie"], temp=0.0, runs=1, exp="S5")),
    ("B1_repeat_T07", dict(data="dev_A",     prompts=ABS,                          temp=0.7, runs=3, exp="consistency")),
])

# ------------------------------------------------------------------ Step B5
# Stage 1b: screen the combined MQM prompt C on the DEVELOPMENT half (same items, seeds and
# repeat design as Stage 1, so it is compared with the Stage 1 baseline/S2 results directly).
STAGE1B = OrderedDict([
    ("B1b_C_T0",         dict(data="dev_AB", prompts=["mqm_combined"], temp=0.0, runs=1, exp="C")),
    ("B1b_C_repeat_T07", dict(data="dev_A",  prompts=["mqm_combined"], temp=0.7, runs=3, exp="consistency")),
])

# Stage 2: confirmation on the HELD-OUT half. Finalists S2 (mqm_fewshot), S5 (pairwise_tie) and,
# only if it passed Stage 1b, C (mqm_combined) - read from data/taskB/stage2_finalists.json.
# The baseline (flat, mqm, pairwise) is re-run in the same session. Phases are ordered by
# importance, so a partial run still gives the main comparison first.
#   repeat = pre-registered repeat subset (40 held-out items: 20 Set A + 20 Set B)
#   B2_repeat_T0 runs 1-2 (seeds 1001, 1002) + run 0 from B2_T0 = 3 runs at T = 0
ABS2 = ["flat", "mqm", "mqm_fewshot", "mqm_combined"]
STAGE2_ALL = OrderedDict([
    ("B2_T0",            dict(data="ho_AB",    prompts=ABS2,                        temp=0.0, runs=1, exp="main")),
    ("B2_pairwise_T0",   dict(data="ho_pairs", prompts=["pairwise", "pairwise_tie"], temp=0.0, runs=1, exp="pairwise")),
    ("B2_repeat_T07",    dict(data="repeat",   prompts=ABS2,                        temp=0.7, runs=5, exp="consistency")),
    ("B2_repeat_T0",     dict(data="repeat",   prompts=ABS2,                        temp=0.0, runs=2, run_start=1, exp="consistency")),
    ("B2_pairwise_T07",  dict(data="ho_pairs", prompts=["pairwise", "pairwise_tie"], temp=0.7, runs=3, exp="consistency")),
    ("B2_wording",       dict(data="repeat",   prompts=["mqm_reworded", "mqm_rw2", "mqm_fewshot_rw1", "mqm_fewshot_rw2",
                                                         "mqm_combined_rw1", "mqm_combined_rw2"],
                              temp=0.0, runs=1, exp="wording")),
    ("B2_wording_pairs", dict(data="ho_pairs", prompts=["pairwise_rw1", "pairwise_rw2", "pairwise_tie_rw1", "pairwise_tie_rw2"],
                              temp=0.0, runs=1, exp="wording")),
])
FINALISTS_FILE = os.path.join(D, "stage2_finalists.json")


def stage2():
    """Stage 2 phases, with C (mqm_combined*) removed unless Stage 1b put it in the finalists."""
    if not os.path.exists(FINALISTS_FILE):
        raise SystemExit("!! data/taskB/stage2_finalists.json not found - run Stage 1b and "
                         "python taskB/analyze_stage1.py first (Step B5, part 1).")
    fin = json.load(open(FINALISTS_FILE))["finalists"]
    out = OrderedDict()
    for p, s in STAGE2_ALL.items():
        prompts = [x for x in s["prompts"] if not x.startswith("mqm_combined") or "mqm_combined" in fin]
        out[p] = dict(s, prompts=prompts)
    return out


STAGES = {"1": STAGE1, "1b": STAGE1B, "2": None}   # "2" is built by stage2() when it is needed


def _rj(name):
    with open(os.path.join(D, name), encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def load_data():
    dA, dB = _rj("dev_setA.jsonl"), _rj("dev_setB.jsonl")
    hA, hB = _rj("heldout_setA.jsonl"), _rj("heldout_setB.jsonl")
    return {"dev_A": dA, "dev_AB": dA + dB, "dev_pairs": _rj("dev_pairs.jsonl"),
            "ho_AB": hA + hB, "ho_pairs": _rj("heldout_pairs.jsonl"), "repeat": _rj("repeat_subset.jsonl")}


def job_key(j):
    return "|".join([j["phase"], j["model"], j["prompt_id"], j["item_id"], f"T{j['temperature']}",
                     f"r{j['run']}", j.get("order", "-")])


def build_jobs(phase, spec, data):
    jobs = []
    for model in MODELS:
        for run in range(spec.get("run_start", 0), spec.get("run_start", 0) + spec["runs"]):
            for pid in spec["prompts"]:
                for it in data[spec["data"]]:
                    base = dict(phase=phase, experiment=spec["exp"], model=model, prompt_id=pid,
                                temperature=spec["temp"], run=run, seed=BASE_SEED + run)
                    if spec["data"].endswith("pairs"):
                        for order in ("AB", "BA"):
                            f, s = ("a", "b") if order == "AB" else ("b", "a")
                            j = dict(base, item_id=it["pair_id"], set="pairs", order=order, source=it["source_text"],
                                     a=it[f"{f}_text"], b=it[f"{s}_text"],
                                     shown_first=it[f"{f}_item_id"], shown_second=it[f"{s}_item_id"])
                            j["key"] = job_key(j)
                            jobs.append(j)
                    else:
                        j = dict(base, item_id=it["item_id"], set=it.get("set", "?"), source=it["source_text"],
                                 mt=it["candidate"], reference=it.get("reference"))
                        j["key"] = job_key(j)
                        jobs.append(j)
    return jobs


def stage_jobs(stage, data=None):
    data = data or load_data()
    phases = stage2() if stage == "2" else STAGES[stage]
    return OrderedDict((p, build_jobs(p, s, data)) for p, s in phases.items())
