"""
Task B · Step B2 — check the strategy prompts and build the review files.

Hard checks (exit code 1 if any fails)
  1. The Sprint 50 baseline prompts (flat, mqm, pairwise) are byte-identical to the ones used in
     Task A (compared with results/prompts_snapshot.json written during the Task A run).
  2. Every Task B prompt renders with a real item (no missing placeholders, no stray braces).
  3. Few-shot examples: each item exists, its text matches the dataset exactly, it belongs to the
     DEVELOPMENT half, and its planted/annotated error span appears in the translation.
  4. No held-out translation text appears inside any prompt template.
  5. Parser round-trip: a well-formed answer for every new output format parses, and the S4
     combined score equals 0.8 x accuracy + 0.2 x fluency.
Also reports the prompt length (characters, rough tokens) - longer prompts run slower on the T4.

Writes
  taskB/PROMPTS_FOR_REVIEW.md          every baseline and strategy prompt, in full
  review/TaskB_FewShot_Review.xlsx     3 few-shot examples for the Mandarin reviewer (~10 min)
  data/taskB/fewshot_exclude.json      sources/items left out of Stage 1 scoring

Run:  python taskB/check_prompts.py
"""
import hashlib
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from judge.parsing import parse  # noqa: E402
from judge.prompts import PROMPTS, render  # noqa: E402
from judge.prompts_taskb import (ACCFLU_WEIGHTS, FEWSHOT_EXAMPLES, FEWSHOT_EXCLUDE, STRATEGY,  # noqa: E402
                                 TASKB_PROMPTS)

D = os.path.join(ROOT, "data", "taskB")
hard, lines = [], []


def rj(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


# 1 baseline unchanged
snap_path = os.path.join(ROOT, "results", "prompts_snapshot.json")
if os.path.exists(snap_path):
    snap = json.load(open(snap_path, encoding="utf-8"))
    for pid in ("flat", "mqm", "pairwise"):
        if snap.get(pid) != PROMPTS[pid][0]:
            hard.append(f"baseline prompt '{pid}' differs from the Task A run")
else:
    hard.append("results/prompts_snapshot.json not found - upload the full Task A project")

dev = {r["item_id"]: r for k in ("setA", "setB") for r in rj(os.path.join(D, f"dev_{k}.jsonl"))}
held = {r["item_id"]: r for k in ("setA", "setB") for r in rj(os.path.join(D, f"heldout_{k}.jsonl"))}
held_pairs = rj(os.path.join(D, "heldout_pairs.jsonl"))
sample = next(iter(dev.values()))
dev_pair = rj(os.path.join(D, "dev_pairs.jsonl"))[0]

# 2 render
lengths = {}
for pid in ["flat", "mqm", "pairwise"] + list(TASKB_PROMPTS):
    try:
        if PROMPTS[pid][1].startswith("pairwise"):
            txt = render(pid, dev_pair["source_text"], a=dev_pair["a_text"], b=dev_pair["b_text"])
        else:
            txt = render(pid, sample["source_text"], mt=sample["candidate"], reference=sample.get("reference"))
        if "{" in txt.replace('{"', "").replace("{{", "") and "<integer" not in txt and '"errors"' not in txt:
            hard.append(f"{pid}: unexpected brace in rendered prompt")
        lengths[pid] = len(txt)
    except Exception as e:  # noqa: BLE001
        hard.append(f"{pid}: does not render ({e})")

# 3 few-shot provenance
for k, ex in enumerate(FEWSHOT_EXAMPLES, start=1):
    iid = ex["item_id"]
    if iid not in dev:
        hard.append(f"few-shot {k} ({iid}) is not in the development half")
        continue
    r = dev[iid]
    if r["source_text"] != ex["source"] or r["candidate"] != ex["mt"]:
        hard.append(f"few-shot {k} ({iid}) text does not match the dataset")
    for e in ex["answer"]["errors"]:
        if e["text"] not in ex["mt"]:
            hard.append(f"few-shot {k}: error span '{e['text']}' not in its translation")
for sid in FEWSHOT_EXCLUDE["sources"]:
    if not any(r.get("source_id") == sid for r in dev.values()):
        hard.append(f"excluded source {sid} is not in the development half")

# 4 no held-out text in prompts
held_texts = {r["candidate"] for r in held.values()} | {p["a_text"] for p in held_pairs} | {p["b_text"] for p in held_pairs}
for pid, (tpl, *_rest) in TASKB_PROMPTS.items():
    for t in held_texts:
        if len(t) >= 6 and t in tpl:
            hard.append(f"{pid}: contains held-out text '{t[:20]}…'")

# 5 parser round-trip
tests = {
    "flat_rubric": '{"score": 72}',
    "mqm_fewshot": '{"errors": [{"text": "每年", "type": "Mistranslation", "severity": "major"}]}',
    "mqm_steps": '```json\n{"steps": {"meaning": "ok", "names_numbers_terms": "ok", "idioms_culture": "none", '
                 '"valid_variation": "ok"}, "errors": []}\n```',
    "flat_accflu": '{"accuracy": 90, "fluency": 60}',
    "pairwise_tie": '{"assessment_a": "accurate", "assessment_b": "wrong number", "better": "A"}',
}
for pid, txt in tests.items():
    fmt, rng = PROMPTS[pid][1], PROMPTS[pid][2]
    r = parse(fmt, txt, rng)
    if r["parse_status"] == "malformed":
        hard.append(f"{pid}: parser rejected a well-formed answer ({r['parse_reason']})")
r = parse("accflu", tests["flat_accflu"])
if abs(r["score"] - (ACCFLU_WEIGHTS["accuracy"] * 90 + ACCFLU_WEIGHTS["fluency"] * 60)) > 1e-9:
    hard.append("S4 combined score is not 0.8 x accuracy + 0.2 x fluency")

# ------------------------------------------------------------------ outputs
json.dump(FEWSHOT_EXCLUDE, open(os.path.join(D, "fewshot_exclude.json"), "w"), indent=1)
md = ["# Task B — all prompts (for review)", "",
      "Placeholders: {src_lang} = English · {tgt_lang} = Standard Mandarin Chinese (Simplified script) · "
      "{source}, {mt}, {a}, {b} = the item being judged. Doubled braces {{ }} print as single braces.", ""]
names = {"flat": "Baseline · flat 0–100 (Sprint 50, verbatim)", "mqm": "Baseline · MQM (Sprint 50, verbatim)",
         "pairwise": "Baseline · pairwise (Task A)"}
for pid in ["flat", "mqm", "pairwise"] + list(TASKB_PROMPTS):
    title = names.get(pid) or f"{STRATEGY[pid][0]} · `{pid}` (compared with baseline `{STRATEGY[pid][1]}`)"
    md += [f"## {title}", "", f"Output format: `{PROMPTS[pid][1]}` · length ≈ {lengths.get(pid, 0)} characters", "",
           "```text", PROMPTS[pid][0], "```", ""]
md += ["## S4 combination rule", "", f"final score = {ACCFLU_WEIGHTS['accuracy']} × accuracy + {ACCFLU_WEIGHTS['fluency']} × fluency (computed in code)", "",
       "## Few-shot examples and why", ""]
for k, ex in enumerate(FEWSHOT_EXAMPLES, start=1):
    md += [f"{k}. `{ex['item_id']}` — {ex['why']}"]
md += ["", f"Left out of Stage 1 scoring for every prompt: sources {FEWSHOT_EXCLUDE['sources']}, Set A {FEWSHOT_EXCLUDE['setA_items']}."]
open(os.path.join(ROOT, "taskB", "PROMPTS_FOR_REVIEW.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")

try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    wb = Workbook()
    ws = wb.active
    ws.title = "Few-shot review"
    ws["A1"] = ("Please check the 3 worked examples below. They are shown to the judge as 'correct evaluations', "
                "so they must be right. Fill only the yellow columns. About 10 minutes.")
    ws["A1"].font = Font(name="Arial", bold=True)
    head = ["Example", "English source", "Chinese translation", "Our annotation (what the judge is told)", "Why",
            "Q1. Is our annotation correct?", "Q2. Is the severity right?", "Q3. Correction / comment"]
    for i, h in enumerate(head, start=1):
        c = ws.cell(row=3, column=i, value=h)
        c.font = Font(name="Arial", bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", start_color="1F3864")
        c.alignment = Alignment(wrap_text=True, vertical="center")
    dv1 = DataValidation(type="list", formula1='"Yes,No,Partly"', allow_blank=True)
    dv2 = DataValidation(type="list", formula1='"Yes,Should be minor,Should be major,Should be critical,Not an error,n/a"', allow_blank=True)
    ws.add_data_validation(dv1)
    ws.add_data_validation(dv2)
    for k, ex in enumerate(FEWSHOT_EXAMPLES, start=1):
        r = 3 + k
        ann = "No errors" if not ex["answer"]["errors"] else "; ".join(
            f"「{e['text']}」 {e['type']}, {e['severity']}" for e in ex["answer"]["errors"])
        vals = [k, ex["source"], ex["mt"], ann, ex["why"], None, None if ex["answer"]["errors"] else "n/a", None]
        for i, v in enumerate(vals, start=1):
            c = ws.cell(row=r, column=i, value=v)
            c.font = Font(name="Arial", size=10)
            c.alignment = Alignment(wrap_text=True, vertical="top")
            if i >= 6:
                c.fill = PatternFill("solid", start_color="FFF2CC")
        dv1.add(f"F{r}")
        dv2.add(f"G{r}")
    for col, w in zip("ABCDEFGH", (9, 40, 34, 34, 44, 16, 18, 40)):
        ws.column_dimensions[col].width = w
    os.makedirs(os.path.join(ROOT, "review"), exist_ok=True)
    wb.save(os.path.join(ROOT, "review", "TaskB_FewShot_Review.xlsx"))
except ImportError:
    hard.append("openpyxl missing - pip install openpyxl")

lines += ["TASK B · STEP B2 — PROMPT CHECKS", "=" * 50]
for pid in lengths:
    tag = STRATEGY.get(pid, ("baseline", ""))[0]
    lines.append(f"  {pid:14s} {tag:9s} {lengths[pid]:5d} chars (~{lengths[pid] // 3} tokens)")
lines += ["", f"Few-shot examples: {[e['item_id'] for e in FEWSHOT_EXAMPLES]}",
          f"Excluded from Stage 1 scoring: {FEWSHOT_EXCLUDE}", "", f"HARD FAILURES: {len(hard)}"] + [f"  - {h}" for h in hard]
lines += ["", "Wrote taskB/PROMPTS_FOR_REVIEW.md and review/TaskB_FewShot_Review.xlsx"]
print("\n".join(lines))
sys.exit(1 if hard else 0)
