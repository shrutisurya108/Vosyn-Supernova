"""
Task B · Step B4 — Stage 1 screening analysis (development half only). CPU only, deterministic.

  python taskB/analyze_stage1.py          # writes analysis_taskB/stage1/ (tables + STAGE1_SUMMARY.md)

Every strategy is compared with the baseline re-run in the SAME Task B session (B1_baseline):
  S1 flat_rubric, S4 flat_accflu  vs  flat        S2 mqm_fewshot, S3 mqm_steps  vs  mqm
  S5 pairwise_tie                 vs  pairwise (both orders)
  C  mqm_combined (Stage 1b, Step B5) vs mqm - and, pre-registered in Step B5, C goes to Stage 2 only
     if it passes the same rule AND is not clearly worse than S2 on any metric (else S2 alone is better).
     The result is written to data/taskB/stage2_finalists.json (S2 + S5 approved by the user + C if it passes).

Few-shot sources (N_IDI1, N_NUM1) and Set A item A::en_to_cmn_258 are left out for EVERY prompt
(data/taskB/fewshot_exclude.json), so all prompts are scored on the same items.

Definitions are the Task A ones (analysis/analyze.py, taskB/BASELINE_AND_METRICS.md):
  band             clean >= 85, moderate 60-84, poor < 60
  inconsistent     the 3 runs at T = 0.7 differ by >= 10 points OR fall in more than one band
  below-gold       a flawed version (fluent_wrong, targeted_error) scored strictly below its own gold
  above-gold       ... scored strictly above its own gold
  false errors     share of correct translations (gold + paraphrase) with >= 1 listed error (MQM-style)
  correct < 85     share of correct translations scored below the clean band (any style)
  spans not in MT  share of listed error spans that do not occur in the translation (MQM-style)
  detected         a listed span contains / lies inside the planted error span (Task A rule)
Stage 1 decision rule (pre-registered): primary metric better than baseline for >= 1 judge AND no
reliability metric clearly worse (> 10 percentage points, or rho drop > 0.15) for either judge AND
malformed <= 5 %. Stage 1 is screening only: the bootstrap intervals are shown for orientation.
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
D = os.path.join(ROOT, "data", "taskB")
RES = os.path.join(ROOT, "results_taskB")
OUT = os.path.join(ROOT, "analysis_taskB", "stage1")
os.makedirs(OUT, exist_ok=True)
MODELS = ["glm4", "qwen", "ens"]          # ens = mean of glm4 and qwen (Sprint 50 ensemble = median of 2)
ABS = ["flat", "flat_rubric", "flat_accflu", "mqm", "mqm_fewshot", "mqm_steps", "mqm_combined"]
MQM_STYLE = {"mqm", "mqm_fewshot", "mqm_steps", "mqm_combined"}
BASE = {"flat_rubric": "flat", "flat_accflu": "flat", "mqm_fewshot": "mqm", "mqm_steps": "mqm", "pairwise_tie": "pairwise",
        "mqm_combined": "mqm"}
NAME = {"flat": "baseline flat", "mqm": "baseline MQM", "flat_rubric": "S1 rubric", "mqm_fewshot": "S2 few-shot",
        "mqm_steps": "S3 steps", "flat_accflu": "S4 acc+flu", "pairwise": "baseline pairwise", "pairwise_tie": "S5 pairwise+tie", "mqm_combined": "C combined"}
SEED = 42


def rj(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def band(s):
    return "clean" if s >= 85 else ("moderate" if s >= 60 else "poor")


def rho(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    return float(spearmanr(x, y).statistic) if len(set(x)) > 1 and len(set(y)) > 1 else float("nan")


def kripp(mat):
    mat = np.asarray(mat, float)
    n_items, m = mat.shape
    v = mat.ravel()
    do = sum(((r[:, None] - r[None, :]) ** 2).sum() / (m - 1) for r in mat) / v.size
    de = ((v[:, None] - v[None, :]) ** 2).sum() / (v.size * (v.size - 1))
    return float(1 - do / de) if de > 0 else float("nan")


def detected(errs, span):
    if not isinstance(span, str) or not span or not isinstance(errs, list):
        return False
    for e in errs:
        t = str(e.get("text") or "")
        if t and (t in span or (span in t and len(t) <= max(3 * len(span), len(span) + 6))):
            return True
    return False


def boot_diff(f, units, n=2000):
    """Paired bootstrap over units (items or sources): CI of f(sample) where f returns new - base."""
    rng = np.random.default_rng(SEED)
    units = np.asarray(units)
    vals = []
    for _ in range(n):
        s = units[rng.integers(0, len(units), len(units))]
        v = f(s)
        if v == v:
            vals.append(v)
    return (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))) if vals else (np.nan, np.nan)


# ============================================================================ load
excl = json.load(open(os.path.join(D, "fewshot_exclude.json")))
A = {r["item_id"]: r for r in rj(os.path.join(D, "dev_setA.jsonl")) if r["item_id"] not in excl["setA_items"]}
B = {r["item_id"]: r for r in rj(os.path.join(D, "dev_setB.jsonl")) if r["source_id"] not in excl["sources"]}
P = {r["pair_id"]: r for r in rj(os.path.join(D, "dev_pairs.jsonl")) if r["source_id"] not in excl["sources"]}
rows = [r for f in sorted(os.listdir(RES)) if f.startswith(("B1_", "B1b_")) for r in rj(os.path.join(RES, f))]
df = pd.DataFrame(rows)
HAVE_C = bool((df.prompt_id == "mqm_combined").any())
if not HAVE_C:
    ABS.remove("mqm_combined")
    del BASE["mqm_combined"]
mal = df.groupby(["prompt_id", "model"]).parse_status.apply(lambda s: (s == "malformed").mean())
dfo = df[df.parse_status != "malformed"].copy()
env = rj(os.path.join(RES, "environment.jsonl"))

t0 = dfo[(dfo.temperature == 0.0) & dfo.prompt_id.isin(ABS)].copy()
t0 = t0[t0.item_id.isin(set(A) | set(B))]
# ensemble rows = mean of the two judges (only where both parsed)
w = t0.pivot_table(index=["prompt_id", "item_id"], columns="model", values="score").dropna()
ens = w.mean(axis=1).rename("score").reset_index().assign(model="ens", set=lambda x: x.item_id.str[0])
t0 = pd.concat([t0, ens], ignore_index=True)
gap = (w["glm4"] - w["qwen"]).groupby("prompt_id")
t0["source_id"] = t0.item_id.map(lambda i: (A.get(i) or B.get(i))["source_id"])
t0["variant"] = t0.item_id.map(lambda i: B[i]["variant_type"] if i in B else "setA")
t0["candidate"] = t0.item_id.map(lambda i: (A.get(i) or B.get(i))["candidate"])

S = {}  # (prompt, model) -> per-unit series used by metrics + bootstrap


def per_prompt(p, m):
    g = t0[(t0.prompt_id == p) & (t0.model == m)]
    ga = g[g.set == "A"].set_index("item_id").score
    gb = g[g.set == "B"]
    gold = gb[gb.variant == "gold"].set_index("source_id").score
    fl = gb[gb.variant.isin(["fluent_wrong", "targeted_error"])].copy()
    fl["d"] = fl.source_id.map(gold) - fl.score                    # > 0 = flawed below gold (good)
    fl = fl.dropna(subset=["d"])
    lit = gb[gb.variant == "literal"].set_index("source_id").score
    fw = gb[gb.variant == "fluent_wrong"].set_index("source_id").score
    lf = (lit - fw).dropna()
    corr = gb[gb.variant.isin(["gold", "paraphrase"])]
    nongold = gb[(gb.variant != "gold") & gb.item_id.map(lambda i: B[i]["script"] == "simplified")]
    true_ord = nongold.item_id.map(lambda i: {"poor": 0, "moderate": 1, "clean": 2}[B[i]["expected_quality_band"]])
    r = dict(prompt=p, model=m,
             rho_human_setA=rho(ga, [A[i]["human_score"] for i in ga.index]), n_setA=len(ga),
             rho_true_band_setB=rho(nongold.score, true_ord),
             band_accuracy_setB=float(np.mean([band(s) == B[i]["expected_quality_band"] for s, i in zip(gb.score, gb.item_id)])),
             below_gold_strict=float((fl.d > 0).mean()), tie_with_gold=float((fl.d == 0).mean()),
             above_gold=float((fl.d < 0).mean()), n_flawed=len(fl),
             literal_beats_fluent_wrong=float((lf > 0).mean()), n_lit_fw=len(lf),
             correct_below_85=float((corr.score < 85).mean()), mean_score_correct=float(corr.score.mean()),
             mean_score_flawed=float(fl.score.mean()), n_correct=len(corr))
    S[(p, m)] = dict(ga=ga, fl=fl.set_index("item_id"), lf=lf, corr=corr.set_index("item_id"))
    if p in MQM_STYLE and m != "ens":
        r["false_error_rate_on_correct"] = float((corr.n_errors > 0).mean())
        r["major_or_critical_on_correct"] = float(np.mean([(c["major"] + c["critical"]) > 0 for c in corr.severity_counts]))
        spans = [(str(e.get("text") or "") not in c) for es, c in zip(gb.errors, gb.candidate) if isinstance(es, list) for e in es]
        r["spans_not_in_translation"] = float(np.mean(spans)) if spans else np.nan
        r["n_spans"] = len(spans)
        pl = gb[gb.variant.isin(["fluent_wrong", "targeted_error"])]
        r["planted_error_detected"] = float(np.mean([detected(e, (B[i].get("planted_error") or {}).get("span"))
                                                     for e, i in zip(pl.errors, pl.item_id)]))
        r["mean_errors_listed"] = float(gb.n_errors.mean())
    if m != "ens":
        r["malformed"] = float(mal.get((p, m), 0))
    else:
        gg = gap.get_group(p)
        r["mean_abs_judge_gap"] = float(gg.abs().mean())
        r["judge_agreement_rho"] = rho(w.loc[p]["glm4"], w.loc[p]["qwen"])
    return r


T1 = pd.DataFrame([per_prompt(p, m) for p in ABS for m in MODELS])

# ============================================================================ consistency at T = 0.7 (Set A, 3 runs)
rep = dfo[dfo.phase.isin(["B1_repeat_T07", "B1b_C_repeat_T07"]) & dfo.item_id.isin(A)]
cons = []
CONS = {}
for (p, m), g in rep.groupby(["prompt_id", "model"]):
    mat = g.pivot_table(index="item_id", columns="run", values="score").dropna()
    rng_ = mat.max(axis=1) - mat.min(axis=1)
    nb = mat.apply(lambda r: len({band(x) for x in r}), axis=1)
    inc = (rng_ >= 10) | (nb > 1)
    CONS[(p, m)] = pd.DataFrame({"inc": inc, "spread": rng_, "sd": mat.std(axis=1)})
    cons.append(dict(prompt=p, model=m, n_items=len(mat), inconsistent_share=float(inc.mean()),
                     band_changes=float((nb > 1).mean()), mean_spread=float(rng_.mean()), max_spread=float(rng_.max()),
                     mean_sd=float(mat.std(axis=1).mean()), kripp_alpha_runs=kripp(mat.values),
                     rho_human_mean_of_runs=rho(mat.mean(axis=1), [A[i]["human_score"] for i in mat.index])))
T2 = pd.DataFrame(cons)
T2["prompt"] = pd.Categorical(T2.prompt, ABS, ordered=True)
T2 = T2.sort_values(["prompt", "model"])

# ============================================================================ pairwise (both orders)
pw = dfo[(dfo.phase == "B1_pairwise") & dfo.item_id.isin(P)].copy()


def orig(r):
    if r.better == "tie":
        return "tie"
    first, second = ("a", "b") if r.order == "AB" else ("b", "a")
    return first if r.better == "A" else second


pw["verdict"] = pw.apply(orig, axis=1)
pw["expected"] = pw.item_id.map(lambda i: P[i]["expected_preference"])
pw["ok"] = [(v == e) or (e == "a_or_tie" and v in ("a", "tie")) for v, e in zip(pw.verdict, pw.expected)]
pwr, PW = [], {}
for (p, m), g in pw.groupby(["prompt_id", "model"]):
    wd = g.pivot_table(index="item_id", columns="order", values="verdict", aggfunc="first").dropna()
    wd["consistent"] = wd.AB == wd.BA
    nontie = g[g.better != "tie"]
    PW[(p, m)] = wd
    pwr.append(dict(prompt=p, model=m, n_pairs=len(wd), order_consistent=float(wd.consistent.mean()),
                    first_position_rate=float((g.better == "A").mean()),
                    first_share_of_non_tie=float((nontie.better == "A").mean()) if len(nontie) else np.nan,
                    tie_rate=float((g.better == "tie").mean()), verdict_matches_expected=float(g.ok.mean()),
                    flawed_preferred=float(np.mean([(e == "a" and v == "b") for v, e in zip(g.verdict, g.expected)])),
                    ties_on_tie_pairs=float((g[g.expected == "tie"].verdict == "tie").mean()),
                    malformed=float(mal.get((p, m), 0))))
T3 = pd.DataFrame(pwr)

# ============================================================================ deltas vs baseline + bootstrap + decision
PRIMARY = {
    "flat_rubric": [("cons", "inconsistent_share", -1), ("cons", "mean_spread", -1), ("ens", "mean_abs_judge_gap", -1)],
    "mqm_fewshot": [("abs", "false_error_rate_on_correct", -1), ("abs", "above_gold", -1)],
    "mqm_steps": [("abs", "spans_not_in_translation", -1), ("abs", "planted_error_detected", +1)],
    "flat_accflu": [("abs", "below_gold_strict", +1), ("abs", "literal_beats_fluent_wrong", +1)],
    "pairwise_tie": [("pw", "order_consistent", +1), ("pw", "first_position_rate", -1)],
    "mqm_combined": [("abs", "false_error_rate_on_correct", -1), ("abs", "above_gold", -1),
                     ("abs", "spans_not_in_translation", -1), ("abs", "planted_error_detected", +1)],
}
GUARD_ABS = [("rho_human_setA", +1, "rho"), ("rho_true_band_setB", +1, "rho"), ("below_gold_strict", +1, "pp"),
             ("above_gold", -1, "pp"), ("band_accuracy_setB", +1, "pp"), ("correct_below_85", -1, "pp"),
             ("false_error_rate_on_correct", -1, "pp"), ("spans_not_in_translation", -1, "pp"),
             ("planted_error_detected", +1, "pp"), ("malformed", -1, "pp")]
GUARD_CONS = [("inconsistent_share", -1, "pp")]
GUARD_PW = [("order_consistent", +1, "pp"), ("verdict_matches_expected", +1, "pp"), ("flawed_preferred", -1, "pp"),
            ("malformed", -1, "pp")]


def tab(kind):
    return {"abs": T1, "cons": T2, "pw": T3, "ens": T1}[kind]


def val(kind, p, m, metric):
    t = tab(kind)
    x = t[(t.prompt == p) & (t.model == m)]
    return float(x[metric].iloc[0]) if len(x) and metric in x and x[metric].iloc[0] == x[metric].iloc[0] else np.nan


def boot(kind, metric, p, b, m):
    """Paired bootstrap CI of (new - base) over the units the metric is defined on."""
    if kind == "cons":
        X, Y = CONS[(p, m)], CONS[(b, m)]
        u = X.index.intersection(Y.index)
        col = "inc" if metric == "inconsistent_share" else "spread"
        return boot_diff(lambda s: X.loc[s, col].astype(float).mean() - Y.loc[s, col].astype(float).mean(), u)
    if kind == "pw":
        X, Y = PW[(p, m)], PW[(b, m)]
        u = X.index.intersection(Y.index)
        if metric == "order_consistent":
            return boot_diff(lambda s: X.loc[s, "consistent"].mean() - Y.loc[s, "consistent"].mean(), u)
        g1 = pw[(pw.prompt_id == p) & (pw.model == m)].set_index("item_id")
        g0 = pw[(pw.prompt_id == b) & (pw.model == m)].set_index("item_id")
        return boot_diff(lambda s: (g1.loc[s].better == "A").mean() - (g0.loc[s].better == "A").mean(), u)
    if kind == "ens":
        gg1, gg0 = gap.get_group(p).droplevel(0).abs(), gap.get_group(b).droplevel(0).abs()
        u = gg1.index.intersection(gg0.index)
        return boot_diff(lambda s: gg1.loc[s].mean() - gg0.loc[s].mean(), u)
    X, Y = S[(p, m)], S[(b, m)]
    if metric in ("below_gold_strict", "above_gold"):
        sgn = (lambda d: d > 0) if metric == "below_gold_strict" else (lambda d: d < 0)
        u = X["fl"].index.intersection(Y["fl"].index)
        return boot_diff(lambda s: sgn(X["fl"].loc[s, "d"]).mean() - sgn(Y["fl"].loc[s, "d"]).mean(), u)
    if metric == "literal_beats_fluent_wrong":
        u = X["lf"].index.intersection(Y["lf"].index)
        return boot_diff(lambda s: (X["lf"].loc[s] > 0).mean() - (Y["lf"].loc[s] > 0).mean(), u)
    if metric == "false_error_rate_on_correct":
        u = X["corr"].index.intersection(Y["corr"].index)
        return boot_diff(lambda s: (X["corr"].loc[s, "n_errors"] > 0).mean() - (Y["corr"].loc[s, "n_errors"] > 0).mean(), u)
    if metric in ("spans_not_in_translation", "planted_error_detected"):
        g1 = t0[(t0.prompt_id == p) & (t0.model == m) & (t0.set == "B")].set_index("item_id")
        g0 = t0[(t0.prompt_id == b) & (t0.model == m) & (t0.set == "B")].set_index("item_id")
        if metric == "planted_error_detected":
            pl = [i for i in g1.index.intersection(g0.index) if B[i]["variant_type"] in ("fluent_wrong", "targeted_error")]
            sp = {i: (B[i].get("planted_error") or {}).get("span") for i in pl}
            d1 = pd.Series({i: float(detected(g1.loc[i, "errors"], sp[i])) for i in pl})
            d0 = pd.Series({i: float(detected(g0.loc[i, "errors"], sp[i])) for i in pl})
            return boot_diff(lambda s: d1.loc[s].mean() - d0.loc[s].mean(), np.array(pl))

        def cnt(g):
            return pd.DataFrame({"bad": [sum(str(e.get("text") or "") not in c for e in es) if isinstance(es, list) else 0
                                         for es, c in zip(g.errors, g.candidate)],
                                 "n": [len(es) if isinstance(es, list) else 0 for es in g.errors]}, index=g.index)
        c1, c0 = cnt(g1), cnt(g0)
        u = c1.index.intersection(c0.index)

        def f(s):
            a, z = c1.loc[s].sum(), c0.loc[s].sum()
            return (a.bad / a.n if a.n else np.nan) - (z.bad / z.n if z.n else np.nan)
        return boot_diff(f, u)
    return (np.nan, np.nan)


drows, decisions = [], []
for p, b in BASE.items():
    judges = ["glm4", "qwen"]
    prim_ok = {}
    for kind, metric, sgn in PRIMARY[p]:
        for m in (["ens"] if kind == "ens" else judges):
            v1, v0 = val(kind, p, m, metric), val(kind, b, m, metric)
            lo, hi = boot(kind, metric, p, b, m)
            better = (v1 - v0) * sgn > 0
            ci_excl = (lo > 0 or hi < 0)
            drows.append(dict(strategy=NAME[p], prompt=p, baseline=b, role="PRIMARY", metric=metric, model=m,
                              baseline_value=v0, strategy_value=v1, delta=v1 - v0, ci_lo=lo, ci_hi=hi,
                              better=better, ci_excludes_zero=ci_excl))
            prim_ok[(metric, m)] = better
    regress = []
    guards = GUARD_PW if p == "pairwise_tie" else GUARD_ABS + GUARD_CONS
    for metric, sgn, unit in guards:
        if metric in [x[1] for x in PRIMARY[p]]:
            continue
        for m in judges:
            kind = "pw" if p == "pairwise_tie" else ("cons" if metric in dict((g[0], 1) for g in GUARD_CONS) else "abs")
            v1, v0 = val(kind, p, m, metric), val(kind, b, m, metric)
            if v1 != v1 or v0 != v0:
                continue
            d = (v1 - v0) * sgn
            bad = d < -0.15 if unit == "rho" else d < -0.10
            drows.append(dict(strategy=NAME[p], prompt=p, baseline=b, role="guard", metric=metric, model=m, baseline_value=v0,
                              strategy_value=v1, delta=v1 - v0, ci_lo=np.nan, ci_hi=np.nan, better=d > 0, clearly_worse=bad))
            if bad:
                regress.append(f"{metric} ({m}) {v0:.2f} -> {v1:.2f}")
    malf = float(max(mal.get((p, "glm4"), 0), mal.get((p, "qwen"), 0)))
    passes = any(prim_ok.values()) and not regress and malf <= 0.05
    decisions.append(dict(strategy=NAME[p], prompt=p, primary_better_for=", ".join(f"{k[0]}[{k[1]}]" for k, v in prim_ok.items() if v) or "none",
                          clearly_worse=("; ".join(regress) or "none"), malformed=malf,
                          stage1_rule="PASS" if passes else "FAIL"))
DL = pd.DataFrame(drows)
DEC = pd.DataFrame(decisions)

# ============================================================================ Step B5: C vs S2 + finalists
CS2 = pd.DataFrame()
if HAVE_C:
    cr = []
    for metric, sgn, unit in GUARD_ABS + GUARD_CONS:
        for m in ("glm4", "qwen"):
            kind = "cons" if metric == "inconsistent_share" else "abs"
            v1, v0 = val(kind, "mqm_combined", m, metric), val(kind, "mqm_fewshot", m, metric)
            if v1 != v1 or v0 != v0:
                continue
            d = (v1 - v0) * sgn
            cr.append(dict(metric=metric, model=m, S2=v0, C=v1, delta=v1 - v0, C_better=d > 0,
                           clearly_worse=(d < -0.15) if unit == "rho" else (d < -0.10)))
    CS2 = pd.DataFrame(cr)
    c_rule = DEC.loc[DEC.prompt == "mqm_combined", "stage1_rule"].iloc[0] == "PASS"
    c_vs_s2 = not CS2.clearly_worse.any()
    fin = ["mqm_fewshot", "pairwise_tie"] + (["mqm_combined"] if c_rule and c_vs_s2 else [])
    json.dump({"finalists": fin, "C_passes_rule_vs_baseline": bool(c_rule), "C_not_clearly_worse_than_S2": bool(c_vs_s2),
               "worse_than_S2": [f"{r.metric} ({r.model}) {r.S2:.2f} -> {r.C:.2f}" for r in CS2[CS2.clearly_worse].itertuples()],
               "note": "S2 and S5 approved by the user after Stage 1; C added only if it passes (pre-registered in Step B5)"},
              open(os.path.join(D, "stage2_finalists.json"), "w"), indent=1)

# ============================================================================ drift check vs Task A (same prompts, T = 0)
drift = []
taskA = os.path.join(ROOT, "results")
if os.path.exists(taskA):
    TA = pd.DataFrame([r for f in sorted(os.listdir(taskA)) if f.startswith("P") and f.endswith(".jsonl")
                       for r in rj(os.path.join(taskA, f))])
    TA = TA[((TA.phase == "P01_E1_T00") & (TA.run == 0)) | TA.phase.isin(["P06_E4_setB_mqm", "P08_E5_setB_flat"])]
    for m in ("glm4", "qwen"):
        for p in ("flat", "mqm"):
            a = TA[(TA.model == m) & (TA.prompt_id == p)].drop_duplicates("item_id").set_index("item_id").score
            bb = df[(df.phase == "B1_baseline") & (df.model == m) & (df.prompt_id == p)].set_index("item_id").score
            u = a.index.intersection(bb.index)
            d = (bb.loc[u] - a.loc[u]).abs()
            drift.append(dict(model=m, prompt=p, items=len(u), identical=float((d == 0).mean()), moved_10plus=float((d >= 10).mean()),
                              mean_abs_change=float(d.mean())))
DR = pd.DataFrame(drift)

# ============================================================================ write
for t, n in ((T1, "S1_absolute_T0.csv"), (T2, "S1_consistency_T07.csv"), (T3, "S1_pairwise.csv"),
             (DL, "S1_deltas_vs_baseline.csv"), (DEC, "S1_decisions.csv"), (DR, "S1_drift_vs_taskA.csv"),
             (CS2, "S1b_C_vs_S2.csv")):
    t.round(3).to_csv(os.path.join(OUT, n), index=False, encoding="utf-8-sig")

pd.set_option("display.width", 220, "display.max_columns", 40, "display.max_colwidth", 70)
L = ["# Task B · Stage 1 screening (development half)", "",
     f"Calls: {len(df)}, malformed {int((df.parse_status == 'malformed').sum())}, retried {int((df.attempts > 1).sum())}, "
     f"cut off {int((df.done_reason == 'length').sum())}. Sessions: {len(env)}, Ollama {env[-1]['ollama_version']}, "
     f"same model digests in all sessions: {len({json.dumps(e['models'], sort_keys=True) for e in env}) == 1}.",
     f"Scored items: Set A {len(A)}, Set B {len(B)}, pairs {len(P)} (few-shot sources excluded for every prompt).", ""]
for title, t in (("Absolute prompts, T = 0", T1), ("Consistency, T = 0.7 x 3 runs, Set A", T2), ("Pairwise, both orders", T3),
                 ("Deltas vs baseline (primary metrics with 95% paired bootstrap CI; guard metrics)", DL),
                 ("Stage 1 decision rule", DEC), ("Baseline drift vs Task A run (same prompts, T = 0)", DR)) + (
                 (("Stage 1b: combined prompt C vs S2 (same items)", CS2),) if HAVE_C else ()):
    L += [f"## {title}", "", "```", t.round(3).to_string(index=False), "```", ""]
if HAVE_C:
    f = json.load(open(os.path.join(D, "stage2_finalists.json")))
    L += ["## Stage 2 finalists (written to data/taskB/stage2_finalists.json)", "",
          f"C passes the rule vs baseline: {f['C_passes_rule_vs_baseline']}; C not clearly worse than S2: "
          f"{f['C_not_clearly_worse_than_S2']} {f['worse_than_S2'] or ''}",
          f"FINALISTS: {', '.join(f['finalists'])}", ""]
open(os.path.join(OUT, "STAGE1_SUMMARY.md"), "w", encoding="utf-8").write("\n".join(L))
print("\n".join(L))
print(f"Wrote {OUT}")
