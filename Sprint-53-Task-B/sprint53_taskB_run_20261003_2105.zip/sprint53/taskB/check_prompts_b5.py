"""
Task B · Step B5 — check the combined prompt C and the rewordings before any GPU call.

Hard checks (exit code 1 if any fails)
  1. Every prompt used in Stage 1 is byte-identical to what Stage 1 actually ran
     (results_taskB/prompts_snapshot.json), and Task A's mqm_reworded is unchanged
     (results/prompts_snapshot.json) - so Stage 2 runs the same prompts that were screened.
  2. Every new prompt renders with a real development item / pair (no missing placeholder).
  3. Rewordings change wording only: same output format as the original, the same JSON schema line,
     and (few-shot / combined) the three few-shot examples byte-identical.
  4. No held-out translation text appears in any new template.
  5. Parser round-trip for C.
Writes taskB/PROMPTS_B5_FOR_REVIEW.md (C and all rewordings in full).

Run:  python taskB/check_prompts_b5.py
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from judge.parsing import parse  # noqa: E402
from judge.prompts import PROMPTS, render  # noqa: E402
from judge.prompts_taskb import _EX_DELIM, B5_PROMPTS, REWORDINGS, _examples  # noqa: E402

D = os.path.join(ROOT, "data", "taskB")
hard = []


def rj(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


# 1 Stage 1 prompts unchanged
s1 = os.path.join(ROOT, "results_taskB", "prompts_snapshot.json")
if not os.path.exists(s1):
    hard.append("results_taskB/prompts_snapshot.json not found - upload the Stage 1 checkpoint")
else:
    snap = json.load(open(s1, encoding="utf-8"))
    for pid in ("flat", "mqm", "pairwise", "flat_rubric", "mqm_fewshot", "mqm_steps", "flat_accflu", "pairwise_tie"):
        if snap.get(pid) != PROMPTS[pid][0]:
            hard.append(f"'{pid}' differs from the prompt Stage 1 ran")
ta = os.path.join(ROOT, "results", "prompts_snapshot.json")
if os.path.exists(ta) and json.load(open(ta, encoding="utf-8")).get("mqm_reworded") != PROMPTS["mqm_reworded"][0]:
    hard.append("Task A 'mqm_reworded' has changed")

# 2 render
dev = rj(os.path.join(D, "dev_setA.jsonl")) + rj(os.path.join(D, "dev_setB.jsonl"))
pair = rj(os.path.join(D, "dev_pairs.jsonl"))[0]
item = dev[0]
lengths = {}
for pid in B5_PROMPTS:
    try:
        if PROMPTS[pid][1].startswith("pairwise"):
            txt = render(pid, pair["source_text"], a=pair["a_text"], b=pair["b_text"])
            ok = pair["a_text"] in txt and pair["b_text"] in txt
        else:
            txt = render(pid, item["source_text"], mt=item["candidate"])
            ok = item["candidate"] in txt and item["source_text"] in txt
        if not ok or "None" in txt.split("Answer:")[-1][-200:]:
            hard.append(f"{pid}: item text not rendered correctly")
        lengths[pid] = len(txt)
    except Exception as e:  # noqa: BLE001
        hard.append(f"{pid}: does not render ({e})")


# 3 rewordings are wording-only
def schema(t):
    m = re.findall(r"^\{\{.*\}\}$", t, re.M)
    return m[-1] if m else None


for orig, rws in REWORDINGS.items():
    for rw in rws:
        if PROMPTS[rw][1] != PROMPTS[orig][1]:
            hard.append(f"{rw}: output format {PROMPTS[rw][1]} != {PROMPTS[orig][1]}")
        if schema(PROMPTS[rw][0]) != schema(PROMPTS[orig][0]):
            hard.append(f"{rw}: JSON schema line differs from {orig}")
        if orig == "mqm_fewshot" and _examples not in PROMPTS[rw][0]:
            hard.append(f"{rw}: few-shot examples are not byte-identical")
        if orig == "mqm_combined" and _EX_DELIM not in PROMPTS[rw][0]:
            hard.append(f"{rw}: few-shot examples are not byte-identical")
        if PROMPTS[rw][0] == PROMPTS[orig][0]:
            hard.append(f"{rw}: identical to {orig} (not a rewording)")
if _EX_DELIM not in PROMPTS["mqm_combined"][0]:
    hard.append("mqm_combined: few-shot examples missing")
if "different wording" in PROMPTS["mqm_combined"][0].lower() or "valid variation" in PROMPTS["mqm_combined"][0].lower():
    hard.append("mqm_combined: contains the S3 'valid variation' step that failed Stage 1")

# 4 no held-out text
held = rj(os.path.join(D, "heldout_setA.jsonl")) + rj(os.path.join(D, "heldout_setB.jsonl"))
hp = rj(os.path.join(D, "heldout_pairs.jsonl"))
texts = {r["candidate"] for r in held} | {p["a_text"] for p in hp} | {p["b_text"] for p in hp}
for pid, (tpl, *_r) in B5_PROMPTS.items():
    for t in texts:
        if len(t) >= 6 and t in tpl:
            hard.append(f"{pid}: contains held-out text '{t[:20]}…'")

# 5 parser
r = parse("mqm", '{"errors": [{"text": "每年", "type": "Mistranslation", "severity": "major"}]}')
if r["parse_status"] == "malformed" or r["score"] != 95:
    hard.append("parser round-trip for C failed")

# ------------------------------------------------------------------ review file
md = ["# Task B · Step B5 — new prompts (combined prompt C + rewordings)", "",
      "C = S2 few-shot examples + S3 delimiters + 'quote only from the TRANSLATION' + S3 steps 1-3 as a one-line "
      "checklist. It does NOT contain S3 step 4 ('different wording is not an error'), which made the judge explain "
      "real errors away in Stage 1.", "",
      "Rewordings (wording-robustness test): same instructions, same few-shot examples (byte-identical), same JSON "
      "schema; rw1 = paraphrase in the same order, rw2 = paraphrase with a different order/framing. "
      "Baseline MQM rewording 1 = Task A's `mqm_reworded`.", ""]
for pid in ["mqm_combined"] + [x for v in REWORDINGS.values() for x in v]:
    md += [f"## `{pid}`", "", f"Output format: `{PROMPTS[pid][1]}` · rendered length ≈ {lengths.get(pid, len(PROMPTS[pid][0]))} characters",
           "", "```text", PROMPTS[pid][0], "```", ""]
open(os.path.join(ROOT, "taskB", "PROMPTS_B5_FOR_REVIEW.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")

print("TASK B · STEP B5 — PROMPT CHECKS")
print("=" * 50)
for pid, n in lengths.items():
    print(f"  {pid:18s} {PROMPTS[pid][1]:13s} {n:5d} chars (~{n // 3} tokens)")
print(f"\nHARD FAILURES: {len(hard)}")
for h in hard:
    print("  -", h)
print("\nWrote taskB/PROMPTS_B5_FOR_REVIEW.md")
sys.exit(1 if hard else 0)
