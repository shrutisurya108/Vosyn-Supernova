"""
A fake Ollama server for testing the harness without a GPU (used by Claude while building;
you do not need it on Colab). Returns canned answers in the shapes real judges produce,
including some deliberately messy ones.

  python tests/mock_ollama.py 11500 &
  OLLAMA_HOST_URL=http://127.0.0.1:11500 python run_experiments.py --smoke
"""
import json
import random
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, obj):
        b = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path == "/api/tags":
            self._send({"models": [{"name": "glm4:latest", "digest": "abc123def4567890"},
                                   {"name": "qwen2.5:7b", "digest": "fed987cba6543210"}]})
        elif self.path == "/api/version":
            self._send({"version": "mock-0.0"})
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        p, seed = body["prompt"], body["options"]["seed"]
        rng = random.Random(hash((p, seed, body["model"], body["options"]["temperature"])))
        time.sleep(0.005)
        roll = rng.random()
        if '"better"' in p:
            text = json.dumps({"better": rng.choice(["A", "B", "tie"])})
        elif '"accuracy"' in p:
            text = json.dumps({"accuracy": rng.randint(40, 100), "fluency": rng.randint(40, 100)})
        elif '"errors"' in p:
            errs = [{"text": "X", "type": "Mistranslation", "severity": rng.choice(["minor", "major", "Major"])}
                    for _ in range(rng.randint(0, 3))]
            obj = {"errors": errs}
            if '"analysis"' in p:
                obj = {"analysis": "ok", **obj}
            text = json.dumps(obj, ensure_ascii=False)
            if roll < 0.15:
                text = "Here is my evaluation:\n```json\n" + text + "\n```"
        else:
            hi = 5 if "1 to 5" in p else 10 if "1 to 10" in p else 100
            obj = {"score": rng.randint(max(1, hi // 2), hi)}
            if '"rationale"' in p:
                obj = {"rationale": "fine", **obj}
            text = json.dumps(obj)
        if roll > 0.95:
            text = "I think this translation is pretty good overall."   # malformed
        self._send({"response": text, "done": True, "done_reason": "stop",
                    "prompt_eval_count": len(p) // 3, "eval_count": len(text) // 2})


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
