"""
Task B runner — same engine as Task A (run_experiments.py): every finished call is saved at once,
restarts skip saved calls, and the run stops cleanly at the time budget.

  python taskB/run_taskb.py --check                          # Ollama up, both models present, GPU recorded
  python taskB/run_taskb.py --smoke                          # Step B3: 1 call per prompt per judge + Stage 1 time estimate
  python taskB/run_taskb.py --status --stage 1               # progress of each phase
  python taskB/run_taskb.py --run --stage 1 --budget 30m     # Step B4: continue Stage 1 for 30 minutes

Results go to results_taskB/<phase>.jsonl (Task A results/ is never touched).
"""
import argparse
import json
import os
import sys
import time
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "taskB"))

import run_experiments as RE  # noqa: E402  (Task A engine: run_job, execute, resolve_models, ...)
from judge.prompts import PROMPTS  # noqa: E402
from plan_taskb import RESULTS_TB, STAGES, load_data, stage_jobs  # noqa: E402

SMOKE_PROMPTS = ["flat", "mqm", "flat_rubric", "mqm_fewshot", "mqm_steps", "flat_accflu", "pairwise", "pairwise_tie"]


def rpath(phase):
    return os.path.join(RESULTS_TB, f"{phase}.jsonl")


def read(phase):
    rows = []
    if os.path.exists(rpath(phase)):
        for line in open(rpath(phase), encoding="utf-8"):
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return rows


def cmd_check():
    RE.RESULTS_DIR = RESULTS_TB          # environment record goes to results_taskB/environment.jsonl
    RE.cmd_check()
    print("   (Task B copy: results_taskB/environment.jsonl - the Task A results/ folder is not touched)")


def cmd_status(stage):
    plan = stage_jobs(stage)
    tot = done = 0
    nxt = None
    print(f"{'phase':16s} {'calls':>6s} {'done':>6s} {'%':>5s} {'malformed':>9s}")
    rows = []
    for p, jobs in plan.items():
        keys = {j["key"] for j in jobs}
        res = [r for r in read(p) if r.get("key") in keys]
        d = len({r["key"] for r in res})
        mal = sum(r["parse_status"] == "malformed" for r in res)
        mark = "✔" if d == len(jobs) else ("…" if d else " ")
        print(f"{p:16s} {len(jobs):6d} {d:6d} {100 * d / len(jobs):4.0f}% {mal:9d}  {mark}")
        rows.append(dict(phase=p, calls=len(jobs), done=d, malformed=mal))
        tot += len(jobs)
        done += d
        if nxt is None and d < len(jobs):
            nxt = p
    print(f"{'TOTAL':16s} {tot:6d} {done:6d} {100 * done / tot:4.0f}%")
    print(f"Next phase to run: {nxt or 'none - stage complete'}")
    json.dump({"stage": stage, "total": tot, "done": done, "next_phase": nxt, "phases": rows},
              open(os.path.join(RESULTS_TB, f"progress_stage{stage}.json"), "w"), indent=1)
    return nxt


def cmd_smoke():
    tags = RE.resolve_models()
    data = load_data()
    item = data["dev_A"][0]
    pair = data["dev_pairs"][0]
    # warm-up: load both models into GPU memory (not saved, not timed)
    for m in tags:
        RE.oc.generate(tags[m][0], "Say OK.", 0.0, 1, 8)
    jobs = []
    for m in tags:
        for pid in SMOKE_PROMPTS:
            if PROMPTS[pid][1].startswith("pairwise"):
                j = dict(item_id=pair["pair_id"], set="pairs", order="AB", source=pair["source_text"],
                         a=pair["a_text"], b=pair["b_text"])
            else:
                j = dict(item_id=item["item_id"], set="A", source=item["source_text"], mt=item["candidate"],
                         reference=item.get("reference"))
            j.update(phase="SMOKE_B", experiment="smoke", model=m, prompt_id=pid, temperature=0.0, run=0, seed=1000)
            j["key"] = f"SMOKE_B|{m}|{pid}"
            jobs.append(j)
    path = rpath("smoke")
    if os.path.exists(path):
        os.remove(path)
    print(f">> Smoke test: {len(jobs)} calls ({len(SMOKE_PROMPTS)} prompts x {len(tags)} judges), models already loaded.")
    t0 = time.time()
    RE.execute(jobs, tags, 1, time.time() + 3600, "smoke", path)
    rows = [json.loads(l) for l in open(path, encoding="utf-8")]
    print(f"\n{'judge':6s} {'prompt':14s} {'parse':10s} {'value':>8s} {'tries':>5s} {'secs':>6s} {'out tok':>7s} {'end':>6s}")
    for r in sorted(rows, key=lambda r: (r["model"], SMOKE_PROMPTS.index(r["prompt_id"]))):
        v = r.get("score") if r.get("score") is not None else r.get("better", "-")
        print(f"{r['model']:6s} {r['prompt_id']:14s} {r['parse_status']:10s} {str(v):>8s} {r['attempts']:5d} "
              f"{r['wall_seconds']:6.1f} {str(r['output_tokens']):>7s} {str(r['done_reason']):>6s}")
    ok = sum(r["parse_status"] != "malformed" for r in rows)
    print(f"\nParsed: {ok}/{len(rows)}   wall time {RE.fmt_secs(time.time() - t0)}")
    secs = {(r["model"], r["prompt_id"]): r["wall_seconds"] for r in rows}
    est = 0.0
    for p, js in stage_jobs("1", data).items():
        for j in js:
            est += secs.get((j["model"], j["prompt_id"]), 3.0)
    n = sum(len(v) for v in stage_jobs("1", data).values())
    print(f"Stage 1: {n} calls  ->  estimated run time ~{RE.fmt_secs(est)} "
          f"(from one call per prompt; long error lists take longer, so allow +30%)")
    json.dump({"parsed": ok, "calls": len(rows), "seconds": {f"{m}|{p}": s for (m, p), s in secs.items()},
               "stage1_calls": n, "stage1_estimated_seconds": est},
              open(os.path.join(RESULTS_TB, "smoke_summary.json"), "w"), indent=1)


def cmd_run(stage, budget, workers):
    tags = RE.resolve_models()
    plan = stage_jobs(stage)
    deadline = time.time() + budget
    snap = os.path.join(RESULTS_TB, "prompts_snapshot.json")
    if not os.path.exists(snap):
        json.dump({k: v[0] for k, v in PROMPTS.items()}, open(snap, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f">> Stage {stage}: budget {RE.fmt_secs(budget)}, {workers} worker(s)")
    for p, jobs in plan.items():
        done = {r.get("key") for r in read(p)}
        todo = [j for j in jobs if j["key"] not in done]
        if not todo:
            print(f"== {p}: already complete ({len(jobs)} calls)")
            continue
        if time.time() >= deadline - 30:
            break
        print(f"== {p}: {len(jobs) - len(todo)}/{len(jobs)} done, {len(todo)} to go")
        n, spc, early = RE.execute(todo, tags, workers, deadline, p, rpath(p))
        print(f"   {p}: +{n} calls this session" + (f", {spc:.1f} s/call" if spc else ""))
        if early:
            print(">> Time budget reached. Progress is saved - run the same command to continue.")
            break
    print()
    return cmd_status(stage)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    for f in ("--check", "--smoke", "--status", "--run"):
        g.add_argument(f, action="store_true")
    ap.add_argument("--stage", default="1", choices=list(STAGES))
    ap.add_argument("--budget", type=RE.parse_duration, default=RE.parse_duration("30m"))
    ap.add_argument("--workers", type=int, default=1)
    a = ap.parse_args()
    if a.check:
        cmd_check()
    elif a.smoke:
        cmd_smoke()
    elif a.status:
        cmd_status(a.stage)
    else:
        try:
            cmd_run(a.stage, a.budget, a.workers)
        except RuntimeError as e:
            print(f"\n!! Stopped: {e}\n   Saved calls are kept. Re-run the setup cell, then the same command.")
            cmd_status(a.stage)
            sys.exit(1)
        except KeyboardInterrupt:
            print("\n!! Interrupted. Saved calls are kept; run the same command to continue.")
            sys.exit(1)


if __name__ == "__main__":
    main()
