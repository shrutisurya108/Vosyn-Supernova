#!/usr/bin/env bash
# Mac quickstart — no virtualenv, run directly with your system python3.
#
# Usage:
#   chmod +x run_mac_quickstart.sh
#   ./run_mac_quickstart.sh
#
# What this does:
#   1. Installs Python deps for your user (no venv, no bitsandbytes — that's
#      CUDA-only and will not install/work on macOS).
#   2. Runs a dry run (tiny data, 1-2 steps) to validate the full pipeline
#      wiring cheaply before committing to a real run.
#   3. Runs the full pipeline against the gold dataset in data/raw/.
#
# Requires: gold_en_cmn.jsonl already placed at data/raw/gold_en_cmn.jsonl
# (it ships inside this zip already).

set -e

echo "=== Installing dependencies (user site, no venv) ==="
pip3 install --user -r requirements.txt

echo
echo "=== Checking device availability ==="
python3 -c "
import torch
print('cuda available:', torch.cuda.is_available())
print('mps available:', getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available())
"

RUN_NAME="en-zh-candidate-mac-01"
SEED=42

echo
echo "=== Dry run (validates pipeline wiring) ==="
python3 run_pipeline.py --config config/default_config.yaml \
  --set run.run_name="$RUN_NAME" \
  --set run.seed=$SEED \
  --set run.dry_run=true

echo
echo "Dry run complete. Inspect outputs/$RUN_NAME/ if you want to check it before continuing."
read -p "Proceed with the FULL run now? [y/N] " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
  echo "Stopping after dry run. Re-run this script (or run_pipeline.py directly) when ready."
  exit 0
fi

echo
echo "=== Full run ==="
python3 run_pipeline.py --config config/default_config.yaml \
  --set run.run_name="$RUN_NAME" \
  --set run.seed=$SEED \
  --set run.dry_run=false

echo
echo "=== Done. Candidate manifest: outputs/$RUN_NAME/candidate_manifest.json ==="
