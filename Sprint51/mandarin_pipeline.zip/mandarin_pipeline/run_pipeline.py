#!/usr/bin/env python
"""
End-to-end orchestrator for the English -> Mandarin fine-tuning pipeline.

Usage:
    python run_pipeline.py --config config/default_config.yaml
    python run_pipeline.py --config config/default_config.yaml --set run.dry_run=true
    python run_pipeline.py --config config/default_config.yaml --set model.method=qlora --set run.seed=7

Stages (each individually re-runnable via src/<stage>.py):
    1. data_prep      -> validated, versioned, hashed, disjoint splits
    2. hardware_check -> smoke test, decides lora/qlora
    3. train          -> fine-tunes, checkpoints, supports resume
    4. evaluate       -> loads checkpoint, generates translations, scores
    5. build_manifest -> writes candidate_manifest.json
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from utils import dump_config, load_config, setup_logging  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default_config.yaml")
    parser.add_argument("--set", dest="overrides", action="append", default=[],
                         help="Dotted-path override, e.g. --set training.seed=123")
    parser.add_argument("--dry_run", type=lambda s: s.lower() == "true", default=None,
                         help="Shortcut for --set run.dry_run=true/false")
    parser.add_argument("--skip", nargs="*", default=[],
                         choices=["data_prep", "hardware_check", "train", "evaluate", "manifest"],
                         help="Stages to skip (must have run previously in this output dir)")
    args = parser.parse_args()

    overrides = list(args.overrides)
    if args.dry_run is not None:
        overrides.append(f"run.dry_run={str(args.dry_run).lower()}")

    cfg = load_config(args.config, overrides)

    run_dir = Path(cfg["run"]["output_root"]) / cfg["run"]["run_name"]
    run_dir.mkdir(parents=True, exist_ok=True)
    dump_config(cfg, str(run_dir / "resolved_config.yaml"))

    logger = setup_logging("pipeline", cfg["logging"]["log_dir"], cfg["logging"]["level"])
    logger.info(f"=== Mandarin fine-tuning pipeline | run_name={cfg['run']['run_name']} "
                f"| dry_run={cfg['run']['dry_run']} ===")
    logger.info(f"Resolved config saved to {run_dir / 'resolved_config.yaml'}")

    if "data_prep" not in args.skip:
        from data_prep import prepare_data
        logger.info(">>> STAGE 1/5: data_prep")
        prepare_data(cfg)
    else:
        logger.info(">>> STAGE 1/5: data_prep [SKIPPED]")

    if "hardware_check" not in args.skip:
        from hardware_check import run_smoke_test
        logger.info(">>> STAGE 2/5: hardware_check")
        run_smoke_test(cfg)
    else:
        logger.info(">>> STAGE 2/5: hardware_check [SKIPPED]")

    if "train" not in args.skip:
        from train import run_training
        logger.info(">>> STAGE 3/5: train")
        run_training(cfg)
    else:
        logger.info(">>> STAGE 3/5: train [SKIPPED]")

    if "evaluate" not in args.skip:
        from evaluate import run_evaluation
        logger.info(">>> STAGE 4/5: evaluate")
        run_evaluation(cfg)
    else:
        logger.info(">>> STAGE 4/5: evaluate [SKIPPED]")

    if "manifest" not in args.skip:
        from build_manifest import build_manifest
        logger.info(">>> STAGE 5/5: build_manifest")
        manifest = build_manifest(cfg)
        logger.info(f"candidate_manifest.json written: {run_dir / cfg['manifest']['filename']}")
        logger.info(f"Candidate ID: {manifest['candidate_id']}")
    else:
        logger.info(">>> STAGE 5/5: build_manifest [SKIPPED]")

    logger.info("=== Pipeline complete ===")


if __name__ == "__main__":
    main()
