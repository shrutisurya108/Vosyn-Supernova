# Mandarin (EN→ZH) Reproducible Fine-Tuning Pipeline — Sprint 51, Task A

A reusable pipeline that prepares English→Mandarin data, runs a fine-tuning
experiment, and produces a loadable candidate checkpoint with a full
provenance manifest. **Cantonese is intentionally excluded.**

## Which dataset does this use?

By default, `data.source_type: gold_export` — this pipeline runs on
**`data/raw/gold_en_cmn.jsonl`**, the Sprint 50 judge-validation gold export
(English→Mandarin direction, 40 human-verified examples with reference
translations, MT hypotheses, MQM error spans, and human quality scores).
`gold_cmn_en.jsonl` (the reverse direction) is **not** used here — its
`reference_text` fields are all `null`, so it has no gold Mandarin target to
train or evaluate against.

Because this set is small (~40 examples), the `judge_calibration` split
specifically retains the full annotations (`mt_text`, `human_error_spans`,
`human_score`) — it's exactly the kind of data a judge-calibration step
needs. The other four splits get plain `{en, zh}` pairs for translation
fine-tuning/eval. See `config/default_config.yaml`'s `data:` section to
switch to a larger corpus (`source_type: hf_hub`, e.g. `Helsinki-NLP/opus-100`)
for a production-scale run instead.

## Can I run this for free on a MacBook Air?

**Yes**, for this small gold dataset. No paid compute, no virtualenv needed.

- **Apple Silicon (M1/M2/M3)**: PyTorch uses the `mps` backend automatically — real
  acceleration, still free.
- **Intel Mac**: falls back to plain CPU — slower per step, but with only
  ~24-32 training examples it still finishes in a reasonable time.
- **QLoRA does NOT work on Mac** (bitsandbytes, which QLoRA needs for 4-bit
  quantization, is CUDA-only). The hardware smoke test in this pipeline
  detects this and always recommends plain **LoRA** on Mac — you don't need
  to configure anything for this, it's automatic.
- `requirements.txt` deliberately excludes `bitsandbytes` so `pip install`
  doesn't fail on macOS. `requirements-cuda.txt` adds it back for Colab/Kaggle.

### Quickstart (Mac, no venv)

```bash
cd mandarin_pipeline
./run_mac_quickstart.sh
```

This installs deps for your user only (no venv), runs a cheap dry run to
validate the whole pipeline wires up correctly, asks for confirmation, then
runs the full pipeline. Or do it manually / step by step:

```bash
pip3 install --user -r requirements.txt
python3 run_pipeline.py --config config/default_config.yaml --set run.dry_run=true   # smoke test
python3 run_pipeline.py --config config/default_config.yaml --set run.dry_run=false  # full run
```

If your Mac is slow, low on RAM (8GB unified memory can get tight), or you
just want a GPU, use Colab instead — same code, same config, zero cost.

## Quickstart (Colab)

1. Open `notebooks/Mandarin_Pipeline_Colab.ipynb` in Google Colab.
2. Runtime → Change runtime type → **T4 GPU**.
3. Run the cells top to bottom — this includes a cell that prompts you to
   upload `gold_en_cmn.jsonl` into `data/raw/`. Install uses
   `requirements-cuda.txt` (includes `bitsandbytes` for QLoRA support, which
   only works with a CUDA GPU).
4. Do the **dry run** first (cheap, validates the whole pipeline), then flip
   `DRY_RUN` to `false` for the real run.

## Quickstart (Kaggle)

Same as local — Kaggle notebooks give you a CUDA GPU, so use
`requirements-cuda.txt`:

```bash
pip install -r requirements-cuda.txt
python run_pipeline.py --config config/default_config.yaml --set run.dry_run=true   # smoke test
python run_pipeline.py --config config/default_config.yaml --set run.dry_run=false  # full run
```

Every field is overridable from the CLI with `--set dotted.path=value`, e.g.:

```bash
python run_pipeline.py --config config/default_config.yaml \
  --set model.base_model=facebook/nllb-200-distilled-600M \
  --set model.method=auto \
  --set run.seed=123 \
  --set training.num_train_epochs=2
```

## Pipeline stages

| Stage | Script | What it does |
|---|---|---|
| 1. Data prep | `src/data_prep.py` | Loads EN-ZH pairs (HF Hub or local fallback), validates (length, dedup, langid heuristic), splits **deterministically and disjointly** by hash bucket into 5 sets, writes SHA256 hashes + `data_manifest.json` with a `data_version` fingerprint |
| 2. Hardware smoke test | `src/hardware_check.py` | Detects GPU/CPU, runs a tiny real forward+backward pass of the configured model, measures peak memory, and **decides LoRA vs QLoRA** (or flags infeasible) — written to `hardware_report.json` |
| 3. Train | `src/train.py` | Fine-tunes with PEFT (LoRA or QLoRA per the smoke test decision) on `fine_tune_train`/`fine_tune_val` only. Supports `--dry_run`, checkpointing (`save_steps`), and resume (`training.resume_from_checkpoint: auto`) |
| 4. Evaluate | `src/evaluate.py` | Loads the saved checkpoint fresh (base model + adapter), generates Mandarin translations, scores with chrF/BLEU against `prompt_validation` (never `sealed_test` — this is enforced in code) |
| 5. Manifest | `src/build_manifest.py` | Aggregates config (+hash), data version/hashes, hardware decision, training summary, checkpoint file hashes, eval results, git commit → `candidate_manifest.json` |

`run_pipeline.py` runs all five in order and supports `--skip <stage>...` to
re-run only part of the pipeline (useful after a Colab disconnect).

## Data splits — why five, and why disjoint

Per the acceptance criteria, fine-tuning data, judge-calibration data,
prompt-validation data, and the sealed final-test set must stay separate:

- **`fine_tune_train` / `fine_tune_val`** — used only by `train.py`.
- **`judge_calibration`** — reserved for calibrating an automatic/LLM judge
  against known-good references before trusting it to score candidates.
  Not read by `train.py` or the default `evaluate.py` flow.
- **`prompt_validation`** — used to validate/tune the inference prompt or
  generation settings (this is what `evaluate.py` uses by default for the
  demo translations in this deliverable).
- **`sealed_test`** — written once by `data_prep.py` and never read again by
  any other script in this repo. `evaluate.py` actively **raises an error**
  if you try to point `evaluation.eval_source` at it, so it can't be touched
  accidentally. It exists for a deliberate, separate final-evaluation step
  outside this pipeline.

Splitting is done by hashing each (source, target) pair's text into a
`[0, 100)` bucket (`utils.hash_bucket`) and assigning it based on configured
percentage ranges. This means: no example ever lands in two splits, the
split assignment is 100% reproducible from the data + config alone (no
separate assignment file to keep in sync), and changing the ratios in
config is enough to re-derive new splits.

## Method selection (LoRA vs QLoRA)

`model.method: "auto"` (default) defers to `hardware_check.py`'s smoke-test
decision, which is based on **actually loading the configured model and
running one forward+backward step**, not just assumptions:

- **CUDA GPU, free memory ≥ `qlora_memory_threshold_gb`** (default 16GB) → LoRA (fp16/bf16).
- **CUDA GPU, free memory < threshold** → QLoRA (4-bit, via `bitsandbytes`).
- **CUDA GPU, free memory < `min_free_gb_to_attempt_training`** → flagged
  infeasible; `train.py` refuses to proceed under `method: auto`.
- **Apple Silicon (MPS)** → always LoRA (fp32). QLoRA is never recommended
  here because `bitsandbytes` is CUDA-only and doesn't run on MPS.
- **CPU only** → always LoRA (fp32), with a warning that it will be slow.

`train.py` additionally hard-refuses `model.method: qlora` on any non-CUDA
device even if you force it explicitly, since it would fail regardless.

You can force a method (`model.method: lora` / `qlora`) — the smoke test
still runs and logs a clear warning if your override disagrees with its
recommendation, so the decision is always auditable in `hardware_report.json`.

## Defaults used (change via config)

- **Base model**: `facebook/nllb-200-distilled-600M` — a multilingual
  translation model that fits comfortably on a free-tier Colab T4 and
  supports LoRA on its attention projections. Swap `model.base_model` /
  `model.model_type` for any other seq2seq or causal HF model id.
- **Dataset**: `data/raw/gold_en_cmn.jsonl` (Sprint 50 gold export) via
  `data.source_type: gold_export` — see "Which dataset does this use?" above.
  Set `source_type: hf_hub` (e.g. `Helsinki-NLP/opus-100`, config `en-zh`) for
  a larger corpus, or `source_type: local_pairs` with a plain `.tsv`/`.jsonl`
  of `{en, zh}` pairs.
- **Validation filters**: drop empty/duplicate pairs, length bounds
  (`data.max_char_len` / `min_char_len`), and a lightweight heuristic
  language-ID sanity check (CJK-character ratio for Mandarin, Latin-letter
  ratio for English) to catch obviously mismatched pairs without requiring
  an extra langid model download.

## Configurable surface (acceptance criteria checklist)

All of the following are config fields (see `config/default_config.yaml`),
overridable via `--set`:

- ✅ model (`model.base_model`, `model.model_type`)
- ✅ dataset (`data.dataset_name`, `data.dataset_config`, `data.local_fallback_path`)
- ✅ language direction (`language.direction`, `src_lang`, `tgt_lang`)
- ✅ training method (`model.method`: auto/lora/qlora, resolved post-smoke-test)
- ✅ seed (`run.seed`)
- ✅ training settings (`training.*`: epochs, batch size, LR, etc.)
- ✅ output paths (`run.output_root`, `run.run_name`)
- ✅ dry run (`run.dry_run`)

## Outputs per run

```
outputs/<run_name>/
  resolved_config.yaml         # exact config used, with all overrides applied
  data/
    fine_tune_train.jsonl
    fine_tune_val.jsonl
    judge_calibration.jsonl
    prompt_validation.jsonl
    sealed_test.jsonl          # never read again after this point
    data_manifest.json         # data_version + per-split SHA256 hashes
  hardware_report.json         # smoke test results + lora/qlora decision
  checkpoints/                 # HF Trainer checkpoint-N/ dirs (for resume)
  final_checkpoint/             # final PEFT adapter + tokenizer (the "candidate")
  train_summary.json
  eval_report.json             # sample translations + chrF/BLEU score
  candidate_manifest.json      # <-- the required manifest deliverable
```

## Known limitations / honest notes (gold_export dataset specifically)

- With only ~40 total examples, the deterministic hash-bucket splitting can
  land unevenly — e.g. one run produced 27/6/1/2/4 across the five splits.
  This is expected variance from hashing at small N, not a bug: hashing
  trades "guaranteed exact percentages" for "no separate assignment file
  needed and fully reproducible from the data alone." With `judge_calibration`
  or `prompt_validation` landing at only 1-2 examples, treat this candidate
  run as a **pipeline validation**, not a statistically meaningful eval — for
  a real production candidate, either combine this gold set with a larger
  corpus (fine-tune on the corpus, reserve the full gold set for calibration/
  validation/sealed-test) or gather more gold-annotated examples.
- `gold_cmn_en.jsonl` (Mandarin→English) is not used anywhere in this
  pipeline's default configuration — it has no `reference_text`, so it isn't
  usable as a training/eval target for this direction. It's still copied
  into `data/raw/` for completeness/provenance, in case a future Cantonese-
  or reverse-direction task needs it.

## Known limitations / honest notes (general)

- This code was authored and unit-tested for its **non-GPU logic**
  (config overrides, hashing, deterministic disjoint splitting,
  reproducibility, manifest assembly, the sealed-test guard rail) in an
  environment without GPU or Hugging Face Hub access. The actual
  fine-tuning stage (`train.py`) and generation stage (`evaluate.py`) need
  to be executed in Colab/Kaggle/local GPU to produce the real checkpoint —
  do the dry run first to confirm the full wiring before committing GPU time.
- The langid filter is a cheap heuristic (character-ratio based), not a
  trained classifier — adequate for catching gross mismatches, not a
  substitute for a dedicated langid model if you need stricter guarantees.
- `judge_calibration` data is split out and reserved, but this deliverable
  does not include an LLM-judge implementation — only automatic chrF/BLEU
  scoring against `prompt_validation`. Wiring an LLM judge calibrated
  against `judge_calibration` is a natural next step and the split is
  already in place for it.

## Submission checklist

- [ ] Tested code — this repo (`src/`, `run_pipeline.py`)
- [ ] Configurations — `config/default_config.yaml` + `resolved_config.yaml` per run
- [ ] Manifests — `outputs/<run_name>/candidate_manifest.json`
- [ ] Logs — `outputs/<run_name>/logs/*.log`
- [ ] Report — this README + `reports/` (add run-specific notes here)
- [ ] Working notebook — `notebooks/Mandarin_Pipeline_Colab.ipynb`
- [ ] Mac quickstart (alternative to Colab) — `run_mac_quickstart.sh`
- [ ] Gold dataset snapshot — `data/raw/gold_en_cmn.jsonl` (+ `gold_cmn_en.jsonl` for provenance)
- [ ] Exact GitHub link — **fill in after pushing**: `<paste commit URL here>`
- [ ] Loadable candidate / download path — **fill in after a full run**:
      `outputs/<run_name>/final_checkpoint` (and/or your HF Hub / Drive link)
