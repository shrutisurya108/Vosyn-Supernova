"""
Data preparation for the English -> Mandarin pipeline.

Responsibilities (per Sprint 51 Task A acceptance criteria):
  - Load raw parallel data (HF Hub dataset, or a local .tsv/.jsonl fallback)
  - Validate (drop empty/too-long/too-short, dedup exact duplicates,
    lightweight language-identity sanity filter)
  - Split deterministically into FIVE disjoint sets using a hash-bucket
    scheme (no shared examples, fully reproducible from the source text
    + configured ratios, no separate "assignment file" needed):
        fine_tune_train, fine_tune_val, judge_calibration,
        prompt_validation, sealed_test
  - Version the resulting files (content hash) and write data_manifest.json

The sealed_test split is written but this pipeline never reads it again
after data_prep — it is intentionally not touched by train.py or evaluate.py.
"""
from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Iterator

from utils import hash_bucket, read_json, setup_logging, sha256_file, sha256_text, write_json

# crude CJK ratio check as a cheap language-id sanity filter (no extra model download required)
_CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]")
_LATIN_RE = re.compile(r"[A-Za-z]")


def _looks_like_mandarin(text: str, min_cjk_ratio: float = 0.3) -> bool:
    if not text:
        return False
    cjk = len(_CJK_RE.findall(text))
    return (cjk / max(len(text), 1)) >= min_cjk_ratio


def _looks_like_english(text: str, min_latin_ratio: float = 0.5) -> bool:
    if not text:
        return False
    latin = len(_LATIN_RE.findall(text))
    letters = sum(c.isalpha() for c in text)
    if letters == 0:
        return False
    return (latin / letters) >= min_latin_ratio


def _load_raw_records(cfg: dict, logger) -> Iterator[dict]:
    """Yields dicts with at least {'en': ..., 'zh': ...}, optionally with extra
    judge-relevant fields (mt_text, human_error_spans, human_score, gold_id,
    provenance) when the source is a Sprint-50-style gold export. Source is
    chosen by data.source_type: 'gold_export' | 'hf_hub' | 'local_pairs'.
    """
    source_type = cfg["data"].get("source_type", "hf_hub")

    if source_type == "gold_export":
        gold_path = cfg["data"]["gold_file"]
        expected_direction = "en_to_cmn" if cfg["language"]["direction"] == "en-zh" else "cmn_to_en"
        logger.info(f"Loading gold export: {gold_path} (filtering direction={expected_direction})")
        yield from _load_gold_export(gold_path, expected_direction, logger)
        return

    if source_type == "local_pairs":
        local_fallback = cfg["data"]["local_fallback_path"]
        logger.info(f"Using local pairs data source: {local_fallback}")
        for en, zh in _load_local_pairs(local_fallback):
            yield {"en": en, "zh": zh}
        return

    # default: hf_hub, with local_pairs fallback on failure
    local_fallback = cfg["data"].get("local_fallback_path")
    try:
        from datasets import load_dataset

        name = cfg["data"]["dataset_name"]
        config_name = cfg["data"]["dataset_config"]
        split = cfg["data"]["source_split"]
        logger.info(f"Loading {name}/{config_name} split={split} from Hugging Face Hub")
        ds = load_dataset(name, config_name, split=split)
        for row in ds:
            translation = row.get("translation", row)
            yield {"en": translation.get("en", ""), "zh": translation.get("zh", "")}
    except Exception as e:
        if not local_fallback:
            raise RuntimeError(
                "Could not load dataset from Hugging Face Hub and no "
                "data.local_fallback_path was configured. "
                f"Original error: {e}"
            ) from e
        logger.warning(f"HF Hub load failed ({e}); falling back to local_fallback_path.")
        for en, zh in _load_local_pairs(local_fallback):
            yield {"en": en, "zh": zh}


def _load_gold_export(path: str, expected_direction: str, logger) -> Iterator[dict]:
    """Loads a Sprint-50-style gold judge-validation export (MQM-annotated).

    Expected schema per line: gold_id, direction, source_text, mt_text,
    reference_text, human_error_spans, human_score, provenance.
    `source_text`/`reference_text` become the clean (en, zh) training pair;
    everything else is preserved as extra metadata for the judge_calibration split.
    """
    import json

    skipped_wrong_direction = 0
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if obj.get("direction") != expected_direction:
                skipped_wrong_direction += 1
                continue
            src = obj.get("source_text", "")
            ref = obj.get("reference_text")
            if not ref:
                # no gold reference translation -> unusable as a training/eval target
                continue
            record = {
                "en": src if expected_direction == "en_to_cmn" else ref,
                "zh": ref if expected_direction == "en_to_cmn" else src,
                "gold_id": obj.get("gold_id"),
                "mt_text": obj.get("mt_text"),
                "human_error_spans": obj.get("human_error_spans", []),
                "human_score": obj.get("human_score"),
                "provenance": obj.get("provenance"),
            }
            yield record

    if skipped_wrong_direction:
        logger.info(
            f"Skipped {skipped_wrong_direction} gold records with a direction "
            f"other than '{expected_direction}'."
        )


def _load_local_pairs(path: str) -> Iterator[tuple[str, str]]:
    p = Path(path)
    if p.suffix == ".tsv":
        with open(p, "r", encoding="utf-8") as f:
            reader = csv.reader(f, delimiter="\t")
            for row in reader:
                if len(row) >= 2:
                    yield row[0], row[1]
    elif p.suffix in (".jsonl", ".json"):
        import json

        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                yield obj.get("en", obj.get("source", "")), obj.get("zh", obj.get("target", ""))
    else:
        raise ValueError(f"Unsupported local_fallback_path extension: {p.suffix}")


def prepare_data(cfg: dict) -> dict:
    """Runs the full data prep stage. Returns the data_manifest dict and also
    writes it to disk alongside the split files.
    """
    logger = setup_logging("data_prep", cfg["logging"]["log_dir"], cfg["logging"]["level"])

    dcfg = cfg["data"]
    run_dir = Path(cfg["run"]["output_root"]) / cfg["run"]["run_name"]
    is_dry_run = cfg["run"]["dry_run"]

    max_examples = 200 if is_dry_run else dcfg["max_examples"]
    max_char_len = dcfg["max_char_len"]
    min_char_len = dcfg["min_char_len"]

    seen = set()
    kept, dropped_empty, dropped_len, dropped_dup, dropped_langid = 0, 0, 0, 0, 0

    buckets: dict[str, list[dict]] = {
        "fine_tune_train": [],
        "fine_tune_val": [],
        "judge_calibration": [],
        "prompt_validation": [],
        "sealed_test": [],
    }
    ratios = dcfg["split_ratios"]
    assert sum(ratios.values()) == 100, "split_ratios must sum to 100"
    # build cumulative bucket ranges deterministically from config order
    ranges = []
    cursor = 0
    for name, pct in ratios.items():
        ranges.append((name, cursor, cursor + pct))
        cursor += pct

    def assign_split(en: str, zh: str) -> str:
        b = hash_bucket(en + "|||" + zh, num_buckets=100)
        for name, lo, hi in ranges:
            if lo <= b < hi:
                return name
        return ranges[-1][0]

    logger.info(f"Starting data prep (dry_run={is_dry_run}, max_examples={max_examples})")

    for record in _load_raw_records(cfg, logger):
        if kept + dropped_empty + dropped_len + dropped_dup + dropped_langid >= max_examples * 3:
            # safety valve so a low-yield source doesn't loop forever
            break
        if kept >= max_examples:
            break

        en, zh = (record.get("en") or "").strip(), (record.get("zh") or "").strip()

        if not en or not zh:
            dropped_empty += 1
            continue
        if not (min_char_len <= len(en) <= max_char_len) or not (
            min_char_len <= len(zh) <= max_char_len
        ):
            dropped_len += 1
            continue
        if dcfg["dedup"]:
            key = sha256_text(en + "|||" + zh)
            if key in seen:
                dropped_dup += 1
                continue
            seen.add(key)
        if not (_looks_like_english(en) and _looks_like_mandarin(zh)):
            dropped_langid += 1
            continue

        record["en"], record["zh"] = en, zh
        split_name = assign_split(en, zh)
        buckets[split_name].append(record)
        kept += 1

    logger.info(
        f"Filtering done: kept={kept} dropped_empty={dropped_empty} "
        f"dropped_len={dropped_len} dropped_dup={dropped_dup} dropped_langid={dropped_langid}"
    )
    for name, examples in buckets.items():
        logger.info(f"  split {name}: {len(examples)} examples")

    # write split files + collect hashes
    data_dir = run_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    file_hashes = {}
    counts = {}
    import json as _json

    judge_fields = ["en", "zh", "gold_id", "mt_text", "human_error_spans", "human_score", "provenance"]
    for name, examples in buckets.items():
        out_path = data_dir / f"{name}.jsonl"
        with open(out_path, "w", encoding="utf-8") as f:
            for record in examples:
                if name == "judge_calibration" and any(k in record for k in judge_fields[2:]):
                    row = {k: record.get(k) for k in judge_fields if record.get(k) is not None or k in ("en", "zh")}
                else:
                    row = {"en": record["en"], "zh": record["zh"]}
                f.write(_json.dumps(row, ensure_ascii=False) + "\n")
        file_hashes[name] = sha256_file(str(out_path))
        counts[name] = len(examples)

    source_type = dcfg.get("source_type", "hf_hub")
    if source_type == "gold_export":
        dataset_name_for_manifest = dcfg["gold_file"]
    elif dcfg.get("local_fallback_path"):
        dataset_name_for_manifest = dcfg["local_fallback_path"]
    else:
        dataset_name_for_manifest = dcfg["dataset_name"]

    manifest_body = {
        "source_type": source_type,
        "dataset_name": dataset_name_for_manifest,
        "dataset_config": dcfg.get("dataset_config"),
        "language_direction": cfg["language"]["direction"],
        "filters": {
            "max_char_len": max_char_len,
            "min_char_len": min_char_len,
            "dedup": dcfg["dedup"],
            "langid_heuristic": True,
        },
        "split_ratios": ratios,
        "counts": counts,
        "sha256": file_hashes,
        "dry_run": is_dry_run,
    }
    # data_version = hash of the manifest body itself -> reproducible fingerprint
    data_version = sha256_text(_json.dumps(manifest_body, sort_keys=True, ensure_ascii=False))[:16]
    manifest = {"data_version": data_version, **manifest_body}

    manifest_path = data_dir / "data_manifest.json"
    write_json(manifest, str(manifest_path))
    logger.info(f"Wrote data manifest: {manifest_path} (data_version={data_version})")
    logger.info(
        "NOTE: 'sealed_test' split is written to disk but must not be read again "
        "by train.py or evaluate.py in this pipeline."
    )

    return manifest


if __name__ == "__main__":
    import argparse
    import sys

    sys.path.insert(0, str(Path(__file__).parent))
    from utils import load_config

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default_config.yaml")
    parser.add_argument("--set", dest="overrides", action="append", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.overrides)
    prepare_data(cfg)
