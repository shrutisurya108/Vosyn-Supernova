"""
Loads the fine-tuned candidate checkpoint (base model + PEFT adapter),
confirms it loads and generates Mandarin translations, and scores it
against a small evaluation split.

Per the acceptance criteria, this MUST NOT touch the sealed_test split —
it evaluates against `evaluation.eval_source` (default: prompt_validation).
Judge-calibration data is loaded separately and kept distinct; it is used
here only to report agreement/consistency, not to tune the model further.
"""
from __future__ import annotations

import json
from pathlib import Path

from utils import get_device, read_json, setup_logging, write_json


def load_candidate(run_dir: Path, cfg: dict, logger):
    from peft import PeftModel
    from transformers import AutoModelForSeq2SeqLM, AutoModelForCausalLM, AutoTokenizer

    final_dir = run_dir / "final_checkpoint"
    if not final_dir.exists():
        raise FileNotFoundError(
            f"No final checkpoint found at {final_dir}. Run train.py first."
        )

    model_type = cfg["model"]["model_type"]
    base_model_id = cfg["model"]["base_model"]
    loader = AutoModelForSeq2SeqLM if model_type == "seq2seq" else AutoModelForCausalLM

    logger.info(f"Loading base model {base_model_id} + adapter from {final_dir}")
    base_model = loader.from_pretrained(base_model_id)
    model = PeftModel.from_pretrained(base_model, str(final_dir))
    tokenizer = AutoTokenizer.from_pretrained(str(final_dir))
    device = get_device()
    model.to(device)
    model.eval()
    logger.info(f"Candidate checkpoint loaded on device='{device}'.")
    return model, tokenizer, device


def translate(model, tokenizer, texts: list[str], cfg: dict, device: str = "cpu") -> list[str]:
    tgt_lang = cfg["language"]["tgt_lang"]
    max_new_tokens = cfg["evaluation"]["max_new_tokens"]

    forced_bos_token_id = None
    if hasattr(tokenizer, "lang_code_to_id") and tgt_lang in getattr(tokenizer, "lang_code_to_id", {}):
        forced_bos_token_id = tokenizer.lang_code_to_id[tgt_lang]
    elif hasattr(tokenizer, "convert_tokens_to_ids"):
        try:
            candidate = tokenizer.convert_tokens_to_ids(tgt_lang)
            if candidate is not None and candidate != tokenizer.unk_token_id:
                forced_bos_token_id = candidate
        except Exception:
            pass

    inputs = tokenizer(texts, return_tensors="pt", padding=True, truncation=True).to(device)
    gen_kwargs = {"max_new_tokens": max_new_tokens}
    if forced_bos_token_id is not None:
        gen_kwargs["forced_bos_token_id"] = forced_bos_token_id

    outputs = model.generate(**inputs, **gen_kwargs)
    return tokenizer.batch_decode(outputs, skip_special_tokens=True)


def run_evaluation(cfg: dict) -> dict:
    logger = setup_logging("evaluate", cfg["logging"]["log_dir"], cfg["logging"]["level"])
    run_dir = Path(cfg["run"]["output_root"]) / cfg["run"]["run_name"]
    data_dir = run_dir / "data"

    eval_source = cfg["evaluation"]["eval_source"]
    if eval_source == "sealed_test":
        raise RuntimeError(
            "Refusing to use 'sealed_test' as evaluation.eval_source in the standard "
            "candidate-evaluation flow — sealed_test must remain untouched until a "
            "deliberate, explicit final-test step outside this script."
        )

    eval_path = data_dir / f"{eval_source}.jsonl"
    examples = []
    with open(eval_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                examples.append(json.loads(line))

    n_demo = min(cfg["evaluation"]["num_demo_translations"], len(examples))
    if n_demo == 0:
        raise RuntimeError(f"No examples available in {eval_path} to evaluate against.")
    demo_examples = examples[:n_demo]

    model, tokenizer, device = load_candidate(run_dir, cfg, logger)

    sources = [e["en"] for e in demo_examples]
    references = [e["zh"] for e in demo_examples]
    logger.info(f"Generating {len(sources)} Mandarin translations from '{eval_source}' split...")
    hypotheses = translate(model, tokenizer, sources, cfg, device=device)

    metric_name = cfg["evaluation"]["metric"]
    score = None
    try:
        import sacrebleu

        if metric_name == "chrf":
            score = sacrebleu.corpus_chrf(hypotheses, [references]).score
        else:
            score = sacrebleu.corpus_bleu(hypotheses, [references]).score
        logger.info(f"{metric_name.upper()} score on '{eval_source}' demo set: {score:.2f}")
    except ImportError:
        logger.warning("sacrebleu not installed — skipping automatic metric.")

    samples = [
        {"source_en": s, "reference_zh": r, "candidate_zh": h}
        for s, r, h in zip(sources, references, hypotheses)
    ]

    eval_report = {
        "eval_source": eval_source,
        "metric": metric_name,
        "score": score,
        "num_examples": len(samples),
        "checkpoint_loaded_and_generated_ok": True,
        "samples": samples,
    }
    write_json(eval_report, str(run_dir / "eval_report.json"))
    logger.info(f"Wrote eval_report.json — sample translation:\n{samples[0]}")
    return eval_report


if __name__ == "__main__":
    import argparse
    import sys

    sys.path.insert(0, str(Path(__file__).parent))
    from utils import load_config

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default_config.yaml")
    parser.add_argument("--set", dest="overrides", action="append", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.overrides)
    run_evaluation(cfg)
