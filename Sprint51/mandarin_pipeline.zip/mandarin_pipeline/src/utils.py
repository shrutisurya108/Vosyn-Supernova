"""
Shared utilities for the Mandarin fine-tuning pipeline.

- Config loading (YAML) with dotted-path CLI overrides (--set a.b.c=value)
- Deterministic seeding
- SHA256 hashing for files and text (used for data versioning)
- Logging setup (console + file)
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
def load_config(config_path: str, overrides: list[str] | None = None) -> dict:
    """Load a YAML config and apply dotted-path overrides like 'training.seed=123'.

    Value parsing tries, in order: int, float, bool, null, raw string.
    """
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    for item in overrides or []:
        if "=" not in item:
            raise ValueError(f"--set override must be 'dotted.path=value', got: {item}")
        path, raw_val = item.split("=", 1)
        _set_dotted(cfg, path.strip(), _parse_value(raw_val.strip()))

    return cfg


def _parse_value(raw: str) -> Any:
    if raw.lower() in ("null", "none", "~"):
        return None
    if raw.lower() in ("true", "false"):
        return raw.lower() == "true"
    try:
        if "." in raw or "e" in raw.lower():
            return float(raw)
        return int(raw)
    except ValueError:
        pass
    # allow JSON lists/dicts, e.g. --set lora.target_modules='["q_proj","v_proj"]'
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return raw


def _set_dotted(cfg: dict, dotted_path: str, value: Any) -> None:
    keys = dotted_path.split(".")
    node = cfg
    for k in keys[:-1]:
        if k not in node or not isinstance(node[k], dict):
            node[k] = {}
        node = node[k]
    node[keys[-1]] = value


def dump_config(cfg: dict, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)


def config_hash(cfg: dict) -> str:
    """Stable hash of a config dict, independent of key ordering."""
    canonical = json.dumps(cfg, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------- #
# Hashing (data versioning)
# --------------------------------------------------------------------------- #
def sha256_file(path: str, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def hash_bucket(text: str, num_buckets: int = 100) -> int:
    """Deterministic bucket in [0, num_buckets) derived from a stable hash of text.
    Used to split data reproducibly without needing to store split assignments.
    """
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return int(digest, 16) % num_buckets


# --------------------------------------------------------------------------- #
# Device detection (CUDA / Apple Silicon MPS / CPU)
# --------------------------------------------------------------------------- #
def get_device() -> str:
    """Returns 'cuda', 'mps' (Apple Silicon), or 'cpu' — in that preference order.
    Centralized here so every stage (smoke test, train, evaluate) agrees on
    what hardware is actually available.
    """
    try:
        import torch

        if torch.cuda.is_available():
            return "cuda"
        if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            return "mps"
    except ImportError:
        pass
    return "cpu"


# --------------------------------------------------------------------------- #
# Seeding
# --------------------------------------------------------------------------- #
def set_seed(seed: int) -> None:
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import numpy as np

        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
def setup_logging(name: str, log_dir: str | None = None, level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.propagate = False
    if logger.handlers:
        return logger  # already configured (avoid duplicate handlers on re-import)

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    if log_dir:
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(Path(log_dir) / f"{name}.log", encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    return logger


def write_json(obj: Any, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, sort_keys=False)


def read_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_git_commit() -> str:
    """Best-effort current git commit hash; 'unknown' if not in a repo (e.g. fresh Colab)."""
    import subprocess

    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL
        )
        return out.decode().strip()
    except Exception:
        return "unknown-not-a-git-repo"


def deep_merge(base: dict, override: dict) -> dict:
    result = deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = deep_merge(result[k], v)
        else:
            result[k] = v
    return result
