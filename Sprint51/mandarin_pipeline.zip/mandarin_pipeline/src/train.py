"""
Fine-tuning entry point.

- Reads the method chosen by hardware_check.py's report (or an explicit
  config override) and applies LoRA or QLoRA accordingly via PEFT.
- Trains ONLY on the fine_tune_train / fine_tune_val splits produced by
  data_prep.py. judge_calibration, prompt_validation and sealed_test are
  never touched here.
- Supports --dry_run (tiny subset, 1-2 steps, verifies save/load works),
  checkpointing (HF Trainer save_steps) and resume (resume_from_checkpoint).
"""
from __future__ import annotations

import glob
import os
from pathlib import Path

from utils import get_device, read_json, set_seed, setup_logging, write_json


def _find_latest_checkpoint(output_dir: str) -> str | None:
    ckpts = sorted(
        glob.glob(os.path.join(output_dir, "checkpoint-*")),
        key=lambda p: int(p.rsplit("-", 1)[-1]),
    )
    return ckpts[-1] if ckpts else None


def _resolve_method(cfg: dict, run_dir: Path, logger) -> str:
    configured = cfg["model"]["method"]
    hw_report_path = run_dir / "hardware_report.json"

    if not hw_report_path.exists():
        raise RuntimeError(
            "hardware_report.json not found. The training method must be selected "
            "after a hardware smoke test — run hardware_check.py (or run_pipeline.py) first."
        )
    hw_report = read_json(str(hw_report_path))
    recommended = hw_report.get("decision")
    device = hw_report.get("device", "cpu")

    if configured == "qlora" and device != "cuda":
        raise RuntimeError(
            f"model.method='qlora' was requested but the smoke test found device='{device}'. "
            "QLoRA needs bitsandbytes, which is CUDA-only — it cannot run on MPS or CPU. "
            "Use model.method=lora (or auto) on this machine, or run on a CUDA GPU (Colab/Kaggle)."
        )

    if recommended == "infeasible" and configured == "auto":
        raise RuntimeError(
            "Hardware smoke test determined training is infeasible on this machine "
            f"({hw_report.get('decision_reason')}). Use a larger GPU/Colab/Kaggle runtime, "
            "or reduce model size / force a method override in config if you accept the risk."
        )

    if configured == "auto":
        method = recommended
        logger.info(f"Method 'auto' -> using smoke-test recommendation: {method}")
    else:
        method = configured
        if method != recommended:
            logger.warning(
                f"Config forces method='{method}', which DIFFERS from the smoke-test "
                f"recommendation ('{recommended}': {hw_report.get('decision_reason')}). "
                "Proceeding with the explicit override."
            )
        else:
            logger.info(f"Config method='{method}' matches smoke-test recommendation.")
    return method


def _load_model_and_tokenizer(cfg: dict, method: str, logger):
    import torch
    from transformers import AutoModelForSeq2SeqLM, AutoModelForCausalLM, AutoTokenizer
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

    model_id = cfg["model"]["base_model"]
    model_type = cfg["model"]["model_type"]
    loader = AutoModelForSeq2SeqLM if model_type == "seq2seq" else AutoModelForCausalLM

    tokenizer = AutoTokenizer.from_pretrained(model_id)

    device = get_device()
    quant_kwargs = {}
    if method == "qlora":
        if device != "cuda":
            raise RuntimeError("QLoRA requires a CUDA GPU (bitsandbytes has no MPS/CPU support).")
        from transformers import BitsAndBytesConfig

        qcfg = cfg["qlora"]
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type=qcfg["quant_type"],
            bnb_4bit_use_double_quant=qcfg["double_quant"],
            bnb_4bit_compute_dtype=getattr(torch, qcfg["compute_dtype"]),
        )
        quant_kwargs["quantization_config"] = bnb_config
        logger.info("Loading base model in 4-bit (QLoRA) mode on CUDA.")
    elif device == "cuda":
        quant_kwargs["torch_dtype"] = torch.bfloat16 if cfg["training"].get("bf16") else torch.float16
        logger.info("Loading base model in fp16/bf16 (LoRA) mode on CUDA.")
    else:
        # fp16 is unreliable for training on MPS and pointless on CPU; use fp32 there.
        quant_kwargs["torch_dtype"] = torch.float32
        logger.info(f"Loading base model in fp32 (LoRA) mode on device='{device}'.")

    model = loader.from_pretrained(model_id, **quant_kwargs)

    if method == "qlora":
        model = prepare_model_for_kbit_training(model)
    elif device != "cuda":
        model.to(device)

    lcfg = cfg["lora"]
    peft_config = LoraConfig(
        r=lcfg["r"],
        lora_alpha=lcfg["alpha"],
        lora_dropout=lcfg["dropout"],
        target_modules=lcfg["target_modules"],
        bias="none",
        task_type="SEQ_2_SEQ_LM" if model_type == "seq2seq" else "CAUSAL_LM",
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    return model, tokenizer


def run_training(cfg: dict) -> dict:
    logger = setup_logging("train", cfg["logging"]["log_dir"], cfg["logging"]["level"])
    set_seed(cfg["run"]["seed"])

    run_dir = Path(cfg["run"]["output_root"]) / cfg["run"]["run_name"]
    data_dir = run_dir / "data"
    checkpoint_dir = run_dir / "checkpoints"
    is_dry_run = cfg["run"]["dry_run"]

    data_manifest = read_json(str(data_dir / "data_manifest.json"))
    method = _resolve_method(cfg, run_dir, logger)

    from datasets import load_dataset

    train_path = data_dir / "fine_tune_train.jsonl"
    val_path = data_dir / "fine_tune_val.jsonl"
    raw = load_dataset(
        "json", data_files={"train": str(train_path), "validation": str(val_path)}
    )

    if is_dry_run:
        n = min(8, len(raw["train"]))
        raw["train"] = raw["train"].select(range(n))
        raw["validation"] = raw["validation"].select(range(min(4, len(raw["validation"]))))
        logger.info(f"[DRY RUN] Truncated to {n} train / {len(raw['validation'])} val examples.")

    model, tokenizer = _load_model_and_tokenizer(cfg, method, logger)

    src_lang = cfg["language"]["src_lang"]
    tgt_lang = cfg["language"]["tgt_lang"]
    if hasattr(tokenizer, "src_lang"):
        tokenizer.src_lang = src_lang
    max_len = cfg["data"]["max_char_len"]

    def preprocess(batch):
        # Modern API: tokenize source and target together via text_target=.
        # (as_target_tokenizer() is the legacy path some tokenizers still
        # support, kept below only as a fallback for older tokenizer classes.)
        try:
            return tokenizer(batch["en"], text_target=batch["zh"], truncation=True, max_length=max_len)
        except TypeError:
            model_inputs = tokenizer(batch["en"], truncation=True, max_length=max_len)
            if hasattr(tokenizer, "as_target_tokenizer"):
                with tokenizer.as_target_tokenizer():
                    labels = tokenizer(batch["zh"], truncation=True, max_length=max_len)
            else:
                labels = tokenizer(batch["zh"], truncation=True, max_length=max_len)
            model_inputs["labels"] = labels["input_ids"]
            return model_inputs

    tokenized = raw.map(preprocess, batched=True, remove_columns=["en", "zh"])

    from transformers import DataCollatorForSeq2Seq, Seq2SeqTrainer, Seq2SeqTrainingArguments
    import inspect as _inspect

    collator_sig = _inspect.signature(DataCollatorForSeq2Seq.__init__)
    if "processing_class" in collator_sig.parameters:
        collator = DataCollatorForSeq2Seq(processing_class=tokenizer, model=model)
    else:
        collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, model=model)

    tcfg = cfg["training"]
    max_steps = 2 if is_dry_run else -1

    desired_training_args = dict(
        output_dir=str(checkpoint_dir),
        num_train_epochs=tcfg["num_train_epochs"] if max_steps == -1 else 1,
        max_steps=max_steps,
        per_device_train_batch_size=tcfg["per_device_train_batch_size"],
        per_device_eval_batch_size=tcfg["per_device_eval_batch_size"],
        gradient_accumulation_steps=tcfg["gradient_accumulation_steps"],
        learning_rate=tcfg["learning_rate"],
        warmup_ratio=tcfg["warmup_ratio"],
        weight_decay=tcfg["weight_decay"],
        logging_dir=str(run_dir / "tb_logs"),
        logging_steps=1 if is_dry_run else tcfg["logging_steps"],
        eval_strategy="steps" if not is_dry_run else "no",
        eval_steps=tcfg["eval_steps"],
        save_steps=1 if is_dry_run else tcfg["save_steps"],
        save_total_limit=tcfg["save_total_limit"],
        max_grad_norm=tcfg["max_grad_norm"],
        fp16=tcfg["fp16"] and method != "qlora" and get_device() == "cuda",
        # Note: recent transformers/accelerate versions auto-detect and use the MPS
        # device on Apple Silicon without needing an explicit training-args flag.
        bf16=tcfg["bf16"],
        seed=cfg["run"]["seed"],
        predict_with_generate=False,
        report_to=[],
        remove_unused_columns=False,
    )

    # transformers' TrainingArguments surface drifts across versions (args get
    # renamed/removed). Filter to whatever this installed version actually
    # accepts rather than hardcoding an exact API, and log what got dropped so
    # it's visible instead of silently missing.
    accepted_params = set(_inspect.signature(Seq2SeqTrainingArguments.__init__).parameters)
    training_kwargs = {k: v for k, v in desired_training_args.items() if k in accepted_params}
    dropped = sorted(set(desired_training_args) - set(training_kwargs))
    if dropped:
        logger.warning(
            f"Seq2SeqTrainingArguments in this transformers version doesn't accept: "
            f"{dropped} — proceeding without them (check transformers changelog if "
            f"these matter, e.g. a renamed equivalent)."
        )

    training_args = Seq2SeqTrainingArguments(**training_kwargs)

    trainer_kwargs = dict(
        model=model,
        args=training_args,
        train_dataset=tokenized["train"],
        eval_dataset=tokenized["validation"],
        data_collator=collator,
    )
    # transformers renamed Trainer's `tokenizer=` kwarg to `processing_class=` in
    # newer versions; detect which this installed version expects so the code
    # doesn't break across Colab's auto-installed transformers version.
    import inspect

    sig = inspect.signature(Seq2SeqTrainer.__init__)
    if "processing_class" in sig.parameters:
        trainer_kwargs["processing_class"] = tokenizer
    else:
        trainer_kwargs["tokenizer"] = tokenizer

    trainer = Seq2SeqTrainer(**trainer_kwargs)

    resume_cfg = tcfg.get("resume_from_checkpoint")
    resume_path = None
    if resume_cfg == "auto":
        resume_path = _find_latest_checkpoint(str(checkpoint_dir))
        if resume_path:
            logger.info(f"Resuming from latest checkpoint: {resume_path}")
    elif resume_cfg:
        resume_path = resume_cfg
        logger.info(f"Resuming from configured checkpoint: {resume_path}")

    logger.info(f"Starting training (method={method}, dry_run={is_dry_run})...")
    try:
        trainer.train(resume_from_checkpoint=resume_path)
    except Exception:
        logger.exception("Training crashed — full traceback above.")
        raise

    final_dir = run_dir / "final_checkpoint"
    final_dir.mkdir(parents=True, exist_ok=True)
    trainer.save_model(str(final_dir))
    tokenizer.save_pretrained(str(final_dir))
    logger.info(f"Saved final adapter checkpoint to {final_dir}")

    train_summary = {
        "method": method,
        "base_model": cfg["model"]["base_model"],
        "data_version": data_manifest["data_version"],
        "dry_run": is_dry_run,
        "final_checkpoint_path": str(final_dir),
        "train_examples": len(tokenized["train"]),
        "val_examples": len(tokenized["validation"]),
    }
    write_json(train_summary, str(run_dir / "train_summary.json"))
    return train_summary


if __name__ == "__main__":
    import argparse
    import sys

    sys.path.insert(0, str(Path(__file__).parent))
    from utils import load_config

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default_config.yaml")
    parser.add_argument("--set", dest="overrides", action="append", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.overrides)
    run_training(cfg)
