"""
Hardware smoke test.

Per the acceptance criteria, the training METHOD must be selected only
after this smoke test runs — not hardcoded up front. This module:

  1. Detects available accelerator (CUDA GPU, else CPU) and free memory.
  2. Attempts a tiny forward+backward pass of the configured base model
     (a handful of dummy examples, 1 optimizer step) to (a) confirm the
     model actually loads/trains in this environment and (b) measure
     peak memory used.
  3. Applies a simple, documented decision rule to choose "lora" or
     "qlora" (or raises an actionable error if even that is infeasible).
  4. Writes hardware_report.json with everything measured + the decision,
     so the choice is auditable, not just asserted.

If cfg.model.method is set to something other than "auto", the smoke
test still runs (for the report/log) but the explicit override wins —
this is logged clearly as a deviation from the smoke-test recommendation.
"""
from __future__ import annotations

from pathlib import Path

from utils import get_device, setup_logging, write_json


def _bytes_to_gb(x: float) -> float:
    return round(x / (1024 ** 3), 2)


def run_smoke_test(cfg: dict) -> dict:
    logger = setup_logging("hardware_check", cfg["logging"]["log_dir"], cfg["logging"]["level"])
    hc = cfg["hardware_check"]
    run_dir = Path(cfg["run"]["output_root"]) / cfg["run"]["run_name"]

    report = {
        "device": None,
        "cuda_available": False,
        "mps_available": False,
        "gpu_name": None,
        "total_gpu_gb": None,
        "free_gpu_gb": None,
        "forward_backward_ok": False,
        "peak_mem_gb_during_test": None,
        "error": None,
        "decision": None,
        "decision_reason": None,
    }

    try:
        import torch

        device = get_device()
        report["device"] = device
        report["cuda_available"] = device == "cuda"
        report["mps_available"] = device == "mps"

        if device == "cuda":
            props = torch.cuda.get_device_properties(0)
            free_bytes, total_bytes = torch.cuda.mem_get_info(0)
            report["gpu_name"] = props.name
            report["total_gpu_gb"] = _bytes_to_gb(total_bytes)
            report["free_gpu_gb"] = _bytes_to_gb(free_bytes)
            logger.info(
                f"CUDA GPU detected: {props.name} | total={report['total_gpu_gb']}GB "
                f"free={report['free_gpu_gb']}GB"
            )
        elif device == "mps":
            report["gpu_name"] = "Apple Silicon (MPS)"
            logger.info(
                "Apple Silicon MPS backend detected. Note: bitsandbytes (QLoRA's 4-bit "
                "quantization) is CUDA-only and does not work on MPS/CPU — QLoRA will "
                "never be recommended on this hardware, only plain LoRA."
            )
        else:
            logger.warning(
                "No CUDA GPU or Apple MPS backend detected. Will attempt CPU-only "
                "smoke test (slow) — expect real training to be slow too; keep the "
                "dataset and batch size small."
            )
    except ImportError:
        logger.error("torch not installed — cannot run hardware smoke test.")
        report["error"] = "torch not installed"
        write_json(report, str(run_dir / "hardware_report.json"))
        return report

    # --- tiny forward/backward smoke test on the actual configured model ---
    try:
        _tiny_train_step_smoke_test(cfg, report, logger)
    except Exception as e:  # noqa: BLE001 - we want to capture and report, not crash the pipeline
        logger.error(f"Smoke test forward/backward failed: {e}")
        report["error"] = str(e)

    # --- decision rule ---
    threshold = hc["qlora_memory_threshold_gb"]
    min_free = hc["min_free_gb_to_attempt_training"]

    if report["device"] == "mps":
        report["decision"] = "lora"
        report["decision_reason"] = (
            "Apple Silicon MPS backend detected. bitsandbytes (required for QLoRA's "
            "4-bit quantization) is CUDA-only and unavailable on MPS, so plain LoRA "
            "(fp32, since fp16 on MPS is often unstable for training) is used instead."
        )
    elif report["device"] == "cpu":
        report["decision"] = "lora"
        report["decision_reason"] = (
            "No GPU/MPS detected. QLoRA is unavailable without CUDA, so plain LoRA on "
            "CPU is used. This will be slow — keep dataset size, batch size, and epochs "
            "small, or move to Kaggle/Colab for a GPU."
        )
    elif report["free_gpu_gb"] is not None and report["free_gpu_gb"] < min_free:
        report["decision"] = "infeasible"
        report["decision_reason"] = (
            f"Only {report['free_gpu_gb']}GB free GPU memory, below the "
            f"min_free_gb_to_attempt_training threshold ({min_free}GB)."
        )
    elif report["free_gpu_gb"] is not None and report["free_gpu_gb"] < threshold:
        report["decision"] = "qlora"
        report["decision_reason"] = (
            f"Free GPU memory ({report['free_gpu_gb']}GB) is below the "
            f"qlora_memory_threshold_gb ({threshold}GB) -> use 4-bit QLoRA."
        )
    else:
        report["decision"] = "lora"
        report["decision_reason"] = (
            f"Free GPU memory ({report['free_gpu_gb']}GB) is at/above the "
            f"qlora_memory_threshold_gb ({threshold}GB) -> plain LoRA (fp16/bf16) is feasible."
        )

    logger.info(f"Smoke test decision: {report['decision']} — {report['decision_reason']}")

    write_json(report, str(run_dir / "hardware_report.json"))
    return report


def _tiny_train_step_smoke_test(cfg: dict, report: dict, logger) -> None:
    """Loads the actual configured base model, runs 1 forward+backward step on
    a couple of dummy sentence pairs, and records peak memory. Kept intentionally
    tiny and fast — this is a smoke test, not a benchmark.
    """
    import torch
    from transformers import AutoModelForSeq2SeqLM, AutoModelForCausalLM, AutoTokenizer

    model_id = cfg["model"]["base_model"]
    model_type = cfg["model"]["model_type"]

    logger.info(f"Loading {model_id} ({model_type}) for smoke test...")
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    loader = AutoModelForSeq2SeqLM if model_type == "seq2seq" else AutoModelForCausalLM
    device = report["device"]
    # fp16 only on CUDA; MPS training in fp16 is frequently unstable, CPU doesn't benefit from it
    dtype = torch.float16 if device == "cuda" else torch.float32
    model = loader.from_pretrained(model_id, torch_dtype=dtype)
    model.to(device)
    model.train()

    if device == "cuda":
        torch.cuda.reset_peak_memory_stats(0)

    dummy_src = ["This is a smoke test sentence.", "Hardware check before fine-tuning."]
    dummy_tgt = ["这是一个冒烟测试句子。", "微调前的硬件检查。"]

    enc = tokenizer(dummy_src, return_tensors="pt", padding=True, truncation=True).to(device)
    with tokenizer.as_target_tokenizer() if hasattr(tokenizer, "as_target_tokenizer") else _nullctx():
        labels = tokenizer(dummy_tgt, return_tensors="pt", padding=True, truncation=True).input_ids.to(device)

    if model_type == "seq2seq":
        out = model(**enc, labels=labels)
    else:
        out = model(**enc, labels=enc["input_ids"])

    loss = out.loss
    loss.backward()
    model.zero_grad(set_to_none=True)

    report["forward_backward_ok"] = True
    if device == "cuda":
        peak = torch.cuda.max_memory_allocated(0)
        report["peak_mem_gb_during_test"] = _bytes_to_gb(peak)
        logger.info(f"Smoke test peak GPU memory: {report['peak_mem_gb_during_test']}GB")

    del model
    if device == "cuda":
        torch.cuda.empty_cache()


class _nullctx:
    def __enter__(self):
        return None

    def __exit__(self, *a):
        return False


if __name__ == "__main__":
    import argparse
    import sys

    sys.path.insert(0, str(Path(__file__).parent))
    from utils import load_config

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default_config.yaml")
    parser.add_argument("--set", dest="overrides", action="append", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.overrides)
    run_smoke_test(cfg)
