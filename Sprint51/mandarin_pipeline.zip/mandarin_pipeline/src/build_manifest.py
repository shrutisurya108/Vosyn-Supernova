"""
Assembles candidate_manifest.json — the single source of truth tying together:
  - the exact config used (and its hash)
  - the data version + per-split hashes
  - the hardware smoke-test decision
  - the training summary (method, checkpoint path)
  - checkpoint file hashes (for integrity verification / reproducibility)
  - evaluation results
  - git commit + timestamp
"""
from __future__ import annotations

import platform
from datetime import datetime, timezone
from pathlib import Path

from utils import config_hash, get_git_commit, read_json, sha256_file, write_json


def _hash_checkpoint_dir(checkpoint_dir: Path) -> dict:
    hashes = {}
    if not checkpoint_dir.exists():
        return hashes
    for f in sorted(checkpoint_dir.glob("*")):
        if f.is_file():
            hashes[f.name] = sha256_file(str(f))
    return hashes


def build_manifest(cfg: dict) -> dict:
    run_dir = Path(cfg["run"]["output_root"]) / cfg["run"]["run_name"]

    data_manifest = read_json(str(run_dir / "data" / "data_manifest.json"))
    hardware_report = read_json(str(run_dir / "hardware_report.json"))
    train_summary = read_json(str(run_dir / "train_summary.json"))

    eval_report_path = run_dir / "eval_report.json"
    eval_report = read_json(str(eval_report_path)) if eval_report_path.exists() else None

    final_checkpoint_dir = Path(train_summary["final_checkpoint_path"])

    manifest = {
        "candidate_id": f"{cfg['run']['run_name']}_{data_manifest['data_version']}",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "language_direction": cfg["language"]["direction"],
        "cantonese_excluded": True,
        "config": {
            "raw": cfg,
            "config_hash": config_hash(cfg),
        },
        "seed": cfg["run"]["seed"],
        "data": {
            "data_version": data_manifest["data_version"],
            "dataset_name": data_manifest["dataset_name"],
            "counts": data_manifest["counts"],
            "sha256": data_manifest["sha256"],
            "splits_kept_separate": [
                "fine_tune_train", "fine_tune_val", "judge_calibration",
                "prompt_validation", "sealed_test",
            ],
        },
        "hardware_smoke_test": hardware_report,
        "training": train_summary,
        "checkpoint": {
            "path": str(final_checkpoint_dir),
            "file_sha256": _hash_checkpoint_dir(final_checkpoint_dir),
        },
        "evaluation": eval_report,
        "environment": {
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "git_commit": get_git_commit(),
        },
    }

    out_path = run_dir / cfg["manifest"]["filename"]
    write_json(manifest, str(out_path))
    return manifest


if __name__ == "__main__":
    import argparse
    import sys

    sys.path.insert(0, str(Path(__file__).parent))
    from utils import load_config

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default_config.yaml")
    parser.add_argument("--set", dest="overrides", action="append", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.overrides)
    build_manifest(cfg)
