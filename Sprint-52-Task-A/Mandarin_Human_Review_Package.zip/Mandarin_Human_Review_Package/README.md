# Mandarin Human Review Package

Fresh, independently-sourced examples for external human review of the Mandarin
judge, covering both directions: **English → Mandarin** and **Mandarin → English**.

## What's in this folder

| File | Purpose |
|---|---|
| `Reviewer_Instructions_and_Rubric.docx` | Hand this to reviewers. Full instructions, error categories, severity levels, scoring bands, and four worked examples. |
| `Mandarin_Review_Scoring_Workbook.xlsx` | Hand this to reviewers. Two tabs (`en_to_cmn`, `cmn_to_en`), one worked example row per tab, then the 20 real items per direction with blank columns for scores. |
| `data/en_to_cmn.jsonl`, `data/cmn_to_en.jsonl` | Same 40 items in machine-readable form, with full provenance metadata, for re-import once scores come back. |

## Target size (set upfront)

**20 examples per direction, 40 total.** This is smaller than Sprint 50's 30–50/direction
gold sets, and that's a deliberate, disclosed trade-off — see "Sourcing" below for why.
It's easy to extend to 40/direction later using the same process if the team wants a
larger batch.

## Directions covered

English→Mandarin and Mandarin→English — the two directions the Mandarin judge scores.
(Cantonese is a separate judge/dataset, out of scope here, per the Sprint 50 split.)

## Sourcing — independent of the Sprint 50 "borrowed" data, and how

Sprint 50's gold sets borrowed from two existing public corpora: **SiniticMTError**
(English→Mandarin, English→Cantonese) and **Google's WMT MQM newstest2021**
(Mandarin→English). Every example in *this* package is deliberately **not** drawn from
either of those, so this new set gives genuinely independent human labels rather than
re-scoring the same sentences a second time.

Two source types are mixed in, and every row's `source_origin` field says which:

- **`tatoeba_cc_by_2.0_fr`** (10 of 40 rows) — real sentence pairs from the Tatoeba
  Project (CC-BY 2.0 France), surfaced via a Tatoeba-derived dataset. These are
  genuinely independent, previously-existing, community-translated sentences with a
  traceable attribution note in `source_reference`.
- **`author_composed_claude`** (30 of 40 rows) — source sentences written for this task
  and translated single-pass by Claude Sonnet 4.6, not post-edited.

**Why the mix, honestly:** the sandbox this was built in can only reach a short
allow-list of package/code-hosting domains (GitHub, PyPI, npm, etc.) — it cannot reach
Tatoeba's download server, the Hugging Face Hub, or statmt.org, all of which host the
large independent corpora that would have been the ideal source for all 40 rows. I
pulled what real, license-clean Tatoeba sentence pairs I could retrieve through search
results, and disclosed the gap rather than silently padding the set with more
corpus-labeled rows than were actually sourced that way. If you have direct access to
Tatoeba, FLORES-200, or another independent MT corpus, swapping in real sentences for
the `author_composed_claude` rows (same schema) is a straightforward follow-up and
would let every row carry external, third-party provenance.

## Quality range (not just clean sentences)

Every direction spans three difficulty tiers, tagged in `difficulty_tag`:

- **easy** (11/direction) — short, everyday sentences, mostly clean translations.
- **medium** (5/direction) — business/technical register, longer clauses; a few rows
  have a genuine omission or a slightly awkward calque.
- **hard** (4/direction) — idioms, word-sense ambiguity (e.g. "bank" as riverbank vs.
  financial institution), and idiomatic Chinese structures (走后门, 前脚…后脚…) that a
  literal, single-pass translation handles badly. These produce real major/critical
  errors, not manufactured ones — every candidate is genuine single-pass MT-style
  output, not a translation deliberately sabotaged after the fact. Rows with a known,
  intentional issue (e.g. a misspelled transliterated name, a dropped clause) are
  flagged in `seeding_note_internal` in the JSONL — **that field is for your team's
  own calibration use only and is not shown to reviewers** in the rubric or workbook.

## Traceability

Every example records, per row: a stable `example_id`, `direction`, `source_origin`,
`source_reference` (Tatoeba attribution where applicable), `difficulty_tag`, and
`candidate_generated_by`. This is enough to trace any given row back to where its
source sentence came from and how its candidate translation was produced.

## Scoring package

The rubric document defines four severity levels (Critical/Major/Minor/None) and four
error categories (Accuracy/Fluency/Terminology/Register), gives explicit 0–100 scoring
bands, and walks through one worked example per severity level using sentences drawn
directly from this dataset — a reviewer should be able to work through the whole set
without needing to ask a clarifying question.
