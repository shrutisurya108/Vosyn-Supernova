"""
Step 1 (after merge) - apply hand fixes that merge_review.py cannot do automatically,
then regenerate the pairs and print every reviewer correction for a final check.

Current fixes
  * B::S52_020::traditional_tw - the reviewer corrected the S52_020 gold to
    说得客气一点，首席财务官的那番话不太坦诚。 so its Taiwan-localised version must follow.

Run:  python scripts/apply_manual_fixes.py
      python scripts/validate_datasets.py
Safe to run more than once.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
P = os.path.join(os.path.dirname(HERE), "data", "processed")

FIXES = {
    "B::S52_020::traditional_tw": {
        "expected_gold": "说得客气一点，首席财务官的那番话不太坦诚。",
        "candidate": "說得客氣一點，財務長的那番話不太坦誠。",
        "why": "Follows the reviewer's corrected gold; Taiwan term 財務長 for CFO.",
    },
}


def main():
    from build_datasets import build_pairs, diff_words, write_jsonl
    path = os.path.join(P, "setB_items.jsonl")
    if not os.path.exists(os.path.join(P, "setB_items.prereview.jsonl")):
        sys.exit("!! No review has been merged yet - run run_step1.sh --merge first.")
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    by_id = {r["item_id"]: r for r in rows}
    log = []

    for iid, fx in FIXES.items():
        r = by_id.get(iid)
        if r is None:
            sys.exit(f"!! {iid} not found")
        gold = by_id[f"B::{r['source_id']}::gold"]["candidate"]
        if gold != fx["expected_gold"]:
            sys.exit(f"!! {iid}: gold is now '{gold}', not the expected '{fx['expected_gold']}'. "
                     "Send this message to Claude before continuing.")
        if r["candidate"] != fx["candidate"]:
            r.setdefault("candidate_author", r["candidate"])
            r["candidate"] = fx["candidate"]
            char = by_id.get(f"B::{r['source_id']}::traditional_char")
            if char:
                r["tw_vocab_changes"] = diff_words(char["candidate"], fx["candidate"])
            r["review_status"] = "corrected_manually"
            r["manual_fix_note"] = fx["why"]
            log.append(f"fixed {iid}: {fx['candidate']}")
        else:
            log.append(f"already fixed {iid}")

    write_jsonl(path, rows)
    pairs = build_pairs([r for r in rows if r.get("include_in_experiments", True)])
    write_jsonl(os.path.join(P, "pairs.jsonl"), pairs)

    print("\n".join(log))
    print(f"Pairs regenerated: {len(pairs)}")
    print("\nALL CORRECTED ROWS (send this list to Claude):")
    for r in rows:
        if r.get("review_status", "").startswith("corrected"):
            before = r.get("candidate_author") or "(gold - see setB_items.prereview.jsonl)"
            print(f"  {r['item_id']}\n     before: {before}\n     after:  {r['candidate']}")
            if r.get("planted_error") and r["planted_error"].get("span"):
                ok = r["planted_error"]["span"] in r["candidate"]
                print(f"     planted span '{r['planted_error']['span']}' still present: {ok}")
            if r.get("review", {}).get("comments"):
                print(f"     reviewer comment: {r['review']['comments']}")
    with open(os.path.join(P, "merge_report.txt"), "a", encoding="utf-8") as f:
        f.write("\nMANUAL FIXES (apply_manual_fixes.py):\n" + "\n".join(f"  - {l}" for l in log) + "\n")


if __name__ == "__main__":
    main()
