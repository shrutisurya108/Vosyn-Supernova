#!/usr/bin/env bash
# Sprint 53 - install and start Ollama on a Colab GPU runtime, then download both judge models.
# Safe to run again: it skips whatever is already done. Takes ~3-6 minutes on a fresh runtime
# (most of it is downloading ~10 GB of model weights).
set -euo pipefail

echo ">> 1/4 System packages (zstd is needed by the Ollama installer, pciutils/lshw for GPU detection)"
apt-get -qq update >/dev/null 2>&1 || true
apt-get -qq install -y zstd pciutils lshw >/dev/null 2>&1

if ! command -v ollama >/dev/null 2>&1; then
  echo ">> 2/4 Installing Ollama"
  curl -fsSL https://ollama.com/install.sh | sh >/dev/null
else
  echo ">> 2/4 Ollama already installed"
fi

if ! curl -s http://127.0.0.1:11434/api/version >/dev/null 2>&1; then
  echo ">> 3/4 Starting the Ollama server in the background (log: /content/ollama.log)"
  # MAX_LOADED_MODELS=2 keeps glm4 AND qwen in GPU memory together (~10 GB of the T4's 15 GB)
  # NUM_PARALLEL=4 only reserves room for parallel requests; the runner sends 1 at a time by default
  OLLAMA_MAX_LOADED_MODELS=2 OLLAMA_NUM_PARALLEL=4 OLLAMA_KEEP_ALIVE=60m \
    nohup ollama serve > /content/ollama.log 2>&1 &
  for i in $(seq 1 60); do
    curl -s http://127.0.0.1:11434/api/version >/dev/null 2>&1 && break
    sleep 1
  done
else
  echo ">> 3/4 Ollama server already running"
fi
curl -s http://127.0.0.1:11434/api/version || { echo "!! Ollama did not start - see /content/ollama.log"; exit 1; }
echo

echo ">> 4/4 Downloading judge models (same tags as Sprint 50)"
ollama pull glm4 2>&1 | tail -1
ollama pull qwen2.5:7b 2>&1 | tail -1
ollama list
echo ">> Setup finished."
