"""
Step 1 - build the reviewer package: SetB_Review_Workbook.xlsx

One row per Set B item that needs a human check (the 10 Sprint 50 MT outputs are
excluded - they already carry human MQM labels from SiniticMTError).

Run:  python scripts/build_review_workbook.py
Needs: pip install openpyxl
"""
import json
import os

from openpyxl import Workbook
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "data", "processed", "setB_items.jsonl")
OUT = os.path.join(ROOT, "review", "SetB_Review_Workbook.xlsx")

FONT = "Arial"
YELLOW = PatternFill("solid", start_color="FFF2CC")
GREY = PatternFill("solid", start_color="EDEDED")
HEAD = PatternFill("solid", start_color="1F3864")
SUB = PatternFill("solid", start_color="D9E1F2")
thin = Side(style="thin", color="BFBFBF")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
WRAP = Alignment(wrap_text=True, vertical="top")

VARIANT_ORDER = ["gold", "paraphrase", "literal", "padded", "fluent_wrong", "targeted_error",
                 "original_candidate", "traditional_char", "traditional_tw"]

DESCRIPTION = {
    "gold": "PROPOSED REFERENCE. Should be a fully correct, natural Mainland Mandarin translation. "
            "If anything is wrong or unnatural, write a corrected sentence in column Q - it will become "
            "the reference for every row of this source.",
    "paraphrase": "Should mean EXACTLY the same as the gold row, using deliberately different wording. "
                  "Check nothing is added, lost or changed, and that it sounds natural.",
    "literal": "Should have NO meaning errors, but be stiff / word-for-word on purpose. "
               "Stiffness is intended - only flag meaning problems or ungrammatical Chinese.",
    "padded": "Same meaning as gold, deliberately wordy/redundant. Check no meaning was added or lost.",
    "fluent_wrong": "Should read naturally but contain exactly ONE planted meaning error (columns J-K). "
                    "Check the error is real and that there is no OTHER error.",
    "targeted_error": "Contains exactly ONE planted error typical of this category (columns J-K). "
                      "Check the error is real and that there is no OTHER error.",
    "original_candidate": "Existing Sprint 52 machine translation, not written for this sprint. "
                          "We only need your quality band and any errors you see.",
    "traditional_char": "Gold converted to Traditional CHARACTERS only - same words. Check the meaning is "
                        "unchanged and characters look right (e.g. no wrong 裡/里 swaps in names).",
    "traditional_tw": "Gold adapted for Taiwan: Traditional characters + Taiwan vocabulary (e.g. 伺服器, 公尺, "
                      "財務長) + 「」 quotes. Check the meaning is unchanged. If you are unsure whether a word "
                      "is natural in Taiwan, answer 'Not sure' in Q1 rather than guessing.",
}

COLUMNS = [
    # (header, width, key)
    ("item_id", 26, "item_id"),
    ("Source ID", 10, "source_id"),
    ("Category", 14, "category"),
    ("Row type", 14, "variant_type"),
    ("Script", 12, "script"),
    ("English source", 40, "source_text"),
    ("Candidate translation (CHECK THIS)", 44, "candidate"),
    ("Gold reference (for comparison)", 36, "reference"),
    ("What this row is supposed to be", 42, "description"),
    ("Planted error - text", 16, "pe_span"),
    ("Planted error - what is wrong", 34, "pe_desc"),
    ("Our expected band", 11, "expected_quality_band"),
    ("Q1. Row matches its description?", 14, None),
    ("Q2. Your quality band", 12, None),
    ("Q3. Planted error severity", 14, None),
    ("Q4. Other errors you found", 30, None),
    ("Q5. Suggested correction (full sentence)", 36, None),
    ("Comments", 28, None),
    ("Band agrees? (auto)", 12, None),
]
Q_COLS = {"q1": "M", "q2": "N", "q3": "O", "q4": "P", "q5": "Q", "comments": "R", "agree": "S"}


def load_rows():
    rows = [json.loads(l) for l in open(SRC, encoding="utf-8") if l.strip()]
    rows = [r for r in rows if not (r["variant_type"] == "original_candidate" and r["source_origin"] == "sprint50")]
    order = []
    for r in rows:
        if r["source_id"] not in order:
            order.append(r["source_id"])
    rows.sort(key=lambda r: (order.index(r["source_id"]), VARIANT_ORDER.index(r["variant_type"])))
    return rows


def style_header(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
        cell.fill = HEAD
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        cell.border = BORDER


def build_review_sheet(wb, rows):
    ws = wb.create_sheet("Review")
    for i, (h, w, _) in enumerate(COLUMNS, start=1):
        ws.cell(row=1, column=i, value=h)
        ws.column_dimensions[get_column_letter(i)].width = w
    style_header(ws, 1, len(COLUMNS))
    ws.row_dimensions[1].height = 42

    dv_q1 = DataValidation(type="list", formula1='"Yes,No,Partly,Not sure"', allow_blank=True)
    dv_q2 = DataValidation(type="list", formula1='"clean,moderate,poor"', allow_blank=True)
    dv_q3 = DataValidation(type="list", formula1='"minor,major,critical,not an error,n/a"', allow_blank=True)
    for dv in (dv_q1, dv_q2, dv_q3):
        dv.error = "Please pick a value from the dropdown list."
        dv.showErrorMessage = True
        ws.add_data_validation(dv)

    prev_source = None
    for n, r in enumerate(rows, start=2):
        pe = r.get("planted_error") or {}
        values = {
            **r,
            "description": DESCRIPTION[r["variant_type"]] + (
                f" Expected: {pe['description']}" if r["variant_type"] == "original_candidate" and pe else ""),
            "pe_span": pe.get("span") or "",
            "pe_desc": (f"[{pe.get('type')}, {pe.get('severity')}] {pe.get('description')}"
                        if pe and r["variant_type"] != "original_candidate" else ""),
        }
        if r.get("notes") and r["variant_type"] == "gold":
            values["description"] += f"  NOTE: {r['notes']}"
        for i, (_, _, key) in enumerate(COLUMNS, start=1):
            cell = ws.cell(row=n, column=i, value=values.get(key) if key else None)
            cell.font = Font(name=FONT, size=10, bold=(key == "candidate"))
            cell.alignment = WRAP
            cell.border = BORDER
        # reviewer columns
        for col in "MNOPQR":
            ws[f"{col}{n}"].fill = YELLOW
        if not pe or r["variant_type"] == "original_candidate" and not pe.get("span"):
            if not pe:
                ws[f"O{n}"] = "n/a"
                ws[f"O{n}"].fill = GREY
        ws[f"S{n}"] = f'=IF(N{n}="","",IF(N{n}=L{n},"agree","DISAGREE"))'
        ws[f"S{n}"].font = Font(name=FONT, size=10)
        ws[f"S{n}"].fill = GREY
        dv_q1.add(f"M{n}")
        dv_q2.add(f"N{n}")
        dv_q3.add(f"O{n}")
        # thick separator between sources
        if prev_source is not None and r["source_id"] != prev_source:
            for i in range(1, len(COLUMNS) + 1):
                c = ws.cell(row=n, column=i)
                c.border = Border(left=thin, right=thin, bottom=thin, top=Side(style="medium", color="1F3864"))
        prev_source = r["source_id"]
        # gold rows shaded so the reviewer sees the anchor of each group
        if r["variant_type"] == "gold":
            for col in "ABCDEFGHIJKL":
                ws[f"{col}{n}"].fill = SUB

    last = len(rows) + 1
    ws.conditional_formatting.add(f"S2:S{last}", FormulaRule(
        formula=[f'S2="DISAGREE"'], font=Font(name=FONT, color="C00000", bold=True)))
    ws.freeze_panes = "H2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(COLUMNS))}{last}"
    return ws, last


def build_start_sheet(wb, n_rows):
    ws = wb.active
    ws.title = "Start here"
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 95
    title = ws.cell(row=1, column=1, value="Sprint 53 - Set B translation review (English → Mandarin)")
    title.font = Font(name=FONT, bold=True, size=14, color="1F3864")
    lines = [
        ("What you are doing",
         "Checking translations we wrote to test automatic (LLM) translation judges. For each row, tell us if the "
         "row is what it claims to be, and what quality band you would give it. Read SetB_Reviewer_Instructions.docx "
         "first (about 10 minutes)."),
        ("Rows to review", f"{n_rows} rows on the 'Review' tab, grouped by English sentence (40 sentences). "
                           "Expect about 1 minute per row; it is fine to work in several sittings."),
        ("Where to type", "ONLY in the yellow columns M-R. Grey and white columns are pre-filled - please do not edit "
                          "them. Column S fills itself in."),
        ("Q1 Row matches its description?", "Yes / No / Partly / Not sure. Column I says what the row is supposed to be."),
        ("Q2 Your quality band", "clean / moderate / poor - your own judgement of the candidate (definitions below)."),
        ("Q3 Planted error severity", "Only for rows with a planted error (columns J-K): minor / major / critical, or "
                                      "'not an error' if you think it is actually acceptable. 'n/a' is pre-filled "
                                      "where there is no planted error."),
        ("Q4 Other errors", "Any error we did not plant or describe. Quote the Chinese text and say why."),
        ("Q5 Suggested correction", "Only if the row is wrong for its purpose. Write the FULL corrected sentence. "
                                    "For gold rows this becomes the new reference."),
        ("Band: clean", "Correct meaning, natural Chinese. You would publish it with at most tiny edits."),
        ("Band: moderate", "Meaning is essentially right, but it is stiff, unnatural, slightly off in tone, or has "
                           "small errors a reader would notice."),
        ("Band: poor", "At least one meaning error that would mislead a reader, or the sentence does not make sense."),
        ("Traditional-script rows", "You are not expected to be a Traditional-script expert. Check the meaning; "
                                    "answer 'Not sure' in Q1 about Taiwan word choice if unfamiliar."),
        ("When finished", "Save the file with your initials in the name (e.g. SetB_Review_Workbook_LW.xlsx) and send it back. "
                          "The 'Summary' tab shows your progress."),
    ]
    r = 3
    for k, v in lines:
        a = ws.cell(row=r, column=1, value=k)
        b = ws.cell(row=r, column=2, value=v)
        a.font = Font(name=FONT, bold=True, size=10)
        b.font = Font(name=FONT, size=10)
        a.alignment = b.alignment = WRAP
        a.border = b.border = BORDER
        a.fill = SUB
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Example of a completed row").font = Font(name=FONT, bold=True, size=11, color="1F3864")
    r += 1
    example = [
        ("Row type", "fluent_wrong"),
        ("English source", "The museum opens at nine every morning."),
        ("Candidate translation", "博物馆每天晚上九点开门。"),
        ("Planted error", "晚上 - [Mistranslation, major] 'Morning' becomes 'evening'."),
        ("Q1. Row matches its description?", "Yes"),
        ("Q2. Your quality band", "poor"),
        ("Q3. Planted error severity", "major"),
        ("Q4. Other errors you found", "(blank - none)"),
        ("Q5. Suggested correction", "(blank - the error is intentional, do not correct it)"),
        ("Comments", "Reads naturally, so a careless reader would be misled."),
    ]
    for k, v in example:
        a = ws.cell(row=r, column=1, value=k)
        b = ws.cell(row=r, column=2, value=v)
        a.font = Font(name=FONT, bold=True, size=10)
        b.font = Font(name=FONT, size=10, italic=True)
        a.border = b.border = BORDER
        a.alignment = b.alignment = WRAP
        b.fill = YELLOW if k.startswith(("Q", "Comments")) else PatternFill()
        r += 1
    return ws


def build_summary_sheet(wb, last):
    ws = wb.create_sheet("Summary")
    ws.column_dimensions["A"].width = 22
    for c in "BCDE":
        ws.column_dimensions[c].width = 16
    ws["A1"] = "Review progress and agreement with our expected bands (all cells are formulas)"
    ws["A1"].font = Font(name=FONT, bold=True, size=12, color="1F3864")
    heads = ["Row type", "Rows", "Reviewed (Q2 filled)", "Band agrees", "Agreement rate"]
    for i, h in enumerate(heads, start=1):
        ws.cell(row=3, column=i, value=h)
    style_header(ws, 3, len(heads))
    rng = lambda col: f"Review!${col}$2:${col}${last}"  # noqa: E731
    r = 4
    for vt in VARIANT_ORDER + ["TOTAL"]:
        ws.cell(row=r, column=1, value=vt)
        if vt == "TOTAL":
            ws.cell(row=r, column=2, value=f"=SUM(B4:B{r-1})")
            ws.cell(row=r, column=3, value=f"=SUM(C4:C{r-1})")
            ws.cell(row=r, column=4, value=f"=SUM(D4:D{r-1})")
        else:
            ws.cell(row=r, column=2, value=f'=COUNTIF({rng("D")},A{r})')
            ws.cell(row=r, column=3, value=f'=COUNTIFS({rng("D")},A{r},{rng("N")},"<>")')
            ws.cell(row=r, column=4, value=f'=COUNTIFS({rng("D")},A{r},{rng("S")},"agree")')
        ws.cell(row=r, column=5, value=f'=IF(C{r}=0,"-",D{r}/C{r})')
        ws.cell(row=r, column=5).number_format = "0%"
        for c in range(1, 6):
            cell = ws.cell(row=r, column=c)
            cell.font = Font(name=FONT, size=10, bold=(vt == "TOTAL"))
            cell.border = BORDER
        r += 1
    ws.cell(row=r + 1, column=1, value="Q1 answered 'No' or 'Partly':").font = Font(name=FONT, bold=True, size=10)
    ws.cell(row=r + 1, column=2, value=f'=COUNTIF({rng("M")},"No")+COUNTIF({rng("M")},"Partly")').font = Font(name=FONT, size=10)
    ws.cell(row=r + 2, column=1, value="Corrections suggested (Q5):").font = Font(name=FONT, bold=True, size=10)
    ws.cell(row=r + 2, column=2, value=f'=COUNTIF({rng("Q")},"?*")').font = Font(name=FONT, size=10)


def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    rows = load_rows()
    wb = Workbook()
    build_start_sheet(wb, len(rows))
    _, last = build_review_sheet(wb, rows)
    build_summary_sheet(wb, last)
    for ws in wb.worksheets:   # print-friendly: landscape, fit all columns on one page width
        ws.page_setup.orientation = "landscape"
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True
    wb.save(OUT)
    print(f"Wrote {OUT} with {len(rows)} review rows")


if __name__ == "__main__":
    main()
