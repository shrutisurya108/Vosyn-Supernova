"""
Pure-Python chrF, equivalent to sacrebleu's sentence-level CHRF() defaults
(character n-gram order 6, word n-gram order 0, beta 2, whitespace removed,
effective-order averaging). Used instead of sacrebleu so Step 1 needs no compiled
packages (sacrebleu pulls in numpy/lxml/regex, which can lag behind new Python
versions such as 3.14 on macOS).

    from chrf import chrf
    chrf("我们试试吧。", "咱们来试一下。")  -> score in 0-100
"""
from collections import Counter

CHAR_ORDER = 6
BETA = 2
EPS = 1e-16


def _ngrams(text, n):
    return Counter(text[i:i + n] for i in range(len(text) - n + 1))


def chrf(hypothesis, reference, char_order=CHAR_ORDER, beta=BETA):
    hyp = "".join(hypothesis.split())
    ref = "".join(reference.split())
    precisions, recalls = [], []
    for n in range(1, char_order + 1):
        h, r = _ngrams(hyp, n), _ngrams(ref, n)
        h_total, r_total = sum(h.values()), sum(r.values())
        if h_total == 0 or r_total == 0:
            continue  # effective order: skip n-gram orders longer than the text
        match = sum((h & r).values())
        precisions.append(match / h_total)
        recalls.append(match / r_total)
    if not precisions:
        return 0.0
    p = sum(precisions) / len(precisions)
    r = sum(recalls) / len(recalls)
    if p + r == 0:
        return 0.0
    b2 = beta ** 2
    return 100 * (1 + b2) * p * r / (b2 * p + r + EPS)
