// Step 1 - build SetB_Reviewer_Instructions.docx
// Run: node scripts/build_reviewer_instructions.js   (needs: npm install docx)
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, AlignmentType,
  HeadingLevel, LevelFormat, WidthType, ShadingType, BorderStyle, Footer, PageNumber,
} = require("docx");

const OUT = path.join(__dirname, "..", "review", "SetB_Reviewer_Instructions.docx");
const FONT = { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei", cs: "Arial" };
const W = 9360; // content width in DXA (US Letter, 1" margins)
const border = { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" };
const borders = { top: border, bottom: border, left: border, right: border };

const run = (text, o = {}) => new TextRun({ text, font: FONT, size: 21, ...o });
const p = (children, o = {}) => new Paragraph({
  spacing: { after: 120 }, ...o,
  children: typeof children === "string" ? [run(children)] : children,
});
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: t, font: FONT })] });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t, font: FONT })] });
const bullet = (children) => new Paragraph({
  numbering: { reference: "bullets", level: 0 }, spacing: { after: 60 },
  children: typeof children === "string" ? [run(children)] : children,
});
const step = (children) => new Paragraph({
  numbering: { reference: "steps", level: 0 }, spacing: { after: 80 },
  children: typeof children === "string" ? [run(children)] : children,
});

function table(widths, header, rows) {
  const cell = (text, w, isHead) => new TableCell({
    borders, width: { size: w, type: WidthType.DXA },
    shading: isHead ? { fill: "1F3864", type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: String(text).split("\n").map((line) => new Paragraph({
      children: [run(line, isHead ? { bold: true, color: "FFFFFF", size: 19 } : { size: 19 })],
    })),
  });
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: widths,
    rows: [
      new TableRow({ tableHeader: true, children: header.map((t, i) => cell(t, widths[i], true)) }),
      ...rows.map((r) => new TableRow({ children: r.map((t, i) => cell(t, widths[i], false)) })),
    ],
  });
}

function example(title, fields) {
  return [
    new Paragraph({ spacing: { before: 160, after: 60 }, children: [run(title, { bold: true, color: "1F3864" })] }),
    table([2600, 6760], ["Field", "Value"], fields),
  ];
}

const children = [
  new Paragraph({ spacing: { after: 60 }, children: [run("Sprint 53 · LLM-as-a-Judge failure analysis", { color: "808080", size: 19 })] }),
  new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: "Set B Translation Review — Instructions", font: FONT })] }),
  p([run("Direction: English → Mandarin (Simplified, Mainland).  Files: ", {}), run("SetB_Review_Workbook.xlsx", { bold: true }),
     run(" and this document.  Time: about 1 minute per row, 265 rows (4–5 hours; fine to split across several sittings).")]),

  h1("1. Why this review matters"),
  p("We are testing how reliably automatic LLM \"judges\" (glm4 and qwen2.5) score English→Mandarin translations. To catch a judge making a mistake, we need translations whose true quality we already know. We wrote those translations on purpose: some are correct, some are stiff, and some contain exactly one deliberate (\"planted\") error."),
  p("Your job is to confirm that each row really is what we say it is. If our labels are wrong, every conclusion about the judges built on them will be wrong too, so your corrections are the most valuable part of this review."),

  h1("2. How the workbook is organised"),
  bullet([run("Start here", { bold: true }), run(" tab — a one-page summary of these instructions and a completed example row.")]),
  bullet([run("Review", { bold: true }), run(" tab — 265 rows, grouped by English sentence (40 sentences). The first row of each group (light blue) is the gold reference; the other rows are variants of it.")]),
  bullet([run("Summary", { bold: true }), run(" tab — counts your progress automatically. You do not type anything here.")]),
  p([run("Type ", {}), run("only in the yellow columns M–R", { bold: true }), run(". Everything else is pre-filled. Column S (\"Band agrees?\") fills itself in and turns red when your band differs from ours — that is expected sometimes and is useful information, not a problem.")]),

  h1("3. What to do for each row"),
  step([run("Read the English source (column F), then the candidate translation (column G, bold). ", {}), run("Judge the candidate on its own first", { bold: true }), run(" — before looking at our labels.")]),
  step("Read column I (\"What this row is supposed to be\") and, if present, the planted error in columns J–K."),
  step([run("Q1 — Row matches its description? ", { bold: true }), run("Yes / No / Partly / Not sure. For example, a \"paraphrase\" row matches only if it means exactly the same as gold; a \"fluent_wrong\" row matches only if the planted error is real and there is no other error.")]),
  step([run("Q2 — Your quality band: ", { bold: true }), run("clean / moderate / poor (definitions in section 5). Give your own honest judgement, even if it differs from column L.")]),
  step([run("Q3 — Planted error severity: ", { bold: true }), run("only for rows with a planted error: minor / major / critical, or \"not an error\" if you think the change is actually acceptable. Rows without a planted error already show \"n/a\".")]),
  step([run("Q4 — Other errors: ", { bold: true }), run("any error we did not describe. Quote the Chinese text and say briefly why (e.g. \"'开了' — too colloquial for a medical context\").")]),
  step([run("Q5 — Suggested correction: ", { bold: true }), run("only when the row is wrong for its purpose. Write the full corrected sentence. Never \"fix\" a planted error — it is there on purpose. For gold rows, your correction becomes the reference for all rows of that sentence.")]),
  step("Comments: anything else — alternative translations, regional notes, or doubts."),

  h1("4. What each row type is, and what to check"),
  table([1900, 3300, 4160], ["Row type", "What it is", "What to check"], [
    ["gold", "Our proposed correct, natural reference.", "Fully correct and natural Mainland Mandarin? If not, correct it in Q5."],
    ["paraphrase", "Same meaning as gold, deliberately different wording.", "Exactly equivalent meaning (nothing added, lost or changed) and natural. Expected band: clean."],
    ["literal", "Meaning correct, but stiff / word-for-word on purpose.", "No meaning error and still understandable Chinese. Stiffness is intended — do not mark it as an error. Expected band: moderate."],
    ["padded", "Same meaning as gold, deliberately wordy.", "No meaning added or lost. Expected band: clean (maybe moderate if you find it too wordy)."],
    ["fluent_wrong", "Reads naturally, one planted meaning error.", "The planted error is real, and there is no other error. Expected band: poor."],
    ["targeted_error", "One planted error typical of the sentence's category (idiom, name, number, term, culture, register…).", "The planted error is real, and there is no other error. Register-only errors are expected to be moderate; the rest poor."],
    ["original_candidate", "Existing Sprint 52 machine translation.", "Your band and any errors. Column I says what we expect and why."],
    ["traditional_char", "Gold in Traditional characters, same words.", "Meaning unchanged; characters look right. Script choice itself is not an error for this review."],
    ["traditional_tw", "Gold adapted for Taiwan (characters + Taiwan vocabulary, 「」 quotes).", "Meaning unchanged. If unsure whether a word is natural in Taiwan, answer \"Not sure\" in Q1."],
  ]),

  h1("5. Quality bands (Q2)"),
  table([1600, 7760], ["Band", "Definition"], [
    ["clean", "Correct meaning and natural Chinese. You would publish it with at most tiny edits."],
    ["moderate", "Meaning essentially right, but stiff, unnatural, slightly wrong in tone/register, or with small errors a reader would notice."],
    ["poor", "At least one meaning error that would mislead a reader (wrong number, name, negation, idiom taken literally…), or the sentence does not make sense."],
  ]),
  p("A single meaning error in a short sentence is usually enough for \"poor\": the reader comes away with the wrong information, however fluent the Chinese is.", { spacing: { before: 120, after: 120 } }),

  h1("6. Error types and severity (Q3, Q4)"),
  h2("Error types (MQM, as used by our judges)"),
  table([2200, 7160], ["Type", "Meaning"], [
    ["Mistranslation", "Meaning differs from the source (wrong word, number, name, negation, sense)."],
    ["Omission", "Part of the source meaning is missing."],
    ["Addition", "Meaning not in the source has been added."],
    ["Grammar", "Ungrammatical Chinese."],
    ["Spelling / Typography", "Wrong character, wrong punctuation or formatting."],
    ["Untranslated", "Source text left in English where it should be translated."],
    ["Unintelligible", "Cannot be understood."],
    ["Style/Register", "Meaning kept but tone is wrong for the context (too casual for an official notice, too stiff for a text message). The judges' prompt has no label for this — that is deliberate."],
  ]),
  h2("Severity"),
  table([1600, 7760], ["Severity", "Use when…"], [
    ["minor", "A careful reader would notice, but the meaning and usability are intact (awkward word choice, small register slip)."],
    ["major", "The meaning is changed or confusing; a reader would be misinformed about something that matters."],
    ["critical", "The translation becomes unusable or potentially harmful (e.g. a password that no longer works, a dose or safety instruction that is wrong, text that is nonsense)."],
  ]),

  h1("7. Special cases"),
  bullet([run("Names and transliteration. ", { bold: true }), run("Several transliterations can be valid (穆里尔 / 穆瑞尔). Only mark an error if the name refers to a different person/place, or a fixed form exists and is not used (e.g. 九龙 for Kowloon).")]),
  bullet([run("Culture words. ", { bold: true }), run("Some rows test over-localisation (Thanksgiving → 中秋节, SAT → 高考) and conventions such as 40% off = 六折. Tell us if you would accept a localised version in real use.")]),
  bullet([run("Idioms. ", { bold: true }), run("Gold renders the meaning, not the words. If a calque such as 火箭科学 is acceptable in current Mainland usage, say so in Comments.")]),
  bullet([run("Ambiguous sources. ", { bold: true }), run("A few English sentences are ambiguous on purpose (bank, pitcher, glasses, check). Gold picks the reading the context supports; tell us if you read it differently.")]),
  bullet([run("Punctuation. ", { bold: true }), run("Full-width Chinese punctuation is expected. Do not mark half-width commas as errors unless they hurt readability.")]),
  bullet([run("Do not", { bold: true }), run(" edit grey/white columns, delete rows, re-order rows, or rename tabs — the file is read back in by a script.")]),

  h1("8. Worked examples"),
  ...example("Example A — a paraphrase that matches", [
    ["English", "Our flight was delayed because of the storm."],
    ["Row type / candidate", "paraphrase — 受风暴影响，我们的班机晚点了。"],
    ["Q1 / Q2 / Q3", "Yes / clean / n/a"],
    ["Comments", "(blank)"],
  ]),
  ...example("Example B — a planted error that is real", [
    ["English", "The store is having a Black Friday sale, with everything 40% off."],
    ["Row type / candidate", "targeted_error — 这家店正在搞黑色星期五促销，全场四折。"],
    ["Planted error", "四折 — '40% off' is 六折; 四折 means paying 40% (60% off)."],
    ["Q1 / Q2 / Q3", "Yes / poor / major"],
    ["Comments", "A shopper would expect a much bigger discount than offered."],
  ]),
  ...example("Example C — a literal row with an unintended second problem", [
    ["English", "He sat for the SATs twice before getting into college."],
    ["Row type / candidate", "literal — (imagine) 他坐了SAT两次在进入大学之前。"],
    ["Q1 / Q2 / Q3", "No / poor / n/a"],
    ["Q4 Other errors", "'坐了SAT' — 'sat' translated as 'sat down'; this is a meaning error, not just stiffness."],
    ["Q5 Correction", "在进入大学之前，他参加了SAT考试两次。"],
  ]),
  ...example("Example D — gold that needs improving", [
    ["English", "The CFO's remarks were, to put it mildly, a bit disingenuous."],
    ["Row type / candidate", "gold — 说得客气一点，首席财务官的那番话有些言不由衷。"],
    ["Q1 / Q2 / Q3", "Partly / clean / n/a"],
    ["Q5 Correction", "(only if you have a better, fully natural version — e.g. a more idiomatic rendering of 'disingenuous')"],
    ["Comments", "言不由衷 is fine; 不够坦诚 also works."],
  ]),

  h1("9. Returning the file"),
  p("Save the workbook with your initials added (e.g. SetB_Review_Workbook_LW.xlsx) and send it back. Before sending, check the Summary tab: \"Reviewed\" should equal \"Rows\" in the TOTAL line. Thank you — this review directly decides which judge failures we can trust."),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 21 } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal", run: { size: 40, bold: true, color: "1F3864", font: "Arial" }, paragraph: { spacing: { after: 160 } } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 28, bold: true, color: "1F3864", font: "Arial" }, paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 23, bold: true, color: "2F5496", font: "Arial" }, paragraph: { spacing: { before: 180, after: 80 }, outlineLevel: 1 } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "steps", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ],
  },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [run("Set B review instructions · page ", { size: 17, color: "808080" }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 17, color: "808080" })] })] }) },
    children,
  }],
});

Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUT, buf); console.log("Wrote " + OUT); });
