"""
Step 1 (after review) - merge the reviewer's workbook back into Set B.

What it does
  * Backs up data/processed/setB_items.jsonl -> setB_items.prereview.jsonl (once).
  * Reads the yellow columns (M-R) of the 'Review' tab, matched by item_id.
  * Q5 correction on a gold row -> replaces the gold text AND the reference of every row
    of that source; the traditional_char row is regenerated from the new gold.
  * Q5 correction on any other row -> replaces that row's candidate.
  * The reviewer's band (Q2) becomes the final expected band; our original band is kept
    as expected_quality_band_author.
  * The reviewer's severity (Q3) becomes the planted error severity; expected MQM score
    is recomputed with Sprint 50's weights.
  * Q1 = "No" with no correction -> row excluded from experiments (include_in_experiments=false).
  * Rows needing a human decision (corrected error rows whose planted span disappeared,
    Taiwan rows whose gold changed, Q1 = Partly / Not sure, Q3 = "not an error") are
    listed in data/processed/merge_report.txt.
  * Regenerates pairs.jsonl from the reviewed rows.

Run:  python scripts/merge_review.py review/SetB_Review_Workbook_<initials>.xlsx
      python scripts/validate_datasets.py
"""
import json
import os
import shutil
import sys
from collections import Counter, defaultdict

from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
P = os.path.join(ROOT, "data", "processed")
SEVERITY_WEIGHTS = {"minor": 1, "major": 5, "critical": 25}
REVIEW_COLS = {"q1": 13, "q2": 14, "q3": 15, "q4": 16, "q5": 17, "comments": 18}  # M..R


def clean(v):
    if v is None:
        return ""
    return str(v).strip()


def main(xlsx):
    import opencc
    from build_datasets import build_pairs, write_jsonl
    to_trad = opencc.OpenCC("s2tw")

    src_path = os.path.join(P, "setB_items.jsonl")
    backup = os.path.join(P, "setB_items.prereview.jsonl")
    if not os.path.exists(backup):
        shutil.copy(src_path, backup)
    rows = [json.loads(l) for l in open(backup, encoding="utf-8") if l.strip()]  # always merge onto the pre-review file
    by_id = {r["item_id"]: r for r in rows}

    ws = load_workbook(xlsx)["Review"]
    header = [c.value for c in ws[1]]
    assert header[0] == "item_id" and header[12].startswith("Q1"), "Unexpected workbook layout"
    reviews = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row[0]:
            continue
        reviews[row[0]] = {k: clean(row[i - 1]) for k, i in REVIEW_COLS.items()}

    attention, log = [], []
    missing = [i for i in reviews if i not in by_id]
    if missing:
        attention.append(f"{len(missing)} workbook item_ids not found in Set B: {missing[:5]}")

    # 1) gold corrections first, so references propagate before other rows are processed
    gold_changed = {}
    for iid, rv in reviews.items():
        r = by_id.get(iid)
        if r and r["variant_type"] == "gold" and rv["q5"]:
            gold_changed[r["source_id"]] = rv["q5"]
    for sid, new_gold in gold_changed.items():
        for r in rows:
            if r["source_id"] != sid:
                continue
            r["reference"] = new_gold
            if r["variant_type"] == "gold":
                r["candidate"] = new_gold
            elif r["variant_type"] == "traditional_char":
                r["candidate"] = to_trad.convert(new_gold)
                r["regenerated_from_corrected_gold"] = True
            elif r["variant_type"] == "traditional_tw":
                attention.append(f"{r['item_id']}: gold changed - update the Taiwan version by hand "
                                 f"(new gold: {new_gold})")
        log.append(f"gold corrected for {sid}: {new_gold}")

    # 2) per-row review fields
    for iid, rv in reviews.items():
        r = by_id.get(iid)
        if not r:
            continue
        r["review"] = rv
        r["expected_quality_band_author"] = r["expected_quality_band"]
        if rv["q2"] in ("clean", "moderate", "poor"):
            r["expected_quality_band"] = rv["q2"]
        pe = r.get("planted_error")
        if pe and rv["q3"] in SEVERITY_WEIGHTS:
            pe["severity_author"] = pe["severity"]
            pe["severity"] = rv["q3"]
            if r["variant_type"] != "original_candidate":
                r["expected_mqm_score"] = 100 - SEVERITY_WEIGHTS[rv["q3"]]
        if pe and rv["q3"] == "not an error":
            pe["reviewer_says_not_an_error"] = True
            attention.append(f"{iid}: reviewer says the planted change is NOT an error - decide keep/drop")
        if rv["q5"] and r["variant_type"] == "original_candidate":
            # Real MT output under test - must stay exactly as produced. Keep the reviewer's
            # fix as reference information only.
            r["reviewer_suggested_correction"] = rv["q5"]
        elif rv["q5"] and r["variant_type"] != "gold":
            r["candidate_author"] = r["candidate"]
            r["candidate"] = rv["q5"]
            if pe and pe.get("span") and pe["span"] not in rv["q5"]:
                attention.append(f"{iid}: corrected text no longer contains planted span '{pe['span']}' - "
                                 "update planted_error.span by hand")
        # status
        if rv["q5"] and r["variant_type"] == "original_candidate":
            r["review_status"] = "confirmed_with_suggestion"
        elif rv["q5"]:
            r["review_status"] = "corrected"
        elif rv["q1"] == "Yes":
            r["review_status"] = "confirmed"
        elif rv["q1"] == "No":
            r["review_status"] = "rejected"
            r["include_in_experiments"] = False
        elif rv["q1"] in ("Partly", "Not sure"):
            r["review_status"] = f"flagged_{rv['q1'].lower().replace(' ', '_')}"
            attention.append(f"{iid}: Q1={rv['q1']} - {rv['comments'] or rv['q4'] or '(no comment)'}")
        else:
            r["review_status"] = "not_reviewed"
        r.setdefault("include_in_experiments", True)

    for r in rows:
        r.setdefault("include_in_experiments", True)

    write_jsonl(src_path, rows)
    pairs = build_pairs([r for r in rows if r["include_in_experiments"]])
    write_jsonl(os.path.join(P, "pairs.jsonl"), pairs)

    # report
    reviewed = [r for r in rows if r.get("review")]
    agree = defaultdict(lambda: [0, 0])
    for r in reviewed:
        if r["review"]["q2"]:
            agree[r["variant_type"]][1] += 1
            agree[r["variant_type"]][0] += r["review"]["q2"] == r["expected_quality_band_author"]
    lines = ["SPRINT 53 - SET B REVIEW MERGE REPORT", "=" * 60,
             f"Workbook: {xlsx}",
             f"Rows in workbook: {len(reviews)}; merged: {len(reviewed)}",
             f"Status counts: {dict(Counter(r['review_status'] for r in rows))}",
             f"Excluded from experiments: {sum(not r['include_in_experiments'] for r in rows)}",
             f"Gold rows corrected: {len(gold_changed)}",
             f"Pairs regenerated: {len(pairs)}", "",
             "Reviewer vs author band agreement by row type:"]
    for vt, (a, n) in sorted(agree.items()):
        lines.append(f"  {vt:20s} {a}/{n} ({a / n:.0%})" if n else f"  {vt:20s} -")
    lines += ["", f"NEEDS ATTENTION ({len(attention)}):"] + [f"  - {a}" for a in attention]
    lines += ["", "LOG:"] + [f"  - {l}" for l in log]
    report = "\n".join(lines)
    open(os.path.join(P, "merge_report.txt"), "w", encoding="utf-8").write(report + "\n")
    print(report)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: python scripts/merge_review.py <reviewed_workbook.xlsx>")
    main(sys.argv[1])
