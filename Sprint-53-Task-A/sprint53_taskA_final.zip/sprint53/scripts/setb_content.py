"""
Sprint 53 - Set B source content (hand-written, controlled variants).

Every English source gets these Simplified-Chinese variants:
  gold            - correct, natural reference translation (written for this sprint;
                    for Sprint 50 sources it is based on the SiniticMTError reference)
  paraphrase      - same meaning, deliberately different wording/structure from gold
  literal         - meaning fully correct, but stiff / word-for-word English structure
  fluent_wrong    - reads naturally, contains exactly ONE meaning error (planted)
  targeted_error  - contains exactly ONE error of the source's own category (planted)
  padded          - (5 sources only) same meaning as gold but verbose / redundant,
                    used for the verbosity check in the position-bias experiment

Planted errors are tuples: (candidate_text, error_span, mqm_type, severity, description)
  - error_span must appear verbatim in candidate_text (validate_datasets.py checks this)
  - mqm_type uses the Sprint 50 MQM_PROMPT vocabulary where possible; register errors
    use "Style/Register", which the Sprint 50 prompt does NOT offer - deliberately, so
    we can see how judges handle an error type their prompt has no label for.

Sources that come from Sprint 52 (en_to_cmn.jsonl) or Sprint 50 (gold_en_cmn.jsonl)
keep their original source text; build_datasets.py re-checks it against the raw files.
"""

MAJ, MIN, CRIT = "major", "minor", "critical"

SOURCES = [
    # ------------------------------------------------------------------ simple_control
    dict(
        source_id="S52_001", origin="sprint52", origin_ref="encmn_001", category="simple_control",
        source_text="Let's try it.",
        gold="我们试试吧。",
        paraphrase="咱们来试一下。",
        literal="让我们尝试它。",
        fluent_wrong=("我们别试了吧。", "别试了", "Mistranslation", MAJ, "Suggestion to try becomes suggestion NOT to try (polarity reversed)."),
        targeted_error=("我们已经试过了。", "已经试过了", "Mistranslation", MAJ, "Proposal ('let's try') becomes a statement about the past ('we already tried')."),
    ),
    dict(
        source_id="S52_002", origin="sprint52", origin_ref="encmn_002", category="simple_control",
        source_text="I have to go to sleep.",
        gold="我得去睡觉了。",
        paraphrase="我必须上床休息了。",
        literal="我有去睡觉的必要。",
        fluent_wrong=("我不想去睡觉。", "不想", "Mistranslation", MAJ, "'Have to' becomes 'don't want to'."),
        targeted_error=("我得去上班了。", "上班", "Mistranslation", MAJ, "'Sleep' becomes 'go to work'."),
    ),
    dict(
        source_id="S52_005", origin="sprint52", origin_ref="encmn_005", category="simple_control",
        source_text="I will be back soon.",
        gold="我很快就回来。",
        paraphrase="我去去就来。",
        literal="我将会很快地回来。",
        fluent_wrong=("我很快就走。", "走", "Mistranslation", MAJ, "'Be back' becomes 'leave'."),
        targeted_error=("我明天就回来。", "明天", "Mistranslation", MAJ, "'Soon' becomes 'tomorrow'."),
    ),
    dict(
        source_id="S52_008", origin="sprint52", origin_ref="encmn_008", category="simple_control",
        source_text="Our flight was delayed because of the storm.",
        gold="因为暴风雨，我们的航班延误了。",
        paraphrase="受风暴影响，我们的班机晚点了。",
        literal="我们的航班被延误了因为暴风雨。",
        fluent_wrong=("因为暴风雨，我们的航班取消了。", "取消", "Mistranslation", MAJ, "'Delayed' becomes 'cancelled'."),
        targeted_error=("因为暴风雪，我们的航班延误了。", "暴风雪", "Mistranslation", MAJ, "'Storm' becomes 'snowstorm/blizzard'."),
        padded="由于遇上了暴风雨天气的原因，我们所乘坐的这趟航班最终出现了延误的情况。",
    ),
    # ------------------------------------------------------------ numbers_units_dates
    dict(
        source_id="S52_006", origin="sprint52", origin_ref="encmn_006", category="numbers_units_dates",
        source_text="The museum opens at nine every morning.",
        gold="博物馆每天早上九点开门。",
        paraphrase="这家博物馆每日上午9时开放。",
        literal="博物馆在每一个早晨的九点钟打开。",
        fluent_wrong=("博物馆每天晚上九点开门。", "晚上", "Mistranslation", MAJ, "'Morning' becomes 'evening'."),
        targeted_error=("博物馆每天早上十点开门。", "十点", "Mistranslation", MAJ, "Nine o'clock becomes ten o'clock."),
    ),
    dict(
        source_id="A_375", origin="sprint50", origin_ref="en_to_cmn_375", category="numbers_units_dates",
        source_text="A person who weighs 200 pounds (90kg) on Earth would weigh about 36 pounds (16kg) on Io. So the gravity, of course, pulls less on you.",
        gold="一个在地球上重200磅（90千克）的人，到了木卫一上体重只有约36磅（16千克）。因此，那里的引力对你的拉力自然更小。",
        paraphrase="在地球上体重90公斤（200磅）的人，若站在木卫一上，体重约为16公斤（36磅）——很显然，那里的重力对人的牵引要小得多。",
        literal="一个在地球上称重200磅（90千克）的人，在木卫一上将称重大约36磅（16千克）。所以重力，当然，在你身上拉得更少。",
        fluent_wrong=("一个在地球上重200磅（90千克）的人，到了木卫一上体重只有约36磅（16千克）。因此，那里的引力对你的拉力自然更大。", "更大", "Mistranslation", MAJ, "Gravity pulls 'less' becomes 'more'."),
        targeted_error=("一个在地球上重200磅（90千克）的人，到了木卫一上体重只有约36千克（16磅）。因此，那里的引力对你的拉力自然更小。", "36千克（16磅）", "Mistranslation", MAJ, "Units swapped: 36 pounds (16 kg) becomes 36 kg (16 pounds)."),
    ),
    dict(
        source_id="A_43", origin="sprint50", origin_ref="en_to_cmn_43", category="numbers_units_dates",
        source_text="The storm, situated about 645 miles (1040 km) west of the Cape Verde islands, is likely to dissipate before threatening any land areas, forecasters say.",
        gold="预报员称，这场风暴位于佛得角群岛以西约645英里（1040公里）处，很可能在对任何陆地构成威胁之前就会消散。",
        paraphrase="据气象预报人员介绍，这个风暴目前位于佛得角群岛西侧约1040公里（645英里）的海面上，有望在威胁到陆地之前自行减弱消失。",
        literal="这场风暴，位于大约645英里（1040公里）在佛得角群岛的西边，很可能在威胁任何陆地地区之前消散，预报员们说。",
        fluent_wrong=("预报员称，这场风暴位于佛得角群岛以西约645英里（1040公里）处，很可能在对陆地构成威胁之后才会消散。", "之后才会", "Mistranslation", MAJ, "Dissipate 'before' threatening land becomes 'after'."),
        targeted_error=("预报员称，这场风暴位于佛得角群岛以西约465英里（1040公里）处，很可能在对任何陆地构成威胁之前就会消散。", "465英里", "Mistranslation", MAJ, "645 miles becomes 465 miles (digits transposed)."),
    ),
    dict(
        source_id="A_1741", origin="sprint50", origin_ref="en_to_cmn_1741", category="numbers_units_dates",
        source_text="The vertical clearance under the bridge is 15 meters. Construction was completed in August 2011, it didn't open to traffic until March 2017.",
        gold="桥下的垂直净空为15米。大桥于2011年8月完工，但直到2017年3月才通车。",
        paraphrase="这座桥的桥下净高达15米；工程在2011年8月就已竣工，却一直拖到2017年3月才开放通行。",
        literal="在桥下面的垂直间隙是15米。建设在2011年8月被完成，它没有对交通开放直到2017年3月。",
        fluent_wrong=("桥下的垂直净空为15米。大桥于2011年8月动工，但直到2017年3月才通车。", "动工", "Mistranslation", MAJ, "Construction 'completed' becomes 'started'."),
        targeted_error=("桥下的垂直净空为15米。大桥于2011年8月完工，但直到2017年5月才通车。", "2017年5月", "Mistranslation", MAJ, "March 2017 becomes May 2017."),
        padded="这座桥梁桥下的垂直净空高度为15米。该座大桥的建设工程于2011年8月份正式宣告完工，但是却直到2017年3月份才最终开放通车。",
    ),
    dict(
        source_id="N_NUM1", origin="new_sprint53", origin_ref="", category="numbers_units_dates",
        source_text="The rent increased by 15% to $2,300 a month, effective October 1.",
        gold="房租上涨了15%，涨至每月2300美元，自10月1日起生效。",
        paraphrase="从10月1日开始，月租金上调百分之十五，达到2300美元。",
        literal="房租增加了15%到每月2,300美元，有效于10月1日。",
        fluent_wrong=("房租上涨了15%，涨至每年2300美元，自10月1日起生效。", "每年", "Mistranslation", MAJ, "'A month' becomes 'a year'."),
        targeted_error=("房租上涨了50%，涨至每月2300美元，自10月1日起生效。", "50%", "Mistranslation", MAJ, "15% becomes 50%."),
    ),
    # ------------------------------------------------------------------ named_entity
    dict(
        source_id="S52_003", origin="sprint52", origin_ref="encmn_003", category="named_entity",
        source_text="Muiriel is 20 now.",
        gold="穆里尔现在二十岁了。",
        paraphrase="穆瑞尔如今已年满二十。",
        literal="穆里尔现在是二十岁。",
        fluent_wrong=("穆里尔现在十二岁了。", "十二", "Mistranslation", MAJ, "Age 20 becomes 12."),
        targeted_error=("穆勒现在二十岁了。", "穆勒", "Mistranslation", MAJ, "Name transliterated as a different name (Muiriel -> 'Müller')."),
        notes="Paraphrase deliberately uses a different but valid transliteration (穆瑞尔 vs 穆里尔) to test whether judges penalise transliteration variation.",
    ),
    dict(
        source_id="S52_004", origin="sprint52", origin_ref="encmn_004", category="named_entity",
        source_text="The password is \"Muiriel\".",
        gold="密码是“Muiriel”。",
        paraphrase="口令为“Muiriel”。",
        literal="那个密码是“Muiriel”。",
        fluent_wrong=("密码不是“Muiriel”。", "不是", "Mistranslation", MAJ, "Statement negated."),
        targeted_error=("密码是“穆里尔”。", "穆里尔", "Mistranslation", CRIT, "A password must stay verbatim; transliterating it makes the information unusable."),
    ),
    dict(
        source_id="A_386", origin="sprint50", origin_ref="en_to_cmn_386", category="named_entity",
        source_text="Hangeul is the only purposely invented alphabet in popular daily use. The alphabet was invented in 1444 during the reign of King Sejong (1418 – 1450).",
        gold="韩文字母是唯一一种特意发明、供日常使用的字母表，于1444年世宗大王（1418—1450年在位）统治时期创制。",
        paraphrase="在日常生活中普遍使用的字母文字里，只有韩文是人为专门创造的；它诞生于1444年，当时朝鲜正处在世宗大王的统治之下（1418至1450年）。",
        literal="韩文是唯一的被故意发明的字母在流行的日常使用中。这个字母被发明于1444年在世宗国王的统治期间（1418–1450）。",
        fluent_wrong=("韩文字母是最早一种特意发明、供日常使用的字母表，于1444年世宗大王（1418—1450年在位）统治时期创制。", "最早", "Mistranslation", MAJ, "'The only' becomes 'the earliest'."),
        targeted_error=("韩文字母是唯一一种特意发明、供日常使用的字母表，于1444年世祖大王（1418—1450年在位）统治时期创制。", "世祖大王", "Mistranslation", MAJ, "King Sejong (世宗) replaced by a different Joseon king (世祖)."),
        notes="Gold departs from the Sprint 50 reference, which says 世宗皇帝 ('Emperor'); Sejong was a king, conventionally 世宗大王.",
    ),
    dict(
        source_id="A_1106", origin="sprint50", origin_ref="en_to_cmn_1106", category="named_entity",
        source_text="Dr. Malar Balasubramanian, 29, was found in Blue Ash, Ohio, a suburb approximately 15 miles north of Cincinnati lying on the ground beside the road in a T-shirt and underwear in an apparently heavily medicated state.",
        gold="29岁的马拉尔·巴拉苏布拉马尼安医生被发现躺在俄亥俄州布卢阿什的路边地上。布卢阿什是辛辛那提以北约15英里的一个郊区。被发现时，她身穿T恤和内裤，显然服用了大量药物。",
        paraphrase="在辛辛那提北面约15英里的郊区——俄亥俄州布卢阿什，人们发现现年29岁的马拉尔·巴拉苏布拉马尼安医生倒卧在路旁，身上穿着T恤和内衣，看起来像是服用了大量药物。",
        literal="马拉尔·巴拉苏布拉马尼安医生，29岁，被发现在布卢阿什，俄亥俄州，一个大约在辛辛那提北边15英里的郊区，躺在路旁边的地上，穿着一件T恤和内衣，处在一个显然被大量用药的状态中。",
        fluent_wrong=("29岁的马拉尔·巴拉苏布拉马尼安医生被发现躺在俄亥俄州布卢阿什的路边地上。布卢阿什是辛辛那提以南约15英里的一个郊区。被发现时，她身穿T恤和内裤，显然服用了大量药物。", "以南", "Mistranslation", MAJ, "'North of Cincinnati' becomes 'south of'."),
        targeted_error=("29岁的马拉尔·巴拉苏布拉马尼安医生被发现躺在俄亥俄州蓝灰市的路边地上。蓝灰市是辛辛那提以北约15英里的一个郊区。被发现时，她身穿T恤和内裤，显然服用了大量药物。", "蓝灰市", "Mistranslation", MAJ, "Place name 'Blue Ash' translated word-by-word ('blue-grey city') instead of transliterated (same error as the Sprint 50 MT output). Appears twice."),
        notes="'Dr.' is ambiguous (medical doctor vs PhD); gold follows the Sprint 50 reference (医生).",
    ),
    dict(
        source_id="A_1727", origin="sprint50", origin_ref="en_to_cmn_1727", category="named_entity",
        source_text="To get the best views of Hong Kong, leave the island and head for the Kowloon waterfront opposite.",
        gold="若想从最佳角度欣赏香港的美景，可以离开香港岛，前往对面的九龙海滨。",
        paraphrase="想把香港景色尽收眼底，不妨离开港岛，到对岸的九龙海滨去。",
        literal="为了得到香港的最好的景色，离开这个岛并且前往对面的九龙海滨。",
        fluent_wrong=("若想从最佳角度欣赏香港的美景，可以离开香港岛，前往后方的九龙海滨。", "后方", "Mistranslation", MAJ, "Waterfront 'opposite' becomes 'behind'."),
        targeted_error=("若想从最佳角度欣赏香港的美景，可以离开香港岛，前往对面的科隆海滨。", "科隆", "Mistranslation", MAJ, "Kowloon rendered as 科隆 (Cologne) - same error as the Sprint 50 MT output."),
    ),
    dict(
        source_id="A_126", origin="sprint50", origin_ref="en_to_cmn_126", category="named_entity",
        source_text="Since its inception, The Onion has become a veritable news parody empire, with a print edition, a website that drew 5,000,000 unique visitors in the month of October, personal ads, a 24 hour news network, podcasts, and a recently launched world atlas called Our Dumb World.",
        gold="自创办以来，《洋葱报》已经成为一个名副其实的恶搞新闻帝国，旗下拥有印刷版、网站（10月份吸引了500万独立访客）、个人广告、24小时新闻网络、播客，以及近期推出的世界地图集《我们的愚蠢世界》。",
        paraphrase="《洋葱报》创刊至今，已发展成一个不折不扣的恶搞新闻王国：它既有纸质版，也有网站（仅10月就迎来了500万名独立访客），还经营征友广告、全天候新闻频道和播客，最近更推出了一本世界地图集，书名叫《我们的愚蠢世界》。",
        literal="自从它的开始，《洋葱报》已经变成了一个名副其实的新闻模仿帝国，带有一个印刷版、一个在十月份吸引了5,000,000个独立访问者的网站、个人广告、一个24小时新闻网络、播客，以及一个最近推出的叫作《我们的愚蠢世界》的世界地图集。",
        fluent_wrong=("自创办以来，《洋葱报》已经成为一个名副其实的恶搞新闻帝国，旗下拥有印刷版、网站（10月份吸引了5000万独立访客）、个人广告、24小时新闻网络、播客，以及近期推出的世界地图集《我们的愚蠢世界》。", "5000万", "Mistranslation", MAJ, "5,000,000 (500万) becomes 50,000,000 (5000万) - same error as the Sprint 50 MT output."),
        targeted_error=("自创办以来，《洋葱圈》已经成为一个名副其实的恶搞新闻帝国，旗下拥有印刷版、网站（10月份吸引了500万独立访客）、个人广告、24小时新闻网络、播客，以及近期推出的世界地图集《我们的愚蠢世界》。", "洋葱圈", "Mistranslation", MAJ, "Publication name 'The Onion' becomes 'Onion Rings'."),
    ),
    # ------------------------------------------------------------------ terminology
    dict(
        source_id="S52_012", origin="sprint52", origin_ref="encmn_012", category="terminology",
        source_text="The quarterly earnings report exceeded analysts' expectations.",
        gold="季度财报超出了分析师的预期。",
        paraphrase="这份季报的业绩好于分析人士的预估。",
        literal="季度的收益报告超过了分析师们的期望。",
        fluent_wrong=("季度财报未达到分析师的预期。", "未达到", "Mistranslation", MAJ, "'Exceeded' becomes 'fell short of'."),
        targeted_error=("季度营收报告超出了分析师的预期。", "营收", "Mistranslation", MAJ, "'Earnings' (profit) rendered as 'revenue' - a finance terminology error."),
        padded="这份季度财务报告所呈现出的业绩表现，超出了分析师们事先所做出的预期。",
    ),
    dict(
        source_id="S52_013", origin="sprint52", origin_ref="encmn_013", category="terminology",
        source_text="Please restart the server if the application becomes unresponsive.",
        gold="如果应用程序无响应，请重启服务器。",
        paraphrase="一旦应用停止响应，请重新启动服务器。",
        literal="请重新启动服务器如果应用程序变得不响应。",
        fluent_wrong=("如果应用程序无响应，请关闭服务器。", "关闭", "Mistranslation", MAJ, "'Restart' becomes 'shut down'."),
        targeted_error=("如果应用程序无响应，请重启服务员。", "服务员", "Mistranslation", MAJ, "'Server' (computer) rendered as 'waiter'."),
    ),
    dict(
        source_id="A_1225", origin="sprint50", origin_ref="en_to_cmn_1225", category="terminology",
        source_text="Murray lost the first set in a tie break after both men held each and every serve in the set.",
        gold="在这一盘中双方都保住了自己的每一个发球局，最终穆雷在抢七中输掉了第一盘。",
        paraphrase="首盘两人均无一失守发球局，穆雷在抢七大战中落败，丢掉了这一盘。",
        literal="穆雷在一个抢七中输掉了第一盘，在两个人都保住了这一盘中的每一个发球局之后。",
        fluent_wrong=("在这一盘中双方都保住了自己的每一个发球局，最终穆雷在抢七中赢下了第一盘。", "赢下", "Mistranslation", MAJ, "'Lost' becomes 'won'."),
        targeted_error=("在这一盘中双方都保住了自己的每一个发球局，最终穆雷在平局中输掉了第一盘。", "平局", "Mistranslation", MAJ, "Tennis 'tie break' (抢七) rendered as 'a draw' (平局)."),
    ),
    dict(
        source_id="A_1676", origin="sprint50", origin_ref="en_to_cmn_1676", category="terminology",
        source_text="Although AI has a strong connotation of science fiction, AI forms a very important branch of computer science, dealing with behavior, learning and intelligent adaptation in a machine.",
        gold="尽管人工智能带有浓厚的科幻色彩，但它是计算机科学中一个非常重要的分支，研究机器的行为、学习和智能适应。",
        paraphrase="提起人工智能，人们常联想到科幻作品，但事实上它是计算机科学的一个重要分支，关注机器的行为方式、学习能力以及智能化的环境适应。",
        literal="虽然人工智能有一个科幻小说的强烈含义，人工智能形成计算机科学的一个非常重要的分支，处理在一台机器中的行为、学习和智能适应。",
        fluent_wrong=("尽管人工智能带有浓厚的科幻色彩，但它只是计算机科学中一个次要的分支，研究机器的行为、学习和智能适应。", "次要", "Mistranslation", MAJ, "'Very important branch' becomes 'minor branch'."),
        targeted_error=("尽管人工智能带有浓厚的科幻色彩，但它是计算机科学中一个非常重要的分支，研究机器的行为、学习和智能改编。", "改编", "Mistranslation", MAJ, "'Adaptation' (适应) rendered as 'adaptation of a work' (改编, e.g. film adaptation)."),
    ),
    dict(
        source_id="N_TERM1", origin="new_sprint53", origin_ref="", category="terminology",
        source_text="The patient was prescribed a broad-spectrum antibiotic after the blood test showed a bacterial infection.",
        gold="验血结果显示患者存在细菌感染，医生随后为其开了广谱抗生素。",
        paraphrase="血检提示细菌感染后，患者被开具了一种广谱抗菌药。",
        literal="病人被开了一种广谱的抗生素，在血液测试显示了一个细菌感染之后。",
        fluent_wrong=("验血结果显示患者存在病毒感染，医生随后为其开了广谱抗生素。", "病毒感染", "Mistranslation", MAJ, "'Bacterial' infection becomes 'viral'."),
        targeted_error=("验血结果显示患者存在细菌感染，医生随后为其开了宽频抗生素。", "宽频", "Mistranslation", MAJ, "Medical term 'broad-spectrum' (广谱) rendered as 'broadband' (宽频)."),
    ),
    # ------------------------------------------------------------------ idiom
    dict(
        source_id="S52_015", origin="sprint52", origin_ref="encmn_015", category="idiom",
        source_text="It's not exactly rocket science, but it does take practice.",
        gold="这事并不算多难，但确实需要练习。",
        paraphrase="这也不是什么高深的学问，不过的确得多加练习。",
        literal="这并不是一件特别困难的事情，但是它确实需要练习。",
        fluent_wrong=("这事其实很难，而且需要练习。", "其实很难", "Mistranslation", MAJ, "'Not hard' becomes 'actually very hard'."),
        targeted_error=("这和火箭科学没什么关系，但确实需要练习。", "和火箭科学没什么关系", "Mistranslation", MAJ, "Idiom read literally: 'this has nothing to do with rocket science'."),
        notes="The Sprint 52 original candidate (这不完全是火箭科学) is a calque; some Chinese speakers also say 又不是造火箭 colloquially - reviewer, please comment on how acceptable the calque is.",
    ),
    dict(
        source_id="S52_017", origin="sprint52", origin_ref="encmn_017", category="idiom",
        source_text="He let the cat out of the bag before the surprise party started.",
        gold="惊喜派对还没开始，他就把秘密说漏嘴了。",
        paraphrase="他在惊喜派对开场前就走漏了风声。",
        literal="他在惊喜派对开始之前就把秘密泄露了出来。",
        fluent_wrong=("惊喜派对结束后，他才把秘密说漏嘴。", "结束后", "Mistranslation", MAJ, "'Before the party started' becomes 'after the party ended'."),
        targeted_error=("惊喜派对还没开始，他就把事情搞砸了。", "把事情搞砸了", "Mistranslation", MAJ, "Idiom misread as 'messed things up' instead of 'revealed the secret'."),
    ),
    dict(
        source_id="S52_019", origin="sprint52", origin_ref="encmn_019", category="idiom",
        source_text="Break a leg tonight — I know you'll nail the audition.",
        gold="今晚祝你好运！我知道你一定能在试镜中大放异彩。",
        paraphrase="今晚好好表现，预祝成功——你的试镜肯定没问题。",
        literal="今晚祝你好运——我知道你会成功地完成这次试镜。",
        fluent_wrong=("今晚祝你好运！我担心你的试镜会不太顺利。", "我担心你的试镜会不太顺利", "Mistranslation", MAJ, "Confidence ('you'll nail it') becomes worry ('I'm afraid it won't go well')."),
        targeted_error=("今晚小心别受伤！我知道你一定能在试镜中大放异彩。", "小心别受伤", "Mistranslation", MAJ, "Idiom misread as a safety warning ('be careful not to get hurt')."),
    ),
    dict(
        source_id="N_IDI1", origin="new_sprint53", origin_ref="", category="idiom",
        source_text="After months of negotiations, the two companies finally decided to bury the hatchet.",
        gold="经过几个月的谈判，两家公司终于决定握手言和。",
        paraphrase="双方公司谈了好几个月，最后总算冰释前嫌。",
        literal="在几个月的谈判之后，这两家公司最终决定了和解。",
        fluent_wrong=("经过几个月的谈判，两家公司终于决定分道扬镳。", "分道扬镳", "Mistranslation", MAJ, "'Make peace' becomes 'part ways'."),
        targeted_error=("经过几个月的谈判，两家公司终于决定埋葬斧头。", "埋葬斧头", "Mistranslation", MAJ, "Idiom translated word-for-word ('bury the axe'), meaningless in Chinese."),
    ),
    dict(
        source_id="N_IDI2", origin="new_sprint53", origin_ref="", category="idiom",
        source_text="She's been feeling under the weather, so she'll work from home today.",
        gold="她最近身体不太舒服，所以今天在家办公。",
        paraphrase="她这几天有点不舒服，今天就居家工作了。",
        literal="她一直感觉身体不适，所以她今天将会从家里工作。",
        fluent_wrong=("她最近心情不太好，所以今天在家办公。", "心情不太好", "Mistranslation", MAJ, "'Unwell' becomes 'in a bad mood'."),
        targeted_error=("她最近被天气影响，所以今天在家办公。", "被天气影响", "Mistranslation", MAJ, "Idiom read literally: 'affected by the weather'."),
    ),
    # ------------------------------------------------------------------ culture
    dict(
        source_id="A_1779", origin="sprint50", origin_ref="en_to_cmn_1779", category="culture",
        source_text="For Australians, the idea of 'flat white' coffee is foreign. A short black is 'espresso', cappuccino comes heaped high with cream (not froth), and tea is served without milk.",
        gold="对澳大利亚人来说，“馥芮白”咖啡是个陌生的概念。小杯黑咖啡（short black）就是“意式浓缩”，卡布奇诺上面堆满了奶油（而不是奶泡），茶也是不加奶的。",
        paraphrase="在澳大利亚人眼里，“澳白”咖啡反倒是个外来的说法；在那里，short black指的就是意式浓缩，卡布奇诺顶上是厚厚一层奶油而非奶泡，茶则清饮，不放牛奶。",
        literal="对于澳大利亚人，“馥芮白”咖啡的想法是外国的。一个小杯黑咖啡是“意式浓缩”，卡布奇诺来的时候堆得高高的有奶油（不是泡沫），并且茶被端上来的时候没有牛奶。",
        fluent_wrong=("对澳大利亚人来说，“馥芮白”咖啡是个陌生的概念。小杯黑咖啡（short black）就是“意式浓缩”，卡布奇诺上面堆满了奶油（而不是奶泡），茶也总是配着牛奶上。", "总是配着牛奶上", "Mistranslation", MAJ, "Tea 'without milk' becomes 'always served with milk'."),
        targeted_error=("对澳大利亚人来说，“平白”咖啡是个陌生的概念。小杯黑咖啡（short black）就是“意式浓缩”，卡布奇诺上面堆满了奶油（而不是奶泡），茶也是不加奶的。", "平白", "Mistranslation", MAJ, "'Flat white' calqued as 平白 (which means 'for no reason') - same error as the Sprint 50 MT output."),
        notes="馥芮白 (Starbucks China term) and 澳白 (common café term) are both used for 'flat white'; paraphrase deliberately uses the other one. The source sentence itself is odd (flat white is an Australian drink) - kept verbatim from FLORES/SiniticMTError.",
    ),
    dict(
        source_id="N_CUL1", origin="new_sprint53", origin_ref="", category="culture",
        source_text="We're having turkey and pumpkin pie for Thanksgiving, just like every year.",
        gold="和往年一样，我们感恩节要吃火鸡和南瓜派。",
        paraphrase="今年感恩节照旧，餐桌上少不了火鸡和南瓜派。",
        literal="我们将要为了感恩节吃火鸡和南瓜派，就像每一年一样。",
        fluent_wrong=("和往年不同，我们感恩节要吃火鸡和南瓜派。", "和往年不同", "Mistranslation", MAJ, "'Just like every year' becomes 'unlike previous years'."),
        targeted_error=("和往年一样，我们中秋节要吃火鸡和南瓜派。", "中秋节", "Mistranslation", MAJ, "Over-localisation: Thanksgiving replaced by Mid-Autumn Festival."),
        padded="就和以往的每一年都一样，在感恩节这一天，我们还是会吃火鸡以及南瓜派。",
    ),
    dict(
        source_id="N_CUL2", origin="new_sprint53", origin_ref="", category="culture",
        source_text="He sat for the SATs twice before getting into college.",
        gold="他考了两次SAT才上了大学。",
        paraphrase="他参加过两回美国大学入学考试（SAT），之后才被大学录取。",
        literal="在进入大学之前，他参加了SAT考试两次。",
        fluent_wrong=("他考了两次SAT都没能上大学。", "都没能上大学", "Mistranslation", MAJ, "'Before getting into college' becomes 'still didn't get into college'."),
        targeted_error=("他考了两次高考才上了大学。", "高考", "Mistranslation", MAJ, "Over-localisation: SAT replaced by China's gaokao."),
    ),
    dict(
        source_id="N_CUL3", origin="new_sprint53", origin_ref="", category="culture",
        source_text="The store is having a Black Friday sale, with everything 40% off.",
        gold="这家店正在搞黑色星期五促销，全场六折。",
        paraphrase="黑五期间，这家商店所有商品一律打六折。",
        literal="这家商店正在举行一个黑色星期五的销售，所有东西都减价40%。",
        fluent_wrong=("这家店正在搞黑色星期五促销，部分商品六折。", "部分商品", "Mistranslation", MAJ, "'Everything' becomes 'some items'."),
        targeted_error=("这家店正在搞黑色星期五促销，全场四折。", "四折", "Mistranslation", MAJ, "Discount convention error: '40% off' = 六折 (pay 60%); 四折 means pay 40% (60% off)."),
    ),
    dict(
        source_id="N_CUL4", origin="new_sprint53", origin_ref="", category="culture",
        source_text="Don't forget to tip the waiter; 20% is standard here.",
        gold="别忘了给服务员小费，这里一般给20%。",
        paraphrase="记得给服务生留小费，在这儿按惯例是两成。",
        literal="不要忘记给服务员小费；20%在这里是标准的。",
        fluent_wrong=("别忘了给服务员小费，这里最多给20%。", "最多", "Mistranslation", MAJ, "'Standard' becomes 'at most'."),
        targeted_error=("别忘了给服务员提示，这里一般给20%。", "提示", "Mistranslation", MAJ, "'Tip' (gratuity) rendered as 'hint' (提示)."),
    ),
    # ------------------------------------------------------------ ambiguity_context
    dict(
        source_id="S52_018", origin="sprint52", origin_ref="encmn_018", category="ambiguity_context",
        source_text="The bank on the corner is closed for renovations, so I couldn't deposit the check by the river.",
        gold="河边街角的那家银行正在装修，暂停营业，所以我没能存那张支票。",
        paraphrase="由于街角靠河的那家银行关门装修，我那张支票没存成。",
        literal="在角落上的银行因为装修而关闭，所以我不能在河边存入那张支票。",
        fluent_wrong=("河边街角的那家银行正在装修，暂停营业，所以我没能兑现那张支票。", "兑现", "Mistranslation", MAJ, "'Deposit' the check becomes 'cash' the check."),
        targeted_error=("河边街角的那家银行正在装修，暂停营业，所以我没能存那张账单。", "账单", "Mistranslation", MAJ, "'Check' read in the other sense ('restaurant bill')."),
        notes="The source has an attachment ambiguity: 'by the river' can attach to the bank or to depositing. Gold attaches it to the bank; literal keeps the surface attachment. Reviewer: please say if you read it differently.",
    ),
    dict(
        source_id="N_AMB1", origin="new_sprint53", origin_ref="", category="ambiguity_context",
        source_text="The pitcher was full, so she poured the extra lemonade into a glass.",
        gold="水壶已经满了，所以她把多出来的柠檬水倒进了一个玻璃杯里。",
        paraphrase="壶里装不下了，她就把剩下的柠檬水倒到杯子里。",
        literal="那个水罐是满的，所以她把额外的柠檬水倒进了一个玻璃杯。",
        fluent_wrong=("水壶已经空了，所以她把多出来的柠檬水倒进了一个玻璃杯里。", "空了", "Mistranslation", MAJ, "'Full' becomes 'empty'."),
        targeted_error=("投手已经吃饱了，所以她把多出来的柠檬水倒进了一个玻璃杯里。", "投手已经吃饱了", "Mistranslation", MAJ, "'Pitcher' read as the baseball player and 'full' as 'full from eating'."),
        padded="因为水壶里面已经装满了，所以她就把多出来的那些柠檬水倒进了一个玻璃杯之中。",
    ),
    dict(
        source_id="N_AMB2", origin="new_sprint53", origin_ref="", category="ambiguity_context",
        source_text="Can you run the numbers before the meeting? The client wants a quote by Friday.",
        gold="你能在开会前把数据算一下吗？客户希望周五前拿到报价。",
        paraphrase="开会之前麻烦你核算一下这些数字，客户要求周五之前给出报价。",
        literal="你能够在会议之前计算这些数字吗？那个客户想要在星期五之前得到一个报价。",
        fluent_wrong=("你能在开会前把数据算一下吗？客户希望周五后拿到报价。", "周五后", "Mistranslation", MAJ, "'By Friday' becomes 'after Friday'."),
        targeted_error=("你能在开会前把数据算一下吗？客户希望周五前拿到一段引言。", "一段引言", "Mistranslation", MAJ, "'Quote' (price quotation) read as 'a quotation/citation'."),
    ),
    dict(
        source_id="N_AMB3", origin="new_sprint53", origin_ref="", category="ambiguity_context",
        source_text="He left his glasses on the table and couldn't read the menu.",
        gold="他把眼镜落在桌上了，所以看不清菜单。",
        paraphrase="眼镜忘在桌子上，他连菜单都看不了。",
        literal="他把他的眼镜留在了桌子上，并且不能阅读菜单。",
        fluent_wrong=("他把眼镜落在桌上了，所以看不清地图。", "地图", "Mistranslation", MAJ, "'Menu' becomes 'map'."),
        targeted_error=("他把玻璃杯落在桌上了，所以看不清菜单。", "玻璃杯", "Mistranslation", MAJ, "'Glasses' (spectacles) read as 'drinking glasses'."),
    ),
    dict(
        source_id="N_AMB4", origin="new_sprint53", origin_ref="", category="ambiguity_context",
        source_text="The match was postponed because the field was flooded.",
        gold="由于球场被水淹了，比赛延期了。",
        paraphrase="场地积水严重，这场比赛只好改期。",
        literal="比赛被推迟了，因为场地被淹了。",
        fluent_wrong=("由于球场被水淹了，比赛取消了。", "取消了", "Mistranslation", MAJ, "'Postponed' becomes 'cancelled'."),
        targeted_error=("由于农田被水淹了，比赛延期了。", "农田", "Mistranslation", MAJ, "'Field' (pitch) read as 'farmland'."),
    ),
    # ------------------------------------------------------------------ register
    dict(
        source_id="S52_014", origin="sprint52", origin_ref="encmn_014", category="register",
        source_text="The new policy will take effect next Monday, pending final approval.",
        gold="新政策待最终批准后，将于下周一生效。",
        paraphrase="如获最终审批通过，这项新政将从下周一起开始实施。",
        literal="新的政策将会在下个星期一生效，等待最终的批准。",
        fluent_wrong=("新政策已获最终批准，将于下周一生效。", "已获最终批准", "Mistranslation", MAJ, "'Pending approval' becomes 'already approved'."),
        targeted_error=("新规矩下礼拜一就管用了，就等上头最后点头。", "新规矩下礼拜一就管用了", "Style/Register", MIN, "Meaning kept, but an official announcement is rendered in very colloquial speech."),
    ),
    dict(
        source_id="S52_016", origin="sprint52", origin_ref="encmn_016", category="register",
        source_text="The committee postponed the vote until further notice.",
        gold="委员会宣布推迟表决，具体时间另行通知。",
        paraphrase="表决已被委员会暂缓，何时举行将另行通知。",
        literal="委员会把投票推迟了直到进一步的通知。",
        fluent_wrong=("委员会宣布将表决推迟到下周进行。", "推迟到下周", "Mistranslation", MAJ, "'Until further notice' becomes 'until next week'."),
        targeted_error=("委员会说投票的事先放放，啥时候再弄等通知吧。", "啥时候再弄等通知吧", "Style/Register", MIN, "Meaning kept, but formal notice rendered in casual speech."),
    ),
    dict(
        source_id="S52_020", origin="sprint52", origin_ref="encmn_020", category="register",
        source_text="The CFO's remarks were, to put it mildly, a bit disingenuous.",
        gold="说得客气一点，首席财务官的那番话有些言不由衷。",
        paraphrase="首席财务官的发言，委婉地说，不太坦诚。",
        literal="首席财务官的言论是，委婉地说，有一点不诚恳的。",
        fluent_wrong=("说得客气一点，首席财务官的那番话十分坦率。", "十分坦率", "Mistranslation", MAJ, "'Disingenuous' becomes 'very candid'."),
        targeted_error=("说白了，那个管钱的老总就是在忽悠人。", "那个管钱的老总就是在忽悠人", "Style/Register", MAJ, "Hedged, formal criticism becomes blunt slang; the hedge 'to put it mildly' is lost (tone reversal)."),
    ),
    dict(
        source_id="N_REG1", origin="new_sprint53", origin_ref="", category="register",
        source_text="We regret to inform you that your application has not been successful.",
        gold="很遗憾地通知您，您的申请未获通过。",
        paraphrase="我们很遗憾地告知，您此次的申请未能通过。",
        literal="我们感到遗憾地告知你，你的申请没有成功。",
        fluent_wrong=("很高兴地通知您，您的申请未获通过。", "很高兴", "Mistranslation", MAJ, "'Regret' becomes 'are pleased'."),
        targeted_error=("跟你说一声，你的申请没戏了。", "你的申请没戏了", "Style/Register", MAJ, "Formal rejection letter rendered as slang."),
    ),
    dict(
        source_id="N_REG2", origin="new_sprint53", origin_ref="", category="register",
        source_text="Hey, you up? Wanna grab some food?",
        gold="嘿，醒着没？要不要一起去吃点东西？",
        paraphrase="在吗？出去吃点啥不？",
        literal="嘿，你起床了吗？想要去吃一些食物吗？",
        fluent_wrong=("嘿，醒着没？要不要一起去买点菜？", "买点菜", "Mistranslation", MAJ, "'Grab some food' (eat) becomes 'buy groceries'."),
        targeted_error=("您好，请问您是否已起床？是否有意共进餐食？", "是否有意共进餐食", "Style/Register", MIN, "Casual text message rendered in stiff, formal written register."),
    ),
]

# Sources that get Traditional-script variants (30 of 40). The 4 simple controls and
# 6 others are left out to keep the review load manageable.
TRADITIONAL_SOURCES = [
    "S52_006", "A_375", "A_43", "A_1741", "N_NUM1",
    "S52_003", "A_386", "A_1106", "A_1727", "A_126",
    "S52_012", "S52_013", "A_1225", "A_1676", "N_TERM1",
    "S52_015", "S52_017", "S52_019", "N_IDI1", "N_IDI2",
    "A_1779", "N_CUL1", "N_CUL3", "N_CUL4",
    "S52_018", "N_AMB1", "N_AMB3",
    "S52_014", "S52_020", "N_REG1",
]

# Expected holistic quality (what a careful human would give on a 0-100 scale), per
# variant. MQM-derived expectations are computed separately from the planted error.
EXPECTED_QUALITY = {
    "gold":            ("clean", 90, 100),
    "paraphrase":      ("clean", 90, 100),
    "literal":         ("moderate", 65, 85),
    "padded":          ("clean", 80, 100),
    "fluent_wrong":    ("poor", 20, 60),
    "targeted_error":  ("poor", 20, 60),   # overridden to moderate for minor errors
    "traditional_char": ("clean", 90, 100),  # if the prompt does not require Simplified
    "traditional_tw":   ("clean", 90, 100),
}

# Expected band for the 16 Sprint 52 original candidates, from their seeding notes.
SPRINT52_ORIGINAL_BANDS = {
    "encmn_004": ("poor", 0, 50, "Password transliterated/misspelled (Muriel vs Muiriel) - the password becomes wrong.", CRIT),
    "encmn_014": ("poor", 30, 65, "Omission of 'pending final approval' changes the legal meaning.", MAJ),
    "encmn_015": ("moderate", 55, 80, "Idiom 'rocket science' calqued; meaning partly conveyed.", MIN),
    "encmn_017": ("poor", 0, 40, "Idiom translated literally ('released the cat from the bag'); meaning lost.", CRIT),
    "encmn_018": ("poor", 0, 40, "'Bank' rendered as riverbank twice; sentence incoherent.", CRIT),
    "encmn_019": ("poor", 0, 40, "'Break a leg' rendered as a literal wish to break a leg.", CRIT),
    "encmn_020": ("clean", 80, 95, "Faithful; 不诚恳 is slightly plain for 'disingenuous'.", MIN),
}

# Taiwan-localised versions of gold, written by hand (script + Taiwan vocabulary +
# 「」 quotation marks). Automatic OpenCC s2twp conversion was tried first but changed
# only 6 of 30 sentences and got 2 of those wrong (菜單→選單 'software menu',
# 通過→透過 'by means of'), so it is kept only as a comparison field.
# Sources not listed here have no Taiwan-specific vocabulary difference, so their
# Taiwan version would be identical to the character-only conversion and is skipped.
TAIWAN_LOCALISED = {
    "A_375":   "一個在地球上重200磅（90公斤）的人，到了木衛一上體重只有約36磅（16公斤）。因此，那裡的引力對你的拉力自然更小。",
    "A_43":    "預報員稱，這場風暴位於維德角群島以西約645英里（1040公里）處，很可能在對任何陸地構成威脅之前就會消散。",
    "A_1741":  "橋下的垂直淨高為15公尺。大橋於2011年8月完工，但直到2017年3月才通車。",
    "A_1106":  "29歲的馬拉爾·巴拉蘇布拉馬尼安醫師被發現躺在俄亥俄州布盧阿什的路邊地上。布盧阿什是辛辛那提以北約15英里的一個郊區。被發現時，她身穿T恤和內褲，顯然服用了大量藥物。",
    "A_126":   "自創辦以來，《洋蔥報》已經成為一個名副其實的惡搞新聞帝國，旗下擁有印刷版、網站（10月份吸引了500萬名不重複訪客）、個人廣告、24小時新聞網路、Podcast，以及近期推出的世界地圖集《我們的愚蠢世界》。",
    "S52_013": "如果應用程式沒有回應，請重新啟動伺服器。",
    "A_1225":  "在這一盤中雙方都保住了自己的每一個發球局，最終莫瑞在搶七中輸掉了第一盤。",
    "A_1676":  "儘管人工智慧帶有濃厚的科幻色彩，但它是電腦科學中一個非常重要的分支，研究機器的行為、學習和智慧適應。",
    "N_TERM1": "驗血結果顯示患者有細菌感染，醫師隨後為其開了廣效抗生素。",
    "A_1779":  "對澳洲人來說，「馥芮白」咖啡是個陌生的概念。小杯黑咖啡（short black）就是「義式濃縮」，卡布奇諾上面堆滿了奶油（而不是奶泡），茶也是不加奶的。",
    "N_CUL3":  "這家店正在辦黑色星期五特賣，全館六折。",
    "N_CUL4":  "別忘了給服務生小費，這裡一般給20%。",
    "S52_018": "河邊街角的那家銀行正在整修，暫停營業，所以我沒能存那張支票。",
    "S52_020": "說得客氣一點，財務長的那番話有些言不由衷。",
}
