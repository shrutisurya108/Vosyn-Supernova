"""
Step 1 - validate the Sprint 53 datasets before they go to review / get used.

Checks
  1. Schema: required fields present, no duplicate IDs.
  2. Planted errors: every planted span appears verbatim in its candidate.
  3. Planted errors are the ONLY change: fluent_wrong / targeted_error differ from gold
     in a small region (reported, not enforced - register errors rewrite the sentence).
  4. Script: Simplified rows contain no Traditional-only characters; Traditional rows
     contain no Simplified-only characters (checked with OpenCC round-trips).
  5. Paraphrase really is lexically different: chrF(paraphrase, gold) is reported and
     flagged if >= 60 (we want paraphrases the judge cannot match by surface overlap).
  6. Coverage: >= 5 sources per non-control category; each source has all core variants.
  7. Pairs: both item IDs exist and texts match.

Writes data/processed/validation_report.txt and exits non-zero if a hard check fails.

Run:  python scripts/validate_datasets.py
Needs: pip install opencc-python-reimplemented   (chrF comes from scripts/chrf.py)
"""
import json
import os
import sys
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, "data", "processed")

CORE_VARIANTS = ["gold", "paraphrase", "literal", "fluent_wrong", "targeted_error"]
REQUIRED_B = ["item_id", "source_id", "category", "variant_type", "script", "source_text",
              "candidate", "reference", "expected_quality_band", "expected_quality_range"]
PARAPHRASE_CHRF_FLAG = 60.0


def read_jsonl(name):
    with open(os.path.join(P, name), encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def main():
    import opencc
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from chrf import chrf  # pure-Python, identical to sacrebleu CHRF() defaults
    s2t, t2s = opencc.OpenCC("s2tw"), opencc.OpenCC("tw2s")

    seta, setb, pairs = read_jsonl("setA_items.jsonl"), read_jsonl("setB_items.jsonl"), read_jsonl("pairs.jsonl")
    hard, soft, lines = [], [], []

    # 1. schema + ids
    ids = [r["item_id"] for r in seta + setb]
    dup = [i for i, c in Counter(ids).items() if c > 1]
    if dup:
        hard.append(f"duplicate item_ids: {dup}")
    for r in setb:
        miss = [k for k in REQUIRED_B if k not in r or r[k] in (None, "")]
        if miss:
            hard.append(f"{r['item_id']} missing {miss}")

    # 2/3. planted errors
    by = {(r["source_id"], r["variant_type"]): r for r in setb}
    for r in setb:
        pe = r.get("planted_error")
        if r["variant_type"] in ("fluent_wrong", "targeted_error"):
            if not pe or not pe.get("span"):
                hard.append(f"{r['item_id']} has no planted span")
            elif pe["span"] not in r["candidate"]:
                hard.append(f"{r['item_id']} span '{pe['span']}' not in candidate")
            gold = by[(r["source_id"], "gold")]["candidate"]
            if r["candidate"] == gold:
                hard.append(f"{r['item_id']} identical to gold")

    # 3b. a row expected to be moderate/poor must not be identical to the gold text
    for r in setb:
        if r["variant_type"] != "gold" and r["expected_quality_band"] in ("moderate", "poor"):
            if r["candidate"] == by[(r["source_id"], "gold")]["candidate"]:
                hard.append(f"{r['item_id']} is expected '{r['expected_quality_band']}' but its text equals gold")

    # 4. script purity - character level.
    #    A char is "Traditional-only" if s2t leaves it alone but t2s changes it, and
    #    "Simplified-only" if t2s leaves it alone but s2t changes it. OpenCC has a few
    #    one-to-many quirks (e.g. tw2s maps 么->幺), so we test each char, not the string.
    #    BOTH_OK: characters that are correct in both scripts in context (里 in names,
    #    e.g. 穆里爾, but s2tw would turn it into 裡; 准 in 批准).
    #    S52_004 paraphrase is expected to be lexically close: the password must stay verbatim.
    BOTH_OK = set("里准")  # 准 is correct Traditional in 批准 (approve)
    for r in setb:
        c = r["candidate"]
        trad_only = [ch for ch in c if s2t.convert(ch) == ch and t2s.convert(ch) != ch]
        simp_only = [ch for ch in c if t2s.convert(ch) == ch and s2t.convert(ch) != ch and ch not in BOTH_OK]
        if r["script"] == "simplified" and trad_only:
            hard.append(f"{r['item_id']} simplified row contains Traditional chars {trad_only}")
        if r["script"] != "simplified":
            if simp_only:
                hard.append(f"{r['item_id']} traditional row contains Simplified-only chars {simp_only}")
            if not trad_only:
                hard.append(f"{r['item_id']} traditional row has no Traditional characters")

    # 5. paraphrase distance
    para_scores = []
    for sid in sorted({r["source_id"] for r in setb}):
        if (sid, "paraphrase") in by:
            g, p = by[(sid, "gold")]["candidate"], by[(sid, "paraphrase")]["candidate"]
            sc = chrf(p, g)
            para_scores.append((sid, round(sc, 1)))
            if sc >= PARAPHRASE_CHRF_FLAG:
                soft.append(f"{sid} paraphrase chrF vs gold = {sc:.1f} (>= {PARAPHRASE_CHRF_FLAG}); lexically close")

    # 6. coverage
    cats = Counter()
    per_source = defaultdict(set)
    for r in setb:
        per_source[r["source_id"]].add(r["variant_type"])
    for sid, vs in per_source.items():
        missing = [v for v in CORE_VARIANTS if v not in vs]
        if missing:
            hard.append(f"{sid} missing variants {missing}")
    for sid in per_source:
        cats[by[(sid, "gold")]["category"]] += 1
    for c, n in cats.items():
        if c != "simple_control" and n < 5:
            hard.append(f"category {c} has only {n} sources")

    # 7. pairs
    items = {r["item_id"]: r for r in setb}
    for p in pairs:
        for side in ("a", "b"):
            it = items.get(p[f"{side}_item_id"])
            if not it or it["candidate"] != p[f"{side}_text"]:
                hard.append(f"{p['pair_id']} side {side} does not match Set B")

    # Set A sanity
    if len(seta) != 40:
        hard.append(f"Set A has {len(seta)} items, expected 40")

    # ---- report
    lines.append("SPRINT 53 - DATASET VALIDATION REPORT")
    lines.append("=" * 60)
    lines.append(f"Set A items: {len(seta)}  (human score range {min(r['human_score'] for r in seta)}-"
                 f"{max(r['human_score'] for r in seta)}; buckets {dict(Counter(r['human_bucket'] for r in seta))})")
    lines.append(f"Set B items: {len(setb)} from {len(per_source)} sources")
    lines.append(f"  variants: {dict(Counter(r['variant_type'] for r in setb))}")
    lines.append(f"  scripts:  {dict(Counter(r['script'] for r in setb))}")
    lines.append(f"  sources per category: {dict(cats)}")
    lines.append(f"  expected quality bands: {dict(Counter(r['expected_quality_band'] for r in setb))}")
    lines.append(f"  planted error severities: "
                 f"{dict(Counter(r['planted_error']['severity'] for r in setb if r.get('planted_error')))}")
    lines.append(f"Pairs: {len(pairs)}  {dict(Counter(p['pair_type'] for p in pairs))}")
    vals = [s for _, s in para_scores]
    lines.append(f"Paraphrase chrF vs gold: min {min(vals)}, median {sorted(vals)[len(vals)//2]}, max {max(vals)} "
                 f"(flag threshold {PARAPHRASE_CHRF_FLAG})")
    lines.append("")
    lines.append(f"HARD FAILURES: {len(hard)}")
    lines += [f"  - {h}" for h in hard]
    lines.append(f"WARNINGS: {len(soft)}")
    lines += [f"  - {s}" for s in soft]
    lines.append("")
    lines.append("Paraphrase chrF per source: " + ", ".join(f"{s}={v}" for s, v in para_scores))
    report = "\n".join(lines)
    with open(os.path.join(P, "validation_report.txt"), "w", encoding="utf-8") as f:
        f.write(report + "\n")
    print(report)
    sys.exit(1 if hard else 0)


if __name__ == "__main__":
    main()
