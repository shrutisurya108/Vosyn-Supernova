"""
Step 1 - build the Sprint 53 datasets.

Inputs  (data/raw/):
    sprint50_gold_en_cmn.jsonl   - Sprint 50 gold set (40 items, human MQM scores)
    sprint52_en_to_cmn.jsonl     - Sprint 52 human-review set (20 items)
    scripts/setb_content.py      - hand-written Set B variants

Outputs (data/processed/):
    setA_items.jsonl   - 40 Sprint 50 items, normalised (accuracy anchor)
    setB_items.jsonl   - controlled variants for 40 English sources
    pairs.jsonl        - 60 A/B pairs for the position-bias experiment

Run:  python scripts/build_datasets.py
Needs: pip install opencc-python-reimplemented
"""
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from setb_content import (SOURCES, TRADITIONAL_SOURCES, EXPECTED_QUALITY,  # noqa: E402
                          SPRINT52_ORIGINAL_BANDS, TAIWAN_LOCALISED)

RAW = os.path.join(ROOT, "data", "raw")
OUT = os.path.join(ROOT, "data", "processed")
os.makedirs(OUT, exist_ok=True)

SEED = 42
SEVERITY_WEIGHTS = {"minor": 1, "major": 5, "critical": 25, "neutral": 0}  # same as Sprint 50
BUCKETS = [(85, 101, "clean"), (60, 85, "moderate"), (0, 60, "poor")]    # same as Sprint 50


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def bucket(score):
    for lo, hi, name in BUCKETS:
        if lo <= score < hi:
            return name
    return BUCKETS[-1][2]


def human_mqm(spans):
    return max(0, 100 - sum(SEVERITY_WEIGHTS.get((s.get("error_severity") or "minor").lower(), 1) for s in spans))


# ----------------------------------------------------------------------------- Set A
def build_set_a(gold_rows):
    rows = []
    for g in gold_rows:
        assert human_mqm(g["human_error_spans"]) == g["human_score"], g["gold_id"]
        rows.append({
            "item_id": f"A::{g['gold_id']}",
            "set": "A",
            "source_id": f"A_{g['gold_id'].split('_')[-1]}",
            "source_text": g["source_text"],
            "candidate": g["mt_text"],
            "reference": g["reference_text"],
            "human_score": g["human_score"],
            "human_bucket": bucket(g["human_score"]),
            "human_error_spans": g["human_error_spans"],
            "n_errors": len(g["human_error_spans"]),
            "origin": "sprint50_gold (SiniticMTError, human bilingual annotators)",
        })
    return rows


# ----------------------------------------------------------------------------- Set B
def expected_mqm(planted):
    """Expected score if a judge found exactly the planted error(s), using Sprint 50's formula."""
    if not planted:
        return None
    return max(0, 100 - SEVERITY_WEIGHTS[planted["severity"]])


def make_row(src, variant_type, candidate, script="simplified", planted=None,
             band=None, lo=None, hi=None, extra=None):
    if band is None:
        band, lo, hi = EXPECTED_QUALITY[variant_type]
    row = {
        "item_id": f"B::{src['source_id']}::{variant_type}",
        "set": "B",
        "source_id": src["source_id"],
        "source_origin": src["origin"],
        "source_origin_ref": src["origin_ref"],
        "category": src["category"],
        "variant_type": variant_type,
        "script": script,
        "source_text": src["source_text"],
        "candidate": candidate,
        "reference": src["gold"],
        "expected_quality_band": band,
        "expected_quality_range": [lo, hi],
        "planted_error": planted,
        "expected_mqm_score": expected_mqm(planted) if planted else None,
        "author": "claude_opus_5.5_sprint53" if variant_type != "original_candidate" else None,
        "review_status": "pending",
        "notes": src.get("notes", ""),
    }
    if extra:
        row.update(extra)
    return row


def planted_dict(t):
    text, span, etype, sev, desc = t
    return {"span": span, "type": etype, "severity": sev, "description": desc}


def build_set_b(gold_by_id, s52_by_id):
    import opencc
    to_trad = opencc.OpenCC("s2tw")    # character conversion only (Taiwan standard glyphs)
    to_tw = opencc.OpenCC("s2twp")     # character conversion + Taiwan vocabulary

    rows = []
    for src in SOURCES:
        # --- check source text against the raw files, and add original candidates
        if src["origin"] == "sprint50":
            g = gold_by_id[src["origin_ref"]]
            assert g["source_text"] == src["source_text"], f"source text mismatch {src['source_id']}"
            rows.append(make_row(
                src, "original_candidate", g["mt_text"],
                band=bucket(g["human_score"]), lo=g["human_score"], hi=g["human_score"],
                extra={"author": "sprint50_mt_output", "human_score": g["human_score"],
                       "human_error_spans": g["human_error_spans"],
                       "sprint50_reference": g["reference_text"],
                       "review_status": "not_needed (human-labelled in Sprint 50)"}))
        elif src["origin"] == "sprint52":
            s = s52_by_id[src["origin_ref"]]
            assert s["source_text"] == src["source_text"], f"source text mismatch {src['source_id']}"
            if src["origin_ref"] in SPRINT52_ORIGINAL_BANDS:
                band, lo, hi, desc, sev = SPRINT52_ORIGINAL_BANDS[src["origin_ref"]]
                planted = {"span": None, "type": "see description", "severity": sev,
                           "description": desc}
            else:
                band, lo, hi, planted = "clean", 85, 100, None
            rows.append(make_row(
                src, "original_candidate", s["candidate_translation"], planted=planted,
                band=band, lo=lo, hi=hi,
                extra={"author": s["candidate_generated_by"]}))

        # --- hand-written variants
        rows.append(make_row(src, "gold", src["gold"]))
        rows.append(make_row(src, "paraphrase", src["paraphrase"]))
        rows.append(make_row(src, "literal", src["literal"]))
        for vt in ("fluent_wrong", "targeted_error"):
            p = planted_dict(src[vt])
            if p["severity"] == "minor":
                row = make_row(src, vt, src[vt][0], planted=p, band="moderate", lo=65, hi=85)
            else:
                row = make_row(src, vt, src[vt][0], planted=p)
            rows.append(row)
        if src.get("padded"):
            rows.append(make_row(src, "padded", src["padded"]))

        # --- Traditional-script variants of gold
        if src["source_id"] in TRADITIONAL_SOURCES:
            trad = to_trad.convert(src["gold"])
            rows.append(make_row(src, "traditional_char", trad, script="traditional_char",
                                 extra={"conversion": "OpenCC s2tw (characters only, punctuation unchanged)"}))
            if src["source_id"] in TAIWAN_LOCALISED:
                tw = TAIWAN_LOCALISED[src["source_id"]]
                rows.append(make_row(src, "traditional_tw", tw, script="traditional_tw",
                                     extra={"conversion": "hand-localised for Taiwan (vocabulary + 「」 quotes)",
                                            "tw_vocab_changes": diff_words(trad, tw),
                                            "opencc_s2twp_output": to_tw.convert(src["gold"])}))
    return rows


def diff_words(a, b):
    """Rough list of the spans where the Taiwan-vocabulary version differs from char-only."""
    import difflib
    sm = difflib.SequenceMatcher(None, a, b)
    return [f"{a[i1:i2]}→{b[j1:j2]}" for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag != "equal"]


# ----------------------------------------------------------------------------- pairs
PAIR_PLAN = [
    # (pair_type, variant_a, variant_b, expected_preference, n)
    ("gold_vs_paraphrase", "gold", "paraphrase", "tie", 20),
    ("literal_vs_fluent_wrong", "literal", "fluent_wrong", "a", 15),
    ("gold_vs_targeted_error", "gold", "targeted_error", "a", 10),
    ("simplified_vs_traditional_char", "gold", "traditional_char", "tie", 5),
    ("simplified_vs_traditional_tw", "gold", "traditional_tw", "tie", 5),
    ("concise_vs_padded", "gold", "padded", "a_or_tie", 5),
]


def build_pairs(setb):
    rng = random.Random(SEED)
    by = {(r["source_id"], r["variant_type"]): r for r in setb}
    source_ids = [s["source_id"] for s in SOURCES]
    pairs = []
    for ptype, va, vb, pref, n in PAIR_PLAN:
        eligible = [sid for sid in source_ids if (sid, va) in by and (sid, vb) in by]
        chosen = sorted(rng.sample(eligible, min(n, len(eligible))), key=source_ids.index)
        for sid in chosen:
            a, b = by[(sid, va)], by[(sid, vb)]
            pairs.append({
                "pair_id": f"P::{ptype}::{sid}",
                "pair_type": ptype,
                "source_id": sid,
                "category": a["category"],
                "source_text": a["source_text"],
                "a_item_id": a["item_id"], "a_text": a["candidate"],
                "b_item_id": b["item_id"], "b_text": b["candidate"],
                "expected_preference": pref,
                "note": "The experiment runner shows every pair in BOTH orders (A,B) and (B,A).",
            })
    return pairs


def main():
    gold = read_jsonl(os.path.join(RAW, "sprint50_gold_en_cmn.jsonl"))
    s52 = read_jsonl(os.path.join(RAW, "sprint52_en_to_cmn.jsonl"))
    gold_by_id = {g["gold_id"]: g for g in gold}
    s52_by_id = {s["example_id"]: s for s in s52}

    seta = build_set_a(gold)
    setb = build_set_b(gold_by_id, s52_by_id)
    pairs = build_pairs(setb)

    write_jsonl(os.path.join(OUT, "setA_items.jsonl"), seta)
    write_jsonl(os.path.join(OUT, "setB_items.jsonl"), setb)
    write_jsonl(os.path.join(OUT, "pairs.jsonl"), pairs)

    from collections import Counter
    print(f"Set A: {len(seta)} items")
    print(f"Set B: {len(setb)} items from {len(SOURCES)} sources")
    print("  by variant:", dict(Counter(r["variant_type"] for r in setb)))
    print("  sources by category:", dict(Counter(s["category"] for s in SOURCES)))
    print(f"Pairs: {len(pairs)}  by type:", dict(Counter(p["pair_type"] for p in pairs)))


if __name__ == "__main__":
    main()
