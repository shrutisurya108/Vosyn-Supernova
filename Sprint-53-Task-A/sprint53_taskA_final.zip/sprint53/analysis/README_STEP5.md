# Sprint 53 · Step 5 — Analysis

Re-runs the whole analysis from `results/*.jsonl` (CPU only, ~30 s, deterministic).

```bash
pip install pandas scipy matplotlib
python analysis/analyze.py      # tables -> analysis_out/tables, charts -> analysis_out/charts, metrics.json
python analysis/examples.py     # example gallery -> analysis_out/examples.md
```

Inputs it needs: `results/`, `data/processed/`, `scripts/chrf.py`, and (optional, for the Sprint 50 comparison)
`data/raw/sprint50_agreement_detail.json`. The manual reasoning audit labels are in `analysis/manual_audit_labels.csv`;
the 50 audited outputs are in `analysis_out/E10_audit_sample.csv`.
