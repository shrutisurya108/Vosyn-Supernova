"""
Sprint 53 - Step 5 analysis. Turns results/*.jsonl into tables, charts, headline metrics and
an example gallery. CPU only, deterministic (bootstrap seed 42), safe to re-run.

  pip install pandas scipy matplotlib
  python analysis/analyze.py            # writes analysis_out/

Definitions used everywhere (agreed in Step 5):
  * band:          clean >= 85, moderate 60-84, poor < 60 (Sprint 50 buckets), on 0-100 scores
  * inconsistent:  repeated runs of the same (model, prompt, temperature, item) differ by
                   >= 10 points OR land in more than one band
  * ground truth:  Set A -> human MQM score (SiniticMTError); Set B -> reviewer-confirmed band
  * detected:      a listed error span contains the planted span (or lies inside it) and is
                   not a whole-sentence quote (<= 3x the planted span length, +6 chars)
  * rho:           Spearman rank correlation; 95% CI from 2,000 item-level bootstrap resamples
"""
import itertools
import json
import os
import re
import sys
from collections import Counter

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from chrf import chrf  # noqa: E402

RES = os.path.join(ROOT, "results")
DATA = os.path.join(ROOT, "data", "processed")
OUT = os.path.join(ROOT, "analysis_out")
TAB, FIG = os.path.join(OUT, "tables"), os.path.join(OUT, "charts")
for d in (TAB, FIG):
    os.makedirs(d, exist_ok=True)

MODELS = ["glm4", "qwen"]
RNG = np.random.default_rng(42)
M = {}  # headline metrics -> metrics.json


# ============================================================================ helpers
def band(s):
    return "clean" if s >= 85 else ("moderate" if s >= 60 else "poor")


def rho(x, y):
    return float(spearmanr(x, y).statistic)


def rho_ci(x, y, n=2000):
    x, y = np.asarray(x, float), np.asarray(y, float)
    vals = []
    for _ in range(n):
        i = RNG.integers(0, len(x), len(x))
        if len(set(x[i])) > 1 and len(set(y[i])) > 1:
            vals.append(spearmanr(x[i], y[i]).statistic)
    return rho(x, y), float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def kripp_alpha_interval(mat):
    """Krippendorff's alpha, interval metric. mat: items x raters (runs), no missing values."""
    mat = np.asarray(mat, float)
    n_items, m = mat.shape
    vals = mat.ravel()
    n = vals.size
    do = sum(((row[:, None] - row[None, :]) ** 2).sum() / (m - 1) for row in mat) / n
    de = ((vals[:, None] - vals[None, :]) ** 2).sum() / (n * (n - 1))
    return float(1 - do / de) if de > 0 else float("nan")


def save(df, name):
    df.to_csv(os.path.join(TAB, name), index=False, encoding="utf-8-sig")


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def detected(errs, span):
    if not isinstance(span, str) or not span or not isinstance(errs, list):
        return False
    for e in errs:
        t = str(e.get("text") or "")
        if not t:
            continue
        if t in span or (span in t and len(t) <= max(3 * len(span), len(span) + 6)):
            return True
    return False


def spans_not_in_mt(errs, mt):
    if not isinstance(errs, list) or not errs:
        return np.nan
    return float(np.mean([str(e.get("text") or "") not in mt for e in errs]))


LATIN_UNTRANSLATED = re.compile(r"^[A-Za-z][A-Za-z '\-,.]{6,}$")


# ============================================================================ load
rows = []
for f in sorted(os.listdir(RES)):
    if re.match(r"P\d\d_.*\.jsonl$", f):
        rows += read_jsonl(os.path.join(RES, f))
df = pd.DataFrame(rows)
A = pd.DataFrame(read_jsonl(os.path.join(DATA, "setA_items.jsonl"))).set_index("item_id")
B = pd.DataFrame(read_jsonl(os.path.join(DATA, "setB_items.jsonl"))).set_index("item_id")
P = pd.DataFrame(read_jsonl(os.path.join(DATA, "pairs.jsonl"))).set_index("pair_id")
env = read_jsonl(os.path.join(RES, "environment.jsonl"))

M["calls_total"] = int(len(df))
M["calls_malformed"] = int((df.parse_status == "malformed").sum())
M["calls_needing_retry"] = int((df.attempts > 1).sum())
M["calls_truncated"] = int((df.done_reason == "length").sum())
M["env"] = {"gpu": env[-1]["gpu"], "ollama": env[-1]["ollama_version"],
            "models": {k: v["tag"] + " @" + v["digest"][:12] for k, v in env[-1]["models"].items()},
            "sessions": len(env),
            "same_model_digests_all_sessions": len({json.dumps(e["models"], sort_keys=True) for e in env}) == 1}
A["chrf_ref"] = [chrf(c, r) for c, r in zip(A.candidate, A.reference)]
B["chrf_ref"] = [chrf(c, r) for c, r in zip(B.candidate, B.reference)]

# ============================================================================ E1 repeatability
e1 = df[df.experiment == "E1"].copy()
e1["human"] = e1.item_id.map(A.human_score)
per = (e1.groupby(["model", "prompt_id", "temperature", "item_id"])
       .agg(runs=("score", "size"), mn=("score", "min"), mx=("score", "max"), sd=("score", "std"),
            nuniq=("score", "nunique"), bands=("score", lambda s: len({band(v) for v in s})),
            human=("human", "first"))
       .reset_index())
per["range"] = per.mx - per.mn
per["inconsistent"] = (per.range >= 10) | (per.bands > 1)
save(per, "E1_per_item.csv")

e1_rows = []
for (m, p, t), g in per.groupby(["model", "prompt_id", "temperature"]):
    runs = e1[(e1.model == m) & (e1.prompt_id == p) & (e1.temperature == t)]
    mat = runs.pivot(index="item_id", columns="run", values="score")
    single = [rho(mat[c], A.loc[mat.index, "human_score"]) for c in mat]
    avg = mat.mean(axis=1)
    r_avg, lo, hi = rho_ci(avg, A.loc[avg.index, "human_score"])
    e1_rows.append(dict(model=m, prompt=p, temperature=t, runs=mat.shape[1],
                        share_identical_all_runs=(g.nuniq == 1).mean(),
                        share_inconsistent=g.inconsistent.mean(),
                        share_band_flip=(g.bands > 1).mean(),
                        mean_range=g.range.mean(), max_range=g.range.max(), mean_sd=g.sd.mean(),
                        kripp_alpha=kripp_alpha_interval(mat.values),
                        mean_score=runs.score.mean(),
                        rho_single_min=min(single), rho_single_max=max(single),
                        rho_mean_of_runs=r_avg, rho_mean_ci_lo=lo, rho_mean_ci_hi=hi))
E1 = pd.DataFrame(e1_rows)
save(E1.round(3), "E1_repeatability.csv")

# MQM error-list stability: same score, different reasons
jac, same_list = [], []
for (m, t, i), g in e1[(e1.prompt_id == "mqm") & (e1.temperature > 0)].groupby(["model", "temperature", "item_id"]):
    for x, y in itertools.combinations(g.to_dict("records"), 2):
        if x["score"] == y["score"] and x["n_errors"] > 0 and y["n_errors"] > 0:
            s1 = {str(z["text"]) for z in x["errors"]}
            s2 = {str(z["text"]) for z in y["errors"]}
            jac.append(len(s1 & s2) / len(s1 | s2))
jac = np.array(jac)
M["E1_same_score_pairs"] = int(len(jac))
M["E1_same_score_identical_error_list"] = float((jac == 1).mean())
M["E1_same_score_no_shared_span"] = float((jac == 0).mean())

# severity drives glm4 MQM variance
sev = (e1[e1.prompt_id == "mqm"].assign(crit=e1.severity_counts.map(lambda c: c.get("critical", 0) if isinstance(c, dict) else 0))
       .groupby(["model", "temperature"]).agg(mean_errors=("n_errors", "mean"), share_with_critical=("crit", lambda s: (s > 0).mean()),
                                              share_score_zero=("score", lambda s: (s == 0).mean())).reset_index())
save(sev.round(3), "E1_mqm_severity_by_temperature.csv")

# comparison with Sprint 50 run of the same prompts (T=0, run 0)
s50_path = os.path.join(ROOT, "data", "raw", "sprint50_agreement_detail.json")
if os.path.exists(s50_path):
    s50 = json.load(open(s50_path, encoding="utf-8"))["en_to_cmn"]
    cmp_rows = []
    for cfg, (m, p) in {"glm4_flat": ("glm4", "flat"), "glm4_mqm": ("glm4", "mqm"),
                        "qwen_flat": ("qwen", "flat"), "qwen_mqm": ("qwen", "mqm")}.items():
        old = {r["gold_id"]: r["judge_score"] for r in s50[cfg]["per_sentence"]}
        g = e1[(e1.model == m) & (e1.prompt_id == p) & (e1.temperature == 0) & (e1.run == 0)]
        new = dict(zip(g.item_id.str.replace("A::", "", regex=False), g.score))
        d = np.array([abs(old[k] - new[k]) for k in old])
        cmp_rows.append(dict(config=cfg, identical=int((d == 0).sum()), of=len(d), mean_abs_diff=d.mean(),
                             max_abs_diff=d.max(), sprint50_rho=s50[cfg]["spearman_rho"],
                             sprint53_rho=rho([new[k] for k in old], [A.loc["A::" + k, "human_score"] for k in old])))
    save(pd.DataFrame(cmp_rows).round(3), "E1_vs_sprint50.csv")

# ============================================================================ E2 prompt wording
base_mqm = df[(df.phase == "P01_E1_T00") & (df.run == 0) & (df.prompt_id == "mqm")]
e2 = pd.concat([base_mqm, df[df.phase == "P04_E2_prompts"]])
e2_rows = []
for m in MODELS:
    w = e2[e2.model == m].pivot(index="item_id", columns="prompt_id", values="score")
    h = A.loc[w.index, "human_score"]
    sevc = e2[e2.model == m].groupby("prompt_id").severity_counts.apply(lambda s: pd.DataFrame(list(s)).sum())
    for c in w:
        r, lo, hi = rho_ci(w[c], h)
        diff = (w[c] - w["mqm"]).abs()
        e2_rows.append(dict(model=m, prompt=c, mean_score=w[c].mean(), sd=w[c].std(), rho_human=r, ci_lo=lo, ci_hi=hi,
                            rho_vs_sprint50_prompt=rho(w[c], w["mqm"]), share_items_moved_10plus=(diff >= 10).mean(),
                            share_items_band_changed=(w[c].map(band) != w["mqm"].map(band)).mean(),
                            mean_errors=e2[(e2.model == m) & (e2.prompt_id == c)].n_errors.mean(),
                            minor=int(sevc.loc[(c, "minor")]), major=int(sevc.loc[(c, "major")]),
                            critical=int(sevc.loc[(c, "critical")])))
E2 = pd.DataFrame(e2_rows)
save(E2.round(3), "E2_prompt_wording.csv")
hs = Counter(s["error_severity"].lower() for l in A.human_error_spans for s in l)
M["human_severity_counts_setA"] = dict(hs)

# ============================================================================ E3 scales
base_flat = df[(df.phase == "P01_E1_T00") & (df.run == 0) & (df.prompt_id == "flat")]
e3 = pd.concat([base_flat, df[df.phase == "P05_E3_scales"]])
e3_rows, dist_rows = [], []
norm = {"flat": lambda s: s, "flat_1to5": lambda s: (s - 1) / 4 * 100, "flat_1to10": lambda s: (s - 1) / 9 * 100}
label = {"flat": "0-100", "flat_1to5": "1-5", "flat_1to10": "1-10"}
for m in MODELS:
    w = e3[e3.model == m].pivot(index="item_id", columns="prompt_id", values="score")
    for c in w:
        nv = norm[c](w[c])
        e3_rows.append(dict(model=m, scale=label[c], rho_human=rho(w[c], A.loc[w.index, "human_score"]),
                            rho_vs_0_100=rho(w[c], w["flat"]), mean_normalised_0_100=nv.mean(),
                            share_poor_band_normalised=(nv < 60).mean(), distinct_values=w[c].nunique(),
                            most_common_value=w[c].mode().iloc[0], share_most_common=(w[c] == w[c].mode().iloc[0]).mean()))
        for v, n in sorted(Counter(w[c]).items()):
            dist_rows.append(dict(model=m, scale=label[c], value=v, count=n))
save(pd.DataFrame(e3_rows).round(3), "E3_scales.csv")
save(pd.DataFrame(dist_rows), "E3_score_distribution.csv")
flat_all = df[df.prompt_id == "flat"]
clus = []
for m in MODELS:
    c = Counter(flat_all[flat_all.model == m].score)
    tot = sum(c.values())
    top = c.most_common(5)
    clus.append(dict(model=m, calls=tot, distinct_values=len(c), top5=", ".join(f"{int(k)} ({v / tot:.0%})" for k, v in top),
                     share_top3=sum(v for _, v in c.most_common(3)) / tot))
save(pd.DataFrame(clus).round(3), "E3_flat_score_clustering.csv")
q20 = e3[(e3.model == "qwen") & (e3.prompt_id == "flat") & (e3.score == 20)]
M["qwen_flat_20_count_setA"] = int(len(q20))
M["qwen_flat_20_human_mean"] = float(A.loc[q20.item_id, "human_score"].mean()) if len(q20) else None

# ============================================================================ Set B (E4-E8)
b = df[df.set == "B"].copy()
b = b.join(B[["source_id", "variant_type", "category", "expected_quality_band", "script", "candidate",
              "reference", "planted_error", "chrf_ref"]], on="item_id")
b["span"] = b.planted_error.map(lambda p: p.get("span") if isinstance(p, dict) else None)
b["judge_band"] = b.score.map(band)
b["band_ok"] = b.judge_band == b.expected_quality_band
b["band_ord"] = b.expected_quality_band.map({"poor": 0, "moderate": 1, "clean": 2})
gold = b[b.variant_type == "gold"].set_index(["prompt_id", "model", "source_id"]).score
b["gold_score"] = [gold.get((p, m, s), np.nan) for p, m, s in zip(b.prompt_id, b.model, b.source_id)]
b["below_gold"] = b.score < b.gold_score
b["detected"] = [detected(e, s) for e, s in zip(b.errors, b.span)]
b["spans_not_in_mt"] = [spans_not_in_mt(e, c) for e, c in zip(b.errors, b.candidate)]
b["n_latin_untranslated"] = [sum(1 for x in (e if isinstance(e, list) else []) if LATIN_UNTRANSLATED.match(str(x.get("text") or ""))
                                 and str(x.get("text")) not in c) for e, c in zip(b.errors, b.candidate)]
VORDER = ["gold", "paraphrase", "padded", "literal", "traditional_char", "traditional_tw",
          "original_candidate", "fluent_wrong", "targeted_error"]
main_p = ["flat", "mqm", "mqm_ref"]

vt = (b[b.prompt_id.isin(main_p)].groupby(["prompt_id", "model", "variant_type"])
      .agg(n=("score", "size"), mean_score=("score", "mean"), band_accuracy=("band_ok", "mean"),
           mean_errors=("n_errors", "mean"), share_zero_errors=("n_errors", lambda s: (s == 0).mean()))
      .reset_index())
vt["variant_type"] = pd.Categorical(vt.variant_type, VORDER, ordered=True)
vt = vt.sort_values(["prompt_id", "model", "variant_type"])
save(vt.round(3), "E4_E7_setB_by_variant.csv")

tq = []
for p in main_p:
    for m in MODELS:
        g = b[(b.prompt_id == p) & (b.model == m) & (b.script == "simplified") & (b.variant_type != "gold")]
        r, lo, hi = rho_ci(g.score, g.band_ord)
        tq.append(dict(prompt=p, model=m, n=len(g), rho_true_band=r, ci_lo=lo, ci_hi=hi, rho_chrf_to_reference=rho(g.score, g.chrf_ref),
                       overall_band_accuracy=(b[(b.prompt_id == p) & (b.model == m)].band_ok.mean())))
save(pd.DataFrame(tq).round(3), "E4_E7_tracks_true_quality.csv")

err = b[b.variant_type.isin(["fluent_wrong", "targeted_error"]) & b.prompt_id.isin(main_p)]
det = (err.groupby(["prompt_id", "model", "variant_type"])
       .agg(n=("score", "size"), detected=("detected", "mean"), ranked_below_own_gold=("below_gold", "mean"),
            mean_drop_vs_gold=("gold_score", lambda s: np.nan))
       .reset_index())
det["mean_drop_vs_gold"] = [(err[(err.prompt_id == p) & (err.model == m) & (err.variant_type == v)].eval("gold_score - score")).mean()
                            for p, m, v in zip(det.prompt_id, det.model, det.variant_type)]
det.loc[det.prompt_id == "flat", "detected"] = np.nan  # flat prompt lists no errors
save(det.round(3), "E6_E7_planted_error_detection.csv")
# sensitivity of the paired-contrast rule: does a tie with the gold count as a failure?
ts = []
for (p_, m_), g in err.groupby(["prompt_id", "model"]):
    d = g.gold_score - g.score
    ts.append(dict(prompt_id=p_, model=m_, n=len(g), below_gold_strict=(d > 0).mean(), tie_with_gold=(d == 0).mean(),
                   not_above_gold_loose=(d >= 0).mean(), above_gold=(d < 0).mean()))
save(pd.DataFrame(ts).round(3), "E6_E7_tie_sensitivity.csv")
cat = (err[err.prompt_id.isin(["mqm", "flat"])].groupby(["category", "prompt_id", "model"])
       .agg(n=("score", "size"), detected=("detected", "mean"), ranked_below_own_gold=("below_gold", "mean")).reset_index())
cat.loc[cat.prompt_id == "flat", "detected"] = np.nan
save(cat.round(3), "E7_detection_by_category.csv")

fp = (b[b.prompt_id.isin(["mqm", "mqm_ref", "mqm_neutral_label"])].groupby(["prompt_id", "model"])
      .agg(share_spans_not_in_translation=("spans_not_in_mt", "mean"),
           rows_with_english_source_flagged=("n_latin_untranslated", lambda s: (s > 0).mean())).reset_index())
okrows = b[(b.prompt_id == "mqm") & b.variant_type.isin(["gold", "paraphrase"])]
fp2 = okrows.groupby("model").agg(correct_rows=("score", "size"), mean_errors_on_correct=("n_errors", "mean"),
                                  share_correct_with_any_error=("n_errors", lambda s: (s > 0).mean()),
                                  share_correct_with_major_or_critical=("severity_counts", lambda s: np.mean([(c["major"] + c["critical"]) > 0 for c in s])),
                                  min_score_on_correct=("score", "min")).reset_index()
save(fp.round(3), "E7_error_span_validity.csv")
save(fp2.round(3), "E7_false_errors_on_correct_translations.csv")

gap = []
for p in main_p:
    for m in MODELS:
        g = b[(b.prompt_id == p) & (b.model == m)]
        gs = g[g.variant_type == "gold"].set_index("source_id").score
        ps = g[g.variant_type == "paraphrase"].set_index("source_id").score
        d = (gs - ps).dropna()
        gap.append(dict(prompt=p, model=m, n=len(d), mean_gold_minus_paraphrase=d.mean(), share_paraphrase_lower=(d > 0).mean(),
                        share_gap_10plus=(d >= 10).mean()))
save(pd.DataFrame(gap).round(3), "E4_E5_paraphrase_gap.csv")

lf = []
for p in main_p:
    for m in MODELS:
        g = b[(b.prompt_id == p) & (b.model == m)]
        l = g[g.variant_type == "literal"].set_index("source_id").score
        f = g[g.variant_type == "fluent_wrong"].set_index("source_id").score
        d = (l - f).dropna()
        lf.append(dict(prompt=p, model=m, n=len(d), literal_correct_wins=(d > 0).mean(), tie=(d == 0).mean(),
                       fluent_wrong_wins=(d < 0).mean(), literal_mean=l.mean(), literal_band_accuracy=g[g.variant_type == "literal"].band_ok.mean()))
save(pd.DataFrame(lf).round(3), "E6_literal_vs_fluent_wrong.csv")

sc = []
for p in ["mqm", "mqm_neutral_label", "flat", "mqm_ref"]:
    for m in MODELS:
        g = b[(b.prompt_id == p) & (b.model == m)]
        gs = g[g.variant_type == "gold"].set_index("source_id").score
        for v in ["traditional_char", "traditional_tw"]:
            t = g[g.variant_type == v].set_index("source_id").score
            d = (gs.reindex(t.index) - t).dropna()
            if len(d):
                sc.append(dict(prompt=p, model=m, variant=v, n=len(d), mean_penalty=d.mean(), share_penalised=(d > 0).mean(),
                               share_rewarded=(d < 0).mean()))
save(pd.DataFrame(sc).round(3), "E8_script.csv")
kw = re.compile(r"(?:traditional|simplified|繁体|简体|繁體|字形|script)", re.I)
M["E8_outputs_mentioning_script"] = int(b[b.script != "simplified"].raw_response.str.contains(kw).sum())
M["E8_traditional_rows_judged"] = int((b.script != "simplified").sum())

# Set A with reference
ar = []
for m in MODELS:
    a0 = base_mqm[base_mqm.model == m].set_index("item_id").score
    a1 = df[(df.phase == "P07_E4_mqm_ref") & (df.set == "A") & (df.model == m)].set_index("item_id").score
    for name, s in (("mqm (no reference)", a0), ("mqm + reference", a1)):
        r, lo, hi = rho_ci(s, A.loc[s.index, "human_score"])
        ar.append(dict(model=m, prompt=name, rho_human=r, ci_lo=lo, ci_hi=hi, rho_chrf=rho(s, A.loc[s.index, "chrf_ref"])))
save(pd.DataFrame(ar).round(3), "E4_setA_reference.csv")
M["setA_rho_human_vs_chrf"] = rho(A.human_score, A.chrf_ref)

# ============================================================================ E9 pairwise
pw = df[df.phase == "P10_E9_pairwise"].copy()
pw["pair_type"] = pw.item_id.map(P.pair_type)
pw["expected"] = pw.item_id.map(P.expected_preference)


def original_side(r):
    if r.better == "tie":
        return "tie"
    first, second = ("a", "b") if r.order == "AB" else ("b", "a")
    return first if r.better == "A" else second


pw["verdict"] = pw.apply(original_side, axis=1)
pw["position"] = pw.better.map({"A": "first", "B": "second", "tie": "tie"})
pos = pw.groupby("model").position.value_counts(normalize=True).unstack().fillna(0).reset_index()
wide = pw.pivot_table(index=["model", "item_id"], columns="order", values="verdict", aggfunc="first").reset_index()
wide["consistent"] = wide.AB == wide.BA
wide["pair_type"] = wide.item_id.map(P.pair_type)
cons = wide.groupby("model").consistent.mean().rename("order_consistent").reset_index()
save(pos.merge(cons).round(3), "E9_position_bias.csv")
pt = (pw.groupby(["pair_type", "model"]).verdict.value_counts(normalize=True).unstack().fillna(0).reset_index())
pt = pt.merge(wide.groupby(["pair_type", "model"]).consistent.mean().rename("order_consistent").reset_index())
save(pt.round(3), "E9_by_pair_type.csv")

# ============================================================================ E10 reasoning
rat = df[df.prompt_id == "flat_rationale"].copy()
fl0 = base_flat.set_index(["model", "item_id"]).score
rat["flat_score"] = [fl0[(m, i)] for m, i in zip(rat.model, rat.item_id)]
e10 = []
for m in MODELS:
    g = rat[rat.model == m]
    e10.append(dict(model=m, prompt="flat + rationale", mean_score=g.score.mean(), mean_score_plain_flat=g.flat_score.mean(),
                    share_moved_10plus=((g.score - g.flat_score).abs() >= 10).mean(),
                    rho_human=rho(g.score, A.loc[g.item_id, "human_score"]),
                    rho_human_plain_flat=rho(g.flat_score, A.loc[g.item_id, "human_score"])))
save(pd.DataFrame(e10).round(3), "E10_rationale_effect.csv")

audit_path = os.path.join(ROOT, "analysis", "manual_audit_labels.csv")
sample_path = os.path.join(OUT, "E10_audit_sample.csv")
if not os.path.exists(sample_path):
    parts = [rat.sample(10, random_state=s) for s in (1,)]
    ana = df[df.prompt_id == "mqm_analysis_first"]
    corr = b[(b.prompt_id == "mqm") & b.variant_type.isin(["gold", "paraphrase"]) & (b.n_errors > 0)]
    samp = pd.concat([rat[rat.model == "glm4"].sample(10, random_state=1), rat[rat.model == "qwen"].sample(10, random_state=1),
                      ana[ana.model == "glm4"].sample(10, random_state=1), ana[ana.model == "qwen"].sample(10, random_state=1),
                      corr[corr.model == "glm4"].sample(5, random_state=1), corr[corr.model == "qwen"].sample(5, random_state=1)])
    samp = samp.assign(source=samp.item_id.map(lambda i: A.loc[i, "source_text"] if i in A.index else B.loc[i, "source_text"]),
                       candidate=samp.item_id.map(lambda i: A.loc[i, "candidate"] if i in A.index else B.loc[i, "candidate"]),
                       human_score=samp.item_id.map(A.human_score))
    samp[["key", "model", "prompt_id", "item_id", "human_score", "source", "candidate", "score", "rationale", "analysis",
          "errors"]].to_csv(sample_path, index=False, encoding="utf-8-sig")
if os.path.exists(audit_path):
    lab = pd.read_csv(audit_path)
    s = pd.read_csv(sample_path)
    lab = s.merge(lab, on="key")
    summ = lab.groupby(["prompt_id", "label"]).size().unstack(fill_value=0)
    summ.reset_index().to_csv(os.path.join(TAB, "E10_manual_audit_summary.csv"), index=False)
    M["E10_audit_n"] = int(len(lab))
    M["E10_audit_labels"] = lab.label.value_counts().to_dict()

# ============================================================================ headline metrics
def pick(dfx, **kw):
    q = dfx
    for k, v in kw.items():
        q = q[q[k] == v]
    return q.iloc[0]


for m in MODELS:
    for p in ["mqm", "flat"]:
        for t in [0.0, 0.7, 1.0]:
            r = pick(E1, model=m, prompt=p, temperature=t)
            M[f"E1_{m}_{p}_T{t}_inconsistent"] = float(r.share_inconsistent)
            M[f"E1_{m}_{p}_T{t}_identical"] = float(r.share_identical_all_runs)
            M[f"E1_{m}_{p}_T{t}_mean_range"] = float(r.mean_range)
            M[f"E1_{m}_{p}_T{t}_alpha"] = float(r.kripp_alpha)
json.dump(M, open(os.path.join(OUT, "metrics.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False, default=float)
b.drop(columns=["errors", "raw_response", "raw_earlier_attempts"]).to_csv(os.path.join(TAB, "setB_all_judgements.csv"), index=False, encoding="utf-8-sig")

print("Tables  ->", TAB)
print(f"Calls analysed: {M['calls_total']}  malformed: {M['calls_malformed']}  retries: {M['calls_needing_retry']}")

if "--no-charts" not in sys.argv:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from charts import make_charts  # noqa: E402
    make_charts(OUT, E1, E2, pd.DataFrame(e3_rows), vt, det, pd.DataFrame(gap), pos.merge(cons), pd.DataFrame(sc), pd.DataFrame(tq))
    print("Charts  ->", FIG)
