"""Static charts (PNG, 200 dpi) for the Sprint 53 report. Called by analyze.py."""
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

COL = {"glm4": "#2a78d6", "qwen": "#eb6834"}      # validated categorical slots 1-2
LAB = {"glm4": "glm4 (9B)", "qwen": "qwen2.5:7b"}
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.titlesize": 10, "axes.titleweight": "bold",
                     "axes.titlecolor": INK, "figure.facecolor": SURF, "axes.facecolor": SURF, "legend.frameon": False})


def _style(ax, grid_axis="y"):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def _bars(ax, groups, series, values, fmt="{:.0%}", ylim=(0, 1.05)):
    x = np.arange(len(groups))
    w = 0.34
    for k, s in enumerate(series):
        v = values[s]
        pos = x + (k - (len(series) - 1) / 2) * (w + 0.03)
        ax.bar(pos, v, w, color=COL[s], label=LAB[s], zorder=2)
        for p, val in zip(pos, v):
            ax.text(p, val + (ylim[1] - ylim[0]) * 0.015, fmt.format(val), ha="center", va="bottom", fontsize=7.5, color=INK2)
    ax.set_xticks(x, groups)
    ax.set_ylim(*ylim)
    _style(ax)


def _save(fig, out, name):
    fig.savefig(os.path.join(out, "charts", name), dpi=200, bbox_inches="tight", facecolor=SURF)
    plt.close(fig)


def make_charts(out, E1, E2, E3, vt, det, gap, pos, sc, tq):
    # 1 repeatability
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.1), sharey=True)
    for ax, p, title in zip(axes, ["mqm", "flat"], ["MQM error-list prompt", "Flat 0-100 prompt"]):
        g = E1[E1.prompt == p]
        vals = {m: g[g.model == m].sort_values("temperature").share_inconsistent.values for m in COL}
        _bars(ax, ["T = 0.0\n(3 runs)", "T = 0.7\n(5 runs)", "T = 1.0\n(5 runs)"], list(COL), vals)
        ax.set_title(title, loc="left")
    axes[0].set_ylabel("Share of the 40 Set A items\nscored inconsistently")
    axes[1].legend(loc="upper left")
    fig.suptitle("E1  Same translation, same prompt, repeated: how often the verdict changes\n(inconsistent = runs differ by ≥10 points or fall in different bands)",
                 x=0.02, ha="left", fontsize=9.5, color=INK)
    fig.tight_layout()
    _save(fig, out, "fig1_repeatability.png")

    # 2 prompt wording
    names = {"mqm": "Sprint 50 MQM prompt", "mqm_reworded": "Same instructions, reworded", "mqm_zh": "Instructions in Chinese",
             "mqm_severity_defs": "+ severity definitions", "mqm_analysis_first": "+ short analysis first"}
    order = list(names)
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    for k, m in enumerate(COL):
        g = E2[E2.model == m].set_index("prompt").loc[order]
        y = np.arange(len(order)) + (k - 0.5) * 0.28
        ax.errorbar(g.rho_human, y, xerr=[g.rho_human - g.ci_lo, g.ci_hi - g.rho_human], fmt="o", color=COL[m], ms=5.5,
                    elinewidth=1.2, capsize=0, label=LAB[m], mec=SURF, mew=1.2)
    ax.set_yticks(np.arange(len(order)), [names[o] for o in order])
    ax.invert_yaxis()
    ax.set_xlim(-0.1, 1)
    ax.set_xlabel("Spearman ρ with human MQM score (Set A, n = 40) — dot = estimate, line = 95% bootstrap CI")
    ax.set_title("E2  Rewording the prompt reshuffles which items the judges rank highly", loc="left")
    ax.legend(loc="lower right")
    _style(ax, "x")
    fig.tight_layout()
    _save(fig, out, "fig2_prompt_wording.png")

    # 3 scales
    fig, ax = plt.subplots(figsize=(6.2, 3.0))
    groups = ["0-100", "1-10", "1-5"]
    vals = {m: E3[E3.model == m].set_index("scale").loc[groups].mean_normalised_0_100.values for m in COL}
    _bars(ax, ["0–100 scale", "1–10 scale", "1–5 scale"], list(COL), vals, fmt="{:.0f}", ylim=(0, 100))
    ax.axhline(84.0, color=INK2, lw=1, ls=(0, (1, 2)))
    ax.text(-0.45, 86, "human mean on these 40 items: 84", ha="left", fontsize=7.5, color=INK2)
    ax.set_ylim(0, 110)
    ax.set_ylabel("Mean score, rescaled to 0–100")
    ax.set_title("E3  Same 40 translations, same judge: the scale changes the verdict", loc="left")
    ax.legend(loc="upper right", ncol=2)
    fig.tight_layout()
    _save(fig, out, "fig3_scales.png")

    # 4 variant scores
    vnames = {"gold": "Gold (correct, natural)", "paraphrase": "Valid paraphrase", "literal": "Literal but correct",
              "fluent_wrong": "Fluent, 1 meaning error", "targeted_error": "1 category error"}
    fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.1), sharey=True)
    for ax, p, t in zip(axes, ["flat", "mqm", "mqm_ref"], ["Flat 0-100", "MQM (Sprint 50 formula)", "MQM + reference"]):
        for k, m in enumerate(COL):
            g = vt[(vt.prompt_id == p) & (vt.model == m)].set_index("variant_type").loc[list(vnames)]
            y = np.arange(len(vnames)) + (k - 0.5) * 0.25
            ax.scatter(g.mean_score, y, color=COL[m], s=34, zorder=3, edgecolor=SURF, linewidth=1.2, label=LAB[m])
        ax.set_title(t, loc="left")
        ax.set_xlim(50, 102)
        _style(ax, "x")
    axes[0].set_yticks(np.arange(len(vnames)), list(vnames.values()))
    axes[0].invert_yaxis()
    axes[1].set_xlabel("Mean judge score on Set B (40 sources per row type)")
    axes[2].legend(loc="lower left")
    fig.suptitle("E5–E7  Under MQM scoring a translation with a meaning error scores about the same as a correct one",
                 x=0.02, ha="left", fontsize=9.5, color=INK)
    fig.tight_layout()
    _save(fig, out, "fig4_variant_scores.png")

    # 5 planted errors: ranked below own gold
    d = det.groupby(["prompt_id", "model"]).ranked_below_own_gold.mean().unstack("model").loc[["flat", "mqm", "mqm_ref"]]
    fig, ax = plt.subplots(figsize=(6.2, 3.0))
    _bars(ax, ["Flat 0-100", "MQM", "MQM + reference"], list(COL), {m: d[m].values for m in COL})
    ax.set_ylabel("Share of 80 flawed translations\nscored below their own gold")
    ax.set_title("E6–E7  Does the judge score the flawed version lower than the correct one?", loc="left")
    ax.set_ylim(0, 1.25)
    ax.legend(loc="upper left", ncol=2)
    fig.tight_layout()
    _save(fig, out, "fig5_planted_errors.png")

    # 6 paraphrase penalty with / without reference
    g = gap.set_index(["prompt", "model"]).share_paraphrase_lower.unstack("model").loc[["mqm", "mqm_ref"]]
    fig, ax = plt.subplots(figsize=(5.4, 2.9))
    _bars(ax, ["MQM, no reference", "MQM + reference"], list(COL), {m: g[m].values for m in COL})
    ax.set_ylabel("Share of 40 valid paraphrases\nscored below the gold wording")
    ax.set_title("E4–E5  A reference makes valid paraphrases look worse", loc="left")
    ax.set_ylim(0, 1.25)
    ax.legend(loc="upper left", ncol=2)
    fig.tight_layout()
    _save(fig, out, "fig6_reference_paraphrase.png")

    # 7 position bias
    fig, ax = plt.subplots(figsize=(6.4, 2.2))
    y = np.arange(2)
    left = np.zeros(2)
    shades = {"first": "#2f3b52", "second": "#8a93a6", "tie": "#d3d6de"}
    names2 = {"first": "picked translation shown FIRST", "second": "picked translation shown second", "tie": "tie"}
    p2 = pos.set_index("model").loc[list(COL)]
    for k in ["first", "second", "tie"]:
        ax.barh(y, p2[k], left=left, color=shades[k], height=0.5, label=names2[k], edgecolor=SURF, linewidth=2)
        for yy, l, v in zip(y, left, p2[k]):
            if v > 0.08:
                ax.text(l + v / 2, yy, f"{v:.0%}", ha="center", va="center", fontsize=8, color="white" if k != "tie" else INK)
        left += p2[k].values
    ax.set_yticks(y, [f"{LAB[m]}\n(same verdict in both orders: {p2.loc[m, 'order_consistent']:.0%})" for m in COL])
    ax.invert_yaxis()
    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1))
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=3, fontsize=7.5)
    ax.set_title("E9  Position bias: 60 pairs, each shown in both orders (240 verdicts)", loc="left")
    _style(ax, "x")
    fig.tight_layout()
    _save(fig, out, "fig7_position_bias.png")
