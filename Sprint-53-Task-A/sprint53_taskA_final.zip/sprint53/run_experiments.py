"""
Sprint 53 experiment runner - resumable, time-boxed, safe to interrupt.

  python run_experiments.py --check                 # Ollama up? both models present? GPU? (writes results/environment.jsonl)
  python run_experiments.py --status                # progress of every phase
  python run_experiments.py --smoke                 # Step 2: 1 call per prompt x model, parse check + speed estimate
  python run_experiments.py --run --budget 30m      # Step 4: continue the next unfinished phase(s) for 30 minutes
  python run_experiments.py --run --phase P05_E3_scales --budget 1h   # only that phase

How resuming works
  Every finished call is appended to results/<phase>.jsonl immediately (flushed to disk).
  On start the runner reads every results file and skips calls whose key is already there,
  so stopping at ANY moment (budget reached, Ctrl-C, Colab disconnect) loses at most the
  calls that were in flight. Calls that failed because of a server error are NOT saved, so
  they are retried next time.
"""
import argparse
import datetime as dt
import json
import os
import re
import subprocess
import sys
import threading
import time
from collections import Counter, defaultdict
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

from judge import ollama_client as oc
from judge.parsing import parse
from judge.plan import PHASES, all_jobs, build_jobs, load_data
from judge.prompts import PROMPTS, render
from judge.settings import (DEFAULT_CHUNK, MAX_ATTEMPTS, MODELS, NUM_PREDICT, RESULTS_DIR,
                            RETRY_SEED_STEP)

LOCK = threading.Lock()


# ------------------------------------------------------------------------- helpers
def parse_duration(s):
    m = re.fullmatch(r"\s*(?:(\d+(?:\.\d+)?)h)?\s*(?:(\d+)m)?\s*(?:(\d+)s)?\s*", s or "")
    if not m or not any(m.groups()):
        raise argparse.ArgumentTypeError(f"bad duration '{s}' (use e.g. 30m, 1h, 3h15m)")
    h, mi, se = m.groups()
    return float(h or 0) * 3600 + int(mi or 0) * 60 + int(se or 0)


def fmt_secs(s):
    s = int(s)
    return f"{s // 3600}h{(s % 3600) // 60:02d}m" if s >= 3600 else f"{s // 60}m{s % 60:02d}s"


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def results_path(phase):
    return os.path.join(RESULTS_DIR, f"{phase}.jsonl")


def read_results(phase):
    path = results_path(phase)
    rows = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    pass  # a line cut off by a crash - that call will simply be redone
    return rows


def append(path, row):
    with LOCK:
        # if a crash left a half-written last line, start on a fresh line so this row is intact
        if os.path.exists(path) and os.path.getsize(path) > 0:
            with open(path, "rb") as fb:
                fb.seek(-1, os.SEEK_END)
                needs_nl = fb.read(1) != b"\n"
            if needs_nl:
                with open(path, "a", encoding="utf-8") as f:
                    f.write("\n")
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())


def resolve_models():
    try:
        local = oc.available_models()
    except oc.OllamaUnavailable as e:
        sys.exit(f"!! {e}\n   Ollama is not running - run the setup cell (start Ollama) first.")
    tags, missing = {}, []
    for short, tag in MODELS.items():
        t = oc.resolve_tag(tag, local)
        if t:
            tags[short] = (t, local[t])
        else:
            missing.append(tag)
    if missing:
        sys.exit(f"!! Missing Ollama model(s): {missing}. Run the setup cell (ollama pull ...) first.")
    return tags


def gpu_info():
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=10).stdout.strip()
        return out or "no GPU visible"
    except Exception:
        return "nvidia-smi not available"


# ------------------------------------------------------------------------- one call
def run_job(job, tags, workers):
    fmt = PROMPTS[job["prompt_id"]][1]
    score_range = PROMPTS[job["prompt_id"]][2]
    prompt = render(job["prompt_id"], job["source"], mt=job.get("mt"), reference=job.get("reference"),
                    a=job.get("a"), b=job.get("b"))
    tag, digest = tags[job["model"]]
    attempts, raw_all, total_secs = 0, [], 0.0
    result, gen = None, None
    for k in range(MAX_ATTEMPTS):
        seed = job["seed"] + k * RETRY_SEED_STEP
        for net_try in range(3):  # server/network hiccups: back off and retry, do not count as an attempt
            try:
                gen = oc.generate(tag, prompt, job["temperature"], seed, NUM_PREDICT[fmt])
                break
            except Exception as e:  # noqa: BLE001
                if net_try == 2:
                    raise RuntimeError(f"Ollama call failed 3 times: {e}") from e
                time.sleep(5 * (net_try + 1))
        attempts += 1
        total_secs += gen["wall_seconds"]
        raw_all.append(gen["response"])
        result = parse(fmt, gen["response"], score_range)
        if result["parse_status"] != "malformed":
            break
    row = {k: job[k] for k in ("key", "phase", "experiment", "model", "prompt_id", "item_id", "set",
                               "temperature", "run", "seed") if k in job}
    for k in ("order", "shown_first", "shown_second"):
        if k in job:
            row[k] = job[k]
    row.update(model_tag=tag, model_digest=digest[:12], output_format=fmt, attempts=attempts,
               first_attempt_ok=(attempts == 1 and result["parse_status"] != "malformed"))
    row.update(result)
    row.update(raw_response=raw_all[-1], raw_earlier_attempts=raw_all[:-1] or None,
               done_reason=gen["done_reason"], prompt_tokens=gen["prompt_tokens"],
               output_tokens=gen["output_tokens"], wall_seconds=round(total_secs, 3),
               workers=workers, timestamp=now())
    return row


def execute(jobs, tags, workers, deadline, label, out_path):
    """Run jobs until done or deadline. Returns (n_done, seconds per call, stopped_early)."""
    done, secs, started = 0, [], time.time()
    pending, it = set(), iter(jobs)
    total = len(jobs)
    stopped_early = False

    def est():
        return (sum(secs[-50:]) / len(secs[-50:])) if secs else 10.0

    with ThreadPoolExecutor(max_workers=workers) as pool:
        def submit_next():
            nonlocal stopped_early
            if time.time() + est() / max(workers, 1) > deadline:
                stopped_early = True
                return False
            try:
                j = next(it)
            except StopIteration:
                return False
            pending.add(pool.submit(run_job, j, tags, workers))
            return True

        for _ in range(workers):
            if not submit_next():
                break
        while pending:
            finished, _ = wait(pending, return_when=FIRST_COMPLETED)
            for fut in finished:
                pending.discard(fut)
                row = fut.result()  # a RuntimeError here (server down) stops the run; saved calls are kept
                append(out_path, row)
                done += 1
                secs.append(row["wall_seconds"])
                if done % 25 == 0 or done == total:
                    el = time.time() - started
                    rate = el / done
                    print(f"   [{label}] {done}/{total} calls  |  {rate:.1f} s/call  |  "
                          f"phase ETA {fmt_secs(rate * (total - done))}  |  "
                          f"session time left {fmt_secs(max(0, deadline - time.time()))}", flush=True)
                if not stopped_early:
                    submit_next()
    return done, (sum(secs) / len(secs) if secs else None), stopped_early


# ------------------------------------------------------------------------- commands
def cmd_check():
    info = {"timestamp": now(), "gpu": gpu_info()}
    try:
        tags = resolve_models()
    except oc.OllamaUnavailable as e:
        sys.exit(f"!! {e}\n   Start Ollama with the setup cell first.")
    try:
        with __import__("urllib.request").request.urlopen(f"{oc.OLLAMA_HOST}/api/version", timeout=5) as r:
            info["ollama_version"] = json.loads(r.read()).get("version")
    except Exception:  # noqa: BLE001
        info["ollama_version"] = "unknown"
    info["models"] = {k: {"tag": t, "digest": d} for k, (t, d) in tags.items()}
    append(os.path.join(RESULTS_DIR, "environment.jsonl"), info)
    print(f"GPU            : {info['gpu']}")
    print(f"Ollama version : {info['ollama_version']}")
    for k, (t, d) in tags.items():
        print(f"Model {k:5s}    : {t}  (digest {d[:12]})")
    print("OK - environment recorded in results/environment.jsonl")


def status_table(plan=None):
    plan = plan or all_jobs()
    rows, tot_all, done_all = [], 0, 0
    for phase, jobs in plan.items():
        keys = {j["key"] for j in jobs}
        res = [r for r in read_results(phase) if r.get("key") in keys]
        done_keys = {r["key"] for r in res}
        mal = sum(r["parse_status"] == "malformed" for r in res)
        rows.append((phase, PHASES[phase]["exp"], len(jobs), len(done_keys), mal))
        tot_all += len(jobs)
        done_all += len(done_keys)
    return rows, tot_all, done_all


def cmd_status():
    rows, tot, done = status_table()
    print(f"{'phase':20s} {'exp':7s} {'calls':>6s} {'done':>6s} {'%':>5s} {'malformed':>9s}")
    for phase, exp, n, d, mal in rows:
        mark = "✔" if d == n else ("…" if d else " ")
        print(f"{phase:20s} {exp:7s} {n:6d} {d:6d} {100 * d / n:4.0f}% {mal:9d}  {mark}")
    print(f"{'TOTAL':28s} {tot:6d} {done:6d} {100 * done / tot:4.0f}%")
    nxt = next((p for p, _, n, d, _ in rows if d < n), None)
    print(f"Next phase to run: {nxt or 'none - all phases complete'}")
    json.dump({"timestamp": now(), "total": tot, "done": done, "next_phase": nxt,
               "phases": [dict(phase=p, calls=n, done=d, malformed=m) for p, _, n, d, m in rows]},
              open(os.path.join(RESULTS_DIR, "progress.json"), "w"), indent=1)
    return nxt


def cmd_smoke(workers):
    """One call per prompt template per model, on fixed items; overwrites results/smoke.jsonl."""
    tags = resolve_models()
    data = load_data()
    a0 = data["A"][0]
    b_trad = next(r for r in data["B"] if r["script"] == "traditional_char")
    p0 = data["pairs"][0]
    jobs = []
    for model in MODELS:
        for pid in PROMPTS:
            if pid == "pairwise":
                it = dict(item_id=p0["pair_id"], set="pairs", source=p0["source_text"], a=p0["a_text"],
                          b=p0["b_text"], order="AB")
            else:
                src = b_trad if pid == "mqm_neutral_label" else a0
                it = dict(item_id=src["item_id"], set=src.get("set"), source=src["source_text"],
                          mt=src["candidate"], reference=src.get("reference"))
            j = dict(it, phase="SMOKE", experiment="smoke", model=model, prompt_id=pid,
                     temperature=0.0, run=0, seed=1000)
            j["key"] = "|".join(["SMOKE", model, pid, j["item_id"]])
            jobs.append(j)
    path = os.path.join(RESULTS_DIR, "smoke.jsonl")
    if os.path.exists(path):
        os.remove(path)
    print(f">> Smoke test: {len(jobs)} calls ({len(PROMPTS)} prompts x {len(MODELS)} models). "
          "The first call per model is slower (model loading).")
    t0 = time.time()
    execute(jobs, tags, workers, deadline=time.time() + 3600, label="smoke", out_path=path)
    rows = [json.loads(l) for l in open(path, encoding="utf-8")]
    print(f"\n{'model':6s} {'prompt':20s} {'parse':10s} {'value':>8s} {'tries':>5s} {'secs':>6s} {'tokens':>6s}")
    for r in sorted(rows, key=lambda r: (r["model"], list(PROMPTS).index(r["prompt_id"]))):
        val = r.get("score") if r.get("score") is not None else r.get("better", "-")
        print(f"{r['model']:6s} {r['prompt_id']:20s} {r['parse_status']:10s} {str(val):>8s} "
              f"{r['attempts']:5d} {r['wall_seconds']:6.1f} {str(r['output_tokens']):>6s}")
    ok = sum(r["parse_status"] != "malformed" for r in rows)
    print(f"\nParsed: {ok}/{len(rows)}  |  wall time {fmt_secs(time.time() - t0)}")
    # speed estimate from warm calls (drop each model's first call, which includes loading)
    per_model = defaultdict(list)
    for r in sorted(rows, key=lambda r: r["timestamp"]):
        per_model[r["model"]].append(r["wall_seconds"])
    warm = {m: (sum(v[1:]) / len(v[1:]) if len(v) > 1 else v[0]) for m, v in per_model.items()}
    plan = all_jobs(data)
    n_by_model = Counter(j["model"] for jobs in plan.values() for j in jobs)
    est = sum(n_by_model[m] * warm[m] for m in warm) / max(workers, 1)
    print("Warm seconds/call: " + ", ".join(f"{m} {v:.1f}s" for m, v in warm.items()))
    print(f"Planned calls: {sum(n_by_model.values())}  ->  estimated total run time ~{fmt_secs(est)} "
          f"with {workers} worker(s) (rough: MQM answers are longer on items with many errors)")
    summary = {"timestamp": now(), "parsed": ok, "calls": len(rows), "warm_seconds_per_call": warm,
               "planned_calls": sum(n_by_model.values()), "estimated_seconds": est, "workers": workers}
    json.dump(summary, open(os.path.join(RESULTS_DIR, "smoke_summary.json"), "w"), indent=1)
    if ok < len(rows):
        print("NOTE: a malformed smoke call is not a failure by itself (it is one of the things we measure), "
              "but send the table to Claude before Step 4.")


def cmd_run(phase, budget, workers):
    tags = resolve_models()
    data = load_data()
    deadline = time.time() + budget
    phases = [phase] if phase else list(PHASES)
    snap = os.path.join(RESULTS_DIR, "prompts_snapshot.json")
    if not os.path.exists(snap):
        json.dump({k: v[0] for k, v in PROMPTS.items()}, open(snap, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f">> Session budget {fmt_secs(budget)}, {workers} worker(s), models: "
          + ", ".join(f"{k}={t}" for k, (t, _) in tags.items()))
    for p in phases:
        jobs = build_jobs(p, data)
        done_keys = {r.get("key") for r in read_results(p)}
        todo = [j for j in jobs if j["key"] not in done_keys]
        if not todo:
            print(f"== {p}: already complete ({len(jobs)} calls)")
            continue
        if time.time() >= deadline - 30:
            break
        print(f"== {p} ({PHASES[p]['exp']}): {len(jobs) - len(todo)}/{len(jobs)} done, {len(todo)} to go")
        n, spc, early = execute(todo, tags, workers, deadline, p, results_path(p))
        print(f"   {p}: +{n} calls this session" + (f", {spc:.1f} s/call" if spc else ""))
        if early:
            print(f">> Session budget reached inside {p}. Progress is saved - run the same command to continue.")
            break
    print()
    return cmd_status()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--status", action="store_true")
    g.add_argument("--smoke", action="store_true")
    g.add_argument("--run", action="store_true")
    ap.add_argument("--phase", choices=list(PHASES))
    ap.add_argument("--budget", type=parse_duration, default=parse_duration(DEFAULT_CHUNK),
                    help="stop starting new calls after this long (default 30m)")
    ap.add_argument("--workers", type=int, default=1,
                    help="parallel calls to Ollama (default 1; see README_STEP2 before changing)")
    a = ap.parse_args()
    if a.check:
        cmd_check()
    elif a.status:
        cmd_status()
    elif a.smoke:
        cmd_smoke(a.workers)
    elif a.run:
        try:
            cmd_run(a.phase, a.budget, a.workers)
        except RuntimeError as e:
            print(f"\n!! Stopped: {e}\n   Every call finished before this point is saved. Re-run the setup "
                  "cell to restart Ollama, then run the same command again to continue.")
            cmd_status()
            sys.exit(1)
        except KeyboardInterrupt:
            print("\n!! Interrupted. Every finished call is saved; run the same command again to continue.")
            sys.exit(1)


if __name__ == "__main__":
    main()
