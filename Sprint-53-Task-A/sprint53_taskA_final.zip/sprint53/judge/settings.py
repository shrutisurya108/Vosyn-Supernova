"""
Central settings for the Sprint 53 judge experiments. Change values here, not in the code.

Choices that are kept IDENTICAL to Sprint 50 (so results are comparable):
  * judge models: glm4 and qwen2.5:7b via Ollama (default 4-bit quantisations)
  * prompt wording (FLAT_PROMPT / MQM_PROMPT copied verbatim, see prompts.py)
  * no forced-JSON mode: the model answers free text, we parse it (malformed output is data)
  * MQM severity weights and score formula: 100 - sum(minor 1, major 5, critical 25), floor 0
  * up to 3 attempts when the output cannot be parsed
New in Sprint 53 (not set explicitly in Sprint 50):
  * seed, num_ctx and num_predict are fixed so every call is reproducible and bounded
  * temperatures 0.0 / 0.7 / 1.0 with repeated runs (Sprint 50 only used 0.0)
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data", "processed")
RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

# ----------------------------------------------------------------- judges
MODELS = {                      # short name used in result files -> Ollama tag
    "glm4": "glm4",             # glm4:9b, Ollama default quantisation (q4_0) - same tag as Sprint 50
    "qwen": "qwen2.5:7b",       # Ollama default quantisation (q4_K_M)        - same tag as Sprint 50
}

# ----------------------------------------------------------------- Ollama server
OLLAMA_HOST = os.environ.get("OLLAMA_HOST_URL", "http://127.0.0.1:11434")
OLLAMA_TIMEOUT = 180            # seconds per HTTP call (Sprint 50: 180)
KEEP_ALIVE = "60m"              # keep both models in GPU memory between calls

# ----------------------------------------------------------------- decoding
NUM_CTX = 4096                  # context window; our longest prompt is ~1,000 tokens
NUM_PREDICT = {                 # hard cap on generated tokens, per output format
    "flat": 256,
    "flat_rationale": 512,
    "mqm": 1024,
    "mqm_analysis": 1536,
    "pairwise": 256,
}
BASE_SEED = 1000                # seed = BASE_SEED + run_index (same seed for both models)
MAX_ATTEMPTS = 3                # Sprint 50: JUDGE_MAX_RETRIES = 3
RETRY_SEED_STEP = 100           # attempt k uses seed + k*100 (a retry with the same seed
                                # at temperature 0 would just repeat the same bad output)

# ----------------------------------------------------------------- scoring (Sprint 50)
SEVERITY_WEIGHTS = {"minor": 1, "major": 5, "critical": 25, "neutral": 0}
UNKNOWN_SEVERITY_WEIGHT = 1     # Sprint 50 treated a missing severity as minor

# ----------------------------------------------------------------- running
DEFAULT_SESSION_BUDGET = "3h15m"   # stop cleanly before a ~3.5 h free-GPU session ends
DEFAULT_CHUNK = "30m"              # the notebook saves + downloads a checkpoint this often
