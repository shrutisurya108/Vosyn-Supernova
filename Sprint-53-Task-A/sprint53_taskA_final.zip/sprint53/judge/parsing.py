"""
Turn a judge's raw text into structured values - without ever asking the model to do arithmetic.

Sprint 50 rules kept: the MQM score is computed here from the listed severities
(100 - sum of weights, floor 0; unknown severity counts as minor), and output that cannot be
parsed is "malformed".
New: we also record HOW the output was parsed, because "the judge wrapped its JSON in extra
text" is itself a reliability finding:
  ok         - the whole response is valid JSON (possibly inside ``` fences)
  recovered  - valid JSON found inside extra text, or the value found by a narrow pattern
  malformed  - nothing usable (reason says why)
"""
import json
import re

from .settings import SEVERITY_WEIGHTS, UNKNOWN_SEVERITY_WEIGHT

FENCE = re.compile(r"^\s*```(?:json)?\s*(.*?)\s*```\s*$", re.S)


def _first_json_object(text):
    """Return the first balanced {...} block that parses as JSON, else None."""
    starts = [i for i, ch in enumerate(text) if ch == "{"]
    for s in starts:
        depth, in_str, esc = 0, False, False
        for j in range(s, len(text)):
            ch = text[j]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[s:j + 1])
                    except json.JSONDecodeError:
                        break
    return None


def _load(text):
    t = text.strip()
    m = FENCE.match(t)
    if m:
        t = m.group(1)
    try:
        obj = json.loads(t)
        if isinstance(obj, dict):
            return obj, "ok"
    except json.JSONDecodeError:
        pass
    obj = _first_json_object(text)
    if isinstance(obj, dict):
        return obj, "recovered"
    return None, "malformed"


def _num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        m = re.fullmatch(r"\s*(-?\d+(?:\.\d+)?)\s*(?:/\s*\d+)?\s*", v)
        if m:
            return float(m.group(1)) if "." in m.group(1) else int(m.group(1))
    return None


def mqm_score(errors):
    penalty, unknown, counts = 0, 0, {"minor": 0, "major": 0, "critical": 0, "other": 0}
    for e in errors:
        sev = str(e.get("severity", "")).strip().lower()
        if sev in SEVERITY_WEIGHTS:
            penalty += SEVERITY_WEIGHTS[sev]
            counts[sev if sev in counts else "other"] += 1
        else:
            penalty += UNKNOWN_SEVERITY_WEIGHT
            unknown += 1
            counts["other"] += 1
    return max(0, 100 - penalty), counts, unknown


def parse(fmt, text, score_range=None):
    out = {"parse_status": "malformed", "parse_reason": None, "score": None}
    if not text or not text.strip():
        out["parse_reason"] = "empty response"
        return out
    obj, status = _load(text)

    if fmt in ("flat", "flat_rationale"):
        val = _num(obj.get("score")) if obj else None
        if val is None:  # narrow fallback: "score": 85 somewhere in free text
            m = re.search(r'"?score"?\s*[:=]\s*(-?\d+(?:\.\d+)?)', text, re.I)
            if m:
                val, status = _num(m.group(1)), "recovered"
        if val is None:
            out["parse_reason"] = "no score found"
            return out
        lo, hi = score_range or (0, 100)
        if not lo <= val <= hi:
            out["parse_reason"] = f"score {val} outside {lo}-{hi}"
            out["raw_score"] = val
            return out
        out.update(parse_status=status, score=val)
        if fmt == "flat_rationale":
            out["rationale"] = (obj or {}).get("rationale")
            if not out["rationale"]:
                out["parse_reason"] = "score found but no rationale"
        return out

    if fmt in ("mqm", "mqm_analysis"):
        errs = obj.get("errors") if obj else None
        if not isinstance(errs, list):
            out["parse_reason"] = "no 'errors' list"
            return out
        clean = []
        for e in errs:
            if isinstance(e, dict):
                clean.append({"text": e.get("text"), "type": e.get("type"),
                              "severity": e.get("severity")})
            else:
                out["parse_reason"] = "an error entry is not an object"
                return out
        score, counts, unknown = mqm_score(clean)
        out.update(parse_status=status, score=score, errors=clean, n_errors=len(clean),
                   severity_counts=counts, unknown_severity=unknown)
        if fmt == "mqm_analysis":
            out["analysis"] = obj.get("analysis")
        return out

    if fmt == "pairwise":
        val = obj.get("better") if obj else None
        if val is None:
            m = re.search(r'"?better"?\s*[:=]\s*"?\s*(A|B|tie)\b', text, re.I)
            if m:
                val, status = m.group(1), "recovered"
        if isinstance(val, str) and val.strip().lower() in ("a", "b", "tie"):
            v = val.strip().lower()
            out.update(parse_status=status, better=("tie" if v == "tie" else v.upper()))
        else:
            out["parse_reason"] = f"no valid 'better' value ({val!r})"
        return out

    raise ValueError(f"unknown format {fmt}")
