"""
The experiment plan: which (model, prompt, item, temperature, run) calls make up each phase.

Phases are small, independent units that run in this order. Each temperature of the
repeatability experiment is its own phase, as requested, and the runner can also stop and
resume INSIDE a phase: every finished call is saved immediately under a unique key.

  phase                  experiment(s)   data                        prompts                              temp  runs
  P01_E1_T00             E1              Set A (40)                  mqm, flat                            0.0   3
  P02_E1_T07             E1              Set A (40)                  mqm, flat                            0.7   5
  P03_E1_T10             E1              Set A (40)                  mqm, flat                            1.0   5
  P04_E2_prompts         E2, E10         Set A (40)                  4 MQM wording variants               0.0   1
  P05_E3_scales          E3              Set A (40)                  flat 1-5, flat 1-10                  0.0   1
  P06_E4_setB_mqm        E4-E7           Set B (all rows)            mqm                                  0.0   1
  P07_E4_mqm_ref         E4              Set B + Set A               mqm + reference                      0.0   1
  P08_E5_setB_flat       E5-E7           Set B (all rows)            flat                                 0.0   1
  P09_E8_script          E8              Traditional rows + golds    mqm, neutral "Mandarin Chinese"      0.0   1
  P10_E9_pairwise        E9              60 pairs x 2 orders         pairwise                             0.0   1
  P11_E10_rationale      E10             Set A (40)                  flat + rationale                     0.0   1

Every call is made once per judge model (glm4, qwen).
"""
import json
import os
from collections import OrderedDict

from .settings import BASE_SEED, DATA_DIR, MODELS

PHASES = OrderedDict([
    ("P01_E1_T00",        dict(exp="E1",      data="A",        prompts=["mqm", "flat"], temp=0.0, runs=3)),
    ("P02_E1_T07",        dict(exp="E1",      data="A",        prompts=["mqm", "flat"], temp=0.7, runs=5)),
    ("P03_E1_T10",        dict(exp="E1",      data="A",        prompts=["mqm", "flat"], temp=1.0, runs=5)),
    ("P04_E2_prompts",    dict(exp="E2",      data="A",        prompts=["mqm_reworded", "mqm_zh", "mqm_severity_defs",
                                                                         "mqm_analysis_first"], temp=0.0, runs=1)),
    ("P05_E3_scales",     dict(exp="E3",      data="A",        prompts=["flat_1to5", "flat_1to10"], temp=0.0, runs=1)),
    ("P06_E4_setB_mqm",   dict(exp="E4-E7",   data="B",        prompts=["mqm"], temp=0.0, runs=1)),
    ("P07_E4_mqm_ref",    dict(exp="E4",      data="A+B",      prompts=["mqm_ref"], temp=0.0, runs=1)),
    ("P08_E5_setB_flat",  dict(exp="E5-E7",   data="B",        prompts=["flat"], temp=0.0, runs=1)),
    ("P09_E8_script",     dict(exp="E8",      data="script",   prompts=["mqm_neutral_label"], temp=0.0, runs=1)),
    ("P10_E9_pairwise",   dict(exp="E9",      data="pairs",    prompts=["pairwise"], temp=0.0, runs=1)),
    ("P11_E10_rationale", dict(exp="E10",     data="A",        prompts=["flat_rationale"], temp=0.0, runs=1)),
])


def _read(name):
    with open(os.path.join(DATA_DIR, name), encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def load_data():
    seta = _read("setA_items.jsonl")
    setb = [r for r in _read("setB_items.jsonl") if r.get("include_in_experiments", True)]
    pairs = _read("pairs.jsonl")
    trad_sources = {r["source_id"] for r in setb if r["script"] != "simplified"}
    script = [r for r in setb if r["script"] != "simplified"] + \
             [r for r in setb if r["variant_type"] == "gold" and r["source_id"] in trad_sources]
    return {"A": seta, "B": setb, "A+B": seta + setb, "script": script, "pairs": pairs}


def job_key(j):
    return "|".join([j["phase"], j["model"], j["prompt_id"], j["item_id"],
                     f"T{j['temperature']}", f"r{j['run']}", j.get("order", "-")])


def build_jobs(phase, data, models=None):
    spec = PHASES[phase]
    models = models or list(MODELS)
    items = data[spec["data"]]
    jobs = []
    for model in models:                       # one model's calls together
        for run in range(spec["runs"]):        # finish a whole run before the next one
            for prompt_id in spec["prompts"]:
                for it in items:
                    base = dict(phase=phase, experiment=spec["exp"], model=model, prompt_id=prompt_id,
                                temperature=spec["temp"], run=run, seed=BASE_SEED + run)
                    if spec["data"] == "pairs":
                        for order in ("AB", "BA"):
                            first, second = ("a", "b") if order == "AB" else ("b", "a")
                            j = dict(base, item_id=it["pair_id"], set="pairs", order=order,
                                     source=it["source_text"], a=it[f"{first}_text"], b=it[f"{second}_text"],
                                     shown_first=it[f"{first}_item_id"], shown_second=it[f"{second}_item_id"])
                            j["key"] = job_key(j)
                            jobs.append(j)
                    else:
                        j = dict(base, item_id=it["item_id"], set=it.get("set", "?"), source=it["source_text"],
                                 mt=it["candidate"], reference=it.get("reference"))
                        j["key"] = job_key(j)
                        jobs.append(j)
    return jobs


def all_jobs(data=None, models=None):
    data = data or load_data()
    return OrderedDict((p, build_jobs(p, data, models)) for p in PHASES)
