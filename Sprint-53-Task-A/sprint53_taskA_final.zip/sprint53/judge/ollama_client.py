"""
Minimal Ollama HTTP client (standard library only), extended from Sprint 50's ollama_client.py:
same /api/generate endpoint and non-streaming call, plus explicit seed / num_ctx / num_predict
and the timing + token counts Ollama returns (used for the speed estimates).
"""
import json
import time
import urllib.error
import urllib.request

from .settings import KEEP_ALIVE, NUM_CTX, OLLAMA_HOST, OLLAMA_TIMEOUT


class OllamaUnavailable(RuntimeError):
    pass


def _post(path, payload, timeout):
    req = urllib.request.Request(
        f"{OLLAMA_HOST}{path}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def generate(model, prompt, temperature, seed, num_predict):
    """One non-streaming generation. Returns a dict with the raw text and run metadata."""
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "keep_alive": KEEP_ALIVE,
        "options": {
            "temperature": temperature,
            "seed": seed,
            "num_ctx": NUM_CTX,
            "num_predict": num_predict,
        },
    }
    t0 = time.time()
    body = _post("/api/generate", payload, OLLAMA_TIMEOUT)
    return {
        "response": body.get("response", ""),
        "done_reason": body.get("done_reason"),          # "stop" or "length" (hit num_predict)
        "prompt_tokens": body.get("prompt_eval_count"),
        "output_tokens": body.get("eval_count"),
        "wall_seconds": round(time.time() - t0, 3),
    }


def available_models():
    """Returns {tag: digest} for the models Ollama has locally; raises if the server is down."""
    try:
        req = urllib.request.Request(f"{OLLAMA_HOST}/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, ConnectionError, TimeoutError) as e:
        raise OllamaUnavailable(f"Ollama is not reachable at {OLLAMA_HOST}: {e}") from e
    return {m["name"]: m.get("digest", "") for m in data.get("models", [])}


def resolve_tag(tag, local):
    """'qwen2.5:7b' matches itself; 'glm4' matches 'glm4:latest'."""
    if tag in local:
        return tag
    if f"{tag}:latest" in local:
        return f"{tag}:latest"
    return None
