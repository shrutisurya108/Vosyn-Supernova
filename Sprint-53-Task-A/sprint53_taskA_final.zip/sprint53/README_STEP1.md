# Sprint 53 · Step 1 — Datasets

Goal of this step: build test data whose *true* quality is known, so that in later steps a judge
mistake can be proven rather than guessed.

## Contents

| Path | What it is |
|---|---|
| `data/raw/sprint50_gold_en_cmn.jsonl` | Sprint 50 gold set (40 items, SiniticMTError human MQM labels) — unchanged copy |
| `data/raw/sprint52_en_to_cmn.jsonl` | Sprint 52 review set (20 items) — unchanged copy |
| `scripts/setb_content.py` | All hand-written Set B text: gold, paraphrase, literal, fluent_wrong, targeted_error, padded, Taiwan versions |
| `scripts/build_datasets.py` | Builds the three datasets below |
| `scripts/validate_datasets.py` | Automatic checks; writes `data/processed/validation_report.txt` |
| `scripts/build_review_workbook.py` | Builds `review/SetB_Review_Workbook.xlsx` |
| `scripts/build_reviewer_instructions.js` | Builds `review/SetB_Reviewer_Instructions.docx` |
| `scripts/merge_review.py` | Applies the returned review to Set B and regenerates the pairs |
| `scripts/chrf.py` | Pure-Python chrF (identical to sacrebleu's defaults; avoids compiled dependencies) |
| `run_step1.sh` | One command to install, build, validate, rebuild review files, or merge a review |
| `LIGHTNING_GUIDE.md` | Step-by-step guide for running everything on Lightning AI |
| `data/processed/setA_items.jsonl` | 40 items — accuracy anchor (real MT output + human scores) |
| `data/processed/setB_items.jsonl` | 275 items — controlled variants of 40 English sources |
| `data/processed/pairs.jsonl` | 60 A/B pairs for the position-bias experiment |

## Running it on Lightning AI

Full click-by-click instructions: **`LIGHTNING_GUIDE.md`**. Short version, in a Studio terminal on the free CPU machine:

```bash
unzip -o sprint53_step1.zip && cd sprint53
bash run_step1.sh                                              # build + validate
bash run_step1.sh --merge review/SetB_Review_Workbook_XX.xlsx  # after the review comes back
```

Correct output ends with `Set B items: 275 from 40 sources`, `Pairs: 60`, `HARD FAILURES: 0` and one expected
warning (the password sentence S52_004 cannot be paraphrased much). The build is deterministic: rebuilding produces
byte-identical datasets, so the workbook already sent to the reviewer still matches.

## Settings and why they were chosen

| Setting | Value | Why / alternatives |
|---|---|---|
| Set B size | 40 sources, 275 rows | Your choice. 30 = lighter review, 50 = more statistical power |
| Sources | 16 Sprint 52 + 10 Sprint 50 + 14 new | All 20 Sprint 52 sources were planned; 4 of its 8 simple sentences (encmn_007, 009, 010, 011) were swapped for new ambiguity/register sources so every category reaches 5 sources. 10 Sprint 50 sources chosen by one rule: they contain a named entity, term, number or unit |
| Categories | 7 × 5–6 sources + 4 controls | Mirrors the story's list: idioms, culture, entities, terminology, numbers, ambiguity/context, register |
| One planted error per row | exactly 1 | Makes "what did the judge miss?" unambiguous. Real MT (Set A) has overlapping errors; the two sets complement each other |
| Error variants per source | fluent_wrong + targeted_error | fluent_wrong isolates *fluency vs accuracy*; targeted_error isolates the category skill (idiom, entity…) |
| Character-only Traditional | OpenCC `s2tw` on gold, 30 sources | Isolates the script variable. `s2tw` uses Taiwan-standard glyphs (裡, 啟) |
| Taiwan-localised Traditional | hand-written, 14 sources | Automatic `s2twp` changed only 6/30 sentences and got 2 wrong (菜單→選單, 通過→透過), so it is stored only as `opencc_s2twp_output` for comparison. The other 16 sources have no Taiwan-specific vocabulary, so a Taiwan version would be identical to the character-only one |
| Expected quality bands | clean ≥85 / moderate 60–85 / poor <60 | Same buckets as Sprint 50, so results are comparable |
| Expected MQM score | 100 − Σ(minor 1, major 5, critical 25) | Same formula and weights as Sprint 50. Note: one major error only costs 5 points, so a fluent-but-wrong sentence has an expected MQM score of 95 ("clean" bucket) while a human would call it "poor". Both expectations are stored; this mismatch is itself something the experiments will measure |
| Paraphrase distance check | chrF (char order 6, β=2 — sacrebleu defaults, reimplemented in `scripts/chrf.py`), flag ≥ 60 | Ensures paraphrases cannot be matched by surface overlap; median 17. Only S52_004 is flagged (the password must stay verbatim) |
| Pairs | 60, seed 42 | 20 gold↔paraphrase (tie), 15 literal↔fluent_wrong (literal should win), 10 gold↔targeted_error, 5 + 5 script pairs, 5 concise↔padded. Every pair is shown in both orders in Step 4 |
| Random seed | 42 | Same as Sprint 50 |
