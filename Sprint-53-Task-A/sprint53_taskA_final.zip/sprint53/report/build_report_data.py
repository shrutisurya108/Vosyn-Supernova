"""
Collects every table and number the Word report needs into report/report_data.json, straight
from analysis_out/ and results/ - so the report never contains a hand-typed result.

  python analysis/analyze.py && python analysis/examples.py && python report/build_report_data.py
"""
import json
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
T = os.path.join(ROOT, "analysis_out", "tables")
sys.path.insert(0, ROOT)
from judge.prompts import PROMPTS  # noqa: E402
from judge import settings as S  # noqa: E402

M = json.load(open(os.path.join(ROOT, "analysis_out", "metrics.json"), encoding="utf-8"))


def t(name):
    return pd.read_csv(os.path.join(T, name))


def pct(x):
    return "–" if pd.isna(x) else f"{x:.0%}"


def f1(x):
    return "–" if pd.isna(x) else f"{x:.1f}"


def f2(x):
    return "–" if pd.isna(x) else f"{x:.2f}"


def ci(r, lo, hi):
    return f"{r:.2f} [{lo:.2f}, {hi:.2f}]"


MODEL = {"glm4": "glm4", "qwen": "qwen2.5"}
PNAME = {"flat": "Flat 0-100", "mqm": "MQM", "mqm_ref": "MQM + reference", "mqm_neutral_label": "MQM, neutral label",
         "mqm_reworded": "MQM reworded", "mqm_zh": "MQM in Chinese", "mqm_severity_defs": "MQM + severity definitions",
         "mqm_analysis_first": "MQM + analysis first"}
VNAME = {"gold": "Gold", "paraphrase": "Valid paraphrase", "padded": "Padded (wordy)", "literal": "Literal but correct",
         "traditional_char": "Traditional (characters)", "traditional_tw": "Traditional (Taiwan)",
         "original_candidate": "Original MT output", "fluent_wrong": "Fluent, 1 meaning error",
         "targeted_error": "1 category error"}
D = {"metrics": M}

# ---------------- data sets
A = pd.DataFrame([json.loads(l) for l in open(os.path.join(ROOT, "data", "processed", "setA_items.jsonl"), encoding="utf-8")])
B = pd.DataFrame([json.loads(l) for l in open(os.path.join(ROOT, "data", "processed", "setB_items.jsonl"), encoding="utf-8")])
D["setA"] = dict(n=len(A), min=int(A.human_score.min()), max=int(A.human_score.max()), mean=round(A.human_score.mean(), 1),
                 sd=round(A.human_score.std(), 1), clean=int((A.human_score >= 85).sum()), moderate=int(((A.human_score >= 60) & (A.human_score < 85)).sum()),
                 spans=int(sum(len(x) for x in A.human_error_spans)), major=M["human_severity_counts_setA"].get("major", 0),
                 minor=M["human_severity_counts_setA"].get("minor", 0))
vc = B.variant_type.value_counts()
D["setB_variants"] = [[VNAME[v], str(int(vc[v]))] for v in VNAME if v in vc]
src = B.drop_duplicates("source_id")
cat = src.category.value_counts()
CATN = {"simple_control": "Simple control", "numbers_units_dates": "Numbers, units, dates", "named_entity": "Named entities",
        "terminology": "Domain terminology", "idiom": "Idioms", "culture": "Culture-specific references",
        "ambiguity_context": "Ambiguity / context", "register": "Register and tone"}
ex_src = {c: ", ".join(src[src.category == c].source_id.head(6)) for c in CATN}
D["setB_categories"] = [[CATN[c], str(int(cat[c])), ex_src[c]] for c in CATN]
orig = src.source_origin.value_counts()
D["setB_origin"] = {k: int(v) for k, v in orig.items()}
D["setB_bands"] = {k: int(v) for k, v in B.expected_quality_band.value_counts().items()}
D["setB_review"] = {k: int(v) for k, v in B.review_status.value_counts().items()}

# ---------------- prompts
D["prompts"] = {k: v[0] for k, v in PROMPTS.items()}
D["settings"] = dict(num_ctx=S.NUM_CTX, num_predict=S.NUM_PREDICT, base_seed=S.BASE_SEED, attempts=S.MAX_ATTEMPTS,
                     timeout=S.OLLAMA_TIMEOUT, keep_alive=S.KEEP_ALIVE, weights=S.SEVERITY_WEIGHTS)

# ---------------- E1
e1 = t("E1_repeatability.csv")
D["E1"] = [[MODEL[r.model], PNAME[r.prompt], f"{r.temperature:.1f}", str(r.runs), pct(r.share_identical_all_runs), pct(r.share_inconsistent),
            pct(r.share_band_flip), f1(r.mean_range), f"{r.max_range:.0f}", f2(r.kripp_alpha), f1(r.mean_score)]
           for r in e1.sort_values(["prompt", "model", "temperature"], ascending=[False, True, True]).itertuples()]
D["E1_rho"] = [[MODEL[r.model], PNAME[r.prompt], f"{r.temperature:.1f}", f"{r.rho_single_min:.2f}–{r.rho_single_max:.2f}",
                ci(r.rho_mean_of_runs, r.rho_mean_ci_lo, r.rho_mean_ci_hi)]
               for r in e1.sort_values(["prompt", "model", "temperature"], ascending=[False, True, True]).itertuples()]
sev = t("E1_mqm_severity_by_temperature.csv")
D["E1_sev"] = [[MODEL[r.model], f"{r.temperature:.1f}", f1(r.mean_errors), pct(r.share_with_critical), pct(r.share_score_zero)] for r in sev.itertuples()]
s50 = t("E1_vs_sprint50.csv")
D["E1_s50"] = [[r.config, f"{r.identical}/{r.of}", f1(r.mean_abs_diff), f"{r.max_abs_diff:.0f}", f2(r.sprint50_rho), f2(r.sprint53_rho)] for r in s50.itertuples()]

# ---------------- E2
e2 = t("E2_prompt_wording.csv")
order = ["mqm", "mqm_reworded", "mqm_zh", "mqm_severity_defs", "mqm_analysis_first"]
e2["o"] = e2.prompt.map(order.index)
D["E2"] = [[MODEL[r.model], PNAME[r.prompt], f1(r.mean_score), ci(r.rho_human, r.ci_lo, r.ci_hi), f2(r.rho_vs_sprint50_prompt),
            pct(r.share_items_moved_10plus), pct(r.share_items_band_changed), f"{r.minor}/{r.major}/{r.critical}"]
           for r in e2.sort_values(["model", "o"]).itertuples()]

# ---------------- E3
e3 = t("E3_scales.csv")
D["E3"] = [[MODEL[r.model], r.scale, f2(r.rho_human), f2(r.rho_vs_0_100), f1(r.mean_normalised_0_100), pct(r.share_poor_band_normalised),
            str(r.distinct_values), f"{r.most_common_value:g} ({r.share_most_common:.0%})"] for r in e3.itertuples()]
cl = t("E3_flat_score_clustering.csv")
D["E3_cluster"] = [[MODEL[r.model], str(r.calls), str(r.distinct_values), r.top5, pct(r.share_top3)] for r in cl.itertuples()]

# ---------------- Set B
vt = t("E4_E7_setB_by_variant.csv")
rows = []
for v in VNAME:
    row = [VNAME[v]]
    for p in ["flat", "mqm", "mqm_ref"]:
        for m in ["glm4", "qwen"]:
            q = vt[(vt.prompt_id == p) & (vt.model == m) & (vt.variant_type == v)]
            row.append(f1(q.mean_score.iloc[0]) if len(q) else "–")
    rows.append(row)
D["B_scores"] = rows
rows = []
for v in VNAME:
    row = [VNAME[v], B[B.variant_type == v].expected_quality_band.mode().iloc[0]]
    for p in ["flat", "mqm"]:
        for m in ["glm4", "qwen"]:
            q = vt[(vt.prompt_id == p) & (vt.model == m) & (vt.variant_type == v)]
            row.append(pct(q.band_accuracy.iloc[0]) if len(q) else "–")
    rows.append(row)
D["B_band"] = rows
tq = t("E4_E7_tracks_true_quality.csv")
D["B_track"] = [[PNAME[r.prompt], MODEL[r.model], ci(r.rho_true_band, r.ci_lo, r.ci_hi), f2(r.rho_chrf_to_reference), pct(r.overall_band_accuracy)] for r in tq.itertuples()]
det = t("E6_E7_planted_error_detection.csv")
D["B_det"] = [[PNAME[r.prompt_id], MODEL[r.model], VNAME[r.variant_type], pct(r.detected) if r.prompt_id != "flat" else "n/a (no error list)",
               pct(r.ranked_below_own_gold), f1(r.mean_drop_vs_gold)] for r in det.itertuples()]
ts = t("E6_E7_tie_sensitivity.csv")
ts["o"] = ts.prompt_id.map(["flat", "mqm", "mqm_ref"].index)
D["B_ties"] = [[PNAME[r.prompt_id], MODEL[r.model], str(r.n), pct(r.below_gold_strict), pct(r.tie_with_gold),
                pct(r.not_above_gold_loose), pct(r.above_gold)] for r in ts.sort_values(["o", "model"]).itertuples()]
c = t("E7_detection_by_category.csv")
rows = []
for k in CATN:
    row = [CATN[k]]
    for m in ["glm4", "qwen"]:
        q = c[(c.category == k) & (c.prompt_id == "mqm") & (c.model == m)].iloc[0]
        row.append(pct(q.detected))
    for p in ["mqm", "flat"]:
        for m in ["glm4", "qwen"]:
            q = c[(c.category == k) & (c.prompt_id == p) & (c.model == m)].iloc[0]
            row.append(pct(q.ranked_below_own_gold))
    rows.append(row)
D["B_cat"] = rows
fp = t("E7_false_errors_on_correct_translations.csv")
D["B_fp"] = [[MODEL[r.model], str(r.correct_rows), f1(r.mean_errors_on_correct), pct(r.share_correct_with_any_error),
              pct(r.share_correct_with_major_or_critical), f"{r.min_score_on_correct:.0f}"] for r in fp.itertuples()]
sv = t("E7_error_span_validity.csv")
D["B_spans"] = [[PNAME[r.prompt_id], MODEL[r.model], pct(r.share_spans_not_in_translation), pct(r.rows_with_english_source_flagged)] for r in sv.itertuples()]
gp = t("E4_E5_paraphrase_gap.csv")
D["B_gap"] = [[PNAME[r.prompt], MODEL[r.model], f1(r.mean_gold_minus_paraphrase), pct(r.share_paraphrase_lower), pct(r.share_gap_10plus)] for r in gp.itertuples()]
lf = t("E6_literal_vs_fluent_wrong.csv")
D["B_lf"] = [[PNAME[r.prompt], MODEL[r.model], pct(r.literal_correct_wins), pct(r.tie), pct(r.fluent_wrong_wins), f1(r.literal_mean), pct(r.literal_band_accuracy)] for r in lf.itertuples()]
ar = t("E4_setA_reference.csv")
D["A_ref"] = [[MODEL[r.model], r.prompt, ci(r.rho_human, r.ci_lo, r.ci_hi), f2(r.rho_chrf)] for r in ar.itertuples()]
sc = t("E8_script.csv")
VN2 = {"traditional_char": "characters only", "traditional_tw": "Taiwan-localised"}
D["E8"] = [[PNAME[r.prompt], MODEL[r.model], VN2[r.variant], str(r.n), f"{r.mean_penalty:+.1f}", pct(r.share_penalised), pct(r.share_rewarded)] for r in sc.itertuples()]

# ---------------- E9
pb = t("E9_position_bias.csv")
D["E9"] = [[MODEL[r.model], pct(r.first), pct(r.second), pct(r.tie), pct(r.order_consistent)] for r in pb.itertuples()]
pt = t("E9_by_pair_type.csv")
PT = {"gold_vs_paraphrase": ("Gold vs valid paraphrase", "either / tie"), "literal_vs_fluent_wrong": ("Literal-correct vs fluent-wrong", "literal"),
      "gold_vs_targeted_error": ("Gold vs category error", "gold"), "simplified_vs_traditional_char": ("Simplified vs Traditional (chars)", "tie"),
      "simplified_vs_traditional_tw": ("Simplified vs Traditional (Taiwan)", "tie"), "concise_vs_padded": ("Concise vs padded", "concise or tie")}
D["E9_types"] = [[PT[r.pair_type][0], MODEL[r.model], PT[r.pair_type][1], pct(r.a), pct(r.b), pct(r.tie), pct(r.order_consistent)]
                 for r in pt.sort_values(["pair_type", "model"]).itertuples()]

# ---------------- E10
ra = t("E10_rationale_effect.csv")
D["E10"] = [[MODEL[r.model], f1(r.mean_score_plain_flat), f1(r.mean_score), pct(r.share_moved_10plus), f2(r.rho_human_plain_flat), f2(r.rho_human)] for r in ra.itertuples()]
au = t("E10_manual_audit_summary.csv")
labs = ["consistent", "false_error_claim", "invalid_span", "severity_miscalibrated", "missed_major_error", "vague"]
D["E10_audit"] = [[PNAME.get(r["prompt_id"], "Flat + rationale")] + [str(int(r.get(l, 0))) for l in labs] for _, r in au.iterrows()]
D["E10_audit"].append(["Total"] + [str(int(au[l].sum())) if l in au else "0" for l in labs])

json.dump(D, open(os.path.join(ROOT, "report", "report_data.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("wrote report/report_data.json")
