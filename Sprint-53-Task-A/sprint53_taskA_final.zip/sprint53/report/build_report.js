// Sprint 53 · Task A report builder.  node report/build_report.js
// Reads report/report_data.json (all tables/numbers) + analysis_out/examples.md + charts.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, AlignmentType, HeadingLevel,
  LevelFormat, WidthType, ShadingType, BorderStyle, Footer, Header, PageNumber, PageBreak, TabStopType,
} = require("docx");

const ROOT = path.join(__dirname, "..");
const D = JSON.parse(fs.readFileSync(path.join(ROOT, "report", "report_data.json"), "utf8"));
const M = D.metrics;
const OUT = path.join(ROOT, "report", "Sprint53_TaskA_LLM_Judge_Failure_Analysis.docx");

const FONT = { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei", cs: "Arial" };
const MONO = { ascii: "Consolas", hAnsi: "Consolas", eastAsia: "Microsoft YaHei", cs: "Consolas" };
const W = 9360;
const NAVY = "1F3864", BLUE = "2F5496", GREY = "595959", LIGHT = "D9E1F2", PALE = "F2F2F2";
const bd = { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" };
const borders = { top: bd, bottom: bd, left: bd, right: bd };

// ---------- inline markup: **bold**, _italic_
function runs(text, o = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|(?<![A-Za-z0-9])_[^_]+_(?![A-Za-z0-9]))/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, size: 21, ...o }));
    const s = m[0];
    if (s.startsWith("**")) out.push(new TextRun({ text: s.slice(2, -2), font: FONT, size: 21, ...o, bold: true }));
    else if (s.startsWith("`")) out.push(new TextRun({ text: s.slice(1, -1), font: MONO, size: 19, ...o, font: MONO }));
    else out.push(new TextRun({ text: s.slice(1, -1), font: FONT, size: 21, ...o, italics: true }));
    last = m.index + s.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, size: 21, ...o }));
  return out;
}
const P = (text, o = {}) => new Paragraph({ spacing: { after: 120, line: 276 }, ...o, children: runs(text, o.run || {}) });
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: [new TextRun({ text: t, font: FONT })] });
const H1n = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: t, font: FONT })] });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t, font: FONT })] });
const H3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun({ text: t, font: FONT })] });
const B = (text, level = 0) => new Paragraph({ numbering: { reference: "bullets", level }, spacing: { after: 60, line: 264 }, children: runs(text) });
const N = (text, ref = "num1") => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 60, line: 264 }, children: runs(text) });
const note = (text) => new Paragraph({ spacing: { before: 40, after: 160 }, children: runs(text, { size: 17, color: GREY, italics: false }) });

function table(widths, header, rows, o = {}) {
  const fs_ = o.size || 17;
  const tot = widths.reduce((a, b) => a + b, 0);
  const scale = W / tot;
  const w = widths.map((x) => Math.round(x * scale));
  w[w.length - 1] += W - w.reduce((a, b) => a + b, 0);
  const cell = (text, i, head, shade) => new TableCell({
    borders, width: { size: w[i], type: WidthType.DXA },
    shading: head ? { fill: NAVY, type: ShadingType.CLEAR, color: "auto" } : (shade ? { fill: shade, type: ShadingType.CLEAR, color: "auto" } : undefined),
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: String(text).split("\n").map((line) => new Paragraph({
      alignment: (!head && o.alignRight && i >= (o.firstNumCol || 1)) ? AlignmentType.RIGHT : AlignmentType.LEFT,
      children: runs(line, head ? { bold: true, color: "FFFFFF", size: fs_ } : { size: fs_ }),
    })),
  });
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: w,
    rows: [
      new TableRow({ tableHeader: true, children: header.map((h, i) => cell(h, i, true)) }),
      ...rows.map((r, k) => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, i, false, (o.zebra !== false && k % 2 === 1) ? PALE : (o.shadeFirst && i === 0 ? LIGHT : undefined))) })),
    ],
  });
}
const cap = (t) => new Paragraph({ spacing: { before: 60, after: 200 }, children: runs(t, { size: 17, color: GREY }) });
const gap = () => new Paragraph({ spacing: { after: 80 }, children: [] });

function pngSize(p) {
  const b = fs.readFileSync(p);
  return [b.readUInt32BE(16), b.readUInt32BE(20)];
}
function figure(file, caption, widthIn = 6.5) {
  const p = path.join(ROOT, "analysis_out", "charts", file);
  const [w, h] = pngSize(p);
  const wpx = Math.round(widthIn * 96);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120 }, children: [new ImageRun({ type: "png", data: fs.readFileSync(p), transformation: { width: wpx, height: Math.round(wpx * h / w) }, altText: { title: caption, description: caption, name: file } })] }),
    cap(caption),
  ];
}
function callout(title, lines) {
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [W],
    rows: [new TableRow({ children: [new TableCell({
      borders: { top: { style: BorderStyle.SINGLE, size: 12, color: BLUE }, bottom: bd, left: bd, right: bd },
      shading: { fill: "EEF3FA", type: ShadingType.CLEAR, color: "auto" }, width: { size: W, type: WidthType.DXA },
      margins: { top: 100, bottom: 100, left: 160, right: 160 },
      children: [new Paragraph({ spacing: { after: 80 }, children: runs(title, { bold: true, color: NAVY }) }),
        ...lines.map((l) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 50 }, children: runs(l, { size: 20 }) }))],
    })] })],
  });
}
function mono(text) {
  return text.split("\n").map((line) => new Paragraph({ spacing: { after: 0, line: 240 }, shading: { fill: PALE, type: ShadingType.CLEAR, color: "auto" },
    children: [new TextRun({ text: line || " ", font: MONO, size: 16 })] }));
}

// ---------- examples.md -> paragraphs
function examples() {
  const md = fs.readFileSync(path.join(ROOT, "analysis_out", "examples.md"), "utf8").split("\n");
  const out = [];
  for (const line of md) {
    if (line.startsWith("# ") || line.startsWith("_Generated")) continue;
    if (line.startsWith("## ")) { out.push(H3(line.slice(3).replace(/^\d+\.\s*/, (m) => "Example " + m))); continue; }
    if (line.startsWith("**What it shows:**")) { out.push(P(line)); continue; }
    const m = line.match(/^(\s*)\* (.*)$/);
    if (m) out.push(B(m[2], Math.min(2, Math.floor(m[1].length / 2))));
  }
  return out;
}

const pct = (x) => `${Math.round(x * 100)}%`;
const k = (key) => M[key];

// =====================================================================================
const C = [];

// ---------------- title page
C.push(
  new Paragraph({ spacing: { before: 1800, after: 120 }, children: [new TextRun({ text: "Vosyn Supernova · Sprint 53 · Task A", font: FONT, size: 22, color: GREY })] }),
  new Paragraph({ spacing: { after: 240 }, children: [new TextRun({ text: "Failure Analysis of LLM-as-a-Judge for English → Mandarin Translation Evaluation", font: FONT, size: 44, bold: true, color: NAVY })] }),
  new Paragraph({ spacing: { after: 480 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: BLUE, space: 8 } },
    children: [new TextRun({ text: "Where automated judging becomes inconsistent, inaccurate, biased, or sensitive to the evaluation setup", font: FONT, size: 24, color: BLUE })] }),
  table([2400, 6960], ["Item", "Detail"], [
    ["Sprint goal", "Improve the reliability and consistency of LLM-as-a-judge evaluation for English-to-Mandarin translation"],
    ["User story", "As an ML Engineer, I want to investigate failure cases when using LLM-as-a-Judge for English-to-Mandarin translation evaluation so that we can understand where automated LLM-based evaluation becomes unreliable or inconsistent."],
    ["Judges studied", "glm4 (9B) and qwen2.5 (7B) via Ollama — the judges selected in Sprint 50"],
    ["Scale of study", `${M.calls_total.toLocaleString()} judge calls · 40 real MT outputs with human scores · 275 controlled, human-reviewed translation variants · 60 comparison pairs`],
    ["Date", "30 September 2026"],
    ["Follow-on work", "Task B — prompt-engineering techniques to improve consistency and reliability (Section 12 is the hand-off)"],
  ], { zebra: false, shadeFirst: true, size: 19 }),
);

// ---------------- contents
C.push(H1("Contents"));
[
  "1. Executive summary", "2. Task, questions and scope", "3. Starting point: what Sprints 50–52 provided",
  "4. How the work was done: phases, platforms and decisions", "5. Data", "6. Judge setup and experiment design",
  "7. Analysis method", "    7.1 How a judge failure is defined", "8. Results by experiment", "9. Failure catalogue", "10. Worked English → Mandarin examples",
  "11. Implications for the Sprint 50 judge configuration", "12. Areas for prompt engineering (hand-off to Task B)",
  "13. Limitations", "14. Acceptance criteria", "Appendix A. Prompts (verbatim)", "Appendix B. Settings, files and how to reproduce",
  "Appendix C. Glossary",
].forEach((t) => C.push(new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: t, font: FONT, size: 22 })] })));

// ---------------- 1 executive summary
C.push(H1("1. Executive summary"));
C.push(P(`We tested the two judges chosen in Sprint 50 (glm4 and qwen2.5, run locally through Ollama) with ${M.calls_total.toLocaleString()} evaluation calls on English → Mandarin translations whose true quality we already knew: 40 real machine translations with human MQM scores, and 275 translations we built on purpose — correct ones, valid paraphrases, stiff literal ones, and ones containing exactly one planted error — each checked by a native Mainland Mandarin reviewer. Every call ran to completion, none produced unreadable output, and every headline number was recomputed independently from the raw files.`));
C.push(P("**The judges fail in all four ways the task asked about.**"));
C.push(callout("Headline findings", [
  "**Inaccurate — the Sprint 50 MQM scoring cannot tell a correct translation from one with a meaning error.** On the controlled set its score barely follows true quality (Spearman ρ 0.05 for glm4, 0.14 for qwen; the simple 0–100 prompt reaches 0.55–0.57). The judges list “errors” on correct translations (glm4 on 98% of them, qwen on 66%), and one real major error costs only 5 points, so it disappears in that noise.",
  "**Inconsistent — with sampling (temperature 0.7 or 1.0) verdicts are close to random.** 98–100% of items receive inconsistent MQM scores from glm4 across five runs (average spread 56–61 points); one sentence scored 98, 80, 78, 70 and 0. Even at temperature 0, 5–8% of items change between runs, and re-running Sprint 50’s exact configurations reproduced only 29–37 of its 40 scores.",
  "**Sensitive to setup — rewording the prompt, changing the scale or adding a reference changes the verdict.** Four rewordings of the same instructions reorder the items (ρ 0.29–0.69 with the original ranking) and move 22–45% of scores by 10 points or more. On a 1–5 scale glm4 calls 70% of the same translations “poor”; on 0–100, 8%.",
  "**Biased — position and reference bias.** In side-by-side comparison glm4 picks whichever translation is shown first 72% of the time and keeps its verdict when the order is swapped only 48% of the time. Given a reference, both judges score equally correct paraphrases lower than the reference wording 98–100% of the time.",
  "**glm4 misreads what it is judging.** 32% of the error spans it reports do not exist in the translation — it often flags the English source as “untranslated”; one correct translation scored 0 for this reason.",
  "**Explanations are not trustworthy evidence.** In a manual audit of 50 explanations, 13 describe errors that do not exist and only 22 were accurate and consistent with the score.",
]));
C.push(gap());
C.push(P("**What it means.** The Sprint 50 configuration (glm4 + qwen MQM ensemble) still ranks real, error-heavy machine translation about as well as before (ρ 0.52 here vs 0.60 in Sprint 50, within noise). But GEPA compares close candidates, and on close calls — one error vs none — this configuration does not separate good from bad (ρ 0.09 on the controlled set). Its “median of two judges” is simply their average, so it gives no protection against one judge being badly wrong."));
C.push(P("**Next.** Section 12 lists, for each failure, whether prompt engineering is a plausible fix and how Task B should test it. Temperature 0 (or averaging several runs), order-swapping for pairwise judging, and a revised MQM severity scheme are fixes outside the prompt; wording, rubric anchors, calibration examples, span-quoting rules and reference instructions are prompt-engineering candidates."));

// ---------------- 2 task
C.push(H1("2. Task, questions and scope"));
C.push(P("**Task A (this report):** research and experimentally explore common failure modes when an LLM evaluates English → Mandarin translations, focusing on cases where the judge gives inconsistent scores, incorrect assessments, or judgments that do not reflect translation quality."));
C.push(P("The sprint story listed thirteen areas to investigate. Each was turned into an experiment (E1–E10) with data built so that the right answer is known in advance:"));
C.push(table([3200, 1300, 4860], ["Area in the story", "Experiment", "How it was tested"], [
  ["Variability across repeated evaluations", "E1", "Every Set A item judged 3× at temperature 0 and 5× at 0.7 and 1.0, with both prompts and both judges"],
  ["Sensitivity to prompt wording and instructions", "E2", "Four rewordings of the Sprint 50 MQM prompt, each changing one thing"],
  ["Score calibration / interpretation of scales", "E3", "Same flat prompt on 0–100, 1–10 and 1–5 scales"],
  ["Over-reliance on lexical similarity to a reference", "E4", "MQM with and without a reference; correlation with chrF to the reference"],
  ["Semantic equivalence despite different wording; multiple valid translations", "E5", "Valid paraphrases vs gold, deliberately worded differently"],
  ["Literal vs natural; fluency vs accuracy", "E6", "Stiff-but-correct vs fluent-but-wrong versions of the same sentence"],
  ["Idioms, culture, context; proper nouns, terminology, named entities", "E7", "One planted error per category; is it found and is the score lowered?"],
  ["Simplified vs Traditional Chinese", "E8", "Character-converted and Taiwan-localised copies of gold, with and without a script label"],
  ["Position / order bias", "E9", "60 pairs, each shown in both orders"],
  ["Reasoning or explanation inconsistencies", "E10", "Rationale prompt, analysis-first prompt, rule checks and a manual audit of 50 explanations"],
], { size: 18 }));
C.push(gap());
C.push(P("**Acceptance criteria:** failure categories identified and documented; English→Mandarin examples; repeated evaluations; observed inconsistencies and causes documented; areas for prompt engineering identified; findings summarised (in this Word document, as agreed, instead of Notion). Section 14 maps each criterion to the evidence."));
C.push(P("**In scope:** English → Mandarin (Simplified, Mainland) only; the two Sprint 50 judges; the Sprint 50 prompts and controlled variations of them. **Out of scope:** Cantonese and Mandarin → English; improving the prompts (Task B); other judge models."));

// ---------------- 3 background
C.push(H1("3. Starting point: what Sprints 50–52 provided"));
C.push(table([1500, 3900, 3960], ["Sprint", "What it produced", "How Sprint 53 used it"], [
  ["50", "Judge validation: 5 configurations (glm4/qwen × flat/MQM + ensemble) scored against human-labelled gold sets. Selected glm4_qwen_ensemble_mqm for English → Mandarin (Spearman 0.598, MAE 8.43). Prompts, Ollama client, severity weights 1/5/25, guardrails.", "Same judges, same prompts (verbatim), same scoring formula. Its 40-item English → Mandarin gold set (SiniticMTError) became Set A. Its per-sentence scores were used to test reproducibility."],
  ["51", "Reproducible English → Mandarin fine-tuning pipeline on Colab (LoRA/QLoRA).", "Not needed for Task A (a possible source of candidate translations later)."],
  ["52", "20 independently sourced English → Mandarin items with candidate translations and seeded errors, packaged for human review (instructions + workbook).", "All 20 sources reviewed for Set B; 16 kept (4 simple sentences swapped for harder categories). Its review-package design was reused."],
], { size: 18 }));
C.push(gap());
C.push(P("Two observations in the Sprint 50 results pointed to where to look: (1) the ensemble “median” of two judges equals their mean, so a single outlier (e.g. glm4 7 vs qwen 88 on one sentence) drags the result; (2) qwen’s flat 0–100 scores had good ranking but poor calibration (MAE 23.1), clustering on a few values such as 20."));

// ---------------- 4 phases
C.push(H1("4. How the work was done: phases, platforms and decisions"));
C.push(P("The work was run as confirmed steps: each step was planned, questions were answered, the step was executed, and its output was checked before moving on."));
C.push(table([1300, 3700, 4360], ["Phase", "What was done", "Key decisions and why"], [
  ["0 · Planning", "Mapped the 13 story areas to experiments; reviewed Sprints 50–52 for reusable judges, prompts, data and code.", "Test the judges the team actually uses (glm4 + qwen via Ollama) rather than a different API model, so the findings apply to the Sprint 50 decision."],
  ["1 · Datasets", "Built Set A (40 real MT outputs), Set B (275 controlled variants of 40 sources) and 60 pairs; automatic validation; external review by one native Mainland reviewer; merge of corrections.", "One planted error per variant so a miss is unambiguous. Traditional variants in two forms (character-only and Taiwan-localised) at your request. Gold references written by Claude, corrected by the reviewer."],
  ["2 · Harness", "Judge code (prompts, Ollama client, parser, experiment plan, resumable runner), Colab notebook without Google Drive, 24-call smoke test.", "Sprint 50 prompts verbatim; no forced-JSON mode; seed, context size and output caps fixed for reproducibility; every call saved immediately so a stop loses nothing."],
  ["3 · Settings", "Confirmed the run: 4,758 calls, one call at a time, 3 h 15 min per session in 30-minute checkpointed chunks.", "Smoke test measured 2.3 s/call (glm4) and 1.4 s/call (qwen), so the full plan fitted in about 2.5 hours — no need to trim or parallelise (parallel calls could blur the repeatability test)."],
  ["4 · Experiments", "All 11 phases run on a free Colab T4 GPU across 5 sessions, resuming from downloaded checkpoints.", "Identical model files in every session (recorded digests)."],
  ["5 · Analysis", "Integrity checks, tables, 7 charts, bootstrap confidence intervals, rule-based reasoning checks, manual audit of 50 explanations, 10-case example gallery; independent recomputation of headline numbers.", "Inconsistent = runs differ by ≥10 points or land in different bands. Set B truth = reviewer-confirmed band. Reasoning audited without another GPU run."],
  ["6 · Report", "This document.", "Traditional-script output is treated as neutral (not an error), per product decision."],
], { size: 17 }));
C.push(gap());
C.push(H2("4.1 Platform history"));
C.push(P("The execution platform changed during the sprint; none of the changes affected results, because the code, data and judge models stayed the same:"));
C.push(B("Planned first on Claude via API — replaced by the Sprint 50 Ollama judges so the study tests the configuration in use."));
C.push(B("A local 8 GB Mac was considered — feasible for Step 1 but too slow for ~4,800 judge calls (glm4 would swap memory)."));
C.push(B("Lightning AI Studio (CPU) was used for Step 1: dataset build, review merge and fixes."));
C.push(B("Google Colab free tier (Tesla T4, 15 GB) ran Steps 2–4, **without mounting Google Drive**: each session starts by uploading the latest checkpoint zip, and the notebook downloads a new checkpoint every 30 minutes."));
C.push(B("Findings are summarised in this Word document instead of Notion."));

// ---------------- 5 data
C.push(H1("5. Data"));
C.push(P("Two complementary sets were used. **Set A** contains real, messy machine translation with independent human scores — it tells us whether judges agree with people. **Set B** contains controlled translations where we changed exactly one thing — it tells us what a judge misses and why."));
C.push(H2("5.1 Set A — real MT output with human MQM scores"));
const a = D.setA;
C.push(table([2600, 6760], ["Property", "Value"], [
  ["Source", "Sprint 50 English → Mandarin gold set, drawn from SiniticMTError (human bilingual annotators)"],
  ["Items", `${a.n} English sentences (FLORES-style news, science and travel text) with one MT output each and a human reference translation`],
  ["Human labels", `${a.spans} annotated error spans (${a.major} major, ${a.minor} minor); human score = 100 − Σ(minor 1, major 5), floor 0`],
  ["Score range", `${a.min}–${a.max}, mean ${a.mean}, SD ${a.sd}; ${a.clean} “clean” (≥85), ${a.moderate} “moderate” (60–84), none “poor”`],
  ["Used in", "E1 repeatability, E2 wording, E3 scales, E4 reference, E10 reasoning"],
], { zebra: false, shadeFirst: true, size: 18 }));
C.push(H2("5.2 Set B — controlled variants"));
C.push(P("**Design principle:** for each English source we wrote several Mandarin versions whose quality we control. Error versions contain **exactly one** planted error, recorded with its text span, MQM type, severity and a description, so a judge’s miss or over-penalty can be pinned down."));
C.push(P(`**Sources (40):** ${D.setB_origin.sprint52} from Sprint 52, ${D.setB_origin.sprint50} from Set A (chosen by one rule: the sentence contains a named entity, domain term, number or unit), and ${D.setB_origin.new_sprint53} new sentences written so that every category has at least five sources.`));
C.push(table([2600, 900, 5860], ["Category", "Sources", "Source IDs"], D.setB_categories, { size: 17 }));
C.push(cap("Table 5.1 — Set B sources by category. S52 = Sprint 52, A = Set A (Sprint 50), N = new in Sprint 53."));
C.push(table([2600, 5200, 1560], ["Variant", "How it was made / what it tests", "Rows"], [
  ["Gold", "Correct, natural Mainland Mandarin reference (Set A references reused; others written and reviewer-checked)", D.setB_variants.find((r) => r[0] === "Gold")[1]],
  ["Valid paraphrase", "Same meaning, deliberately different wording (median chrF to gold 17 of 100) — tests semantic equivalence", D.setB_variants.find((r) => r[0] === "Valid paraphrase")[1]],
  ["Literal but correct", "Word-for-word English structure, no meaning error — tests literal vs natural", D.setB_variants.find((r) => r[0] === "Literal but correct")[1]],
  ["Fluent, 1 meaning error", "Reads naturally but one meaning error (negation, number, agent, tense…) — tests fluency vs accuracy", D.setB_variants.find((r) => r[0] === "Fluent, 1 meaning error")[1]],
  ["1 category error", "One error typical of the source’s category (idiom taken literally, wrong name, wrong unit, over-localisation, register slip)", D.setB_variants.find((r) => r[0] === "1 category error")[1]],
  ["Padded (wordy)", "Same meaning as gold, deliberately verbose — verbosity check in pairwise judging", D.setB_variants.find((r) => r[0] === "Padded (wordy)")[1]],
  ["Traditional (characters)", "Gold converted with OpenCC s2tw — script changes, words stay", D.setB_variants.find((r) => r[0] === "Traditional (characters)")[1]],
  ["Traditional (Taiwan)", "Gold hand-localised for Taiwan (伺服器, 公尺, 財務長, 「」). Automatic s2twp changed only 6 of 30 sentences and got 2 wrong, so it was not used", D.setB_variants.find((r) => r[0] === "Traditional (Taiwan)")[1]],
  ["Original MT output", "The existing Sprint 50/52 machine translation, kept exactly as produced", D.setB_variants.find((r) => r[0] === "Original MT output")[1]],
], { size: 17 }));
C.push(cap(`Table 5.2 — Set B variant types (275 rows). Expected bands: ${D.setB_bands.clean} clean, ${D.setB_bands.moderate} moderate, ${D.setB_bands.poor} poor.`));
C.push(P("**Automatic validation** (script `validate_datasets.py`, must pass before use): required fields and unique IDs; every planted span present verbatim in its text; no flawed row identical to gold; Simplified rows contain no Traditional-only characters and vice versa (character-level OpenCC check); paraphrases lexically distant from gold (chrF < 60; one expected exception — a password must stay verbatim); at least five sources per category; pairs match their rows. Final result: 0 hard failures, 1 expected warning."));
C.push(H2("5.3 Human review"));
C.push(P("One native Mainland Mandarin reviewer checked all 265 rows that were not already human-labelled, using a workbook (dropdown answers, auto-computed agreement column, progress summary) and a four-page instruction document with band definitions, MQM error types, severity guidance and worked examples. For each row the reviewer answered: does the row match its description; their own quality band; the severity of the planted error; any other errors; a corrected sentence if needed."));
C.push(B("**Result:** the reviewer confirmed all rows and agreed with our expected band on 265 of 265 rows."));
C.push(B("**Corrections:** one gold reference was improved (S52_020: 说得客气一点，首席财务官的那番话不太坦诚。); its Taiwan version was updated by hand to match."));
C.push(B("**A process bug found and fixed:** the reviewer also wrote corrected versions of five Sprint 52 machine translations. The first merge script replaced those machine outputs with the corrections — which would have made four “poor” rows identical to gold. A new validation check caught it; the original machine outputs were restored and the corrections kept as reference information only."));
C.push(B("**Caveat:** 100% agreement is unusually high and may partly reflect anchoring on the “expected band” column shown in the workbook. See Limitations."));
C.push(H2("5.4 Pairs"));
C.push(P("60 A/B pairs for position-bias testing, drawn with a fixed seed: 20 gold vs paraphrase (either is acceptable), 15 literal-correct vs fluent-wrong (literal should win), 10 gold vs category error (gold should win), 5 + 5 Simplified vs Traditional (tie), 5 concise vs padded. Every pair is judged in both orders."));

// ---------------- 6 judge setup
C.push(H1("6. Judge setup and experiment design"));
C.push(H2("6.1 Models and environment"));
C.push(table([2600, 6760], ["Item", "Value"], [
  ["Judge 1", `${M.env.models.glm4} — glm4 9B, Ollama default 4-bit quantisation (same tag as Sprint 50)`],
  ["Judge 2", `${M.env.models.qwen} — qwen2.5 7B, Ollama default 4-bit quantisation (same tag as Sprint 50)`],
  ["Runtime", `Ollama ${M.env.ollama} on Google Colab free tier, ${M.env.gpu}; both models kept loaded together`],
  ["Sessions", `${M.env.sessions} Colab sessions; model digests identical in all sessions: ${M.env.same_model_digests_all_sessions ? "yes" : "no"}`],
], { zebra: false, shadeFirst: true, size: 18 }));
C.push(H2("6.2 Prompt set"));
C.push(P("The Sprint 50 flat and MQM prompts were copied **verbatim** (checked character-for-character, including the target label “Standard Mandarin Chinese (Simplified script)”). Every other prompt changes exactly one thing, so its effect can be isolated. Full texts are in Appendix A."));
C.push(table([2300, 1100, 5960], ["Prompt", "Used in", "What changes vs the Sprint 50 prompt"], [
  ["flat", "E1, E5–E7", "Nothing — Sprint 50 holistic 0–100 score"],
  ["mqm", "E1, E4–E7", "Nothing — Sprint 50 error list; score computed in Python"],
  ["mqm_reworded", "E2", "Same instructions, different English wording"],
  ["mqm_zh", "E2", "Same instructions written in Chinese"],
  ["mqm_severity_defs", "E2", "Adds definitions of minor / major / critical"],
  ["mqm_analysis_first", "E2, E10", "Asks for a short analysis (≤ 3 sentences) before the error list"],
  ["flat_1to5 / flat_1to10", "E3", "1–5 or 1–10 scale instead of 0–100"],
  ["mqm_ref", "E4", "Adds the gold/human reference translation"],
  ["mqm_neutral_label", "E8", "Target label “Mandarin Chinese” (no script named)"],
  ["pairwise", "E9", "Which of translation A or B is better, or tie"],
  ["flat_rationale", "E10", "1–2 sentence rationale before the 0–100 score"],
], { size: 17 }));
C.push(H2("6.3 Settings and why"));
const s = D.settings;
C.push(table([1900, 2300, 2900, 2260], ["Setting", "Value", "Why", "Alternatives considered"], [
  ["Output format", "Free text, parsed by us", "Same as Sprint 50; malformed output is itself a failure mode", "Ollama forced-JSON mode (changes decoding)"],
  ["MQM score", `100 − Σ(minor ${s.weights.minor}, major ${s.weights.major}, critical ${s.weights.critical}), floor 0; unknown severity = minor`, "Sprint 50 formula, computed in code (never by the model)", "—"],
  ["Temperatures / runs", "E1: 0.0 ×3, 0.7 ×5, 1.0 ×5; all other experiments 0.0 ×1", "0 is the deployed setting; 0.7 and 1.0 expose sampling variability (1.0 added at your request)", "—"],
  ["Seed", `${s.base_seed} + run index; retries +100`, "Reproducible runs; a same-seed retry at T=0 would repeat the same bad output", "Unseeded"],
  ["Attempts", `up to ${s.attempts} if unparseable`, "Sprint 50 value; first-attempt success also recorded", "1 attempt"],
  ["Context size", `${s.num_ctx} tokens`, "Longest prompt ≈ 1,000 tokens; default can be 2,048", "2,048"],
  ["Output cap", `flat ${s.num_predict.flat}, MQM ${s.num_predict.mqm}, MQM+analysis ${s.num_predict.mqm_analysis}, rationale ${s.num_predict.flat_rationale}, pairwise ${s.num_predict.pairwise} tokens`, "Stops runaway output; truncation is flagged", "Unlimited (Sprint 50)"],
  ["Timeout", `${s.timeout} s per call, 3 network retries`, "Sprint 50 final value", "—"],
  ["Parallelism", "1 call at a time", "Parallel requests are batched on the GPU and could blur the repeatability test; not needed for speed", "2–4 workers"],
], { size: 16 }));
C.push(H2("6.4 Experiment plan"));
C.push(P("Eleven phases ran in order. Each temperature of the repeatability experiment is its own phase, as requested, so a session could stop at any point and continue later."));
C.push(table([2100, 1000, 2300, 2400, 800, 760], ["Phase", "Exp.", "Data", "Prompts", "Temp", "Calls"], [
  ["P01_E1_T00", "E1", "Set A (40)", "mqm, flat", "0.0 ×3", "480"],
  ["P02_E1_T07", "E1", "Set A", "mqm, flat", "0.7 ×5", "800"],
  ["P03_E1_T10", "E1", "Set A", "mqm, flat", "1.0 ×5", "800"],
  ["P04_E2_prompts", "E2", "Set A", "4 MQM variants", "0.0", "320"],
  ["P05_E3_scales", "E3", "Set A", "flat 1–5, 1–10", "0.0", "160"],
  ["P06_E4_setB_mqm", "E4–E7", "Set B (275)", "mqm", "0.0", "550"],
  ["P07_E4_mqm_ref", "E4", "Set A + B", "mqm + reference", "0.0", "630"],
  ["P08_E5_setB_flat", "E5–E7", "Set B", "flat", "0.0", "550"],
  ["P09_E8_script", "E8", "44 Traditional + 30 golds", "mqm, neutral label", "0.0", "148"],
  ["P10_E9_pairwise", "E9", "60 pairs × 2 orders", "pairwise", "0.0", "240"],
  ["P11_E10_rationale", "E10", "Set A", "flat + rationale", "0.0", "80"],
  ["Total", "", "", "", "", M.calls_total.toLocaleString()],
], { size: 17 }));
C.push(cap("Table 6.1 — Every call is made once per judge; counts include both judges."));
C.push(H2("6.5 Execution and data integrity"));
C.push(B("Every finished call was appended to its phase file immediately with a unique key (phase, model, prompt, item, temperature, run, order); on restart the runner skipped saved keys. Tested before use for budget stops, forced kills, half-written lines and server crashes."));
C.push(B(`**Integrity of the final data:** ${M.calls_total.toLocaleString()} of ${M.calls_total.toLocaleString()} planned calls present; 0 duplicates; 0 unparseable answers; ${M.calls_needing_retry} calls needed a second attempt; ${M.calls_truncated} hit the output cap.`));
C.push(B("Measured cost: about 2.5 GPU-hours of judge time (glm4 2.5 s and qwen 1.3 s per call on average)."));

// ---------------- 7 method
C.push(H1("7. Analysis method"));
C.push(table([2400, 6960], ["Term", "Definition used in this report"], [
  ["Band", "clean ≥ 85 · moderate 60–84 · poor < 60 on the 0–100 scale (Sprint 50 buckets). Other scales are rescaled to 0–100 first."],
  ["Inconsistent (E1)", "Repeated runs of the same judge, prompt, temperature and item differ by ≥ 10 points **or** fall in more than one band."],
  ["Ground truth, Set A", "Human MQM score from SiniticMTError."],
  ["Ground truth, Set B", "Reviewer-confirmed band. The MQM-expected score is not used as truth because one major error only costs 5 points under the Sprint 50 formula (still “clean”)."],
  ["Agreement", "Spearman rank correlation ρ. 95% confidence intervals from 2,000 item-level bootstrap resamples (seed 42). With n = 40, intervals are about ±0.25 wide — differences smaller than that are not meaningful and are not claimed."],
  ["Krippendorff’s α", "Agreement of a judge with itself across repeated runs (interval metric); 1 = identical, 0 = no better than chance."],
  ["Detected (planted error)", "A listed error span contains the planted span (or lies inside it) and is not a whole-sentence quote (≤ 3× the span length + 6 characters)."],
  ["Ranked below own gold", "The flawed version of a sentence scores strictly lower than the correct version of the same sentence, same judge, same prompt."],
  ["Reasoning audit", "Rule-based checks on all rationales/analyses, plus a manual audit of 50 outputs labelled consistent, false error claim, invalid span, severity miscalibrated, missed major error, or vague."],
], { zebra: false, shadeFirst: true, size: 18 }));
C.push(gap());
C.push(P("**Verification.** All tables come from one script (`analysis/analyze.py`); the report builder reads those tables directly, so no result is typed by hand. Headline numbers were recomputed with separate code straight from the raw result files and matched exactly."));
C.push(H2("7.1 How a judge failure is defined"));
C.push(P("An output is counted as a **judge failure only when it disagrees with a reference we can trust**. Four kinds of reference are used, from strongest to weakest. Every failure in Section 9 is traced to at least one of them."));
C.push(table([1900, 2500, 2900, 2060], ["Test", "What the judge is compared against", "Counted as a failure when", "Supports"], [
  ["1. Invariance (no correct answer needed)", "The judge itself, under a change that should not matter: re-running, swapping the order, rewording the same instructions", "The verdict changes. Repeats: runs differ by ≥ 10 points or land in different bands. Pairs: the preferred translation flips when the order is swapped. Rewordings: the ranking of items changes", "F2, F3, F4, F5, F12"],
  ["2. Paired contrast (Set B)", "The same sentence in two versions whose order of quality is known: the correct gold vs the same sentence with one planted error; gold vs a valid paraphrase", "The flawed version is not scored lower than its own gold; a valid paraphrase is penalised", "F1, F6, F9, F11"],
  ["3. Checkable facts", "The text itself", "The judge reports an error that does not exist in the translation, quotes English source text as ‘untranslated’, or calls a correct rendering wrong (e.g. 全场六折 for ‘everything 40% off’)", "F7, F11, F12, F13"],
  ["4. Human scores (Set A)", "Independent human MQM scores (SiniticMTError)", "Measured statistically as rank agreement, not item by item. Called a failure only when agreement collapses or drops relative to a comparable setup", "F1, F3, F8"],
], { size: 16 }));
C.push(cap("Table 7.1 — The four tests behind every failure finding."));
C.push(P("**Why the paired contrast carries the most weight.** It does not depend on calibration or thresholds. If a judge gives the same 95 to 这家店正在搞黑色星期五促销，全场六折。 and to the version that wrongly says 部分商品六折, it cannot tell them apart, whatever cut-off is chosen. That is why F1 rests on ‘scored below its own gold’ rather than on band accuracy: under the Sprint 50 formula a single major error leaves 95 (‘clean’), so band accuracy would overstate the MQM failure."));
C.push(P("**What is deliberately not called a failure:**"));
C.push(B("A single item where the judge disagrees with the human score. Humans disagree with each other too, and no human-vs-human agreement figure exists for these 40 items, so an agreement of about 0.5 is reported as ‘moderate’, not as a failure."));
C.push(B("Differences inside the statistical noise. With 40 items, differences in Spearman ρ below about 0.25 are not claimed; this is why no reworded prompt is declared better than another."));
C.push(B("Traditional-script output, which is acceptable by product decision (F10 is informational)."));
C.push(H3("Sensitivity check: does a tie with the gold count as a failure?"));
C.push(P("The paired-contrast rule used throughout is strict: the flawed version must score **strictly lower** than its gold. For ranking candidates a tie means the judge cannot separate them, so the strict rule matches how the judge is used. The table shows how much the results depend on that choice (80 flawed translations per row: 40 fluent-but-wrong + 40 category errors):"));
C.push(table([2100, 1000, 700, 1500, 1200, 1500, 1360], ["Prompt", "Judge", "n", "Below gold (strict rule)", "Tie with gold", "Not above gold (loose rule)", "Above gold"], D.B_ties, { size: 16 }));
C.push(cap("Table 7.2 — Paired-contrast results under the strict and the loose tie rule."));
C.push(B("Under the loose rule the MQM prompt looks better (71% glm4, 85% qwen instead of 35% and 60%), because many flawed versions tie with their gold."));
C.push(B("**The conclusion of F1 does not depend on the rule:** with MQM scoring the flawed version is scored strictly **higher** than the correct one in 29% (glm4) and 15% (qwen) of cases, against 1% for the flat prompt. A judge that ranks the wrong translation above the right one in roughly one case in five is unreliable for close comparisons under either rule."));
C.push(B("With a reference the strict and loose rules agree (no ties), but that result is inflated: the gold is identical to the reference and scores about 100 (Section 8.4)."));
C.push(H3("Where the definition is weaker than it looks"));
C.push(B("**‘Judge’ means the whole configuration: model + prompt + scoring formula.** Some failures belong to the model (glm4 quoting the English source as an error, F7); others partly to the scoring scheme (in F1, the 5-point weight for a major error). Section 9 attributes causes, and Task B must separate them, because prompt changes cannot fix the formula."));
C.push(B("**Variability at temperature 0.7–1.0 (F2) is a failure for single-shot scoring,** which is how GEPA uses the judge. If many runs are averaged it becomes a cost rather than a failure."));
C.push(B("**Set B’s ground truth is only as good as its review.** The variants were written by Claude and confirmed by one reviewer who agreed with every expected band, possibly anchored on the ‘expected band’ column. A planted error that is actually debatable would turn a ‘judge failure’ into a labelling issue."));
C.push(B("**Detection of planted errors is string-based** (the judge must quote the planted span), so detection rates are a lower bound."));
C.push(B("**The manual audit of explanations was done by Claude,** not a native speaker."));
C.push(P("**What would make the verdicts firmer:** a second, independent reviewer on Set B who does not see the expected band (rows where reviewers disagree would be dropped from the paired tests); a human-vs-human agreement baseline on Set A; and a native-speaker check of the flagged cases — the 13 explanations labelled as false error claims and the planted errors the judges missed."));

// ---------------- 8 results
C.push(H1("8. Results by experiment"));
// E1
C.push(H2("8.1 E1 — Repeatability"));
C.push(P("**Question:** does the same judge give the same verdict for the same translation and prompt when asked again?"));
C.push(...figure("fig1_repeatability.png", "Figure 8.1 — Share of the 40 Set A items scored inconsistently across repeated runs."));
C.push(table([900, 1100, 600, 600, 900, 1100, 900, 900, 700, 800, 900], ["Judge", "Prompt", "T", "Runs", "Identical all runs", "Inconsistent", "Band flips", "Mean spread", "Max spread", "α", "Mean score"], D.E1, { size: 15, alignRight: true, firstNumCol: 2 }));
C.push(cap("Table 8.1 — Repeatability on Set A. Spread = max − min score across runs, in points."));
C.push(B("**Temperature 0 is almost, but not fully, deterministic:** 85–95% of items get identical scores in all three runs; 5–8% are inconsistent. Greedy decoding should not depend on the seed, so the remaining differences are most likely GPU numerical non-determinism."));
C.push(B("**Sampling makes the MQM prompt unusable for glm4:** at 0.7 and 1.0 almost every item is inconsistent, the average spread is 56–61 points and self-agreement α falls to 0.14–0.15. qwen is steadier (α ≈ 0.5) but still inconsistent on 70–73% of items. The flat prompt is more stable (α 0.82–0.95) because its scores move in smaller steps."));
C.push(P("**Why glm4’s MQM scores swing so much:** the number of errors it lists barely changes with temperature, but their severity does — at T > 0 it labels at least one error “critical” (−25 points) in 40–51% of calls, and 8.5–9.5% of calls end at score 0:"));
C.push(table([1500, 1500, 2000, 2200, 2160], ["Judge", "Temperature", "Mean errors listed", "Calls with a ‘critical’", "Calls scoring 0"], D.E1_sev, { size: 17, alignRight: true, firstNumCol: 1 }));
C.push(gap());
C.push(P(`**Same score, different reasons:** among ${M.E1_same_score_pairs} pairs of MQM runs that produced the same score, only ${pct(M.E1_same_score_identical_error_list)} listed the same errors and ${pct(M.E1_same_score_no_shared_span)} shared no error span at all — a stable number can hide unstable reasoning.`));
C.push(P("**Averaging runs and agreement with humans:**"));
C.push(table([1200, 1600, 800, 2400, 3360], ["Judge", "Prompt", "T", "ρ of single runs (min–max)", "ρ of the run average [95% CI]"], D.E1_rho, { size: 16 }));
C.push(cap("Table 8.2 — Agreement with human scores. Averaging five qwen MQM runs at 0.7 gave ρ 0.66 vs 0.41 for single T=0 runs, but the intervals overlap: averaging is a candidate fix for Task B, not a result."));
C.push(P("**Reproducing Sprint 50:** the same prompts and model tags at temperature 0, run on different hardware with explicit seed and context settings, reproduced most but not all Sprint 50 scores:"));
C.push(table([1800, 1500, 1500, 1400, 1580, 1580], ["Sprint 50 config", "Identical scores", "Mean |diff|", "Max |diff|", "ρ Sprint 50", "ρ Sprint 53"], D.E1_s50, { size: 17, alignRight: true, firstNumCol: 1 }));
C.push(gap());
// E2
C.push(H2("8.2 E2 — Sensitivity to prompt wording"));
C.push(P("**Question:** do rewordings that ask for the same thing give the same verdict?"));
C.push(...figure("fig2_prompt_wording.png", "Figure 8.2 — Agreement with human scores for five MQM prompt wordings (dot = estimate, line = 95% bootstrap CI)."));
C.push(table([900, 2000, 900, 1700, 1100, 1000, 900, 860], ["Judge", "Prompt", "Mean score", "ρ with human [95% CI]", "ρ vs Sprint 50 prompt", "Items moved ≥10", "Band changed", "Errors minor/major/critical"], D.E2, { size: 15 }));
C.push(cap("Table 8.3 — Prompt-wording variants on Set A (temperature 0)."));
C.push(B("Rewordings **reorder the items**: ranking correlation with the original prompt is only 0.29–0.69, and 22–45% of items move by 10 points or more."));
C.push(B("The **best wording differs by judge** (glm4: the original; qwen: the reworded prompt, 0.66 vs 0.41), but all confidence intervals overlap — no variant is shown to be better. The finding is the instability itself."));
C.push(B("Asking for an analysis first makes glm4 use “minor” much more often (52 vs 13 minor errors) and raises its scores; qwen’s severity definitions prompt produces more “critical” labels."));
C.push(B("Neither judge’s severity use matches the human annotators: humans labelled 32% of errors minor; the judges label 3–35% minor depending on the prompt, mostly “major”."));
// E3
C.push(H2("8.3 E3 — Scale and calibration"));
C.push(P("**Question:** does the scale change the verdict, and do judges use the scale sensibly?"));
C.push(...figure("fig3_scales.png", "Figure 8.3 — Mean score on the same 40 translations with three scales, rescaled to 0–100.", 5.6));
C.push(table([900, 900, 1000, 1200, 1300, 1300, 1000, 1760], ["Judge", "Scale", "ρ with human", "ρ vs 0–100", "Mean (rescaled)", "Judged poor", "Distinct values", "Most common value"], D.E3, { size: 16 }));
C.push(cap("Table 8.4 — Same flat prompt, three scales, Set A, temperature 0."));
C.push(B("**Rankings are stable across scales** (ρ 0.85–0.95 between scales) but **absolute verdicts are not**: glm4 calls 8% of the translations poor on 0–100, 48% on 1–10 and 70% on 1–5. Any fixed threshold (e.g. “accept if ≥ 85”) therefore depends on the scale chosen."));
C.push(B("The two judges disagree on what the scale means: on 0–100 glm4 averages 79 and qwen 61 for the same translations (humans: 84)."));
C.push(table([1000, 900, 1100, 4560, 1800], ["Judge", "Flat calls", "Distinct values", "Most used values (share of calls)", "Top 3 values"], D.E3_cluster, { size: 16 }));
C.push(cap(`Table 8.5 — Score clustering across all flat 0–100 calls. qwen gives exactly 20 to ${M.qwen_flat_20_count_setA} Set A items whose human scores average ${Math.round(M.qwen_flat_20_human_mean)}.`));
// E4
C.push(H2("8.4 E4 — Reference translations and lexical similarity"));
C.push(P("**Question:** does showing a reference make judges reward surface similarity instead of meaning?"));
C.push(...figure("fig6_reference_paraphrase.png", "Figure 8.4 — Share of the 40 valid paraphrases scored below the gold wording, without and with the gold as reference.", 5.2));
C.push(table([2300, 1200, 2000, 2000, 1860], ["Prompt", "Judge", "Mean gold − paraphrase", "Paraphrase scored lower", "Gap ≥ 10 points"], D.B_gap, { size: 17 }));
C.push(cap("Table 8.6 — Valid paraphrases vs the gold wording (Set B)."));
C.push(B("With a reference, **valid paraphrases score below the reference wording 98–100% of the time**, and 40–43% lose 10 points or more. The reference-based judge becomes a difference detector: its scores correlate positively with chrF to the reference (0.21–0.26) but not with true quality (−0.09 to 0.00; Table 8.9)."));
C.push(B("The same effect penalises Traditional-script copies of the gold: glm4 lowers them 90% (characters) and 93% (Taiwan) of the time with a reference, vs 23% and 36% without (Section 8.6)."));
C.push(B("On Set A, adding a reference moved agreement with humans in opposite directions for the two judges; both changes are within noise:"));
C.push(table([1400, 2600, 3200, 2160], ["Judge", "Prompt", "ρ with human [95% CI]", "ρ with chrF to reference"], D.A_ref, { size: 17 }));
C.push(gap());
// E5-E7
C.push(H2("8.5 E5–E7 — Controlled variants: paraphrase, literal vs fluent, planted errors"));
C.push(P("**Question:** when we know exactly what is right and wrong, does the judge see it?"));
C.push(...figure("fig4_variant_scores.png", "Figure 8.5 — Mean score by translation type under three prompts (Set B, temperature 0)."));
C.push(table([2400, 1160, 1160, 1160, 1160, 1160, 1160], ["Variant", "Flat glm4", "Flat qwen", "MQM glm4", "MQM qwen", "MQM+ref glm4", "MQM+ref qwen"], D.B_scores, { size: 16, alignRight: true, firstNumCol: 1 }));
C.push(cap("Table 8.7 — Mean score by variant type."));
C.push(table([2400, 1300, 1415, 1415, 1415, 1415], ["Variant", "Reviewer band", "Flat glm4", "Flat qwen", "MQM glm4", "MQM qwen"], D.B_band, { size: 16 }));
C.push(cap("Table 8.8 — Share of rows where the judge’s band matches the reviewer’s band. MQM is disadvantaged by its formula (one major error = 95 = clean); Table 8.10 compares within the same sentence instead."));
C.push(table([2300, 1100, 2600, 1800, 1560], ["Prompt", "Judge", "ρ with true band [95% CI]", "ρ with chrF to ref.", "Band accuracy (all rows)"], D.B_track, { size: 16 }));
C.push(cap("Table 8.9 — Does the score follow true quality? Set B, Simplified rows except gold (n = 191)."));
C.push(...figure("fig5_planted_errors.png", "Figure 8.6 — Share of the 80 flawed translations (fluent-wrong + category error) scored below their own correct version.", 5.6));
C.push(table([1900, 1000, 2100, 1600, 1500, 1260], ["Prompt", "Judge", "Variant", "Planted error detected", "Scored below own gold", "Mean drop vs gold"], D.B_det, { size: 16 }));
C.push(cap("Table 8.10 — Planted-error detection. With a reference, the gold is identical to the reference and scores ~100, so “below gold” is trivially high there."));
C.push(P("**Key result (F1).** Under the Sprint 50 MQM prompt the judges usually *find* the planted error (55–83% detected), yet the flawed version is scored below the correct one only 35% (glm4) and 60% (qwen) of the time. The reason is visible in Table 8.11: the judges also list errors on correct translations, so the planted error adds only −5 to a score already lowered by false errors. The result holds under a looser tie rule as well (Table 7.2): with MQM the flawed version is scored strictly higher than the correct one in 29% (glm4) and 15% (qwen) of cases."));
C.push(table([1200, 1300, 1700, 1900, 2000, 1260], ["Judge", "Correct rows", "Mean errors listed", "With any error", "With a major/critical", "Lowest score"], D.B_fp, { size: 16, alignRight: true, firstNumCol: 1 }));
C.push(cap("Table 8.11 — Errors reported on correct translations (gold + valid paraphrase, MQM prompt)."));
C.push(table([2700, 1300, 2700, 2660], ["Prompt", "Judge", "Error spans not in the translation", "Rows flagging English source text"], D.B_spans, { size: 16 }));
C.push(cap("Table 8.12 — Error-span validity. glm4 frequently quotes the English source as an ‘Untranslated’ error (F7)."));
C.push(P("**Literal vs natural, fluency vs accuracy (E6).** Stiff, word-for-word translations are rated as clean (88–94 on every prompt) although the reviewer rates them moderate. When a stiff-but-correct and a fluent-but-wrong version of the same sentence are compared, the flat prompt prefers the correct one most of the time; MQM often ties them or prefers the fluent wrong one:"));
C.push(table([2100, 1000, 1500, 1000, 1500, 1100, 1160], ["Prompt", "Judge", "Literal-correct wins", "Tie", "Fluent-wrong wins", "Literal mean", "Literal band correct"], D.B_lf, { size: 16 }));
C.push(gap());
C.push(P("**By category (E7).** Detection is weakest for named entities and terminology and strongest for register and simple sentences:"));
C.push(table([2560, 1100, 1100, 1150, 1150, 1150, 1150], ["Category", "Detected MQM glm4", "Detected MQM qwen", "Below gold MQM glm4", "Below gold MQM qwen", "Below gold flat glm4", "Below gold flat qwen"], D.B_cat, { size: 15 }));
C.push(cap("Table 8.13 — Planted errors by category (10 per category; 12 for named entities, 8 for simple controls). Both judges also flag the correct 全场六折 (“everything 40% off”) as a major error — a cultural-convention gap."));
// E8
C.push(H2("8.6 E8 — Simplified vs Traditional script"));
C.push(P("**Question:** does the judge treat a script change consistently? (Per product decision, Traditional output is **not** an error; this experiment describes behaviour only.)"));
C.push(table([2200, 900, 1700, 600, 1400, 1300, 1260], ["Prompt", "Judge", "Traditional variant", "n", "Score change vs gold", "Scored lower", "Scored higher"], D.E8, { size: 15 }));
C.push(cap("Table 8.14 — Score of the Traditional copy relative to the Simplified gold (positive = Traditional scored lower)."));
C.push(B(`**The script label has no effect.** Without a reference, the Traditional copies score within about ±4 points of the gold, the same under the “Simplified” label as under a neutral label; none of the ${M.E8_traditional_rows_judged} judge outputs on Traditional rows mentions the script. This is consistent with the product decision to treat Traditional output as acceptable.`));
C.push(B("**Behaviour is not symmetric across setups:** with a Simplified reference the Traditional copies are penalised (glm4 90–93% of the time) — through surface difference, not a script rule; in pairwise comparison glm4 prefers the Simplified version 80% of the time while qwen calls it a tie 60–70% of the time. If a script policy is ever introduced, it must be stated explicitly in the prompt."));
// E9
C.push(H2("8.7 E9 — Position bias in pairwise comparison"));
C.push(...figure("fig7_position_bias.png", "Figure 8.7 — Which position wins, and how often the verdict survives swapping the order.", 6.0));
C.push(table([1800, 1800, 1800, 1800, 2160], ["Judge", "Picked first", "Picked second", "Tie", "Same verdict in both orders"], D.E9, { size: 17 }));
C.push(gap());
C.push(table([2600, 900, 1300, 950, 950, 950, 1710], ["Pair type", "Judge", "Expected", "Picked A", "Picked B", "Tie", "Order-consistent"], D.E9_types, { size: 15 }));
C.push(cap("Table 8.15 — Verdicts by pair type (A = first-named item of the pair, e.g. gold; mapped back after swapping)."));
C.push(B("glm4 follows position more than content: it picks the first translation 72% of the time and keeps its verdict after swapping only 48% of the time."));
C.push(B("Bias is largest when the two translations are equally good (gold vs paraphrase: order-consistent 30% / 55%; concise vs padded: 20% / 60%) and smallest when one has a real error (gold vs category error: 70% / 100%)."));
C.push(B("Neither judge uses “tie” much (3% glm4, 13% qwen), even for equally valid translations."));
// E10
C.push(H2("8.8 E10 — Reasoning and explanations"));
C.push(table([1400, 1600, 1700, 1700, 1500, 1460], ["Judge", "Plain flat mean", "Flat + rationale mean", "Score moved ≥ 10", "ρ plain flat", "ρ with rationale"], D.E10, { size: 16, alignRight: true, firstNumCol: 1 }));
C.push(cap("Table 8.16 — Effect of asking for a rationale before the score (Set A, temperature 0)."));
C.push(table([2200, 1150, 1150, 1100, 1300, 1260, 1200], ["Output type", "Consistent", "False error claim", "Invalid span", "Severity mis-graded", "Missed major error", "Vague"], D.E10_audit, { size: 16 }));
C.push(cap("Table 8.17 — Manual audit of 50 explanations (10 items per judge for the rationale and analysis-first prompts; the 10 MQM rows were deliberately sampled from correct translations that received errors, so they show what false errors look like, not how often they occur)."));
C.push(B("Asking for a rationale changes the score itself: glm4 moves ≥ 10 points on 70% of items and becomes harsher (mean 79 → 71); agreement with humans does not improve significantly."));
C.push(B("Rule-based checks found few outright contradictions between the wording of a rationale and its score; the problem is **accuracy**: explanations cite errors that do not exist (e.g. flagging the correct 700万年前 “seven million years ago”), propose wrong fixes (玛利亚 for lunar “maria”), or quote English source text as errors."));
C.push(B("**Format drift:** glm4 wraps 100% of its answers in ``` code fences (a strict JSON parser would reject every one; our parser accepts them); qwen used error types outside the allowed list 64 times in 2,550 errors (e.g. “Unnecessary addition”)."));

// ---------------- 9 catalogue
C.push(H1("9. Failure catalogue"));
C.push(P("Each failure is listed with its evidence, severity for Vosyn’s use (ranking close translation candidates for GEPA), likely cause and whether prompt engineering is a plausible fix."));
const F = [
  ["F1", "MQM scoring cannot tell a correct translation from one with a meaning error", "Inaccurate", "Set B ρ with true quality 0.05 / 0.14 (flat 0.55 / 0.57); flawed version below its correct version only 35% / 60%", "Critical", "False errors on correct translations (98% / 66%) + a major error costs only 5 points", "Partly"],
  ["F2", "Sampling makes verdicts random", "Inconsistent", "T 0.7/1.0: glm4 MQM 98–100% items inconsistent, spread 56–61, α 0.15; qwen 70–73%", "High", "glm4 labels ‘critical’ in 40–51% of calls at T > 0", "No (use T = 0 or average runs)"],
  ["F3", "Temperature 0 not fully reproducible", "Inconsistent", "5–8% items change at T = 0; Sprint 50 reproduced 29–37 / 40; ensemble ρ 0.60 → 0.52", "Medium", "GPU non-determinism; hardware / version differences", "No"],
  ["F4", "Prompt wording changes the ranking", "Setup-sensitive", "ρ 0.29–0.69 vs original; 22–45% items move ≥ 10; best wording differs per judge", "High", "Small models sensitive to instruction surface form", "Yes — main Task B target"],
  ["F5", "Position bias in pairwise judging", "Biased", "glm4 picks first 72%, order-consistent 48% (qwen 52% / 70%)", "High", "Position prior; ‘tie’ rarely used", "Partly (+ order swapping)"],
  ["F6", "Reference turns the judge into a difference detector", "Biased / setup", "Paraphrases below gold 98–100% with reference vs 25–48% without", "High", "Divergence from reference treated as error", "Yes"],
  ["F7", "glm4 confuses source and translation", "Inaccurate", "32% of glm4 error spans not in the translation; English flagged ‘Untranslated’; correct translation scored 0", "High (glm4)", "Unclear which text is under evaluation", "Yes"],
  ["F8", "Scale and calibration differ by judge and scale", "Setup-sensitive / biased", "glm4 ‘poor’ 8% (0–100) vs 70% (1–5); glm4 mean 79 vs qwen 61; qwen gives 20 in 15% of flat calls", "Medium", "No anchors for what scores mean", "Yes"],
  ["F9", "Stiff literal translations not penalised", "Inaccurate", "Literal rows 88–94; 0–15% put in the reviewer’s moderate band", "Medium", "Fluency / naturalness not asked for explicitly", "Yes"],
  ["F10", "Script label has no effect (neutral by product decision)", "Setup-sensitive (informational)", "0 of 352 outputs mention script; ±4 points; penalised only via a reference", "Informational", "Label not treated as a requirement", "Only if a script policy is adopted"],
  ["F11", "Blind spots: names, terminology, cultural conventions", "Inaccurate", "Detected: entities 25% / 58%, terminology 30% / 40% (register 80%); correct 六折 flagged", "Medium", "Knowledge limits of 7–9B models", "Partly"],
  ["F12", "Explanations often wrong; same score, different reasons", "Inconsistent / inaccurate", "Audit: 22 / 50 consistent, 13 false error claims; same-score runs share identical errors only 51%", "Medium", "Rationales generated, not grounded", "Partly"],
  ["F13", "Output-format drift", "Setup-sensitive", "glm4 code fences 100%; qwen off-list error types 64", "Low", "Instruction-following limits", "Yes (or JSON mode)"],
];
C.push(table([500, 2100, 1150, 2350, 900, 1500, 860], ["#", "Failure", "Type", "Key evidence", "Severity", "Likely cause", "Prompt-fixable?"], F, { size: 15 }));
C.push(cap("Table 9.1 — Failure catalogue. Figures separated by “/” are glm4 / qwen."));

// ---------------- 10 examples
C.push(H1("10. Worked English → Mandarin examples"));
C.push(P("All scores and judge outputs below are read directly from the result files. Scores are 0–100."));
C.push(...examples());

// ---------------- 11 implications
C.push(H1("11. Implications for the Sprint 50 judge configuration"));
C.push(B("**Keep temperature 0.** At 0.7 or 1.0 the MQM judges are not usable for single-shot scoring (F2)."));
C.push(B("**Do not rely on MQM scores for close calls.** On real MT output with several errors the ensemble ranks acceptably (Set A ρ 0.52), but it cannot separate a translation with one meaning error from a correct one (Set B ρ 0.09). GEPA compares close candidates, so this is the most important limitation (F1)."));
C.push(B("**Revisit the ensemble.** With two judges the “median” is the mean, so one badly wrong judge (e.g. glm4 scoring a correct translation 0, F7) pulls the result down. A third judge, a trimmed rule, or a disagreement flag is needed for real outlier protection."));
C.push(B("**Revisit the MQM weights.** With major = 5, any real error is smaller than the judges’ own false-error noise. Task B should test whether better prompts reduce false errors enough, or whether the weights (or a flat/MQM combination) must change."));
C.push(B("**If pairwise judging is used, always evaluate both orders** and treat order-dependent verdicts as ties (F5)."));
C.push(B("**Do not show a single reference as ‘the answer’** without telling the judge it is one valid option (F6)."));
C.push(B("**Record the environment** (Ollama version, model digests, settings) with every judge run; scores drift across environments (F3)."));

// ---------------- 12 hand-off
C.push(H1("12. Areas for prompt engineering (hand-off to Task B)"));
C.push(P("Task A identifies candidates only; Task B will design, run and compare them, reusing the Task A datasets, harness and analysis code. Each candidate is paired with the measurement from this report that should improve."));
C.push(table([700, 3000, 3200, 2460], ["For", "Candidate technique", "Why it may help", "Task A metric to beat"], [
  ["F1", "Few-shot calibration examples including a correct translation with an empty error list; explicit “most good translations have no errors”", "Reduces false errors on correct translations, so real errors stand out", "False-error rate on correct rows (98% / 66%); Set B ρ (0.05 / 0.14); flawed-below-gold (35% / 60%)"],
  ["F1, F4", "Severity definitions with Mandarin examples for minor / major / critical", "Aligns severity use with human annotators (32% minor)", "Minor share; ρ with human; E2 spread"],
  ["F4", "Structured prompt: fixed sections, delimiters, one task per step; test several wordings of the best structure", "Reduces sensitivity to surface wording", "ρ between rewordings (0.29–0.69); items moved ≥ 10 (22–45%)"],
  ["F7", "Label source and translation clearly; “quote error spans only from the translation”", "Stops glm4 flagging English source text", "Spans not in translation (32% glm4)"],
  ["F6", "“The reference is one valid translation; do not penalise different wording with the same meaning”", "Removes reference anchoring", "Paraphrase below gold with reference (98–100%)"],
  ["F8", "Anchored rubric: what 90, 70, 50, 30 mean, with an example each; or a 5-level categorical scale mapped to numbers", "Consistent calibration across judges and scales", "Poor share across scales (8% vs 70%); glm4–qwen mean gap (79 vs 61)"],
  ["F9", "Separate accuracy and fluency criteria (or MQM ‘Fluency/Style’ category)", "Makes stiffness visible without confusing it with meaning errors", "Literal band accuracy (0–15%)"],
  ["F11", "Checklist step: names, numbers/units, terms, idioms, cultural conventions (e.g. 折 discounts)", "Directs attention to the weakest categories", "Detection for entities (25% / 58%) and terminology (30% / 40%)"],
  ["F5", "Explicit tie option with criteria; judge each candidate separately then compare", "Reduces position prior", "First-position rate (72%); order-consistency (48% / 70%)"],
  ["F12", "Require each error to quote a span and give a one-line reason; analysis-before-score only with grounded quotes", "Makes reasoning checkable", "Audit false-error-claim rate (13 / 50)"],
  ["F13", "Ollama JSON mode or a stricter output instruction", "Removes format drift", "Code-fence rate; off-list types"],
], { size: 15 }));
C.push(cap("Table 12.1 — Prompt-engineering candidates for Task B."));
C.push(P("**Not prompt fixes, but to be tested alongside in Task B:** temperature 0 or averaging several sampled runs (F2); swapping and aggregating both orders in pairwise judging (F5); a third judge or trimmed aggregation for the ensemble; revised MQM weights."));

// ---------------- 13 limitations
C.push(H1("13. Limitations"));
C.push(B("**Small samples.** 40 items per set; differences in ρ below about 0.25 are not reliable, and several apparent “better prompt” results fall in that range and are not claimed."));
C.push(B("**Set B is constructed.** Variants were written by Claude and checked by one native Mainland reviewer, who agreed with the expected band on all rows — possibly anchored on the expected-band column in the workbook. A second, blind reviewer would strengthen the ground truth."));
C.push(B("**Two small open judges.** Results describe glm4 9B and qwen2.5 7B at 4-bit; larger or API judges may behave differently."));
C.push(B("**One environment.** Tesla T4 + Ollama 0.35.0; F3 shows scores shift between environments."));
C.push(B("**Tie rule.** Paired contrasts count a tie with the gold as a failure; Table 7.2 shows the results under the looser rule (conclusions unchanged)."));
C.push(B("**String-based detection.** A judge that describes the planted error in other words without quoting it is not credited."));
C.push(B("**Manual audit** of 50 explanations was done by Claude, not a native speaker, and covers about 1% of outputs."));
C.push(B("**Quality bands** are Sprint 50’s thresholds; a different threshold would change band-based percentages (rank correlations are unaffected)."));

// ---------------- 14 acceptance
C.push(H1("14. Acceptance criteria"));
C.push(table([3300, 1100, 4960], ["Criterion", "Status", "Where"], [
  ["Major LLM-as-a-Judge failure categories identified and documented", "Met", "13 categories, Section 9; evidence in Section 8"],
  ["English→Mandarin examples demonstrate the failures", "Met", "10 worked examples, Section 10; example IDs throughout Section 8"],
  ["Repeated evaluations performed to investigate consistency", "Met", "E1: 2,080 calls — 3 runs at T 0, 5 runs at T 0.7 and 1.0, both judges, both prompts (Section 8.1)"],
  ["Observed inconsistencies and potential causes documented", "Met", "Section 8 and the ‘likely cause’ column of Section 9"],
  ["Findings identify areas for prompt engineering", "Met", "‘Prompt-fixable?’ column (Section 9) and hand-off table (Section 12)"],
  ["Research findings and observations summarised", "Met", "This Word document (agreed replacement for Notion)"],
], { size: 17 }));

// ---------------- Appendix A prompts
C.push(H1("Appendix A. Prompts (verbatim)"));
C.push(P("Placeholders: {src_lang} = English, {tgt_lang} = Standard Mandarin Chinese (Simplified script) — or “Mandarin Chinese” in the neutral-label prompt — {source}, {mt}, {reference}, {a}, {b}. Doubled braces are literal braces."));
const PORDER = [["flat", "A.1 flat — Sprint 50 (verbatim); also used for Set B"], ["mqm", "A.2 mqm — Sprint 50 (verbatim); also mqm_neutral_label with the neutral target label"],
  ["mqm_reworded", "A.3 mqm_reworded"], ["mqm_zh", "A.4 mqm_zh"], ["mqm_severity_defs", "A.5 mqm_severity_defs"], ["mqm_analysis_first", "A.6 mqm_analysis_first"],
  ["flat_1to5", "A.7 flat_1to5"], ["flat_1to10", "A.8 flat_1to10"], ["mqm_ref", "A.9 mqm_ref"], ["pairwise", "A.10 pairwise"], ["flat_rationale", "A.11 flat_rationale"]];
for (const [id, title] of PORDER) {
  C.push(new Paragraph({ spacing: { before: 200, after: 80 }, keepNext: true, children: runs(title, { bold: true, color: BLUE }) }));
  C.push(...mono(D.prompts[id]));
}

// ---------------- Appendix B files
C.push(H1("Appendix B. Settings, files and how to reproduce"));
C.push(table([3600, 5760], ["File / folder", "Contents"], [
  ["data/raw/", "Sprint 50 gold set and Sprint 52 items (unchanged copies); Sprint 50 per-sentence judge scores"],
  ["scripts/setb_content.py", "All hand-written Set B text and planted-error annotations"],
  ["scripts/build_datasets.py, validate_datasets.py", "Build Set A/B and pairs; automatic validation"],
  ["scripts/build_review_workbook.py, build_reviewer_instructions.js", "Reviewer workbook and instructions"],
  ["scripts/merge_review.py, apply_manual_fixes.py", "Merge the returned review; restore MT outputs; Taiwan fix"],
  ["data/processed/", "setA_items.jsonl, setB_items.jsonl (+ pre-review backup), pairs.jsonl, validation and merge reports"],
  ["judge/", "settings.py, prompts.py, ollama_client.py, parsing.py, plan.py"],
  ["run_experiments.py", "--check, --status, --smoke, --run (resumable, time-boxed)"],
  ["colab/setup_ollama.sh, notebooks/Sprint53_Colab.ipynb", "Colab GPU setup and notebook (no Google Drive)"],
  ["results/", "P01–P11 raw judge outputs (one JSON line per call), environment and smoke-test records"],
  ["analysis/analyze.py, charts.py, examples.py", "All tables, charts, metrics and the example gallery"],
  ["analysis/manual_audit_labels.csv", "Manual labels for the 50 audited explanations"],
  ["analysis_out/", "tables/ (22 CSV), charts/ (7 PNG), metrics.json, examples.md"],
  ["report/", "build_report_data.py, build_report.js — rebuild this document"],
], { size: 16 }));
C.push(gap());
C.push(P("**To reproduce:**"));
C.push(N("Datasets (CPU): `bash run_step1.sh` builds and validates; after a review, `bash run_step1.sh --merge <workbook>` then `--fixes`.", "num2"));
C.push(N("Judge runs (Colab T4): open `Sprint53_Colab.ipynb`, set runtime to T4, run cells 1–5 (upload data + code, install Ollama and both models), cell 6 for the smoke test, cell 7 for all phases; upload the newest checkpoint zip to resume in a new session.", "num2"));
C.push(N("Analysis (CPU): `python analysis/analyze.py` and `python analysis/examples.py`.", "num2"));
C.push(N("Report: `python report/build_report_data.py` then `node report/build_report.js`.", "num2"));

// ---------------- Appendix C glossary
C.push(H1("Appendix C. Glossary"));
C.push(table([2300, 7060], ["Term", "Meaning"], [
  ["LLM-as-a-judge", "Using a language model to score or compare translations instead of (or before) human raters"],
  ["MQM", "Multidimensional Quality Metrics: annotate each error with a type and severity; here score = 100 − Σ(minor 1, major 5, critical 25)"],
  ["Flat prompt", "The judge gives one holistic score directly (0–100 unless stated)"],
  ["Gold / reference", "A correct, natural human-quality translation of the source"],
  ["Planted error", "One deliberate error inserted into an otherwise correct translation, recorded with its span, type and severity"],
  ["Temperature", "Randomness of generation. 0 = always the most likely token (greedy); higher values sample more freely"],
  ["Spearman ρ", "Rank correlation, −1 to 1: do two sets of scores put items in the same order?"],
  ["Krippendorff’s α", "Agreement of repeated ratings beyond chance; 1 = perfect, 0 = chance"],
  ["chrF", "Character n-gram overlap between two texts (0–100); measures surface similarity, not meaning"],
  ["Bootstrap CI", "Confidence interval from recomputing a statistic on many resamples of the items"],
  ["GEPA", "The prompt-optimisation pipeline that uses the judge to rank translation candidates"],
  ["OpenCC s2tw / s2twp", "Simplified → Traditional conversion: characters only / characters plus Taiwan vocabulary"],
], { zebra: false, shadeFirst: true, size: 17 }));

// =====================================================================================
const doc = new Document({
  creator: "Vosyn Supernova · Sprint 53",
  title: "Sprint 53 Task A — LLM-as-a-Judge failure analysis (English → Mandarin)",
  styles: {
    default: { document: { run: { font: "Arial", size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, color: NAVY, font: "Arial" }, paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 25, bold: true, color: BLUE, font: "Arial" }, paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 22, bold: true, color: NAVY, font: "Arial" }, paragraph: { spacing: { before: 220, after: 80 }, outlineLevel: 2, keepNext: true } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [0, 1, 2].map((l) => ({ level: l, format: LevelFormat.BULLET, text: ["•", "–", "·"][l], alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540 + l * 360, hanging: 270 } } } })) },
      { reference: "num1", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
      { reference: "num2", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
    ],
  },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1300, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "Sprint 53 · Task A · LLM-as-a-Judge failure analysis (EN → ZH)", font: FONT, size: 16, color: GREY })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Page ", font: FONT, size: 16, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: GREY })] })] }) },
    children: C,
  }],
});
Packer.toBuffer(doc).then((b) => { fs.writeFileSync(OUT, b); console.log("wrote " + OUT); });
