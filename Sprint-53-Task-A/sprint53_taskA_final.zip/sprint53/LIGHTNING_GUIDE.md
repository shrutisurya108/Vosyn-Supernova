# Sprint 53 on Lightning AI — step-by-step guide

This guide covers everything from creating the account to getting Step 1's results.
Later steps (the GPU experiments) will add their own sections here when we build them.

> Lightning's website layout changes from time to time. If a button is named slightly
> differently from what is written here, look for the closest match — the commands you
> type in the terminal will not change.

---

## Part A — One-time setup (about 10 minutes)

### A1. Create the account
1. Go to **https://lightning.ai** and click **Sign up** (a Google or GitHub login is fine).
2. Complete any verification it asks for (often a phone number). Free GPU hours are only
   unlocked for verified accounts.
3. Open your account **Billing / Credits** page and note how many free credits or GPU hours
   you have this month. Step 1 uses **no** GPU time; the later experiments need roughly
   4–6 GPU hours in total.

### A2. Create a Studio
A *Studio* is your own cloud computer. Its files are kept when it stops or restarts.

1. Click **New Studio** (or **Start a Studio**).
2. Choose a plain **Code / VS Code** or **Jupyter** template — either works; this guide uses the terminal.
3. Name it `sprint53` and start it.
4. Leave the machine on **CPU** (the default, free). Step 1 does not need a GPU.

### A3. Find your persistent folder
1. Open a **Terminal** (VS Code: menu *Terminal → New Terminal*; Jupyter: *File → New → Terminal*).
2. Type:
   ```bash
   pwd
   ```
   It should print something like `/teamspace/studios/this_studio`. **Everything inside this folder
   survives restarts.** Always keep the project here.

---

## Part B — Step 1: build and validate the datasets (about 5 minutes, CPU)

### B1. Upload the project
1. In the Studio's **file explorer** (left side), make sure you are in the folder shown by `pwd`.
2. Drag and drop **`sprint53_step1.zip`** from your computer into the file explorer
   (or right-click → **Upload**).

### B2. Unzip and run
In the terminal:
```bash
cd /teamspace/studios/this_studio      # the folder `pwd` printed in A3
unzip -o sprint53_step1.zip           # creates the sprint53/ folder
cd sprint53
bash run_step1.sh
```
If `unzip` is not installed, use `python -m zipfile -e sprint53_step1.zip .` instead.

**What happens:** the script installs two small Python packages (OpenCC for Chinese script
conversion, openpyxl for Excel), rebuilds Set A, Set B and the pairs from the raw Sprint 50/52
files, then runs every validation check.

### B3. Check the output is correct
The end of the output must show:
```
Set B items: 275 from 40 sources
Pairs: 60 ...
HARD FAILURES: 0
WARNINGS: 1
  - S52_004 paraphrase chrF vs gold = 70.6 (>= 60.0); lexically close
>> Step 1 finished.
```
The one warning is expected (the password sentence has to stay verbatim, so its paraphrase
cannot differ much). Anything else → copy the full output and send it to me.

### B4. Where the results are
| File | What it is |
|---|---|
| `data/processed/setA_items.jsonl` | 40 accuracy-anchor items |
| `data/processed/setB_items.jsonl` | 275 controlled variants |
| `data/processed/pairs.jsonl` | 60 pairs for the position-bias test |
| `data/processed/validation_report.txt` | the validation report you just saw |

To download any file: right-click it in the file explorer → **Download**.

### B5. Stop the Studio
Click the machine indicator (top right) → **Stop**, or just close the tab: the Studio goes to
sleep after a period of inactivity. Your files stay.

---

## Part C — When the reviewer returns the workbook

1. Start the Studio again and open a terminal.
2. Upload the returned workbook (e.g. `SetB_Review_Workbook_LW.xlsx`) into the
   `sprint53/review/` folder.
3. Run:
   ```bash
   cd /teamspace/studios/this_studio/sprint53
   bash run_step1.sh --merge review/SetB_Review_Workbook_LW.xlsx
   ```
4. **What happens:** the reviewer's corrections, bands and severities are written into Set B
   (the original is backed up as `setB_items.prereview.jsonl`), the pairs are rebuilt from the
   corrected rows, and validation runs again.
5. Download **`data/processed/merge_report.txt`** and send it to me. Anything listed under
   **NEEDS ATTENTION** is resolved together before Step 2.

---

## Part D — Preview of how the GPU steps will work (built in Step 2)

- You will switch the Studio's machine from CPU to a **GPU with ≥16 GB** (T4 or better) only while
  experiments run, and back to CPU afterwards to save free hours.
- Ollama and both judge models (glm4, qwen2.5:7b, ~10 GB) are installed **inside your persistent
  folder**, so they download once and survive restarts.
- Experiments run inside `tmux`, so they keep going if you close the browser tab.
- Every judge call is saved immediately. If the free session stops (about every 4 hours), you
  restart the Studio, run one setup command, and re-run the same experiment command — it
  continues from where it stopped.
