#!/usr/bin/env bash
# Sprint 53 - Step 1 (datasets). Written for a Lightning AI Studio; also works on any Linux/Mac shell.
#   Build + validate:            bash run_step1.sh
#   Also rebuild review files:   bash run_step1.sh --review-files
#   Merge a returned review:     bash run_step1.sh --merge review/SetB_Review_Workbook_XX.xlsx
#   Apply hand fixes after merge: bash run_step1.sh --fixes
#
# Step 1 needs no GPU - run it on the Studio's free CPU machine.
set -euo pipefail
cd "$(dirname "$0")"

# 1. Dependencies go into the Studio's own Python environment, which Lightning keeps
#    between restarts, so this is fast after the first run.
echo ">> Python: $(python --version 2>&1)  ($(command -v python))"
python -m pip install -q -r requirements.txt

if [ "${1:-}" = "--merge" ]; then
  [ -n "${2:-}" ] || { echo "usage: bash run_step1.sh --merge <reviewed_workbook.xlsx>"; exit 1; }
  [ -f "$2" ] || { echo "!! File not found: $2 (upload it into the review/ folder first)"; exit 1; }
  echo ">> Merging review: $2"
  python scripts/merge_review.py "$2"
  echo ">> Re-validating"
  python scripts/validate_datasets.py
  echo ">> Done. Read data/processed/merge_report.txt - resolve anything under NEEDS ATTENTION before Step 2."
  exit 0
fi

if [ "${1:-}" = "--fixes" ]; then
  echo ">> Applying manual fixes"
  python scripts/apply_manual_fixes.py
  echo ">> Re-validating"
  python scripts/validate_datasets.py
  exit 0
fi

# 2. Build and validate
# Guard: once a review has been merged, rebuilding from scratch would overwrite the reviewer's
# corrections. Only validate in that case, unless --force-rebuild is given.
if [ -f data/processed/setB_items.prereview.jsonl ] && [ "${1:-}" != "--force-rebuild" ]; then
  echo ">> Review already merged - NOT rebuilding (that would discard the reviewer's corrections)."
  echo ">> Validating the reviewed data instead. Use --force-rebuild only if you really want to start over."
  python scripts/validate_datasets.py
  exit 0
fi
echo ">> Building datasets"
python scripts/build_datasets.py
echo ">> Validating (must end with HARD FAILURES: 0)"
python scripts/validate_datasets.py

# 3. Optional: rebuild the reviewer files (Excel needs nothing extra; the Word file needs Node.js)
if [ "${1:-}" = "--review-files" ]; then
  echo ">> Rebuilding review/SetB_Review_Workbook.xlsx"
  python scripts/build_review_workbook.py
  if command -v node >/dev/null 2>&1; then
    npm install --silent
    node scripts/build_reviewer_instructions.js
  else
    echo "!! Node.js not found - skipped the .docx (the copy in review/ is already up to date)"
  fi
fi
echo ">> Step 1 finished."
