# Sprint 53 · Step 5 — Draft findings (for review before the Word report)

**Scope:** LLM-as-a-judge failure analysis for English → Mandarin, using the Sprint 50 judges.
**Status:** draft for review. Numbers are final for this run; wording, emphasis and the prompt-engineering map (Step 6) are still open.
All numbers below are produced by `analysis/analyze.py` and were re-computed independently from the raw result files.

---

## 1. What was run

| Item | Value |
|---|---|
| Judges | glm4:latest (glm4 9B, digest 5b699761eca5) and qwen2.5:7b (digest 845dbda0ea48), Ollama 0.35.0, Colab Tesla T4 — identical model files in all 5 sessions |
| Prompts | Sprint 50 FLAT and MQM prompts verbatim + 10 one-change variants |
| Data | Set A: 40 real MT outputs with human MQM scores (SiniticMTError). Set B: 275 reviewer-checked controlled variants of 40 sources. 60 A/B pairs |
| Calls | 4,758 of 4,758 completed · 0 unparseable · 2 needed a retry · 0 truncated |
| Settings | num_ctx 4096 · seed 1000 + run · temperatures 0.0 (×3), 0.7 (×5), 1.0 (×5) for repeatability, 0.0 elsewhere · one call at a time |

## 2. Analysis decisions (what each number means)

| Decision | Choice | Why |
|---|---|---|
| Quality bands | clean ≥ 85, moderate 60–84, poor < 60 | Sprint 50 buckets, so results are comparable |
| "Inconsistent" | repeated runs differ by ≥ 10 points **or** land in different bands | Agreed in Step 5; catches both big swings and verdict flips |
| Ground truth, Set A | human MQM score | Real annotations, independent of us |
| Ground truth, Set B | reviewer-confirmed band | Under Sprint 50's formula one major error only costs 5 points (= "clean"), so MQM-expected scores cannot be the main truth |
| Agreement metric | Spearman ρ with 95% bootstrap CI (2,000 resamples, seed 42) | Rank agreement is what GEPA needs; with n = 40 the CIs are wide (±0.25), so small ρ differences are **not** meaningful |
| "Detected" (planted error) | a listed error span contains the planted span (or lies inside it) and is not a whole-sentence quote | Prevents crediting a judge that just quotes the whole sentence |
| "Ranked below own gold" | flawed version scores strictly lower than the correct version of the same sentence | The fairest test: same sentence, same judge, one planted difference |
| Reasoning check (E10) | rule-based checks on all outputs + manual audit of 50 outputs | No second GPU run needed |

---

## 3. Failure catalogue (most severe first)

| # | Failure | Key evidence | Severity | Likely cause | Prompt-fixable? |
|---|---|---|---|---|---|
| F1 | **MQM scoring cannot tell a correct translation from one with a meaning error** | On Set B the MQM score barely tracks true quality: ρ = 0.05 (glm4) / 0.14 (qwen), CIs include 0 — the flat prompt reaches 0.55 / 0.57. A fluent translation with one meaning error averages 85.8 / 90.2 vs 87.4 / 94.2 for the correct one; only 35% (glm4) / 60% (qwen) of flawed versions score below their own correct version (flat: 79% / 84%). | Critical | (a) Judges list errors on correct translations: glm4 on 98% of them, qwen on 66% (mostly "major"). (b) Sprint 50 weights: one major = −5 points, so a real error is lost in that noise. | Partly — few-shot "no-error" examples, severity anchors; formula change is not a prompt fix |
| F2 | **Sampling makes verdicts random** | At T = 0.7 / 1.0, 98–100% of Set A items get inconsistent MQM scores from glm4 (mean spread 56–61 points, Krippendorff α 0.14–0.15); qwen 70–73% (α ≈ 0.5). Flat prompt: 50–83%. One sentence got 98, 80, 78, 70 and 0 in five glm4 runs. | High | At T > 0 glm4 labels errors "critical" in 40–51% of calls (1% at T = 0); one critical = −25 | No — use T = 0; or average several runs |
| F3 | **Even T = 0 is not fully reproducible** | 85–95% of items identical across 3 runs at T = 0 (5–8% inconsistent). Re-running Sprint 50's exact configs reproduced only 29–37 of 40 scores; the Sprint 50 ensemble's ρ moved from 0.60 to 0.52. | Medium | GPU numerical non-determinism and different hardware / Ollama version | No — record environment, average, or report ranges |
| F4 | **Prompt wording changes the ranking** | Four rewordings with the same instructions correlate only ρ = 0.29–0.69 with the Sprint 50 prompt; 22–45% of items move ≥ 10 points, 20–45% change band. The "best" wording differs by judge (glm4: original 0.61; qwen: reworded 0.66 vs original 0.41). | High | Small models are sensitive to instruction surface form | Yes — this is the main target of prompt engineering; validate on held-out data |
| F5 | **Position bias in pairwise comparison** | glm4 prefers whichever translation is shown first 72% of the time; its verdict survives swapping the order only 48% of the time (qwen: 52% / 70%). For gold vs valid paraphrase, verdicts are order-stable only 30% (glm4) / 55% (qwen) of the time. | High | Known LLM position prior; judges rarely say "tie" (3% / 13%) | Partly — explicit tie option, swap-and-aggregate (not a prompt fix) |
| F6 | **A reference turns the judge into a difference detector** | With the gold as reference, valid paraphrases score below the gold 98–100% of the time (vs 25–48% without); 40–43% lose ≥ 10 points. Traditional-script copies of the gold are penalised 90% (glm4) vs 23% without reference. | High | Judge treats "differs from reference" as "error" | Yes — "the reference is one valid option; do not penalise wording differences" |
| F7 | **glm4 confuses source and translation** | 32% of glm4's MQM error spans are not in the translation at all; on 32% of Set B rows it flags English source text as "Untranslated", often "critical" — a correct translation of the Onion sentence scored 0. qwen: 1%. | High (glm4) | glm4 misreads which text is being evaluated | Yes — clearer delimiters/labels, "quote only text from the translation" |
| F8 | **Calibration and scale depend on the judge and the scale** | Same 40 items, glm4: mean 79 (0–100) → 59 (1–10) → 54 (1–5); share judged "poor" 8% → 48% → 70%. Rankings stay similar (ρ 0.85–0.95). Scores cluster: 3 values = 57–62% of all flat scores; qwen gives exactly 20 in 15% of flat calls, including 9 Set A items humans scored 77 on average. | Medium | No anchors for what each score means | Yes — anchored rubric, few-shot calibration examples |
| F9 | **Stiff, word-for-word translations are not penalised** | "Literal but correct" rows average 88–94 on every prompt (reviewer: moderate); only 0–15% land in the moderate band. | Medium | Judges focus on meaning errors; fluency/naturalness is not asked for explicitly | Yes — add a fluency/naturalness criterion |
| F10 | **"Simplified script" is not enforced** | 0 of 352 outputs on Traditional-script rows mention the script; score difference vs the Simplified gold is −4 to +1 points under the "Simplified" label — the same as under a neutral label. | Medium (depends on spec) | Label in the prompt is not treated as a requirement | Yes — explicit rule + severity for wrong script, if that is the product requirement |
| F11 | **Blind spots: names, terminology, cultural conventions** | Planted errors detected (MQM): named entities 25% (glm4) / 58% (qwen), terminology 30% / 40%, vs 80–100% for register and simple sentences. Both judges flag the correct 全场六折 for "40% off" as a major error. | Medium | Limited world/cultural knowledge in 7–9B models | Partly — checklists help detection; knowledge gaps need a stronger judge |
| F12 | **Explanations are often wrong** | Manual audit of 50 outputs: 22 consistent; 13 claim errors that do not exist; 5 put errors in the wrong place (English source spans); 4 mis-grade severity; 2 miss a major error; 4 vague. Asking for a rationale moves glm4's score ≥ 10 points on 70% of items. Among runs with identical scores, only 51% list the same errors; 15% share none. | Medium | Rationales are generated, not grounded | Partly — require quoting spans; don't treat rationales as evidence |
| F13 | **Output-format drift** | glm4 wraps 100% of answers in ``` code fences (a strict JSON parser would reject all of them); qwen invents error types outside the allowed list in 64 of 2,550 errors (e.g. "Unnecessary addition"). | Low | Instruction-following limits | Yes — Ollama JSON mode or a tolerant parser (already used here) |

**Consequence for the Sprint 50 decision.** The chosen `glm4_qwen_ensemble_mqm` config still ranks real MT output about as well as in Sprint 50 on Set A (ρ 0.52 here vs 0.60 there, within noise), because those outputs contain several errors each. But on controlled data with a single error it does not separate good from bad (ρ 0.09 on Set B), and the "median" of two judges is simply their mean, so it gives no outlier protection. For GEPA, which compares *close* candidates, F1 matters most.

---

## 4. Results by experiment (tables in `analysis_out/tables/`, charts in `analysis_out/charts/`)

**E1 Repeatability** (`E1_repeatability.csv`, fig1) — share of 40 items inconsistent:

| Judge · prompt | T = 0 | T = 0.7 | T = 1.0 |
|---|---|---|---|
| glm4 · MQM | 8% | 98% | 100% |
| qwen · MQM | 8% | 72% | 70% |
| glm4 · flat | 5% | 82% | 78% |
| qwen · flat | 5% | 50% | 70% |

Averaging the 5 runs at T = 0.7 changes agreement with humans (qwen MQM 0.41 single T = 0 → 0.66 averaged; glm4 MQM 0.63 → 0.43), but the CIs are wide; averaging is a candidate fix to test, not a conclusion.

**E2 Prompt wording** (`E2_prompt_wording.csv`, fig2) — see F4. No variant is significantly better than another with n = 40.

**E3 Scales** (`E3_scales.csv`, `E3_flat_score_clustering.csv`, fig3) — see F8.

**E4 Reference** (`E4_E5_paraphrase_gap.csv`, `E4_setA_reference.csv`, fig6) — see F6. On Set A, adding a reference lowered glm4's agreement with humans (0.61 → 0.48) and raised qwen's (0.41 → 0.57); both within noise.

**E5–E7 Set B** (`E4_E7_*.csv`, `E6_E7_planted_error_detection.csv`, `E7_*.csv`, fig4, fig5) — see F1, F7, F9, F11.

**E8 Script** (`E8_script.csv`) — see F10. In pairwise comparison qwen calls Simplified vs Traditional a tie 60–70% of the time; glm4 prefers the Simplified version 80% of the time.

**E9 Position** (`E9_position_bias.csv`, `E9_by_pair_type.csv`, fig7) — see F5. When one side has a real error, verdicts are more stable (gold vs targeted error: correct 85% glm4 / 100% qwen).

**E10 Reasoning** (`E10_rationale_effect.csv`, `E10_manual_audit_summary.csv`, `analysis/manual_audit_labels.csv`) — see F12. The 10 MQM outputs in the audit were deliberately sampled from correct translations *that received errors*, so they measure what those false errors look like, not how often they occur (that rate is in F1).

Example gallery with the Chinese text and both judges' outputs: `analysis_out/examples.md` (10 cases).

## 5. Limitations

* **Small n.** 40 items per set; ρ differences below ~0.25 are not reliable.
* **Set B is constructed.** Variants were written by Claude and checked by one native Mainland reviewer, who agreed with our expected band on all 265 rows — possibly anchored on the "expected band" column. A second reviewer would strengthen it.
* **Two small open models.** Findings describe glm4 9B and qwen2.5 7B at 4-bit; larger judges may behave differently.
* **One hardware setup.** T4 + Ollama 0.35.0; F3 shows results shift across environments.
* **Detection metric is string-based.** A judge that names the error in other words is not credited.
* **Manual audit** was done by Claude, not a native speaker; it covers 50 of 4,758 outputs.
