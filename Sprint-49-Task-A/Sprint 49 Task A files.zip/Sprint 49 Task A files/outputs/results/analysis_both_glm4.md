# Judge Analysis Report (glm4)

## Mandarin (n=79)

**Score distributions**

|       |   flat_score |   severity_weighted_score |   semantic_similarity_x100 |
|:------|-------------:|--------------------------:|---------------------------:|
| count |        79    |                     79    |                      79    |
| mean  |        97.61 |                     99.33 |                      92.16 |
| std   |         1.29 |                      1.85 |                      14.22 |
| min   |        95    |                     90    |                      34.14 |
| 25%   |        98    |                    100    |                      87.23 |
| 50%   |        98    |                    100    |                     100    |
| 75%   |        98    |                    100    |                     100    |
| max   |       100    |                    100    |                     100    |

**Error counts (severity breakdown)**

|              |   total_errors_found |
|:-------------|---------------------:|
| num_minor    |                   13 |
| num_major    |                    8 |
| num_critical |                    0 |

**Flat vs. severity-weighted score**

- Mean(flat - severity_weighted) = -1.72 (positive => flat scoring is more lenient than severity-weighted)
- Pearson correlation(flat, severity_weighted) = 0.583

**Judge vs. automatic metric (LaBSE similarity x100) agreement**

- Spearman(flat_score, semantic_similarity) = -0.067 (p=0.555)
- Spearman(severity_weighted_score, semantic_similarity) = -0.132 (p=0.247)

**Biggest judge-vs-metric disagreements** (severity_weighted_score vs semantic_similarity_x100, both 0-100 scale)

|   row_id | src                                                                                                                                                                      | tgt                                                      |   severity_weighted_score |   semantic_similarity_x100 |   disagreement |
|---------:|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------|--------------------------:|---------------------------:|---------------:|
|       10 | A formal anniversary event was scheduled for a later date, officials said.                                                                                               | 官员表示，正式的周年纪念活动计划在稍后举行。                                   |                       100 |                      34.14 |          65.86 |
|      101 | Submarines are ships designed to travel underwater, and remain there for an extended amount of time.                                                                     | 潜艇是一种用于水下航行并能在水下长时间停留的船只。                                |                       100 |                      34.82 |          65.18 |
|        9 | At least 100 people had attended the party, in order to celebrate the first anniversary of a couple whose wedding was held last year.                                    | 至少有100人参加了这场聚会，以庆祝这对夫妇去年结婚一周年。                           |                       100 |                      54.43 |          45.57 |
|        6 | The cause of death was announced as intrahepatic bile duct cancer.                                                                                                       | 官方公布的死因是肝内胆管癌。                                           |                       100 |                      58.72 |          41.28 |
|       52 | Surface tension happens because the water molecules at the surface of the water are strongly attracted to each other more than they are to the air molecules above them. | 表面张力的产生是因为水面上的水分子彼此之间的吸引力，比它们与上方空气分子之间的吸引力更强。            |                       100 |                      69.1  |          30.9  |
|       50 | This, however, is a very hard problem to solve and will take many years before we see useful fusion reactors built.                                                      | 然而，这是一个非常难以解决的问题，可能需要很多年才能看到实用的聚变反应堆建成。                  |                       100 |                      70.32 |          29.68 |
|       84 | After initial military setbacks, Ethelred was able to agree to terms with Olaf, who returned to Norway to try to gain his kingdom with mixed success.                    | 在经历了最初的军事挫折后，埃塞尔雷德与奥拉夫达成了协议。奥拉夫随后返回挪威，试图夺回自己的王国，但结果喜忧参半。 |                        99 |                      73.92 |          25.08 |
|        5 | Japanese judoka Hitoshi Saito, winner of two Olympic gold medals, has died at the age of 54.                                                                             | 日本柔道选手、两枚奥运会金牌得主齐藤仁（Hitoshi Saito）逝世，享年54岁。              |                       100 |                      74.98 |          25.02 |

## Cantonese (n=35)

**Score distributions**

|       |   flat_score |   severity_weighted_score |   semantic_similarity_x100 |
|:------|-------------:|--------------------------:|---------------------------:|
| count |        35    |                     35    |                      35    |
| mean  |        95.86 |                     99.26 |                      80.56 |
| std   |         1.38 |                      1.42 |                      21.13 |
| min   |        95    |                     95    |                      -1.82 |
| 25%   |        95    |                     99    |                      79.67 |
| 50%   |        95    |                    100    |                      86.12 |
| 75%   |        98    |                    100    |                      92.33 |
| max   |        98    |                    100    |                     100    |

**Error counts (severity breakdown)**

|              |   total_errors_found |
|:-------------|---------------------:|
| num_minor    |                   11 |
| num_major    |                    3 |
| num_critical |                    0 |

**Flat vs. severity-weighted score**

- Mean(flat - severity_weighted) = -3.40 (positive => flat scoring is more lenient than severity-weighted)
- Pearson correlation(flat, severity_weighted) = 0.335

**Judge vs. automatic metric (LaBSE similarity x100) agreement**

- Spearman(flat_score, semantic_similarity) = 0.038 (p=0.83)
- Spearman(severity_weighted_score, semantic_similarity) = 0.227 (p=0.19)

**Biggest judge-vs-metric disagreements** (severity_weighted_score vs semantic_similarity_x100, both 0-100 scale)

|   row_id | src                                                                                                                      | tgt                                                  |   severity_weighted_score |   semantic_similarity_x100 |   disagreement |
|---------:|:-------------------------------------------------------------------------------------------------------------------------|:-----------------------------------------------------|--------------------------:|---------------------------:|---------------:|
|        7 | He died in Osaka on Tuesday.                                                                                             | 佢於星期二喺大阪離世。                                          |                       100 |                      -1.82 |         101.82 |
|      160 | Most televisions are made in a way to please the general public.                                                         | 大部分電視嘅設計都係為咗迎合普羅大眾嘅觀看習慣。                             |                        95 |                      34.23 |          60.77 |
|        2 | French law was changed. His activism went back to age 15 when he joined the French Resistance during World War II.       | 法國法律因此被修改。佢嘅社會運動可以追溯到 15 歲嗰年，當時佢喺第二次世界大戰期間加入咗法國抵抗運動。 |                        98 |                      42.54 |          55.46 |
|       16 | He has also been accused previously of copyright infringement, but was not charged.                                      | 佢過去亦曾被指控侵犯版權，但最終冇被起訴。                                |                       100 |                      50.26 |          49.74 |
|       10 | A formal anniversary event was scheduled for a later date, officials said.                                               | 官員表示，正式嘅周年紀念活動已安排喺稍後日期舉行。                            |                       100 |                      54    |          46    |
|        6 | The cause of death was announced as intrahepatic bile duct cancer.                                                       | 官方公布死因為肝內膽管癌。                                        |                       100 |                      72.6  |          27.4  |
|       12 | The 30-year-old husband, who was born in Buffalo, was one of the four killed in the shooting, but his wife was not hurt. | 呢名 30 歲嘅丈夫喺水牛城出生，係槍擊案中四名死者之一，而佢嘅妻子並冇受傷。              |                        95 |                      73.87 |          21.13 |
|       31 | In 1995 he was voted the best player in Partizan's history.                                                              | 1995年，佢獲選為游擊隊歷史上最佳球員。                                |                       100 |                      79.53 |          20.47 |

## Mandarin vs. Cantonese comparison

|                          |   mandarin |   cantonese |
|:-------------------------|-----------:|------------:|
| flat_score               |      97.61 |       95.86 |
| severity_weighted_score  |      99.33 |       99.26 |
| semantic_similarity_x100 |      92.16 |       80.56 |