# GLM Judge Analysis Report

## Mandarin (n=15)

**Score distributions**

|       |   flat_score |   severity_weighted_score |   semantic_similarity_x100 |
|:------|-------------:|--------------------------:|---------------------------:|
| count |        15    |                     15    |                      15    |
| mean  |        98.07 |                     99.33 |                      96.45 |
| std   |         1.03 |                      2.58 |                       6.43 |
| min   |        95    |                     90    |                      79.81 |
| 25%   |        98    |                    100    |                      95.65 |
| 50%   |        98    |                    100    |                     100    |
| 75%   |        98    |                    100    |                     100    |
| max   |       100    |                    100    |                     100    |

**Error counts (severity breakdown)**

|              |   total_errors_found |
|:-------------|---------------------:|
| num_minor    |                    0 |
| num_major    |                    2 |
| num_critical |                    0 |

**Flat vs. severity-weighted score**

- Mean(flat - severity_weighted) = -1.27 (positive => flat scoring is more lenient than severity-weighted)
- Pearson correlation(flat, severity_weighted) = 0.821

**Judge vs. automatic metric (LaBSE similarity x100) agreement**

- Spearman(flat_score, semantic_similarity) = 0.119 (p=0.672)
- Spearman(severity_weighted_score, semantic_similarity) = 0.140 (p=0.62)

**Biggest judge-vs-metric disagreements** (severity_weighted_score vs semantic_similarity_x100, both 0-100 scale)

|   row_id | src                                                                                                                              | tgt                                                |   severity_weighted_score |   semantic_similarity_x100 |   disagreement |
|---------:|:---------------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------|--------------------------:|---------------------------:|---------------:|
|        4 | In the 1960s he headed back to newly-independent Algeria to teach film directing.                                                | 20世纪60年代，他回到刚刚独立的阿尔及利亚，教授电影导演课程。                   |                       100 |                      79.81 |          20.19 |
|       11 | The couple had married in Texas one year ago and came to Buffalo to celebrate with friends and relatives.                        | 这对夫妇一年前在德克萨斯州结婚，随后来到布法罗与亲朋好友一起庆祝。                  |                       100 |                      84.65 |          15.35 |
|        2 | French law was changed. His activism went back to age 15 when he joined the French Resistance during World War II.               | 法国法律因此得到修改。他的社会活动始于15岁，当时正值第二次世界大战期间，他加入了法国抵抗运动。   |                        90 |                      99.88 |           9.88 |
|        5 | Japanese judoka Hitoshi Saito, winner of two Olympic gold medals, has died at the age of 54.                                     | 日本柔道选手、两枚奥运会金牌得主齐藤仁（Hitoshi Saito）逝世，享年54岁。        |                       100 |                      91.08 |           8.92 |
|       12 | The 30-year-old husband, who was born in Buffalo, was one of the four killed in the shooting, but his wife was not hurt.         | 这名30岁的丈夫出生于布法罗，是枪击事件中四名遇难者之一，但他的妻子没有受伤。            |                       100 |                      93.83 |           6.17 |
|        3 | He documented himself in a 1998 book.                                                                                            | 他在1998年出版的一本书中记录了自己的经历。                            |                       100 |                      97.47 |           2.53 |
|        0 | Following the process, HJR-3 will be reviewed again by the next elected legislature in either 2015 or 2016 to remain in process. | 按照这一程序，HJR-3将由下一届选出的立法机构在2015年或2016年再次审议，以继续推进该程序。 |                       100 |                     100    |           0    |
|        1 | Vautier's achievements outside of directing include a hunger strike in 1973 against what he viewed as political censorship.      | 除了导演工作外，沃蒂埃的成就还包括1973年为抗议他所认为的政治审查而进行的绝食行动。        |                       100 |                     100    |           0    |

## Cantonese (n=12)

**Score distributions**

|       |   flat_score |   severity_weighted_score |   semantic_similarity_x100 |
|:------|-------------:|--------------------------:|---------------------------:|
| count |        12    |                     12    |                      12    |
| mean  |        96.25 |                     99.58 |                      86.64 |
| std   |         1.54 |                      0.67 |                      18.98 |
| min   |        95    |                     98    |                      46.41 |
| 25%   |        95    |                     99    |                      85.7  |
| 50%   |        95    |                    100    |                      95.68 |
| 75%   |        98    |                    100    |                      97.93 |
| max   |        98    |                    100    |                     100    |

**Error counts (severity breakdown)**

|              |   total_errors_found |
|:-------------|---------------------:|
| num_minor    |                    5 |
| num_major    |                    0 |
| num_critical |                    0 |

**Flat vs. severity-weighted score**

- Mean(flat - severity_weighted) = -3.33 (positive => flat scoring is more lenient than severity-weighted)
- Pearson correlation(flat, severity_weighted) = 0.550

**Judge vs. automatic metric (LaBSE similarity x100) agreement**

- Spearman(flat_score, semantic_similarity) = -0.024 (p=0.94)
- Spearman(severity_weighted_score, semantic_similarity) = 0.118 (p=0.716)

**Biggest judge-vs-metric disagreements** (severity_weighted_score vs semantic_similarity_x100, both 0-100 scale)

|   row_id | src                                                                                                                                                                    | tgt                                                                              |   severity_weighted_score |   semantic_similarity_x100 |   disagreement |
|---------:|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|--------------------------:|---------------------------:|---------------:|
|        4 | In the 1960s he headed back to newly-independent Algeria to teach film directing.                                                                                      | 喺 1960 年代，佢返回剛獨立嘅阿爾及利亞，教授電影導演課程。                                                 |                        99 |                      46.41 |          52.59 |
|        5 | Japanese judoka Hitoshi Saito, winner of two Olympic gold medals, has died at the age of 54.                                                                           | 曾奪得兩面奧運金牌嘅日本柔道選手齋藤仁逝世，享年 54 歲。                                                   |                       100 |                      49.33 |          50.67 |
|        8 | As well as a former Olympic and World champion, Saito was the All Japan Judo Federation training committee chairman at the time of his death.                          | 除咗曾經係奧運及世界冠軍之外，齋藤仁喺離世時亦擔任全日本柔道聯盟訓練委員會主席。                                         |                       100 |                      79.77 |          20.23 |
|       17 | A former student said that he 'used slang in class, taught dating skills in notes, and was just like the students' friend.'                                            | 一名舊學生表示：「佢會喺課堂上使用俚語，喺筆記中教授約會技巧，而且就好似學生嘅朋友一樣。」                                    |                       100 |                      87.67 |          12.33 |
|        2 | French law was changed. His activism went back to age 15 when he joined the French Resistance during World War II.                                                     | 法國法律因此被修改。佢嘅社會運動可以追溯到 15 歲嗰年，當時佢喺第二次世界大戰期間加入咗法國抵抗運動。                             |                        98 |                      93.18 |           4.82 |
|        1 | Vautier's achievements outside of directing include a hunger strike in 1973 against what he viewed as political censorship.                                            | 除咗導演工作之外，禾迪亞其他成就包括喺 1973 年進行絕食，以抗議佢認為係政治審查嘅行為。                                   |                       100 |                      96.14 |           3.86 |
|       13 | Karno is a well-known but controversial English tutor who taught under Modern Education and King's Glory who claimed to have 9,000 students at the peak of his career. | 卡諾係一位知名但具爭議性嘅英文導師，曾喺 Modern Education 同 King's Glory 任教，佢聲稱自己喺事業巔峰時期擁有 9000 名學生。 |                        99 |                      95.23 |           3.77 |
|        7 | He died in Osaka on Tuesday.                                                                                                                                           | 佢於星期二喺大阪離世。                                                                      |                       100 |                      96.68 |           3.32 |

## Mandarin vs. Cantonese comparison

|                          |   mandarin |   cantonese |
|:-------------------------|-----------:|------------:|
| flat_score               |      98.07 |       96.25 |
| severity_weighted_score  |      99.33 |       99.58 |
| semantic_similarity_x100 |      96.45 |       86.64 |