"""
Run the GLM judge (+ reference-free automatic metric) over one of your FLORES CSVs.

USAGE
    python run_pipeline.py --lang mandarin --n 20
    python run_pipeline.py --lang cantonese --n 20
    python run_pipeline.py --lang mandarin --n 200          # full run
    python run_pipeline.py --lang mandarin --n 20 --start 50 # rows 50-70

Start small (--n 20) to sanity-check everything works and to see how long each
sentence takes, before committing to a full 200-row run.
"""

import argparse
import os
import time

import pandas as pd
from tqdm import tqdm

from config import DATA_FILES, LANG_DISPLAY_NAME, OUTPUT_DIR, AUTO_METRIC, OLLAMA_MODEL
from judge import judge_one
from metrics import semantic_similarity


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", required=True, choices=["mandarin", "cantonese"])
    ap.add_argument("--n", type=int, default=20, help="number of rows to score")
    ap.add_argument("--start", type=int, default=0, help="starting row index")
    ap.add_argument("--model", default=OLLAMA_MODEL, help="ollama model name")
    args = ap.parse_args()

    csv_path = DATA_FILES[args.lang]
    lang_name = LANG_DISPLAY_NAME[args.lang]
    df = pd.read_csv(csv_path)
    df = df.iloc[args.start: args.start + args.n].reset_index(drop=True)

    print(f"Scoring {len(df)} rows for {args.lang} ({lang_name})")
    print(f"Judge model: {args.model} (via local Ollama)")
    print(f"Automatic metric: {AUTO_METRIC}")

    results = []
    t0 = time.time()
    for i, row in tqdm(df.iterrows(), total=len(df)):
        src, tgt = row["src"], row["tgt"]

        try:
            judge_result = judge_one(src, tgt, lang_name, model=args.model)
        except Exception as e:  # noqa: BLE001
            print(f"[row {i}] judge failed: {e}")
            judge_result = {
                "flat_score": None, "severity_weighted_score": None,
                "num_minor": None, "num_major": None, "num_critical": None,
                "total_penalty": None, "errors_json": "[]",
            }

        try:
            sim = semantic_similarity(src, tgt)
        except Exception as e:  # noqa: BLE001
            print(f"[row {i}] metric failed: {e}")
            sim = None

        results.append({
            "row_id": args.start + i,
            "src": src,
            "tgt": tgt,
            **judge_result,
            "semantic_similarity": sim,
            "semantic_similarity_x100": None if sim is None else round(sim * 100, 2),
        })

    elapsed = time.time() - t0
    print(f"Done in {elapsed:.1f}s ({elapsed / len(df):.1f}s/row)")

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    judge_tag = args.model.replace(":", "_").replace("/", "_")
    out_path = os.path.join(OUTPUT_DIR, f"{args.lang}_{judge_tag}_judge_results.csv")
    pd.DataFrame(results).to_csv(out_path, index=False)
    print(f"Saved -> {out_path}")


if __name__ == "__main__":
    main()
