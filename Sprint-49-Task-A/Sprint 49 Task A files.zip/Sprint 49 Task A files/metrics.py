"""
Reference-free automatic metric.

Your CSVs only contain (English source, target-language translation) -- there's no
separate "reference" vs "hypothesis" translation. That means a reference-BASED metric
like BLEU/chrF++ can't be used honestly here (there's nothing distinct to compare the
translation against except itself). So we use a reference-free / quality-estimation
style metric instead, exactly like COMET-QE (a.k.a. CometKiwi) does: score the
translation directly against the source.

Default: LaBSE cross-lingual embedding cosine similarity.
  - Fully open model, no license gate, no HF login needed.
  - Works well as an adequacy proxy for 100+ languages including Cantonese, which
    CometKiwi's underlying XLM-R data barely covers.
  - Runs fine on CPU on an M3 MacBook Air.

Optional: true COMET-QE (Unbabel/wmt22-cometkiwi-da) -- see the commented-out block
below and the README for setup steps if you want to switch to it.
"""

from functools import lru_cache

_model = None


@lru_cache(maxsize=1)
def _get_model():
    global _model
    from sentence_transformers import SentenceTransformer
    _model = SentenceTransformer("sentence-transformers/LaBSE")
    return _model


def semantic_similarity(src: str, tgt: str) -> float:
    """Cosine similarity between source and translation embeddings, in [0, 1]-ish range
    (LaBSE cosine similarities for genuinely aligned translations are usually ~0.5-0.95;
    unrelated sentences usually score well below 0.4)."""
    import numpy as np
    model = _get_model()
    emb = model.encode([src, tgt], normalize_embeddings=True)
    return float(np.dot(emb[0], emb[1]))


# ---------------------------------------------------------------------------
# Optional: swap in real COMET-QE (CometKiwi) instead of LaBSE.
# Requires: `pip install unbabel-comet` and a free Hugging Face account with the
# wmt22-cometkiwi-da model's license accepted, then `huggingface-cli login`.
#
# from comet import download_model, load_from_checkpoint
# _comet_model = None
# def cometkiwi_score(src: str, tgt: str) -> float:
#     global _comet_model
#     if _comet_model is None:
#         path = download_model("Unbabel/wmt22-cometkiwi-da")
#         _comet_model = load_from_checkpoint(path)
#     data = [{"src": src, "mt": tgt}]
#     output = _comet_model.predict(data, batch_size=1, gpus=0)
#     return float(output.scores[0])
# ---------------------------------------------------------------------------
