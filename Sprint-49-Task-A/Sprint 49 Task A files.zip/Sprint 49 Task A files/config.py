"""
Central config for the MT judge pipeline.
Edit these values instead of hunting through the other files.
"""

# --- Ollama (local, free) settings ---
# This is just the DEFAULT judge model. You override it per-run with
# `python run_pipeline.py --model <name>` -- see run_pipeline.py's --model flag.
# Judge 1 (GLM):           glm4
# Judge 2 (example choice): qwen2.5:7b   (pull with `ollama pull qwen2.5:7b`)
OLLAMA_MODEL = "glm4"          # the GLM model pulled via `ollama pull glm4`
OLLAMA_HOST = "http://localhost:11434"
JUDGE_TEMPERATURE = 0            # deterministic-ish scoring
JUDGE_MAX_RETRIES = 3            # retries if the model returns broken JSON

# --- MQM-style severity weights (Freitag et al. 2021 convention) ---
SEVERITY_WEIGHTS = {
    "minor": 1,
    "major": 5,
    "critical": 25,
}

# --- Reference-free automatic metric ---
# "labse"     -> sentence-transformers/LaBSE cosine similarity (no gated model, easy install)
# "cometkiwi" -> Unbabel wmt22-cometkiwi-da (true COMET-QE, requires free HF account + license accept)
AUTO_METRIC = "labse"

# --- Data ---
DATA_FILES = {
    "mandarin": "/Users/sk/Desktop/Shruti/Vosyn/Sprint49/flores_200_eng_mandarin.csv",
    "cantonese": "/Users/sk/Desktop/Shruti/Vosyn/Sprint49/flores_200_eng_cantonese.csv",
}

LANG_DISPLAY_NAME = {
    "mandarin": "Standard Mandarin Chinese (Simplified script)",
    "cantonese": "Cantonese (Hong Kong written vernacular)",
}

OUTPUT_DIR = "/Users/sk/Desktop/Shruti/Vosyn/Sprint49/outputs/results"
