# GLM-as-judge MT evaluation (Mandarin + Cantonese)

This is judge #1 of the two you're building. It runs **GLM as a judge**, separately, on:
- your `flores_200_eng_mandarin.csv`
- your `flores_200_eng_cantonese.csv`

For each sentence pair it produces **two** judge scores plus **one** automatic metric, so
you can compare all three:

| Score | What it is |
|---|---|
| `flat_score` | GLM's plain 0-100 holistic quality rating — this is your "current" baseline |
| `severity_weighted_score` | Computed by code (not the LLM) from GLM's tagged error list, using MQM-style weights: minor=1, major=5, critical=25 point deductions from 100 |
| `semantic_similarity_x100` | A reference-free automatic metric (LaBSE cross-lingual embedding cosine similarity, 0-100 scale) — same idea as COMET-QE/CometKiwi, doesn't need a separate reference |

**Why reference-free, not chrF++?** Your CSVs only have `src` (English) and `tgt`
(the Cantonese/Mandarin translation) — there's no separate second reference translation
to compare `tgt` against. chrF++/BLEU need that second reference, so they'd be
meaningless here (or circular). COMET-QE / CometKiwi is the correctly-named metric for
this exact setup (source + one translation, no reference) — that's what's implemented,
using LaBSE similarity as the free, ungated stand-in. If you later want the actual
CometKiwi model, see the commented-out block in `metrics.py` (needs a free Hugging
Face account + accepting the model's license, `pip install unbabel-comet`).

---

## 1. One-time setup (everything below is free)

### Install Ollama (runs GLM locally, no API key, no cost)
```bash
brew install ollama
ollama serve &          # starts the local model server, leave running
ollama pull glm4        # downloads GLM-4-9B, ~5.5GB — this is the GLM judge model
```
Test it works:
```bash
ollama run glm4 "Say hello in Cantonese"
```

**RAM note (MacBook Air M3):** `glm4` (9B, Q4 quantized) needs roughly 6-8GB of
free unified memory. This is comfortable on a 16GB/24GB Air. If yours is the 8GB
config, close other apps before running, or ask me for a smaller GLM variant.

### Python environment
You said you're on Python 3.14.3. `sentence-transformers` depends on PyTorch, which
historically lags a few months behind brand-new Python releases. Try the normal path
first:
```bash
cd mt_judge_project
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```
If `sentence-transformers` (really, `torch`) fails to install on 3.14, the fastest fix
is a dedicated 3.12 environment just for this project (still 100% free):
```bash
brew install python@3.12
python3.12 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```
Everything else in this project (the judge itself) has zero dependency on the Python
version — only the LaBSE metric needs torch.

---

## 2. Run it

Always test on a small slice first — 20 rows lets you eyeball whether GLM's error
tagging looks sane before you spend 15-40 minutes on a full 200-row run.

```bash
# quick test, 20 rows each
python run_pipeline.py --lang mandarin --n 20
python run_pipeline.py --lang cantonese --n 20

# inspect
open /mnt/user-data/outputs/results/mandarin_judge_results.csv
```

Once you're happy with it, run the full FLORES-200 set (200 rows each, ~199 usable
sentence pairs):
```bash
python run_pipeline.py --lang mandarin --n 200
python run_pipeline.py --lang cantonese --n 200
```

Then analyze:
```bash
python analyze.py --lang mandarin
python analyze.py --lang cantonese
python analyze.py --lang both     # side-by-side Mandarin vs Cantonese comparison
```

---

## 3. What to expect

- **Speed:** on an M3 Air, expect roughly 5-15 seconds per sentence for the GLM judge
  call (CPU inference via Ollama), plus a fraction of a second for the LaBSE metric.
  200 rows ≈ 20-45 minutes per language. Run it in the background / overnight for the
  full set if you like.
- **`flat_score` vs `severity_weighted_score`:** expect `flat_score` to run a bit
  higher on average. Single holistic 0-100 ratings from LLM judges tend to cluster in
  the 80-95 range and under-punish factual/entity errors relative to a severity-aware
  scheme, where a *single* critical error (wrong number, reversed meaning, mistranslated
  name) can drop a sentence by 25 points outright. The gap between the two is the whole
  point of this experiment — it's evidence for whether severity weighting actually
  changes which sentences look "bad."
- **Cantonese vs Mandarin:** GLM (like most LLMs) is trained on far more Mandarin text
  than written Cantonese, so don't be surprised if Cantonese scores are noisier, or if
  GLM occasionally flags perfectly good colloquial Cantonese (e.g. `喺`, `咗`, `嘅`) as a
  "fluency" issue because it's pattern-matching to Mandarin norms. Worth spot-checking
  the `errors_json` column for this.
- **Judge vs. LaBSE metric agreement:** don't expect a strong correlation — the judge
  is scoring translation *quality* (accuracy, fluency, errors) while LaBSE similarity is
  scoring cross-lingual *semantic closeness*, which is a related but different thing. A
  weak-to-moderate positive correlation (Spearman ~0.2-0.5) is a normal, healthy result.
  What's most useful is the **disagreement table** `analyze.py` prints: rows where the
  judge says "good" but LaBSE says "not similar" (or vice versa) are exactly the cases
  worth reading by hand, since they usually reveal either a judge blind spot or a metric
  blind spot.
- **Output files** (all under `/mnt/user-data/outputs/results/`):
  - `mandarin_judge_results.csv`, `cantonese_judge_results.csv` — one row per sentence,
    every score + the raw list of tagged errors (`errors_json`)
  - `analysis_mandarin.md`, `analysis_cantonese.md`, `analysis_both.md` — the summary
    reports analyze.py generates

---

## 4. Files in this project

| File | Purpose |
|---|---|
| `config.py` | model name, severity weights, file paths — edit here first |
| `judge.py` | the GLM judge prompt + call logic + severity-weighted scoring math |
| `metrics.py` | the reference-free automatic metric (LaBSE similarity) |
| `run_pipeline.py` | main script — scores a CSV, saves results |
| `analyze.py` | compares flat vs. severity-weighted vs. automatic metric, finds disagreements |

## 5. Where judge #2 fits in

This whole project only touches `judge.py`'s prompt + `call_glm_judge` for the model
call. When you're ready to add your second judge (different model), you'll swap the
`model=` argument / endpoint in `judge.py` (e.g. point it at another Ollama model, or
another local/free API) and reuse everything else — same prompt schema, same
severity-weighting code, same analyze.py — so the two judges' outputs stay directly
comparable. Happy to build that out once you've validated this one.
