"""
LLM-as-judge module.

Calls a local GLM model (served by Ollama) to evaluate one English -> target-language
translation. Asks for TWO things in one call:

  1. flat_score       - a plain 0-100 holistic quality score (this is your "current"
                         baseline scoring approach)
  2. errors[]          - a list of specific errors, each tagged minor / major / critical

We then compute the severity-weighted score ourselves, deterministically, in Python,
using MQM-style weights (minor=1, major=5, critical=25; see config.py). We do NOT trust
the model to do that arithmetic -- LLMs are unreliable at that, so the code does it.
"""

import json
import re
import requests

from config import (
    OLLAMA_MODEL, OLLAMA_HOST, JUDGE_TEMPERATURE, JUDGE_MAX_RETRIES,
    SEVERITY_WEIGHTS,
)

JUDGE_PROMPT = """You are an expert professional translation quality evaluator for \
English -> {lang} translation, following MQM (Multidimensional Quality Metrics) principles.

Source (English):
{src}

Translation ({lang}):
{tgt}

Evaluate the translation and respond with ONLY a JSON object (no markdown fences, no \
extra commentary) in this exact schema:

{{
  "flat_score": <integer 0-100, your overall holistic quality judgment>,
  "errors": [
    {{
      "span": "<exact text from the translation containing the error, or empty string if the error is an omission>",
      "category": "<one of: accuracy_mistranslation, accuracy_omission, accuracy_addition, entity_number, terminology, fluency_grammar, style_register, other>",
      "severity": "<one of: minor, major, critical>",
      "explanation": "<one short sentence>"
    }}
  ]
}}

Severity definitions:
- critical: changes or reverses the meaning, introduces false information, mistranslates \
a number/name/date/entity, or would seriously mislead a reader.
- major: a real inaccuracy or omission a bilingual reader would notice that meaningfully \
affects meaning or completeness, but the message is still roughly recoverable.
- minor: awkward phrasing, minor grammar issues, register mismatches, or small word-choice \
issues that don't change meaning.

If there are no errors, return an empty errors list and a flat_score close to 100.
Respond with ONLY the JSON object, nothing else.
"""


def _extract_json(text: str) -> dict:
    """Ollama's format='json' usually returns clean JSON, but we defensively strip
    markdown fences / stray text just in case the model wraps it."""
    text = text.strip()
    text = re.sub(r"^```(json)?", "", text).strip()
    text = re.sub(r"```$", "", text).strip()
    # If there's leading/trailing junk, grab the outermost {...}
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        text = match.group(0)
    return json.loads(text)


def call_judge(src: str, tgt: str, lang: str, model: str = OLLAMA_MODEL) -> dict:
    """Calls whatever Ollama-served model `model` points at (GLM, or your second judge
    model). Returns the parsed judge dict. Raises RuntimeError after JUDGE_MAX_RETRIES
    failed parse attempts."""
    prompt = JUDGE_PROMPT.format(src=src, tgt=tgt, lang=lang)

    last_err = None
    for attempt in range(1, JUDGE_MAX_RETRIES + 1):
        resp = requests.post(
            f"{OLLAMA_HOST}/api/chat",
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "format": "json",
                "stream": False,
                "options": {"temperature": JUDGE_TEMPERATURE},
            },
            timeout=180,
        )
        resp.raise_for_status()
        content = resp.json()["message"]["content"]
        try:
            parsed = _extract_json(content)
            # basic schema sanity check
            assert "flat_score" in parsed
            assert "errors" in parsed
            return parsed
        except Exception as e:  # noqa: BLE001
            last_err = e
            continue

    raise RuntimeError(f"GLM judge returned unparseable output after "
                        f"{JUDGE_MAX_RETRIES} attempts: {last_err}")


def severity_weighted_score(errors: list) -> dict:
    """Deterministically compute the severity-weighted score from the judge's error list."""
    counts = {"minor": 0, "major": 0, "critical": 0}
    penalty = 0
    for err in errors:
        sev = err.get("severity", "minor")
        if sev not in SEVERITY_WEIGHTS:
            sev = "minor"
        counts[sev] += 1
        penalty += SEVERITY_WEIGHTS[sev]

    score = max(0, 100 - penalty)
    return {
        "severity_weighted_score": score,
        "num_minor": counts["minor"],
        "num_major": counts["major"],
        "num_critical": counts["critical"],
        "total_penalty": penalty,
    }


def judge_one(src: str, tgt: str, lang: str, model: str = OLLAMA_MODEL) -> dict:
    """Full judge pass on one sentence pair: calls the judge model, computes both scores."""
    raw = call_judge(src, tgt, lang, model=model)
    sev = severity_weighted_score(raw.get("errors", []))
    return {
        "judge_model": model,
        "flat_score": raw.get("flat_score"),
        **sev,
        "errors_json": json.dumps(raw.get("errors", []), ensure_ascii=False),
    }
