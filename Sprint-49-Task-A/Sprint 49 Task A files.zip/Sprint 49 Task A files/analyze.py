"""
Analyze results produced by run_pipeline.py.

USAGE
    python analyze.py --lang mandarin
    python analyze.py --lang cantonese
    python analyze.py --lang both        # side-by-side comparison

Produces, printed to console AND saved as a markdown report:
  - summary stats for flat_score vs severity_weighted_score
  - error-type / severity breakdown
  - correlation (Spearman) between judge scores and the automatic metric
  - a table of the biggest judge-vs-metric disagreements, for manual inspection
"""

import argparse
import os

import pandas as pd
from scipy.stats import spearmanr, pearsonr

from config import OUTPUT_DIR


def load(lang, judge_tag):
    path = os.path.join(OUTPUT_DIR, f"{lang}_{judge_tag}_judge_results.csv")
    df = pd.read_csv(path)
    return df.dropna(subset=["flat_score", "severity_weighted_score", "semantic_similarity"])


def report_for_lang(lang, df, out_lines):
    out_lines.append(f"\n## {lang.title()} (n={len(df)})\n")

    out_lines.append("**Score distributions**\n")
    desc = df[["flat_score", "severity_weighted_score", "semantic_similarity_x100"]].describe()
    out_lines.append(desc.round(2).to_markdown())

    out_lines.append("\n**Error counts (severity breakdown)**\n")
    err_summary = df[["num_minor", "num_major", "num_critical"]].sum()
    out_lines.append(err_summary.to_frame("total_errors_found").to_markdown())

    out_lines.append("\n**Flat vs. severity-weighted score**\n")
    diff = df["flat_score"] - df["severity_weighted_score"]
    out_lines.append(f"- Mean(flat - severity_weighted) = {diff.mean():.2f} "
                      f"(positive => flat scoring is more lenient than severity-weighted)")
    r_fs, _ = pearsonr(df["flat_score"], df["severity_weighted_score"])
    out_lines.append(f"- Pearson correlation(flat, severity_weighted) = {r_fs:.3f}")

    out_lines.append("\n**Judge vs. automatic metric (LaBSE similarity x100) agreement**\n")
    for score_col in ["flat_score", "severity_weighted_score"]:
        rho, p = spearmanr(df[score_col], df["semantic_similarity_x100"])
        out_lines.append(f"- Spearman({score_col}, semantic_similarity) = {rho:.3f} (p={p:.3g})")

    out_lines.append("\n**Biggest judge-vs-metric disagreements** "
                      "(severity_weighted_score vs semantic_similarity_x100, both 0-100 scale)\n")
    df = df.copy()
    df["disagreement"] = (df["severity_weighted_score"] - df["semantic_similarity_x100"]).abs()
    top = df.sort_values("disagreement", ascending=False).head(8)
    cols = ["row_id", "src", "tgt", "severity_weighted_score",
            "semantic_similarity_x100", "disagreement"]
    out_lines.append(top[cols].round(2).to_markdown(index=False))

    return out_lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", required=True, choices=["mandarin", "cantonese", "both"])
    ap.add_argument("--judge", required=True,
                     help="judge tag matching the --model you used in run_pipeline.py, "
                          "e.g. glm4 or qwen2.5_7b")
    args = ap.parse_args()

    out_lines = [f"# Judge Analysis Report ({args.judge})"]

    if args.lang == "both":
        dfs = {}
        for lang in ["mandarin", "cantonese"]:
            path = os.path.join(OUTPUT_DIR, f"{lang}_{args.judge}_judge_results.csv")
            if not os.path.exists(path):
                print(f"Skipping {lang}: no results file yet ({path})")
                continue
            dfs[lang] = load(lang, args.judge)
            out_lines = report_for_lang(lang, dfs[lang], out_lines)

        if len(dfs) == 2:
            out_lines.append("\n## Mandarin vs. Cantonese comparison\n")
            comp = pd.DataFrame({
                lang: dfs[lang][["flat_score", "severity_weighted_score",
                                  "semantic_similarity_x100"]].mean()
                for lang in dfs
            })
            out_lines.append(comp.round(2).to_markdown())
    else:
        df = load(args.lang, args.judge)
        out_lines = report_for_lang(args.lang, df, out_lines)

    report = "\n".join(str(x) for x in out_lines)
    print(report)

    report_path = os.path.join(OUTPUT_DIR, f"analysis_{args.lang}_{args.judge}.md")
    with open(report_path, "w") as f:
        f.write(report)
    print(f"\nSaved report -> {report_path}")


if __name__ == "__main__":
    main()
